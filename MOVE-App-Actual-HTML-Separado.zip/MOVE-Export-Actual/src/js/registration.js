// Demonstration-only access enrollment. No emails or authentication requests are sent.
let registration = {
  role: "corporate",
  step: "email",
  email: "",
  code: "",
  expires: 0,
  tries: 0,
  issuedAt: 0,
  verified: false,
};
const corporateWhitelist = [
  { email: "ana.perez@gmail.com", name: "Ana Pérez", role: "agent" },
  { email: "carlos.mejia@outlook.com", name: "Carlos Mejía", role: "agent" },
  { email: "supervisor.demo@gmail.com", name: "María Rodríguez", role: "supervisor" },
];
let demoAccounts = [];
try {
  const saved = JSON.parse(localStorage.getItem("move-registered-accounts") || "[]");
  if (Array.isArray(saved)) demoAccounts = saved;
} catch {}
const loginWithRegistration = loginView;
loginView = function () {
  return loginWithRegistration().replace(
    "</form>",
    htmlTemplate("registration/registration/login-view.html"),
  );
};
function startRegistration(role) {
  registration = {
    role: role === "driver" ? "driver" : "corporate",
    step: "email",
    email: "",
    code: "",
    expires: 0,
    tries: 0,
    issuedAt: 0,
    verified: false,
  };
  access.logged = false;
  accountOpen = false;
  saveDriver();
  navigate("register");
  render();
}
function setRegistrationRole(role) {
  if (!["corporate", "driver"].includes(role)) return;
  registration = {
    ...registration,
    role,
    step: "email",
    email: "",
    code: "",
    verified: false,
    expires: 0,
    tries: 0,
  };
  render();
}
function signupSteps() {
  const active =
    registration.step === "email"
      ? 0
      : registration.step === "otp"
        ? 1
        : registration.step === "complete"
          ? 3
          : 2;
  const labels = ["Correo", "Verificación", "Contraseña"];
  return htmlTemplate("registration/registration/signup-steps.html");
}
function registrationView() {
  return htmlTemplate("registration/registration/registration-view.html");
}
function useWhitelistEmail(email) {
  document.getElementById("signupEmail").value = email;
  document.getElementById("signupEmail").focus();
}
function signupError(message) {
  const error = document.getElementById("registrationError");
  if (error) error.textContent = t(message);
  return false;
}
function issueRegistrationOTP() {
  const random = new Uint32Array(1);
  crypto.getRandomValues(random);
  registration.code = String(100000 + (random[0] % 900000));
  registration.expires = Date.now() + 5 * 60000;
  registration.issuedAt = Date.now();
  registration.tries = 0;
  registration.verified = false;
  registration.step = "otp";
}
function submitRegistrationEmail(email) {
  email = String(email).trim().toLowerCase();
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return signupError("Introduce un correo válido.");
  if (demoAccounts.some((a) => a.email === email))
    return signupError("Este correo ya tiene una cuenta en este navegador. Inicia sesión.");
  if (registration.role === "corporate" && !corporateWhitelist.some((r) => r.email === email))
    return signupError(
      "Tu correo no está autorizado. Contacta a tu empresa para que lo agregue a la lista.",
    );
  registration.email = email;
  issueRegistrationOTP();
  render();
  return true;
}
function verifyRegistrationOTP(code) {
  if (registration.step !== "otp") return false;
  if (Date.now() > registration.expires)
    return signupError("El código venció. Solicita uno nuevo.");
  if (registration.tries >= 5)
    return signupError("Se agotaron los intentos. Solicita un nuevo código.");
  registration.tries++;
  if (String(code).trim() !== registration.code)
    return signupError("Código incorrecto. Revisa los 6 dígitos.");
  registration.verified = true;
  registration.step = "password";
  registration.code = "";
  render();
  return true;
}
function resendRegistrationOTP() {
  if (Date.now() - registration.issuedAt < 30000)
    return signupError("Espera 30 segundos antes de solicitar otro código.");
  issueRegistrationOTP();
  render();
  toast(t("Nuevo código de demostración generado."));
}
function backToRegistrationEmail() {
  registration.step = "email";
  registration.code = "";
  registration.verified = false;
  render();
}
function updatePasswordChecklist(password) {
  document.getElementById("passwordLength")?.classList.toggle("passed", password.length >= 8);
  document
    .getElementById("passwordMix")
    ?.classList.toggle("passed", /[A-Za-z]/.test(password) && /[0-9]/.test(password));
}
async function passwordDigest(password, salt) {
  const bytes = new TextEncoder().encode(salt + ":" + password);
  return Array.from(new Uint8Array(await crypto.subtle.digest("SHA-256", bytes)), (b) =>
    b.toString(16).padStart(2, "0"),
  ).join("");
}
async function finishRegistration(data) {
  if (registration.step !== "password") return false;
  const allowed = corporateWhitelist.find((r) => r.email === registration.email);
  if (!registration.verified || (registration.role === "corporate" && !allowed))
    return signupError("Verifica primero tu correo autorizado.");
  const password = String(data.password || "");
  if (
    password.length < 8 ||
    password.length > 128 ||
    !/[A-Za-z]/.test(password) ||
    !/[0-9]/.test(password)
  )
    return signupError("La contraseña debe tener al menos 8 caracteres, una letra y un número.");
  if (password !== data.confirm) return signupError("Las contraseñas no coinciden.");
  const name = registration.role === "corporate" ? allowed.name : String(data.name || "").trim();
  if (name.length < 2) return signupError("Introduce tu nombre completo.");
  if (demoAccounts.some((a) => a.email === registration.email))
    return signupError("Este correo ya tiene una cuenta en este navegador. Inicia sesión.");
  const salt = crypto.randomUUID();
  const hash = await passwordDigest(password, salt);
  const account = {
    email: registration.email,
    name,
    role: registration.role,
    corporateRole: allowed?.role || "agent",
    tenant: allowed?.tenant || "tp",
    salt,
    hash,
  };
  const next = [...demoAccounts, account];
  try {
    localStorage.setItem("move-registered-accounts", JSON.stringify(next));
  } catch {
    return signupError("No pudimos guardar la cuenta en este navegador. Inténtalo de nuevo.");
  }
  demoAccounts = next;
  registration.step = "complete";
  render();
  return true;
}
function goToRegisteredLogin() {
  access.role = registration.role;
  access.logged = false;
  const account = demoAccounts.find((a) => a.email === registration.email);
  access.corporateRole = account?.corporateRole || "agent";
  saveDriver();
  navigate("login");
  render();
  document.getElementById("loginId").value = registration.email;
  document.getElementById("loginPassword").value = "";
  document.getElementById("loginPassword").focus();
}
const loginBeforeRegistration = bindLogin;
bindLogin = function () {
  loginBeforeRegistration();
  const form = document.getElementById("sharedLogin");
  form?.addEventListener(
    "submit",
    async (e) => {
      const email = document.getElementById("loginId").value.trim().toLowerCase();
      const account = demoAccounts.find((a) => a.email === email);
      if (!account) {
        delete access.name;
        access.tenant = "tp";
        return;
      }
      e.preventDefault();
      e.stopImmediatePropagation();
      if (account.role !== access.role) {
        toast(t("Selecciona el tipo de acceso de tu cuenta."));
        return;
      }
      const password = document.getElementById("loginPassword").value;
      const match = await passwordDigest(password, account.salt);
      if (match !== account.hash) {
        toast(t("Correo o contraseña incorrectos."));
        return;
      }
      access.tenant = account.tenant || "tp";
      access.role = account.role;
      access.corporateRole = account.corporateRole;
      access.name = account.name;
      access.logged = true;
      if (access.role === "driver") {
        if (driver.profile.email !== account.email) {
          driver.onboarded = false;
          driver.profile = { name: account.name, email: account.email };
          driver.photos = {};
          onboardDraft = { ...driver.profile };
          onboardStep = 1;
        }
      }
      saveDriver();
      navigate(
        access.role === "driver"
          ? driver.onboarded
            ? "driver-home"
            : "driver-onboarding"
          : "home",
      );
      render();
    },
    true,
  );
};
function bindRegistration() {
  document.getElementById("registrationForm")?.addEventListener("submit", async (e) => {
    e.preventDefault();
    const form = new FormData(e.target);
    if (registration.step === "email") submitRegistrationEmail(form.get("email"));
    else if (registration.step === "otp") verifyRegistrationOTP(form.get("otp"));
    else if (registration.step === "password") {
      const button = e.target.querySelector("button[type=submit]");
      button.disabled = true;
      try {
        await finishRegistration(Object.fromEntries(form));
      } catch {
        signupError("No pudimos crear la cuenta. Inténtalo de nuevo.");
      } finally {
        button.disabled = false;
      }
    }
  });
}

const demoLoginBeforeRegistration = loginDemo;
loginDemo = function () {
  delete access.name;
  access.tenant = "tp";
  demoLoginBeforeRegistration();
};
