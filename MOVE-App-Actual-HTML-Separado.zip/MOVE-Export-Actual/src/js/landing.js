// MOVE's public product presentation lives in the same PWA as both workspaces.
let landingRole = "employee";
const demoNumbers = { people: 1200, vehicles: 42, occupancy: 91, savings: 18 };
function scrollLanding(id) {
  document.getElementById(id)?.scrollIntoView({
    behavior: window.matchMedia?.("(prefers-reduced-motion: reduce)").matches ? "auto" : "smooth",
  });
}
function enterMove() {
  navigate(access.logged ? (access.role === "driver" ? "driver-home" : "home") : "login");
  render();
}
function landingView() {
  return htmlTemplate("landing/landing/landing-view.html");
}
function roleStory() {
  return landingRole === "employee"
    ? htmlTemplate("landing/landing/role-story.html")
    : htmlTemplate("landing/landing/role-story-02.html");
}
function phonePreview() {
  return landingRole === "employee"
    ? htmlTemplate("landing/landing/phone-preview.html")
    : htmlTemplate("landing/landing/phone-preview-02.html");
}
function selectLandingRole(role) {
  if (!["employee", "driver"].includes(role)) return;
  landingRole = role;
  const scroll = window.scrollY;
  render();
  window.scrollTo(0, scroll);
  document.getElementById(role === "employee" ? "employeeTab" : "driverTab")?.focus();
}
function calculateSeats() {
  const get = (id) => Number(document.getElementById(id).value);
  const vehicles = get("calcVehicles"),
    seats = get("calcSeats"),
    cost = get("calcCost"),
    days = get("calcDays"),
    occupancy = get("calcOccupancy");
  document.getElementById("occupancyValue").textContent = occupancy + "%";
  if (
    !Number.isFinite(vehicles + seats + cost + days + occupancy) ||
    vehicles < 1 ||
    vehicles > 10000 ||
    seats < 1 ||
    seats > 100 ||
    cost < 0 ||
    cost > 1000000 ||
    days < 1 ||
    days > 31
  ) {
    document.getElementById("emptyCost").textContent = "Revisa los datos";
    document.getElementById("emptySeats").textContent =
      "Completa valores válidos en todos los campos.";
    return;
  }
  const empty = 1 - occupancy / 100;
  document.getElementById("emptyCost").textContent =
    "RD$" + Math.round(vehicles * cost * days * empty).toLocaleString("en-US");
  document.getElementById("emptySeats").textContent =
    Math.round(vehicles * seats * empty) + " asientos vacíos por día · Estimación en RD$";
}
const renderWorkspace = render;
render = function () {
  const requested = location.hash.slice(1);
  const isLanding = !requested || requested === "landing";
  document.body.classList.toggle("landing-screen", isLanding);
  document.getElementById("landingMenu")?.remove();
  if (!isLanding) {
    renderWorkspace();
    return;
  }
  stopScanner();
  routeAbort?.abort();
  page = "landing";
  document.body.classList.remove("login-screen");
  document.querySelector(".bottom-nav").hidden = true;
  app.innerHTML = landingView();
  const menu = document.createElement("nav");
  menu.id = "landingMenu";
  menu.className = "landing-menu";
  menu.setAttribute("aria-label", "Navegación de la presentación");
  menu.innerHTML = htmlTemplate("landing/landing/render.html");
  document.querySelector("header").append(menu);
  window.scrollTo(0, 0);
};
render();
