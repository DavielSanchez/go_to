/* MOVE administrative UI. All records, telemetry and permissions below are demo data. */
const opsAccounts = [
  {
    id: "site-admin",
    email: "admin.tp.demo@gmail.com",
    name: "María Rodríguez",
    role: "tenant-admin",
    tenants: ["tp-churchill"],
    company: "tp",
  },
  {
    id: "coordinator",
    email: "coordinador.tp.demo@gmail.com",
    name: "Laura Méndez",
    role: "coordinator",
    tenants: ["tp-churchill"],
    company: "tp",
  },
  {
    id: "company-admin",
    email: "country.tp.demo@gmail.com",
    aliases: ["empresa.tp.demo@gmail.com"],
    name: "Carolina Pérez",
    role: "company-admin",
    tenants: ["tp-churchill", "tp-sambil", "tp-santiago"],
    company: "tp",
  },
  {
    id: "platform",
    email: "move.admin.demo@gmail.com",
    name: "Daviel Sánchez",
    role: "platform",
    tenants: [
      "tp-churchill",
      "tp-sambil",
      "tp-santiago",
      "tp-bogota",
      "alorica-sd",
      "concentrix-sd",
      "trueshore-sd",
    ],
    company: "move",
  },
  {
    id: "alorica-admin",
    email: "admin.alorica.demo@gmail.com",
    name: "Ana Torres",
    role: "tenant-admin",
    tenants: ["alorica-sd"],
    company: "alorica",
  },
];
const opsRoleNames = {
  "tenant-admin": "Administrador",
  "company-admin": "Country Admin",
  coordinator: "Coordinación de transporte",
  platform: "Administrador de MOVE",
};
const opsStatusNames = {
  active: "En viaje",
  boarding: "Abordaje",
  paused: "Pausado",
  completed: "Finalizado",
  draft: "Pendiente",
  confirmed: "Confirmado",
};
const opsDrivers = [
  "Ángel Ramírez",
  "Luis Santana",
  "Pedro Castillo",
  "Miguel Ortiz",
  "Elena Sánchez",
  "Carlos Suárez",
  "Andrés Molina",
  "Rafael Díaz",
  "Diana Pérez",
  "Patricia Gil",
  "Fernando Cruz",
  "Rosa Medina",
  "Héctor Núñez",
  "Julia Vargas",
  "Mario Reyes",
  "Sara Santos",
];
const opsTemplateNames = [
  "shell",
  "overview",
  "operation",
  "plans",
  "statistics",
  "configuration",
  "audit",
  "platform",
];
const opsTemplates = {};
let opsTemplatesReady = false;
let opsTemplateError = false;
let opsImpersonation = null;
let opsSelected = [];
let opsSelectedOwner = "";
let opsDrawer = null;
let opsTripFilter = "all";
let opsAuditSearch = "";
let opsAuditImpersonated = false;
let opsConfigTenant = "";
let opsSmallAcknowledged = false;
let opsLive = true;
let opsFocusAfterRender = false;

function opsShiftDate(date, amount) {
  const parsed = new Date(date + "T12:00:00Z");
  parsed.setUTCDate(parsed.getUTCDate() + amount);
  return parsed.toISOString().slice(0, 10);
}
function opsSeed() {
  const journey = opsShiftDate(today(), -1);
  const definitions = [
    ["tp-churchill", "TP · Churchill", "tp", "DO", "Santo Domingo"],
    ["tp-sambil", "TP · Sambil", "tp", "DO", "Santo Domingo"],
    ["tp-santiago", "TP · Santiago", "tp", "DO", "Santiago"],
    ["tp-bogota", "TP · Bogotá", "tp", "CO", "Bogotá"],
    ["alorica-sd", "Alorica · Santo Domingo", "alorica", "DO", "Santo Domingo"],
    ["concentrix-sd", "Concentrix · Santo Domingo", "concentrix", "DO", "Santo Domingo"],
    ["trueshore-sd", "TrueShore · Santo Domingo", "trueshore", "DO", "Santo Domingo"],
  ];
  const tenantRecords = definitions.map(([id, name, company, country, city], i) => ({
    id,
    name,
    company,
    country,
    timezone: country === "CO" ? "America/Bogota" : "America/Santo_Domingo",
    utcOffset: country === "CO" ? "-05:00" : "-04:00",
    city,
    demand: 84 + i * 17,
    eligibleCount: 116 + i * 21,
    config: {
      eligible: "21:00",
      cutoff: "20:00",
      gap: 2,
      grace: 10,
      windows: ["21:30", "22:30", "23:30", "00:30"],
      origin: name,
    },
    occupancy: 88 + (i % 5),
    iex: company === "tp",
    lastSync: today() + "T00:00:00-04:00",
  }));
  const trips = [];
  const plans = [];
  tenantRecords.forEach((tenant, i) => {
    const planId = "PLAN-" + (100 + i);
    plans.push({
      id: planId,
      tenant: tenant.id,
      journey,
      window: "00:30",
      status: i % 3 === 0 ? "confirmed" : "draft",
      demand: i % 3 === 0 ? 20 : 28 + i * 2,
      exceptionCount: 3 + i,
      gap: 2,
      routes: [
        { id: "07", name: "Los Girasoles" },
        { id: "04", name: "Pantoja" },
      ],
    });
    const tripDate = today();
    for (let j = 0; j < 3; j++) {
      const id = "TR-" + (1040 + i * 10 + j);
      const status = j === 0 ? "active" : j === 1 ? "boarding" : "completed";
      const passengers = Array.from({ length: j === 1 ? 8 : 12 }, (_, k) => ({
        id: id + "-P" + k,
        name: [
          "Ana Pérez",
          "Carlos Mejía",
          "Laura Díaz",
          "Miguel Santos",
          "Sofía Rodríguez",
          "Juan Reyes",
          "Diana Gómez",
          "Pedro Núñez",
          "Elena Cruz",
          "Luis Vega",
          "María Gil",
          "José Torres",
        ][k],
        boarded: j === 1 ? k < 6 : true,
        absent: false,
        stop: k % 3,
      }));
      trips.push({
        id,
        tenant: tenant.id,
        journey,
        date: i % 3 === 0 && j < 2 ? tripDate : journey,
        window: i % 3 === 0 && j < 2 ? "00:30" : "23:30",
        route: j === 2 || (i % 3 === 0 && j === 1) ? "04" : "07",
        routeName: j === 2 || (i % 3 === 0 && j === 1) ? "Pantoja" : "Los Girasoles",
        status,
        driver: j === 1 && i % 2 === 0 ? null : opsDrivers[(i * 2 + j) % opsDrivers.length],
        unit: String(12 + i * 3 + j),
        capacity: 16,
        grace: tenant.config.grace,
        passengers,
        progress: j === 0 ? 43 + i * 4 : j === 2 ? 100 : 0,
        eta: j === 0 ? "01:08" : j === 2 ? "23:55" : "00:18",
        incidents: [],
      });
    }
  });
  return {
    version: 1,
    date: journey,
    clock: today() + "T00:42:00-04:00",
    lastUpdate: new Date().toISOString(),
    tenants: tenantRecords,
    plans,
    trips,
    audit: [
      {
        id: "AUD-DEMO-001",
        timestamp: journey + "T20:07:31-04:00",
        actor: {
          id: "platform",
          name: "Daviel Sánchez",
          email: "move.admin.demo@gmail.com",
        },
        effective: {
          id: "site-admin",
          name: "María Rodríguez",
          email: "admin.tp.demo@gmail.com",
          role: "tenant-admin",
        },
        action: "configuration.updated",
        entity: "tp-churchill",
        tenants: ["tp-churchill"],
        before: { gap: 1 },
        after: { gap: 2 },
        reason: "Ejemplo: ajuste de margen de asientos, ticket DEMO-184",
        impersonation: "IMP-DEMO-001",
        session: "DEMO-SESSION",
        source: "Web · demostración",
        timezone: "America/Santo_Domingo",
        demo: true,
      },
    ],
  };
}
let opsModel = opsSeed();
try {
  const saved = JSON.parse(sessionStorage.getItem("move-operations-v1") || "null");
  if (
    saved?.version === 1 &&
    Array.isArray(saved.tenants) &&
    Array.isArray(saved.trips) &&
    Array.isArray(saved.audit)
  )
    opsModel = saved;
} catch {}
const opsSessionId = crypto.randomUUID();
function saveOps() {
  try {
    sessionStorage.setItem("move-operations-v1", JSON.stringify(opsModel));
  } catch {
    toast("No pudimos guardar los cambios de demostración.");
  }
}
function opsActor() {
  return opsAccounts.find((account) => account.id === access.adminAccount) || null;
}
function opsPrincipal() {
  return opsImpersonation
    ? opsAccounts.find((account) => account.id === opsImpersonation.target)
    : opsActor();
}
function isOpsUser() {
  return access.logged && !!opsActor();
}
function opsSessionValid() {
  return isOpsUser() && (!opsImpersonation || Date.now() < opsImpersonation.expires);
}
function canOpsManage() {
  return opsSessionValid() && ["tenant-admin", "company-admin"].includes(opsPrincipal()?.role);
}
function canOpsCoordinate() {
  return (
    opsSessionValid() &&
    ["tenant-admin", "company-admin", "coordinator"].includes(opsPrincipal()?.role)
  );
}
function canOpsPlatform() {
  return opsActor()?.role === "platform" && !opsImpersonation;
}
function opsAllowed() {
  return opsPrincipal()?.tenants || [];
}
function opsTenant(id) {
  return opsModel.tenants.find((tenant) => tenant.id === id);
}
function opsScope() {
  return opsSelected.filter((id) => opsAllowed().includes(id));
}
function opsInScope(tenant) {
  return opsScope().includes(tenant);
}
function opsSnapshot(value) {
  return JSON.parse(JSON.stringify(value));
}
function recordOps(action, entity, tenantIds, before, after, reason) {
  const actor = opsActor();
  const effective = opsPrincipal();
  if (!actor || !effective) return;
  opsModel.audit.unshift({
    id: crypto.randomUUID(),
    timestamp: new Date().toISOString(),
    actor: { id: actor.id, name: actor.name, email: actor.email },
    effective: {
      id: effective.id,
      name: effective.name,
      email: effective.email,
      role: effective.role,
    },
    action,
    entity,
    tenants: [...tenantIds],
    before: opsSnapshot(before),
    after: opsSnapshot(after),
    reason,
    impersonation: opsImpersonation?.id || null,
    impersonationContext: opsImpersonation ? opsSnapshot(opsImpersonation) : null,
    authorizedTenants: [...effective.tenants],
    selectedTenants: [...opsScope()],
    tenantTimezones: tenantIds.map((id) => ({
      tenant: id,
      timezone: opsTenant(id)?.timezone || "America/Santo_Domingo",
    })),
    session: opsSessionId,
    source: "Web · demostración",
    timezone: "America/Santo_Domingo",
    demo: true,
  });
  saveOps();
}
function opsTemplate(name, values) {
  return (opsTemplates[name] || "").replace(/\{\{([a-zA-Z]+)\}\}/g, (_, key) => values[key] ?? "");
}
function opsText(value) {
  return escapeHTML(String(value ?? ""));
}
function opsPill(status, text = opsStatusNames[status]) {
  return htmlTemplate("administration/admin-dashboard/ops-pill.html");
}
function opsMetric(label, value, note, symbol) {
  return htmlTemplate("administration/admin-dashboard/ops-metric.html");
}
function opsTrips() {
  return opsModel.trips.filter(
    (trip) =>
      opsInScope(trip.tenant) &&
      (trip.journey === opsModel.date || ["active", "paused"].includes(trip.status)),
  );
}
function opsPlans() {
  return opsModel.plans.filter((plan) => opsInScope(plan.tenant) && plan.journey === opsModel.date);
}
function opsBoarded(trip) {
  return trip.passengers.filter((passenger) => passenger.boarded).length;
}
function opsDemands() {
  return opsModel.tenants
    .filter((tenant) => opsInScope(tenant.id))
    .reduce((total, tenant) => total + tenant.demand, 0);
}
function opsStats() {
  const trips = opsTrips();
  return {
    active: trips.filter((trip) => trip.status === "active").length,
    boarded: trips.reduce((total, trip) => total + opsBoarded(trip), 0),
    missing: trips.filter((trip) => trip.status === "boarding" && !trip.driver).length,
    draft: opsPlans().filter((plan) => plan.status === "draft").length,
    seats: trips.reduce((total, trip) => total + trip.capacity, 0),
  };
}
function opsMetrics(kind = "operation") {
  const summary = opsStats();
  if (kind === "stats")
    return (
      opsMetric("Ocupación", opsOccupancy() + "%", "Promedio ponderado de la demo", "bus") +
      opsMetric(
        "Pasajeros abordados",
        summary.boarded,
        "Trips de la jornada y viajes activos",
        "user",
      ) +
      opsMetric(
        "Viajes completados",
        opsTrips().filter((trip) => trip.status === "completed").length,
        "Jornada seleccionada",
        "check",
      ) +
      opsMetric(
        "Ausencias",
        opsTrips().reduce((n, trip) => n + trip.passengers.filter((p) => p.absent).length, 0),
        "Registradas en esta operación",
        "clock",
      )
    );
  return (
    opsMetric(
      "Demanda confirmada",
      opsDemands(),
      opsScope().length + " tenants seleccionados",
      "user",
    ) +
    opsMetric(
      "Pasajeros abordados",
      summary.boarded,
      "Asignados al trip, no al conductor",
      "ticket",
    ) +
    opsMetric("Viajes en curso", summary.active, "Incluye jornadas anteriores activas", "bus") +
    opsMetric(
      kind === "overview" && canOpsManage() ? "Planes por confirmar" : "Trips sin conductor",
      kind === "overview" && canOpsManage() ? summary.draft : summary.missing,
      "Necesitan atención",
      "info",
    )
  );
}
function opsScopeControl() {
  const allowed = opsModel.tenants.filter((tenant) => opsAllowed().includes(tenant.id));
  const summary =
    opsScope().length === 1
      ? opsTenant(opsScope()[0]).name
      : opsScope().length + " tenants seleccionados";
  return htmlTemplate("administration/admin-dashboard/ops-scope-control.html");
}
function toggleOpsTenant(id, checked) {
  if (!opsAllowed().includes(id)) return false;
  const before = [...opsSelected];
  const next = checked
    ? [...new Set([...opsSelected, id])]
    : opsSelected.filter((value) => value !== id);
  if (!next.length) {
    toast("Selecciona al menos un tenant.");
    render();
    return false;
  }
  opsSelected = next;
  if (!opsInScope(opsConfigTenant)) opsConfigTenant = next[0];
  opsDrawer = null;
  recordOps("scope.changed", "workspace", next, before, next, "Cambio de alcance de visualización");
  render();
  return true;
}
function selectAllOpsTenants() {
  const before = [...opsSelected];
  opsSelected = [...opsAllowed()];
  opsDrawer = null;
  recordOps(
    "scope.changed",
    "workspace",
    opsSelected,
    before,
    opsSelected,
    "Vista consolidada de tenants autorizados",
  );
  render();
}
function focusOpsTenant(id) {
  if (!opsAllowed().includes(id)) return;
  opsSelected = [id];
  opsDrawer = null;
  navigate("ops-operation");
  render();
}
function setOpsDate(value) {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(value)) return;
  opsModel.date = value;
  opsDrawer = null;
  saveOps();
  render();
}
function opsWindows() {
  return ["21:30", "22:30", "23:30", "00:30"]
    .map((window) => {
      const matching = opsTrips().filter((trip) => trip.window === window);
      const plans = opsPlans().filter((plan) => plan.window === window);
      const aboard = matching.reduce((sum, trip) => sum + opsBoarded(trip), 0);
      const seats = matching.reduce((sum, trip) => sum + trip.capacity, 0);
      const status = plans.some((plan) => plan.status === "draft")
        ? "draft"
        : matching.some((trip) => trip.status === "active")
          ? "active"
          : matching.some((trip) => trip.status === "boarding")
            ? "boarding"
            : "completed";
      return htmlTemplate("administration/admin-dashboard/ops-windows.html");
    })
    .join("");
}
function opsOverviewView() {
  const attention = [];
  opsTrips()
    .filter((trip) => trip.status === "boarding" && !trip.driver)
    .forEach((trip) =>
      attention.push(htmlTemplate("administration/admin-dashboard/ops-overview-view.html")),
    );
  opsPlans()
    .filter((plan) => plan.status === "draft")
    .forEach((plan) =>
      attention.push(htmlTemplate("administration/admin-dashboard/ops-overview-view-02.html")),
    );
  const tenants = opsModel.tenants
    .filter((tenant) => opsInScope(tenant.id))
    .map((tenant) => {
      const trips = opsTrips().filter((trip) => trip.tenant === tenant.id);
      const draft = opsPlans().some((plan) => plan.tenant === tenant.id && plan.status === "draft");
      return htmlTemplate("administration/admin-dashboard/tenants.html");
    })
    .join("");
  return opsTemplate("overview", {
    metrics: opsMetrics("overview"),
    windows: opsWindows(),
    attention: attention.join("") || htmlTemplate("administration/admin-dashboard/attention.html"),
    attentionCount: attention.length,
    tenants,
    tenantCount: opsScope().length,
  });
}
function opsTripCard(trip) {
  const previous = trip.journey !== today() && ["active", "paused"].includes(trip.status);
  return htmlTemplate("administration/admin-dashboard/ops-trip-card.html");
}
function setOpsTripFilter(value) {
  if (!["all", "boarding", "active", "paused", "completed"].includes(value)) return;
  opsTripFilter = value;
  render();
}
function opsOperationView() {
  const trips = opsTrips().filter(
    (trip) => opsTripFilter === "all" || trip.status === opsTripFilter,
  );
  const filters = [
    ["all", "Todos"],
    ["boarding", "Abordaje"],
    ["active", "En viaje"],
    ["paused", "Pausados"],
    ["completed", "Finalizados"],
  ]
    .map(([value, label]) => htmlTemplate("administration/admin-dashboard/filters.html"))
    .join("");
  return opsTemplate("operation", {
    metrics: opsMetrics(),
    filters,
    trips: trips.map(opsTripCard).join(""),
    empty: trips.length ? "" : htmlTemplate("administration/admin-dashboard/empty.html"),
  });
}
function opsPlannedVehicles(plan) {
  return plan.routes.reduce(
    (sum, _, index) =>
      sum +
      Math.ceil(
        (Math.floor(plan.demand / plan.routes.length) +
          (index === 0 ? plan.demand % plan.routes.length : 0)) /
          (16 - plan.gap),
      ),
    0,
  );
}
function opsPlansView() {
  const plans = opsPlans();
  const cards = plans
    .map((plan) => htmlTemplate("administration/admin-dashboard/cards.html"))
    .join("");
  return opsTemplate("plans", {
    planNotice: canOpsManage()
      ? "La confirmación del plan corresponde a administración. Revisa la demanda y las rutas antes de generar los trips."
      : "Consulta operativa. Solo administración del tenant puede confirmar los planes.",
    plans: cards || htmlTemplate("administration/admin-dashboard/plans.html"),
  });
}
function confirmOpsPlan(id, reason) {
  const plan = opsModel.plans.find((value) => value.id === id);
  if (
    !canOpsManage() ||
    !plan ||
    !opsInScope(plan.tenant) ||
    plan.status !== "draft" ||
    String(reason).trim().length < 8
  )
    return false;
  const before = opsSnapshot(plan);
  const generated = [];
  plan.routes.forEach((route, routeIndex) => {
    let remaining =
      Math.floor(plan.demand / plan.routes.length) +
      (routeIndex === 0 ? plan.demand % plan.routes.length : 0);
    let index = 0;
    while (remaining > 0) {
      const passengers = Math.min(remaining, 16 - plan.gap);
      const tripId = `${plan.id}-R${route.id}-T${++index}`;
      opsModel.trips.push({
        id: tripId,
        tenant: plan.tenant,
        journey: plan.journey,
        date: plan.window === "00:30" ? opsShiftDate(plan.journey, 1) : plan.journey,
        window: plan.window,
        route: route.id,
        routeName: route.name,
        status: "boarding",
        driver: null,
        unit: String(30 + generated.length),
        capacity: 16,
        grace: opsTenant(plan.tenant).config.grace,
        passengers: Array.from({ length: passengers }, (_, n) => ({
          id: tripId + "-P" + n,
          name: "Pasajero demo " + (n + 1),
          boarded: false,
          absent: false,
          stop: n % 3,
        })),
        progress: 0,
        eta: "01:18",
        incidents: [],
      });
      generated.push(tripId);
      remaining -= passengers;
    }
  });
  plan.status = "confirmed";
  plan.confirmedAt = new Date().toISOString();
  recordOps(
    "plan.confirmed",
    plan.id,
    [plan.tenant],
    before,
    { ...plan, generatedTrips: generated },
    reason,
  );
  opsDrawer = null;
  render();
  toast("Plan confirmado. Los trips y QR de ruta ya están disponibles.");
  return true;
}
function submitOpsPlan(event, id) {
  event.preventDefault();
  const reason = new FormData(event.target).get("reason");
  if (!confirmOpsPlan(id, reason))
    document.getElementById("opsActionError").textContent =
      "No se pudo confirmar. Revisa el permiso y escribe un motivo de al menos 8 caracteres.";
}
function opsOccupancy() {
  const selected = opsModel.tenants.filter((tenant) => opsInScope(tenant.id));
  const demand = selected.reduce((sum, tenant) => sum + tenant.demand, 0);
  return demand
    ? Math.round(
        selected.reduce((sum, tenant) => sum + tenant.occupancy * tenant.demand, 0) / demand,
      )
    : 0;
}
function opsStatisticsView() {
  const occupancy = opsOccupancy();
  const chart = [-7, -3, -5, -2, -1, -4, 0]
    .map((offset, index) => htmlTemplate("administration/admin-dashboard/chart.html"))
    .join("");
  const comparison = opsModel.tenants
    .filter((tenant) => opsInScope(tenant.id))
    .map((tenant) => htmlTemplate("administration/admin-dashboard/comparison.html"))
    .join("");
  return opsTemplate("statistics", {
    metrics: opsMetrics("stats"),
    occupancy,
    chart,
    comparison,
    insights: htmlTemplate("administration/admin-dashboard/insights.html"),
  });
}
function setConfigTenant(id) {
  if (!canOpsManage() || !opsInScope(id)) return;
  opsConfigTenant = id;
  render();
}
function opsConfigurationView() {
  if (!opsInScope(opsConfigTenant)) opsConfigTenant = opsScope()[0];
  const tenant = opsTenant(opsConfigTenant);
  const config = tenant.config;
  const tenantOptions = opsModel.tenants
    .filter((value) => opsInScope(value.id))
    .map((value) => htmlTemplate("administration/admin-dashboard/tenant-options.html"))
    .join("");
  const integration = htmlTemplate("administration/admin-dashboard/integration.html");
  const windowInputs =
    htmlTemplate("administration/admin-dashboard/window-inputs.html") +
    ["21:30", "22:30", "23:30", "00:30"]
      .map((value) => htmlTemplate("administration/admin-dashboard/window-inputs-02.html"))
      .join("") +
    "</div>";
  return opsTemplate("configuration", {
    tenantOptions,
    integration,
    summary: htmlTemplate("administration/admin-dashboard/summary.html"),
    eligible: config.eligible,
    cutoff: config.cutoff,
    gap: config.gap,
    grace: config.grace,
    origin: opsText(config.origin),
    windowInputs,
  });
}
function saveOpsConfig(event) {
  event.preventDefault();
  const tenant = opsTenant(opsConfigTenant);
  if (!canOpsManage() || !tenant || !opsInScope(tenant.id)) return false;
  const data = new FormData(event.target);
  const next = {
    eligible: String(data.get("eligible")),
    cutoff: String(data.get("cutoff")),
    gap: Number(data.get("gap")),
    grace: Number(data.get("grace")),
    windows: data.getAll("windows"),
    origin: String(data.get("origin") || "").trim(),
  };
  const reason = String(data.get("reason") || "").trim();
  if (
    !Number.isFinite(next.gap) ||
    !Number.isFinite(next.grace) ||
    !next.windows.length ||
    next.gap < 0 ||
    next.gap > 10 ||
    next.grace < 0 ||
    next.grace > 60 ||
    !/^\d\d:\d\d$/.test(next.eligible) ||
    !/^\d\d:\d\d$/.test(next.cutoff) ||
    !next.origin ||
    reason.length < 8
  ) {
    document.getElementById("opsConfigError").textContent =
      "Revisa las reglas, selecciona una ventana y explica el cambio en al menos 8 caracteres.";
    return false;
  }
  const before = opsSnapshot(tenant.config);
  tenant.config = next;
  recordOps("configuration.updated", tenant.id, [tenant.id], before, next, reason);
  render();
  toast("Configuración guardada y registrada en auditoría.");
  return true;
}
function opsDateTime(value) {
  return new Date(value).toLocaleString(interfaceLanguage === "en" ? "en-US" : "es-DO", {
    timeZone: "America/Santo_Domingo",
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
    hour12: false,
  });
}
function opsVisibleAudit() {
  return opsModel.audit.filter(
    (entry) =>
      (entry.tenants.some((id) => opsInScope(id)) || (!entry.tenants.length && canOpsPlatform())) &&
      (!opsAuditImpersonated || entry.impersonation) &&
      (!opsAuditSearch ||
        JSON.stringify(entry).toLowerCase().includes(opsAuditSearch.toLowerCase())),
  );
}
function opsAuditRows() {
  return (
    opsVisibleAudit()
      .map((entry) => htmlTemplate("administration/admin-dashboard/ops-audit-rows.html"))
      .join("") || htmlTemplate("administration/admin-dashboard/ops-audit-rows-03.html")
  );
}
function opsAuditView() {
  return opsTemplate("audit", {
    rows: opsAuditRows(),
    count: opsVisibleAudit().length,
    search: opsText(opsAuditSearch),
    checked: opsAuditImpersonated ? "checked" : "",
  });
}
function filterOpsAudit(value) {
  opsAuditSearch = value;
  document.getElementById("auditRows").innerHTML = opsAuditRows();
  document.getElementById("auditCount").textContent = opsVisibleAudit().length + " registros";
}
function setAuditImpersonated(value) {
  opsAuditImpersonated = value;
  render();
}
function exportOpsAudit() {
  const visible = opsVisibleAudit();
  const blob = new Blob([JSON.stringify(visible, null, 2)], {
    type: "application/json",
  });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = "MOVE-auditoria-demo.json";
  link.click();
  URL.revokeObjectURL(url);
  recordOps(
    "audit.exported",
    "audit",
    opsScope(),
    { records: visible.length },
    { format: "JSON" },
    "Exportación del historial visible",
  );
  render();
}
function opsPlatformView() {
  const companies = ["tp", "alorica", "trueshore", "concentrix"]
    .map((key) => {
      const company = tenants[key];
      const count = opsModel.tenants.filter((tenant) => tenant.company === key).length;
      return htmlTemplate("administration/admin-dashboard/companies.html");
    })
    .join("");
  const targets = opsAccounts
    .filter((account) => account.role !== "platform")
    .map((account) => htmlTemplate("administration/admin-dashboard/targets.html"))
    .join("");
  const users = opsAccounts
    .filter((account) => account.role !== "platform")
    .map((account) => htmlTemplate("administration/admin-dashboard/users.html"))
    .join("");
  return opsTemplate("platform", {
    metrics:
      opsMetric("Empresas", 4, "Clientes de demostración", "home") +
      opsMetric("Tenants", opsModel.tenants.length, "Aislados por site", "pin") +
      opsMetric("Países", 2, "Alcances DO / CO de demostración", "bus") +
      opsMetric(
        "Registros de auditoría",
        opsModel.audit.length,
        "Actores reales y efectivos",
        "shield",
      ),
    companies,
    targets,
    users,
  });
}
function selectImpersonationUser(id) {
  const select = document.getElementById("impersonateUser");
  if (select) {
    select.value = id;
    document.getElementById("impersonateReason").focus();
  }
}
function startOpsImpersonation(event) {
  event.preventDefault();
  const form = new FormData(event.target);
  return beginOpsImpersonation(String(form.get("target")), String(form.get("reason") || ""));
}
function beginOpsImpersonation(targetId, reason) {
  const target = opsAccounts.find(
    (account) => account.id === targetId && account.role !== "platform",
  );
  if (!canOpsPlatform() || !target || reason.trim().length < 8) {
    const error = document.getElementById("impersonateError");
    if (error)
      error.textContent =
        "Selecciona un usuario administrativo y explica el motivo en al menos 8 caracteres.";
    return false;
  }
  opsImpersonation = {
    actor: opsActor().id,
    id: crypto.randomUUID(),
    target: target.id,
    reason: reason.trim(),
    started: Date.now(),
    expires: Date.now() + 15 * 60000,
  };
  sessionStorage.setItem("move-impersonation", JSON.stringify(opsImpersonation));
  opsSelected = [...target.tenants];
  opsSelectedOwner = target.id;
  opsConfigTenant = target.tenants[0];
  opsDrawer = null;
  recordOps(
    "impersonation.started",
    target.id,
    target.tenants,
    { actor: opsActor().id },
    {
      target: target.id,
      expires: new Date(opsImpersonation.expires).toISOString(),
    },
    reason,
  );
  navigate("ops-overview");
  render();
  return true;
}
function endOpsImpersonation(reason = "Cierre voluntario de impersonación") {
  if (!opsImpersonation) return;
  const before = opsSnapshot(opsImpersonation);
  recordOps(
    "impersonation.ended",
    before.target,
    opsPrincipal().tenants,
    before,
    { endedAt: new Date().toISOString() },
    reason,
  );
  sessionStorage.removeItem("move-impersonation");
  opsImpersonation = null;
  opsSelected = [...opsActor().tenants];
  opsSelectedOwner = opsActor().id;
  opsDrawer = null;
  navigate("ops-platform");
  render();
}
function openOpsTrip(id) {
  const trip = opsModel.trips.find((value) => value.id === id);
  if (!trip || !opsInScope(trip.tenant)) return;
  opsDrawer = { type: "trip", id };
  opsFocusAfterRender = true;
  render();
}
function openOpsPlan(id) {
  const plan = opsModel.plans.find((value) => value.id === id);
  if (!plan || !opsInScope(plan.tenant) || !canOpsManage()) return;
  opsDrawer = { type: "plan", id };
  opsFocusAfterRender = true;
  render();
}
function openOpsRoute(planId, routeId) {
  const plan = opsModel.plans.find((value) => value.id === planId);
  if (!plan || !opsInScope(plan.tenant) || plan.status !== "confirmed") return;
  opsDrawer = { type: "route", id: planId, route: routeId };
  opsFocusAfterRender = true;
  render();
}
function openOpsAudit(id) {
  if (!opsVisibleAudit().some((entry) => entry.id === id)) return;
  opsDrawer = { type: "audit", id };
  opsFocusAfterRender = true;
  render();
}
function closeOpsDrawer() {
  opsDrawer = null;
  render();
}
function opsActionForm(trip) {
  if (!canOpsCoordinate() || trip.status === "completed")
    return htmlTemplate("administration/admin-dashboard/ops-action-form.html");
  const buttons =
    trip.status === "boarding"
      ? htmlTemplate("administration/admin-dashboard/buttons.html") +
        trip.id +
        htmlTemplate("administration/admin-dashboard/buttons-02.html") +
        trip.id +
        htmlTemplate("administration/admin-dashboard/buttons-03.html") +
        trip.id +
        "','start')\">Iniciar viaje</button>"
      : htmlTemplate("administration/admin-dashboard/buttons-04.html");
  const available = opsDrivers.filter(
    (name) =>
      !opsModel.trips.some(
        (other) => other.id !== trip.id && other.driver === name && other.status !== "completed",
      ),
  );
  return htmlTemplate("administration/admin-dashboard/ops-action-form-02.html");
}
function performOpsTripAction(id, action) {
  const reason = document.getElementById("tripReason")?.value || "";
  const driverName = document.getElementById("tripDriver")?.value || "";
  const result = changeOpsTrip(id, action, reason, driverName);
  if (!result.ok) document.getElementById("opsActionError").textContent = result.error;
}
function changeOpsTrip(id, action, reason, driverName = "") {
  if (opsPrincipal()?.role === "coordinator" && action === "start")
    return { ok: false, error: "El viaje lo inicia el conductor." };
  const trip = opsModel.trips.find((value) => value.id === id);
  if (!canOpsCoordinate() || !trip || !opsInScope(trip.tenant))
    return {
      ok: false,
      error: "La acción está fuera de tu alcance autorizado.",
    };
  if (reason.trim().length < 8)
    return { ok: false, error: "Explica el motivo en al menos 8 caracteres." };
  const before = opsSnapshot(trip);
  if (action === "detach" && trip.status === "boarding" && trip.driver) trip.driver = null;
  else if (
    action === "assign" &&
    trip.status === "boarding" &&
    opsDrivers.includes(driverName) &&
    !opsModel.trips.some(
      (other) => other.id !== id && other.driver === driverName && other.status !== "completed",
    )
  )
    trip.driver = driverName;
  else if (action === "absent" && trip.status === "boarding")
    trip.passengers.forEach((passenger) => {
      if (!passenger.boarded) passenger.absent = true;
    });
  else if (action === "pause" && trip.status === "active") {
    trip.status = "paused";
    trip.incidents.push({ at: new Date().toISOString(), reason });
  } else if (action === "resume" && trip.status === "paused") trip.status = "active";
  else if (action === "start" && trip.status === "boarding") {
    const departure = new Date(
      trip.date + "T" + trip.window + ":00" + (opsTenant(trip.tenant).utcOffset || "-04:00"),
    ).getTime();
    const graceEnd = departure + (trip.grace ?? opsTenant(trip.tenant).config.grace) * 60000;
    if (
      !trip.driver ||
      trip.passengers.some((passenger) => !passenger.boarded && !passenger.absent) ||
      new Date(opsModel.clock).getTime() < graceEnd
    )
      return {
        ok: false,
        error: "Falta conductor, cerrar el abordaje o superar la salida y el tiempo de gracia.",
      };
    trip.status = "active";
    trip.progress = 1;
  } else
    return {
      ok: false,
      error: "La acción no está disponible para el estado actual o ese conductor está ocupado.",
    };
  recordOps("trip." + action, trip.id, [trip.tenant], before, trip, reason);
  render();
  toast("Decisión aplicada. El registro de auditoría está disponible.");
  return { ok: true };
}
function opsDrawerHTML() {
  if (!opsDrawer) return "";
  let title = "";
  let content = "";
  if (opsDrawer.type === "trip") {
    const trip = opsModel.trips.find((value) => value.id === opsDrawer.id);
    if (!trip || !opsInScope(trip.tenant)) return "";
    title = trip.id + " · " + trip.routeName;
    const stops = [
      opsTenant(trip.tenant).config.origin,
      "Entrada · " + trip.routeName,
      "Parada intermedia",
      "Destino final",
    ];
    content = htmlTemplate("administration/admin-dashboard/content.html");
  } else if (opsDrawer.type === "plan") {
    const plan = opsModel.plans.find((value) => value.id === opsDrawer.id);
    if (!plan || !canOpsManage() || !opsInScope(plan.tenant)) return "";
    title = "Confirmar " + plan.id;
    content = htmlTemplate("administration/admin-dashboard/content-06.html");
  } else if (opsDrawer.type === "route") {
    const plan = opsModel.plans.find((value) => value.id === opsDrawer.id);
    if (!plan || !opsInScope(plan.tenant) || plan.status !== "confirmed") return "";
    const route = plan.routes.find((value) => value.id === opsDrawer.route);
    if (!route) return "";
    const payload = {
      type: "MOVE-ROUTE-DEMO",
      tenant: plan.tenant,
      routeId: plan.id + "-R" + route.id,
      route: route.id,
      window: plan.window,
      journey: plan.journey,
      date: plan.window === "00:30" ? opsShiftDate(plan.journey, 1) : plan.journey,
    };
    const qr = qrcode(0, "M");
    qr.addData(JSON.stringify(payload));
    qr.make();
    const trips = opsModel.trips.filter(
      (trip) =>
        trip.tenant === plan.tenant &&
        trip.journey === plan.journey &&
        trip.route === route.id &&
        trip.window === plan.window,
    );
    title = "QR · Ruta " + route.id;
    content = htmlTemplate("administration/admin-dashboard/content-07.html");
  } else {
    const entry = opsVisibleAudit().find((value) => value.id === opsDrawer.id);
    if (!entry) return "";
    title = "Detalle de auditoría";
    content = htmlTemplate("administration/admin-dashboard/content-09.html");
  }
  return htmlTemplate("administration/admin-dashboard/ops-drawer-html.html");
}
function opsMobileWarning() {
  if (opsSmallAcknowledged) return "";
  return htmlTemplate("administration/admin-dashboard/ops-mobile-warning.html");
}
function acknowledgeOpsSmallScreen() {
  opsSmallAcknowledged = true;
  render();
}
function opsNavigation() {
  let items = [
    ["ops-overview", "home", "Resumen"],
    ["ops-operation", "bus", "Operación en vivo"],
    ["ops-plans", "ticket", "Planes de transporte"],
  ];
  if (canOpsManage() || canOpsPlatform()) items.push(["ops-statistics", "clock", "Estadísticas"]);
  if (canOpsManage()) items.push(["ops-configuration", "shield", "Configuración"]);
  if (canOpsPlatform()) items.unshift(["ops-platform", "shield", "Plataforma / acceso"]);
  items.push(["ops-audit", "user", "Auditoría"]);
  return items;
}
function renderOpsPortal() {
  if (!window.moveManagementReady) {
    app.innerHTML = htmlTemplate("administration/admin-dashboard/render-ops-portal.html");
    return;
  }
  if (opsImpersonation && Date.now() >= opsImpersonation.expires) {
    endOpsImpersonation("Vencimiento automático de la sesión de 15 minutos");
    return;
  }
  const principal = opsPrincipal();
  if (!principal) return;
  if (
    opsSelectedOwner !== principal.id ||
    !opsSelected.some((id) => principal.tenants.includes(id))
  ) {
    opsSelectedOwner = principal.id;
    opsSelected = [...principal.tenants];
  }
  opsSelected = opsSelected.filter((id) => principal.tenants.includes(id));
  if (!opsTemplatesReady) {
    document.body.classList.add("admin-mode");
    app.innerHTML = htmlTemplate("administration/admin-dashboard/render-ops-portal-02.html");
    return;
  }
  document.body.classList.remove(
    "landing-screen",
    "login-screen",
    "registration-screen",
    "brand-loading",
  );
  document.body.classList.add("admin-mode");
  document.getElementById("landingMenu")?.remove();
  document.querySelector(".bottom-nav").hidden = true;
  stopScanner();
  routeAbort?.abort();
  const navigation = opsNavigation();
  const requested = location.hash.slice(1);
  page = navigation.some(([id]) => id === requested)
    ? requested
    : principal.role === "platform"
      ? "ops-platform"
      : "ops-overview";
  const labels = {
    ...managementLabels,
    "ops-overview": [
      "CONTROL DE TRANSPORTE",
      "Tu operación, conectada.",
      "Prioridades y despacho de los tenants que tienes a cargo.",
    ],
    "ops-operation": [
      "DESPACHO Y SEGUIMIENTO",
      "Operación en vivo",
      "Sigue los trips y resuelve situaciones sin perder el contexto.",
    ],
    "ops-plans": [
      "PLANIFICACIÓN",
      "Planes de transporte",
      "Confirmaciones y excepciones aprobadas, distribuidas por ruta.",
    ],
    "ops-statistics": [
      "RESULTADOS",
      "Estadísticas de operación",
      "Compara ocupación y servicio entre los tenants seleccionados.",
    ],
    "ops-configuration": [
      "ADMINISTRACIÓN DEL TENANT",
      "Reglas de tu operación",
      "Configuración aplicada por tenant, con trazabilidad de cambios.",
    ],
    "ops-audit": [
      "TRAZABILIDAD",
      "Auditoría de acciones",
      "Quién actuó, en nombre de quién y qué cambió.",
    ],
    "ops-platform": [
      "ADMINISTRACIÓN MOVE",
      "Una plataforma. Varias empresas.",
      "Supervisa tenants y asiste a usuarios administrativos con acceso visible.",
    ],
  };
  const [eyebrow, title, subtitle] = labels[page];
  const views = {
    ...managementViews,
    "ops-overview": opsOverviewView,
    "ops-operation": opsOperationView,
    "ops-plans": opsPlansView,
    "ops-statistics": opsStatisticsView,
    "ops-configuration": opsConfigurationView,
    "ops-audit": opsAuditView,
    "ops-platform": opsPlatformView,
  };
  const impersonation = opsImpersonation
    ? htmlTemplate("administration/admin-dashboard/impersonation.html")
    : "";
  const hasOvernight = opsTrips().some(
    (trip) => trip.journey < today() && ["active", "paused"].includes(trip.status),
  );
  const notice =
    hasOvernight && ["ops-overview", "ops-operation"].includes(page)
      ? htmlTemplate("administration/admin-dashboard/notice.html")
      : "";
  app.innerHTML = opsTemplate("shell", {
    collaboration: principal.company === "move" ? moveBrand() : tenantBrand(principal.company),
    brandLabel: principal.company === "move" ? "MOVE" : tenants[principal.company].name + " × MOVE",
    company:
      principal.company === "move"
        ? htmlTemplate("administration/admin-dashboard/company.html")
        : htmlTemplate("administration/admin-dashboard/company-02.html"),
    role: opsText(opsRoleNames[principal.role]),
    initials: principal.name
      .split(" ")
      .map((value) => value[0])
      .slice(0, 2)
      .join(""),
    name: opsText(principal.name),
    email: principal.email,
    navigation: navigation
      .map(([id, symbol, label]) => htmlTemplate("administration/admin-dashboard/navigation.html"))
      .join(""),
    impersonation,
    breadcrumb:
      principal.role === "platform"
        ? "MOVE / Plataforma"
        : `${tenants[principal.company].name} / ${opsScope().length} tenants`,
    themeIcon: icon(theme === "dark" ? "sun" : "moon"),
    auditIcon: icon("shield"),
    languages: htmlTemplate("administration/admin-dashboard/languages.html"),
    eyebrow,
    title,
    subtitle,
    actions:
      page === "ops-operation"
        ? htmlTemplate("administration/admin-dashboard/actions.html")
        : canOpsManage() && page === "ops-overview"
          ? htmlTemplate("administration/admin-dashboard/actions-02.html")
          : "",
    scope: opsScopeControl(),
    date: opsModel.date,
    clock: "00:42",
    notice,
    content: views[page](),
    drawer: opsDrawerHTML(),
    smallScreen: opsMobileWarning(),
    updated: opsDateTime(opsModel.lastUpdate),
    mobileNav: managementMobileNavigation(),
  });
  managementAfterRender();
  applyTenantPalette(principal.company === "move" ? "tp" : principal.company);
  translateInterface();
  if (opsFocusAfterRender) {
    opsFocusAfterRender = false;
    document.querySelector(".ops-drawer button")?.focus();
  }
}
function toggleOpsLive() {
  opsLive = !opsLive;
  render();
}
function advanceOpsSimulation() {
  if (!isOpsUser()) return;
  opsTrips()
    .filter((trip) => trip.status === "active")
    .forEach((trip) => {
      trip.progress = Math.min(98, trip.progress + 2);
    });
  opsModel.lastUpdate = new Date().toISOString();
  saveOps();
  if (
    opsDrawer ||
    document.activeElement?.matches("input,textarea,select") ||
    document.querySelector(".ops-scope[open]")
  ) {
    opsTrips().forEach((trip) => {
      document
        .querySelector(`[data-ops-progress="${trip.id}"]`)
        ?.style.setProperty("width", trip.progress + "%");
      const label = document.querySelector(`[data-ops-progress-label="${trip.id}"]`);
      if (label) label.textContent = `${trip.progress}% · ETA ${trip.eta}`;
    });
    document.querySelectorAll("[data-ops-stop]").forEach((stop) => {
      const trip = opsTrips().find((t) => t.id === stop.dataset.opsStop);
      if (trip) stop.classList.toggle("done", trip.progress >= Number(stop.dataset.stopIndex) * 33);
    });
    const updated = document.getElementById("opsUpdated");
    if (updated) updated.textContent = opsDateTime(opsModel.lastUpdate);
  } else render();
}
setInterval(() => {
  if (!isOpsUser() || !document.body.classList.contains("admin-mode")) return;
  if (opsImpersonation && Date.now() >= opsImpersonation.expires) {
    endOpsImpersonation("Vencimiento automático de la sesión de 15 minutos");
    return;
  }
  if (opsLive && ["ops-overview", "ops-operation"].includes(page)) advanceOpsSimulation();
}, 15000);

const opsOriginalLoginView = loginView;
loginView = function () {
  return opsOriginalLoginView().replace(
    "</form>",
    htmlTemplate("administration/admin-dashboard/login-view.html"),
  );
};
function fillOpsLogin(id) {
  const account = opsAccounts.find((value) => value.id === id);
  if (!account) return;
  access.role = "corporate";
  access.corporateRole = "agent";
  render();
  document.getElementById("loginId").value = account.email;
  document.getElementById("loginPassword").value = "MoveDemo123";
}
const opsOriginalBindLogin = bindLogin;
bindLogin = function () {
  opsOriginalBindLogin();
  document.getElementById("sharedLogin")?.addEventListener(
    "submit",
    (event) => {
      const email = document.getElementById("loginId").value.trim().toLowerCase();
      const account = opsAccounts.find(
        (value) => value.email === email || value.aliases?.includes(email),
      );
      if (!account) {
        delete access.adminAccount;
        return;
      }
      event.preventDefault();
      event.stopImmediatePropagation();
      if (
        access.role !== "corporate" ||
        document.getElementById("loginPassword").value !== "MoveDemo123"
      ) {
        toast(t("Correo o contraseña incorrectos."));
        return;
      }
      access.logged = true;
      access.adminAccount = account.id;
      access.name = account.name;
      access.tenant = account.company === "move" ? "tp" : account.company;
      opsSelectedOwner = "";
      opsImpersonation = null;
      opsDrawer = null;
      splashDone = account.role === "platform";
      saveDriver();
      navigate(account.role === "platform" ? "ops-platform" : "ops-overview");
      render();
    },
    true,
  );
};
const opsOriginalLoginDemo = loginDemo;
loginDemo = function () {
  delete access.adminAccount;
  opsOriginalLoginDemo();
};
const opsOriginalLogout = logoutMove;
logoutMove = function () {
  if (isOpsUser()) {
    if (opsImpersonation) endOpsImpersonation("Cierre de sesión del actor real");
    recordOps(
      "session.ended",
      opsActor().id,
      opsAllowed(),
      {},
      { loggedOut: true },
      "Cierre de sesión",
    );
  }
  sessionStorage.removeItem("move-impersonation");
  delete access.adminAccount;
  opsImpersonation = null;
  opsSelectedOwner = "";
  opsDrawer = null;
  document.body.classList.remove("admin-mode");
  opsOriginalLogout();
};
const opsOriginalRender = render;
render = function () {
  if (
    isOpsUser() &&
    location.hash !== "#login" &&
    location.hash !== "#register" &&
    location.hash !== "#landing"
  ) {
    if (!splashDone) {
      document.body.classList.remove("admin-mode");
      showTenantSplash();
      return;
    }
    if (splashActive) return;
    renderOpsPortal();
  } else {
    document.body.classList.remove("admin-mode");
    opsOriginalRender();
  }
};
async function loadOpsTemplates() {
  opsTemplateError = false;
  try {
    const templates = await Promise.all(
      opsTemplateNames.map(async (name) => {
        const response = await fetch(`admin/${name}.html?v=17`);
        if (!response.ok) throw new Error(name);
        return [name, await response.text()];
      }),
    );
    templates.forEach(([name, html]) => {
      opsTemplates[name] = html;
    });
    opsTemplatesReady = true;
  } catch {
    opsTemplateError = true;
  }
  render();
}
Object.assign(enTranslations, {
  Resumen: "Overview",
  "Operación en vivo": "Live operations",
  "Planes de transporte": "Transport plans",
  Estadísticas: "Statistics",
  Configuración: "Configuration",
  Auditoría: "Audit",
  "Administrador del tenant": "Tenant administrator",
  "Administración · varios tenants": "Multi-tenant administration",
  "Coordinación de transporte": "Transport coordination",
  "Administrador de MOVE": "MOVE administrator",
  "Plataforma / acceso": "Platform / access",
  "CONTROL DE TRANSPORTE": "TRANSPORT CONTROL",
  "Tu operación, conectada.": "Your operations, connected.",
  "Prioridades y despacho de los tenants que tienes a cargo.":
    "Priorities and dispatch across your assigned tenants.",
  "DESPACHO Y SEGUIMIENTO": "DISPATCH AND TRACKING",
  "Sigue los trips y resuelve situaciones sin perder el contexto.":
    "Track trips and resolve situations with full context.",
  PLANIFICACIÓN: "PLANNING",
  "Confirmaciones y excepciones aprobadas, distribuidas por ruta.":
    "Confirmations and approved exceptions, distributed by route.",
  RESULTADOS: "RESULTS",
  "Estadísticas de operación": "Operations statistics",
  "Compara ocupación y servicio entre los tenants seleccionados.":
    "Compare occupancy and service across selected tenants.",
  "ADMINISTRACIÓN DEL TENANT": "TENANT ADMINISTRATION",
  "Reglas de tu operación": "Your operating rules",
  "Configuración aplicada por tenant, con trazabilidad de cambios.":
    "Tenant settings with a full change history.",
  TRAZABILIDAD: "TRACEABILITY",
  "Auditoría de acciones": "Action audit",
  "Quién actuó, en nombre de quién y qué cambió.": "Who acted, on whose behalf, and what changed.",
  "ADMINISTRACIÓN MOVE": "MOVE ADMINISTRATION",
  "Una plataforma. Varias empresas.": "One platform. Multiple companies.",
  "Supervisa tenants y asiste a usuarios administrativos con acceso visible.":
    "Oversee tenants and assist administrators with visible access.",
  "Jornada operativa": "Operating day",
  "Reloj de demostración · RD": "Demo clock · Dominican Republic",
  "En vivo · Demo": "Live · Demo",
  DESPACHO: "DISPATCH",
  "Próximas ventanas": "Upcoming departures",
  "Abrir operación": "Open operations",
  PRIORIDADES: "PRIORITIES",
  "Necesita atención": "Needs attention",
  "ALCANCE OPERATIVO": "OPERATIONAL SCOPE",
  "Tus tenants, en una vista": "Your tenants at a glance",
  Demanda: "Demand",
  Abordados: "Boarded",
  "Viajes activos": "Active trips",
  Operación: "Operations",
  "Control de viajes": "Trip control",
  "Ruta, trip y conductor conservan identidades distintas.":
    "Routes, trips and drivers retain separate identities.",
  "Demanda confirmada": "Confirmed demand",
  "Pasajeros abordados": "Boarded passengers",
  "Asignados al trip, no al conductor": "Assigned to the trip, not the driver",
  "Viajes en curso": "Ongoing trips",
  "Incluye jornadas anteriores activas": "Includes active trips from previous operating days",
  "Planes por confirmar": "Plans awaiting confirmation",
  "Trips sin conductor": "Trips without a driver",
  "Necesitan atención": "Need attention",
  "Alcance autorizado · selección múltiple": "Authorized scope · multiple selection",
  "Seleccionar todos los autorizados": "Select all authorized tenants",
  "Revisar planes": "Review plans",
  "Revisar y confirmar plan": "Review and confirm plan",
  "Confirmar y generar trips": "Confirm and create trips",
  "Confirmaciones + excepciones": "Confirmations + exceptions",
  "Vehículos propuestos": "Proposed vehicles",
  "Asientos libres por vehículo": "Available seats per vehicle",
  "QR compartido entre trips": "Shared route QR across trips",
  "Trips por generar": "Trips pending creation",
  "Pendiente de confirmar por administración del tenant.":
    "Awaiting confirmation by tenant administration.",
  "Plan confirmado · trips generados · QR disponibles":
    "Plan confirmed · trips created · QR codes available",
  "Tenant que vas a configurar": "Tenant to configure",
  "Reglas de transporte": "Transport rules",
  "Salida elegible desde": "Eligible departure from",
  "Cutoff del plan": "Plan cutoff",
  "Tiempo de gracia · minutos": "Grace period · minutes",
  "Ventanas disponibles": "Available departure windows",
  "Nombre del punto de origen": "Origin name",
  "Motivo del cambio": "Reason for the change",
  "Guardar configuración": "Save settings",
  Ocupación: "Occupancy",
  Ausencias: "No-shows",
  "Jornada seleccionada": "Selected operating day",
  EMPRESAS: "COMPANIES",
  "Operaciones conectadas": "Connected operations",
  "ASISTENCIA CON TRAZABILIDAD": "TRACEABLE SUPPORT",
  "Impersonar administración": "Impersonate administrators",
  "La sesión conservará tu identidad real. Solo podrás hacer lo que permite el usuario seleccionado.":
    "Your real identity is retained. Actions follow the selected user's permissions.",
  "Usuario y rol": "User and role",
  "Motivo de la intervención": "Reason for intervention",
  "Ticket o necesidad que justifica el acceso.": "Ticket or reason justifying access.",
  "Sesión de 15 minutos · Inicio, acciones y cierre auditados":
    "15-minute session · Start, actions and end audited",
  "Iniciar impersonación": "Start impersonation",
  "Finalizar impersonación": "End impersonation",
  "Usuarios administrativos de demostración": "Demo administrative users",
  Usuario: "User",
  Rol: "Role",
  "Tenants autorizados": "Authorized tenants",
  "Actor real": "Real actor",
  "Usuario efectivo": "Effective user",
  Acción: "Action",
  Antes: "Before",
  Después: "After",
  Detalles: "Details",
  "Detalle de auditoría": "Audit details",
  "Sesión impersonada": "Impersonated session",
  "Sesión directa": "Direct session",
  "Decisión operativa": "Operational decision",
  "Motivo de la acción": "Reason for action",
  "Desvincular conductor": "Detach driver",
  "Marcar pendientes ausentes": "Mark pending passengers absent",
  "Pausar por incidencia": "Pause for an incident",
  "Conductor disponible": "Available driver",
  "Asignar conductor": "Assign driver",
  "Sin conductor": "No driver",
  "Pasajeros del trip": "Trip passengers",
  Ausente: "Absent",
  Abordado: "Boarded",
  "Cerrar detalle": "Close details",
  "Ver auditoría": "View audit",
  "Portales de operación": "Operations portals",
  "Accesos de demostración para revisar roles y alcances.":
    "Demo access to review roles and tenant scopes.",
  "Administración de plataforma": "Platform administration",
});
window.opsTemplatesPromise = loadOpsTemplates();
document.addEventListener("keydown", (event) => {
  if (!isOpsUser() || !opsDrawer) return;
  if (event.key === "Escape") closeOpsDrawer();
  if (event.key === "Tab") {
    const controls = [
      ...document.querySelectorAll(
        ".ops-drawer button,.ops-drawer input,.ops-drawer select,.ops-drawer textarea",
      ),
    ];
    const first = controls[0];
    const last = controls[controls.length - 1];
    if (event.shiftKey && document.activeElement === first) {
      event.preventDefault();
      last?.focus();
    } else if (!event.shiftKey && document.activeElement === last) {
      event.preventDefault();
      first?.focus();
    }
  }
});

try {
  const savedSession = JSON.parse(sessionStorage.getItem("move-impersonation") || "null");
  if (
    savedSession?.actor === opsActor()?.id &&
    opsActor()?.role === "platform" &&
    opsAccounts.some((a) => a.id === savedSession.target && a.role !== "platform")
  )
    opsImpersonation = savedSession;
} catch {}
