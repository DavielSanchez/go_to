/* One route link works both in MOVE's scanner and in the phone camera. */
function routeLink(plan, route) {
  const data = btoa(JSON.stringify({ plan: plan.id, route: route.id }))
    .replace(/\+/g, "-")
    .replace(/\//g, "_")
    .replace(/=+$/, "");
  return location.origin + location.pathname + "?moveRoute=" + data + "#driver-home";
}
function parseRouteLink(raw) {
  try {
    const url = new URL(raw, location.href);
    if (url.origin !== location.origin || url.pathname !== location.pathname) return null;
    const value = url.searchParams.get("moveRoute");
    if (!value || value.length > 1000) return null;
    return JSON.parse(atob(value.replace(/-/g, "+").replace(/_/g, "/")));
  } catch {
    return null;
  }
}
function routeCode(plan, route) {
  const qr = qrcode(0, "M");
  qr.addData(routeLink(plan, route));
  qr.make();
  return qr.createSvgTag({ cellSize: 4, margin: 4, scalable: true });
}
function catalogPlans() {
  return opsModel.plans.filter(
    (p) =>
      opsInScope(p.tenant) &&
      p.status === "confirmed" &&
      (p.journey === opsModel.date || p.kind === "event"),
  );
}
function catalogCards() {
  return catalogPlans()
    .flatMap((plan) =>
      plan.routes.map((route) =>
        htmlTemplate("administration/admin-modules-qr-link/catalog-cards.html"),
      ),
    )
    .join("");
}
function catalogView() {
  return htmlTemplate("administration/admin-modules-qr-link/catalog-view.html");
}
function printCatalog() {
  if (!catalogPlans().length) return toast("No hay códigos QR disponibles.");
  window.print();
}
function exportCatalog() {
  const cards = catalogCards();
  if (!cards) return;
  downloadData(
    "MOVE-catalogo-QR.html",
    htmlTemplate("administration/admin-modules-qr-link/export-catalog.html"),
    "text/html;charset=utf-8",
  );
  recordOps(
    "qr.catalog.exported",
    "catalog",
    opsScope(),
    {},
    { routes: catalogPlans().reduce((n, p) => n + p.routes.length, 0) },
    "Exportación del catálogo de QR visible",
  );
}
function presentRoute(planId, routeId) {
  const plan = opsModel.plans.find((p) => p.id === planId);
  if (!plan || !opsInScope(plan.tenant)) return;
  const route = plan.routes.find((r) => r.id === routeId);
  if (!route) return;
  opsDrawer = { type: "qr-present", id: planId, route: routeId };
  render();
}
const qrBaseDrawer = opsDrawerHTML;
opsDrawerHTML = function () {
  if (opsDrawer?.type === "qr-present" || opsDrawer?.type === "route") {
    const plan = opsModel.plans.find((p) => p.id === opsDrawer.id);
    if (!plan || !opsInScope(plan.tenant) || plan.status !== "confirmed") return "";
    const route = plan.routes.find((r) => r.id === opsDrawer.route);
    if (!route) return "";
    return drawerFrame(
      "Ruta " + route.id + " · " + route.name,
      htmlTemplate("administration/admin-modules-qr-link/ops-drawer-html.html"),
    );
  }
  return qrBaseDrawer();
};
let pendingRouteLink = null;
try {
  pendingRouteLink =
    parseRouteLink(location.href) ||
    JSON.parse(sessionStorage.getItem("move-pending-route") || "null");
  if (pendingRouteLink)
    sessionStorage.setItem("move-pending-route", JSON.stringify(pendingRouteLink));
} catch {}
let routeLinkError = "";
function clearPendingRoute() {
  pendingRouteLink = null;
  routeLinkError = "";
  sessionStorage.removeItem("move-pending-route");
  const url = new URL(location.href);
  url.searchParams.delete("moveRoute");
  history.replaceState(null, "", url);
  render();
}
function claimRoute(data) {
  if (!access.logged || access.role !== "driver" || !driver.onboarded)
    return { ok: false, pending: true };
  const plan = opsModel.plans.find((p) => p.id === data?.plan && p.status === "confirmed"),
    route = plan?.routes.find((r) => r.id === data.route);
  if (!plan || !route)
    return {
      ok: false,
      error: "Este código ya no está disponible o no corresponde a una ruta confirmada.",
    };
  const name = driver.profile?.name || "Conductor demo";
  const occupied = opsModel.trips.find((t) => t.driver === name && t.status !== "completed");
  if (occupied && occupied.id !== driver.linkedTrip)
    return {
      ok: false,
      error: "Ya tienes un viaje asignado. Desvincúlate antes de tomar otro.",
    };
  let trip =
    driver.linkedTrip &&
    opsModel.trips.find(
      (t) => t.id === driver.linkedTrip && t.status !== "completed" && t.driver === name,
    );
  if (
    trip &&
    (trip.route !== route.id ||
      trip.tenant !== plan.tenant ||
      trip.window !== plan.window ||
      trip.journey !== plan.journey)
  )
    return {
      ok: false,
      error: "Ya tienes otro viaje. Finalízalo o desvincúlate antes de cambiar de ruta.",
    };
  trip =
    trip ||
    opsModel.trips.find(
      (t) =>
        (t.plan === plan.id ||
          (t.tenant === plan.tenant && t.journey === plan.journey && t.window === plan.window)) &&
        t.route === route.id &&
        t.status === "boarding" &&
        !t.driver,
    );
  if (!trip)
    return {
      ok: false,
      error: "No quedan viajes libres para esta ruta y salida.",
    };
  const before = opsSnapshot(trip);
  trip.driver = name;
  driver.linkedTrip = trip.id;
  driver.stage = trip.status === "active" ? "active" : "boarding";
  driver.tripDate = trip.date;
  driver.departureTime = trip.window;
  driver.boarded = trip.passengers.filter((p) => p.boarded).map((p) => p.id);
  access.tenant = opsTenant(trip.tenant).company;
  saveDriver();
  saveOps();
  opsModel.audit.unshift({
    id: crypto.randomUUID(),
    timestamp: new Date().toISOString(),
    actor: { id: "driver-demo", name, email: access.email || "conductor.demo" },
    effective: {
      id: "driver-demo",
      name,
      email: "conductor.demo",
      role: "driver",
    },
    action: "driver.trip.joined",
    entity: trip.id,
    tenants: [trip.tenant],
    before,
    after: opsSnapshot(trip),
    reason: "Asignación mediante QR de ruta",
    impersonation: null,
    session: opsSessionId,
    source: "Web · demostración",
    timezone: opsTenant(trip.tenant).timezone,
    demo: true,
  });
  saveOps();
  return { ok: true, trip: trip.id };
}
const qrHandle = handleQRCode;
handleQRCode = function (raw) {
  const link = parseRouteLink(raw);
  if (scannerKind === "zone" && link) {
    pendingRouteLink = link;
    sessionStorage.setItem("move-pending-route", JSON.stringify(link));
    const result = claimRoute(link);
    if (result.ok) {
      stopScanner();
      clearPendingRoute();
      navigate("driver-home");
      render();
    } else {
      const target = document.getElementById("cameraResult");
      if (target)
        target.innerHTML = scanResultHTML({
          kind: "error",
          title: "No se pudo tomar el viaje",
          text: result.error || "Inicia sesión como conductor.",
        });
    }
    return;
  }
  qrHandle(raw);
};
function linkedTrip() {
  return opsModel.trips.find((t) => t.id === driver.linkedTrip);
}
function linkedDriverView(trip) {
  const complete = trip.status === "completed";
  return htmlTemplate("administration/admin-modules-qr-link/linked-driver-view.html");
}
function linkedDriverBoard(id) {
  const t = linkedTrip();
  if (!t || t.driver !== driver.profile.name || t.status !== "boarding") return;
  const p = t.passengers.find((p) => p.id === id);
  if (!p) return;
  p.boarded = true;
  driver.boarded = t.passengers.filter((p) => p.boarded).map((p) => p.id);
  saveOps();
  saveDriver();
  render();
}
function linkedDriverStart() {
  const t = linkedTrip();
  if (!t || t.driver !== driver.profile.name) return;
  const departure = new Date(
    t.date + "T" + t.window + ":00" + (opsTenant(t.tenant).utcOffset || "-04:00"),
  ).getTime();
  if (
    t.passengers.some((p) => !p.boarded && !p.absent) ||
    new Date(opsModel.clock).getTime() < departure + t.grace * 60000
  ) {
    document.getElementById("linkedDriverError").textContent =
      "Falta cerrar el abordaje o superar la salida y el tiempo de gracia.";
    return;
  }
  t.status = "active";
  t.startedAt = new Date(opsModel.clock).toISOString();
  t.progress = 1;
  driver.stage = "active";
  saveOps();
  saveDriver();
  render();
}
function linkedDriverDetach() {
  const t = linkedTrip();
  if (!t || t.driver !== driver.profile.name || t.status !== "boarding") return;
  t.driver = null;
  delete driver.linkedTrip;
  driver.stage = "arrival";
  driver.boarded = [];
  saveOps();
  saveDriver();
  render();
}
function advanceLinkedDriver() {
  const t = linkedTrip();
  if (!t || t.driver !== driver.profile.name || t.status !== "active") return;
  t.progress = Math.min(100, t.progress + 20);
  saveOps();
  render();
}
function finishLinkedDriver() {
  const t = linkedTrip();
  if (!t || t.driver !== driver.profile.name || !["active", "paused"].includes(t.status)) return;
  t.status = "completed";
  t.progress = 100;
  t.completedAt = new Date().toISOString();
  driver.stage = "complete";
  saveOps();
  saveDriver();
  render();
}
function closeLinkedDriver(returnToSite) {
  const t = linkedTrip();
  if (!t || t.status !== "completed") return;
  const detail = document.getElementById("linkedIncident").value.trim();
  if (detail) {
    opsModel.cases.push({
      id: crypto.randomUUID(),
      tenant: t.tenant,
      trip: t.id,
      type: "Conductor",
      detail,
      status: "open",
      at: new Date().toISOString(),
      comments: [],
    });
    saveOps();
  }
  if (returnToSite) {
    const point = t.origin || [18.483, -69.94];
    window.open(
      "https://www.google.com/maps/dir/?api=1&destination=" + point.join(","),
      "_blank",
      "noopener",
    );
  }
  delete driver.linkedTrip;
  driver.stage = "arrival";
  driver.boarded = [];
  saveDriver();
  navigate("driver-home");
  render();
}
const routeBaseRender = render;
render = function () {
  if (pendingRouteLink && access.logged && access.role === "driver" && driver.onboarded) {
    const result = claimRoute(pendingRouteLink);
    if (result.ok) {
      pendingRouteLink = null;
      sessionStorage.removeItem("move-pending-route");
      const url = new URL(location.href);
      url.searchParams.delete("moveRoute");
      history.replaceState(null, "", url);
    } else routeLinkError = result.error;
  }
  routeBaseRender();
  if (pendingRouteLink && !splashActive) {
    const notice = htmlTemplate("administration/admin-modules-qr-link/notice.html");
    (app.querySelector(".ops-content") || app).insertAdjacentHTML("afterbegin", notice);
  }
  const detached = access.logged && access.role === "driver" && linkedTrip();
  if (detached && detached.driver !== driver.profile.name) {
    delete driver.linkedTrip;
    driver.stage = "arrival";
    driver.boarded = [];
    saveDriver();
  }
  const trip = access.logged && access.role === "driver" && driver.onboarded && linkedTrip();
  if (trip && !splashActive && ["driver-home", "driver-board", "driver-route"].includes(page)) {
    drawWorkspace(linkedDriverView(trip), driverNav);
    applyTenantBrand();
    translateInterface();
  }
};
window.addEventListener("hashchange", () => {
  if (location.search.includes("moveRoute=")) {
    const next = parseRouteLink(location.href);
    if (next) {
      pendingRouteLink = next;
      sessionStorage.setItem("move-pending-route", JSON.stringify(next));
    }
  }
});

function driverAudit(action, trip, before, reason) {
  opsModel.audit.unshift({
    id: crypto.randomUUID(),
    timestamp: new Date().toISOString(),
    actor: {
      id: "driver-demo",
      name: driver.profile.name,
      email: driver.profile.email || "conductor.demo",
    },
    effective: {
      id: "driver-demo",
      name: driver.profile.name,
      email: driver.profile.email || "conductor.demo",
      role: "driver",
    },
    action,
    entity: trip.id,
    tenants: [trip.tenant],
    before,
    after: opsSnapshot(trip),
    reason,
    impersonation: null,
    session: opsSessionId,
    source: "Web · demostración",
    timezone: opsTenant(trip.tenant).timezone,
    demo: true,
  });
  saveOps();
}
const auditDriverDetach = linkedDriverDetach;
linkedDriverDetach = function () {
  const trip = linkedTrip();
  if (!trip) return;
  const before = opsSnapshot(trip);
  auditDriverDetach();
  if (!trip.driver)
    driverAudit("driver.trip.detached", trip, before, "Desvinculación solicitada por el conductor");
};
const auditDriverStart = linkedDriverStart;
linkedDriverStart = function () {
  const trip = linkedTrip();
  if (!trip) return;
  const before = opsSnapshot(trip);
  auditDriverStart();
  if (trip.status === "active" && before.status === "boarding")
    driverAudit(
      "driver.trip.started",
      trip,
      before,
      "Abordaje cerrado y horario de salida cumplido",
    );
};
const auditDriverFinish = finishLinkedDriver;
finishLinkedDriver = function () {
  const trip = linkedTrip();
  if (!trip) return;
  const before = opsSnapshot(trip);
  auditDriverFinish();
  if (trip.status === "completed" && before.status !== "completed")
    driverAudit("driver.trip.completed", trip, before, "Fin del recorrido");
};

function openDriverRouteLogin() {
  logoutMove();
  access.role = "driver";
  navigate("login");
  render();
}

window.moveManagementReady = true;
render();
