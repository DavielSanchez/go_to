/* Custom events create normal trips and route QR links. */
let eventDraft = null;
function newEventDraft() {
  const site = manageSite();
  return {
    tenant: site,
    name: "",
    date: today(),
    time: "10:00",
    mode: "common",
    origin: [18.483, -69.94],
    destination: [18.515, -70.005],
    originName: opsTenant(site).name,
    destinationName: "",
    estimated: 0,
    currency: opsTenant(site).country === "CO" ? "COP" : "DOP",
    users: [],
    guests: [],
  };
}
function eventsView() {
  const events = opsModel.events.filter((e) => opsInScope(e.tenant));
  return htmlTemplate("administration/admin-modules-events/events-view.html");
}
function eventForm() {
  if (!eventDraft || eventDraft.tenant !== manageSite()) eventDraft = newEventDraft();
  const d = eventDraft;
  return htmlTemplate("administration/admin-modules-events/event-form.html");
}
function toggleEventUser(id, checked) {
  eventDraft.users = checked
    ? [...new Set([...eventDraft.users, id])]
    : eventDraft.users.filter((u) => u !== id);
}
function guestFields(g, i) {
  return htmlTemplate("administration/admin-modules-events/guest-fields.html");
}
function addEventGuest() {
  eventDraft.guests.push({
    id: crypto.randomUUID(),
    name: "",
    contact: "",
    address: null,
    zone: "",
  });
  render();
}
let eventMapTarget = "destination";
function initializeEventMap() {
  const el = document.getElementById("eventMap");
  if (!el || typeof L === "undefined") return;
  const map = L.map(el).setView(eventDraft.origin, 12);
  managementMap = map;
  L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
    attribution: "© OpenStreetMap",
    maxZoom: 19,
  }).addTo(map);
  const markers = {};
  function marker(key, color) {
    markers[key] = L.marker(eventDraft[key], { draggable: true })
      .addTo(map)
      .bindTooltip(key === "origin" ? "Origen" : "Destino", {
        permanent: true,
      });
    markers[key].on("dragend", () => {
      const p = markers[key].getLatLng();
      eventDraft[key] = [p.lat, p.lng];
    });
  }
  if (eventDraft.mode !== "from-home") marker("origin");
  if (eventDraft.mode !== "to-home") marker("destination");
  map.on("click", (e) => {
    const point = [e.latlng.lat, e.latlng.lng];
    if (eventMapTarget.startsWith("guest-")) {
      const i = Number(eventMapTarget.slice(6)),
        guest = eventDraft.guests[i];
      if (guest) {
        guest.address = { lat: point[0], lng: point[1] };
        const el = document.getElementById("guestPin" + i);
        if (el) el.textContent = "Pin registrado";
        L.circleMarker(point, { radius: 6 }).addTo(map);
      }
      return;
    }
    if (markers[eventMapTarget]) {
      eventDraft[eventMapTarget] = point;
      markers[eventMapTarget].setLatLng(point);
    }
  });
  managementMapDestroy = () => {
    map.remove();
    managementMap = null;
  };
  setTimeout(() => map.invalidateSize(), 0);
}
function saveEvent(event) {
  const d = formData(event),
    draft = eventDraft,
    reason = managementReason(d);
  if (!draft || !authorizedWrite(draft.tenant)) return false;
  const users = draft.users
    .map((id) =>
      opsModel.users.find((u) => u.id === id && u.tenant === draft.tenant && u.status === "active"),
    )
    .filter(Boolean)
    .map((u) => ({
      id: u.id,
      name: u.name,
      guest: false,
      address: u.address,
      zone: u.zone,
    }));
  const guests = draft.guests.map((g) => ({ ...g, guest: true }));
  const participants = [...users, ...guests];
  if (
    !draft.name.trim() ||
    !draft.date ||
    !draft.time ||
    !participants.length ||
    guests.some((g) => !g.name.trim()) ||
    !Number.isFinite(draft.estimated) ||
    draft.estimated < 0 ||
    reason.length < 8
  )
    return errorManagement("Completa el evento, sus participantes, el costo y el motivo.");
  if (
    draft.mode !== "common" &&
    participants.some(
      (p) =>
        !p.address ||
        !opsModel.zones.some(
          (z) =>
            z.tenant === draft.tenant &&
            z.route === p.zone &&
            pointInPolygon([p.address.lat, p.address.lng], z.points),
        ),
    )
  )
    return errorManagement(
      "Cada domicilio debe tener un pin dentro de su ruta. Revisa empleados e invitados.",
    );
  if (
    (draft.mode !== "from-home" && !draft.originName.trim()) ||
    (draft.mode !== "to-home" && !draft.destinationName.trim())
  )
    return errorManagement("Indica los nombres de origen y destino.");
  const next = {
    ...opsSnapshot(draft),
    id: "EV-" + crypto.randomUUID().slice(0, 8),
    name: draft.name.trim(),
    originName: draft.mode === "from-home" ? "Domicilios de los participantes" : draft.originName,
    destinationName:
      draft.mode === "to-home" ? "Domicilios de los participantes" : draft.destinationName,
    participants,
    status: "draft",
    finalCost: null,
    createdAt: new Date().toISOString(),
  };
  opsModel.events.push(next);
  recordOps("event.created", next.id, [next.tenant], {}, next, reason);
  opsDrawer = { type: "event-details", id: next.id };
  saveOps();
  render();
  return true;
}
function eventDetails(id) {
  const event = opsModel.events.find((e) => e.id === id);
  if (!event || !opsInScope(event.tenant)) return "";
  const trips = opsModel.trips.filter((t) => t.event === id);
  return htmlTemplate("administration/admin-modules-events/event-details.html");
}
function confirmEvent(event, id) {
  const d = formData(event);
  return confirmEventById(id, managementReason(d));
}
function confirmEventById(id, reason) {
  const event = opsModel.events.find((e) => e.id === id);
  if (
    !event ||
    !authorizedWrite(event.tenant) ||
    event.status !== "draft" ||
    String(reason).trim().length < 8
  )
    return false;
  const before = opsSnapshot(event);
  try {
    const groups =
      event.mode === "common"
        ? [
            {
              route: "custom",
              name: event.name,
              participants: event.participants,
            },
          ]
        : [...new Set(event.participants.map((p) => p.zone))].map((zone) => ({
            route: zone,
            name: opsModel.zones.find((z) => z.tenant === event.tenant && z.route === zone).name,
            participants: event.participants.filter((p) => p.zone === zone),
          }));
    const plans = [],
      trips = [];
    groups.forEach((group) => {
      const plan = {
        id: event.id + "-" + group.route,
        kind: "event",
        event: event.id,
        tenant: event.tenant,
        journey: event.date,
        window: event.time,
        status: "confirmed",
        revision: 1,
        demand: group.participants.length,
        exceptionCount: 0,
        routes: [{ id: group.route, name: group.name }],
        routeDemands: [{ route: group.route, count: group.participants.length }],
        requestIds: [],
        fleetSnapshot: opsSnapshot(fleetFor(event.tenant)),
      };
      let offset = 0;
      vehicleAllocation(event.tenant, group.participants.length).forEach((vehicle) => {
        const passengers = group.participants
          .slice(offset, offset + vehicle.capacity - vehicle.gap)
          .map((p, index) => ({
            id: p.id,
            name: p.name,
            guest: p.guest,
            address: p.address,
            boarded: false,
            absent: false,
            stop: index,
          }));
        offset += passengers.length;
        const trip = makePlannedTrip(plan, plan.routes[0], vehicle, passengers);
        trip.date = event.date;
        trip.event = event.id;
        trip.origin = event.origin;
        trip.destination = event.destination;
        trip.originName = event.originName;
        trip.destinationName = event.destinationName;
        trip.mode = event.mode;
        trip.cost = { estimated: 0, final: null, currency: event.currency };
        trips.push(trip);
      });
      plans.push(plan);
    });
    trips.forEach((trip, index) => {
      trip.cost.estimated =
        index === trips.length - 1
          ? Math.round(
              (event.estimated - trips.slice(0, index).reduce((n, t) => n + t.cost.estimated, 0)) *
                100,
            ) / 100
          : Math.round((event.estimated / trips.length) * 100) / 100;
    });
    opsModel.trips.push(...trips);
    opsModel.plans.push(...plans);
    event.status = "confirmed";
    event.tripIds = trips.map((t) => t.id);
    recordOps(
      "event.confirmed",
      event.id,
      [event.tenant],
      before,
      { event, createdTrips: event.tripIds },
      reason,
    );
    saveOps();
    render();
    return true;
  } catch (e) {
    return errorManagement(e.message);
  }
}
function saveEventCost(event, id) {
  const d = formData(event),
    item = opsModel.events.find((e) => e.id === id),
    cost = Number(d.get("final")),
    reason = managementReason(d);
  if (
    !item ||
    !authorizedWrite(item.tenant) ||
    item.status !== "confirmed" ||
    !Number.isFinite(cost) ||
    cost < 0 ||
    reason.length < 8
  )
    return errorManagement("Revisa el costo y el motivo.");
  const before = { finalCost: item.finalCost };
  item.finalCost = cost;
  const trips = opsModel.trips.filter((t) => t.event === id);
  trips.forEach(
    (t, i) =>
      (t.cost.final =
        i === trips.length - 1
          ? Math.round((cost - trips.slice(0, i).reduce((n, x) => n + x.cost.final, 0)) * 100) / 100
          : Math.round((cost / trips.length) * 100) / 100),
  );
  recordOps(
    "event.cost.updated",
    id,
    [item.tenant],
    before,
    {
      finalCost: cost,
      currency: item.currency,
      trips: trips.map((t) => ({ id: t.id, cost: t.cost })),
    },
    reason,
  );
  saveOps();
  render();
  return true;
}
