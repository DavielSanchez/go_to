/* Leaflet zone editor. Points and freehand strokes produce editable polygon vertices. */
let zoneDraft = null;
let zoneMode = "points";
let zoneLayers = null;
function blankZone(site) {
  return { id: "", tenant: site, route: "", name: "", revision: 0, points: [] };
}
function zonesView() {
  const site = manageSite();
  if (!zoneDraft || zoneDraft.tenant !== site) zoneDraft = blankZone(site);
  return htmlTemplate("administration/admin-modules-zones/zones-view.html");
}
function newZone() {
  zoneDraft = blankZone(manageSite());
  zoneMode = "points";
  render();
}
function selectZone(id) {
  const zone = opsModel.zones.find((z) => z.id === id);
  if (!zone || !authorizedWrite(zone.tenant)) return;
  zoneDraft = opsSnapshot(zone);
  zoneMode = "pan";
  render();
}
function setZoneMode(mode) {
  if (!["pan", "points", "freehand"].includes(mode)) return;
  zoneMode = mode;
  if (managementMap) {
    if (mode === "pan") managementMap.dragging.enable();
    else managementMap.dragging.disable();
    document.getElementById("zoneMap").dataset.mode = mode;
    document
      .querySelectorAll(".zone-tools button")
      .forEach((b) =>
        b.classList.toggle("selected", b.getAttribute("onclick")?.includes("'" + mode + "'")),
      );
  }
}
function undoZonePoint() {
  zoneDraft.points.pop();
  redrawZone();
}
function clearZone() {
  zoneDraft.points = [];
  redrawZone();
}
function initializeZoneMap() {
  const el = document.getElementById("zoneMap");
  if (!el || typeof L === "undefined") return;
  const map = L.map(el, { zoomControl: true }).setView([18.521, -70.018], 12);
  managementMap = map;
  L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
    maxZoom: 19,
    attribution: "© OpenStreetMap",
  }).addTo(map);
  zoneLayers = L.layerGroup().addTo(map);
  opsModel.zones
    .filter((z) => z.tenant === manageSite() && z.id !== zoneDraft.id)
    .forEach((z) =>
      L.polygon(z.points, { color: "#8a91a6", weight: 2, fillOpacity: 0.1 })
        .addTo(map)
        .bindTooltip(z.name),
    );
  if (zoneDraft.points.length >= 3)
    map.fitBounds(L.latLngBounds(zoneDraft.points), { padding: [35, 35] });
  map.on("click", (event) => {
    if (zoneMode === "points" && zoneDraft.points.length < 120) {
      zoneDraft.points.push([event.latlng.lat, event.latlng.lng]);
      redrawZone();
    }
  });
  let drawing = false,
    last = null;
  const coord = (e) =>
    map.containerPointToLatLng([
      e.clientX - el.getBoundingClientRect().left,
      e.clientY - el.getBoundingClientRect().top,
    ]);
  const down = (e) => {
    if (zoneMode !== "freehand" || e.target.closest(".leaflet-control")) return;
    drawing = true;
    last = [e.clientX, e.clientY];
    zoneDraft.points = [];
    el.setPointerCapture(e.pointerId);
    const p = coord(e);
    zoneDraft.points.push([p.lat, p.lng]);
    e.preventDefault();
  };
  const move = (e) => {
    if (!drawing || zoneDraft.points.length >= 120) return;
    if (Math.hypot(e.clientX - last[0], e.clientY - last[1]) < 10) return;
    const p = coord(e);
    zoneDraft.points.push([p.lat, p.lng]);
    last = [e.clientX, e.clientY];
    redrawZone();
  };
  const up = () => {
    if (!drawing) return;
    drawing = false;
    zoneMode = "pan";
    setZoneMode("pan");
    redrawZone();
  };
  el.addEventListener("pointerdown", down);
  el.addEventListener("pointermove", move);
  el.addEventListener("pointerup", up);
  el.addEventListener("pointercancel", up);
  managementMapDestroy = () => {
    el.removeEventListener("pointerdown", down);
    el.removeEventListener("pointermove", move);
    el.removeEventListener("pointerup", up);
    el.removeEventListener("pointercancel", up);
    map.remove();
    managementMap = null;
    zoneLayers = null;
  };
  setZoneMode(zoneMode);
  redrawZone();
  setTimeout(() => map.invalidateSize(), 0);
}
function redrawZone() {
  if (!zoneLayers) return;
  zoneLayers.clearLayers();
  const points = zoneDraft.points;
  if (points.length > 1)
    L.polygon(points, { color: "#d9004c", fillOpacity: 0.16, weight: 3 }).addTo(zoneLayers);
  points.forEach((point, index) => {
    const marker = L.marker(point, {
      draggable: true,
      icon: L.divIcon({
        className: "zone-vertex",
        html: htmlTemplate("administration/admin-modules-zones/html.html"),
        iconSize: [22, 22],
        iconAnchor: [11, 11],
      }),
    }).addTo(zoneLayers);
    marker.on("drag", (e) => {
      const p = e.target.getLatLng();
      zoneDraft.points[index] = [p.lat, p.lng];
    });
    marker.on("dragend", redrawZone);
  });
  const count = document.getElementById("zonePointCount");
  if (count)
    count.textContent = points.length + " puntos · Arrastra los vértices para ajustar el límite.";
}
function pointInPolygon(point, polygon) {
  let inside = false;
  const [x, y] = point;
  for (let i = 0, j = polygon.length - 1; i < polygon.length; j = i++) {
    const [xi, yi] = polygon[i],
      [xj, yj] = polygon[j];
    if (yi > y !== yj > y && x < ((xj - xi) * (y - yi)) / (yj - yi) + xi) inside = !inside;
  }
  return inside;
}
function segmentCross(a, b, c, d) {
  const cross = (p, q, r) => (q[0] - p[0]) * (r[1] - p[1]) - (q[1] - p[1]) * (r[0] - p[0]);
  return cross(a, b, c) * cross(a, b, d) < 0 && cross(c, d, a) * cross(c, d, b) < 0;
}
function polygonInvalid(points) {
  for (let i = 0; i < points.length; i++)
    for (let j = i + 2; j < points.length; j++) {
      if (i === 0 && j === points.length - 1) continue;
      if (
        segmentCross(
          points[i],
          points[(i + 1) % points.length],
          points[j],
          points[(j + 1) % points.length],
        )
      )
        return true;
    }
  return false;
}
function polygonOverlap(a, b) {
  return (
    a.some((p) => pointInPolygon(p, b)) ||
    b.some((p) => pointInPolygon(p, a)) ||
    a.some((p, i) =>
      b.some((q, j) => segmentCross(p, a[(i + 1) % a.length], q, b[(j + 1) % b.length])),
    )
  );
}
function saveZone(event) {
  const d = formData(event),
    site = manageSite(),
    name = String(d.get("name") || "").trim(),
    route = String(d.get("route") || "").trim(),
    reason = managementReason(d),
    points = zoneDraft.points;
  if (!authorizedWrite(site)) return false;
  if (
    !name ||
    !route ||
    !/^[A-Za-z0-9-]+$/.test(route) ||
    reason.length < 8 ||
    points.length < 3 ||
    polygonInvalid(points)
  )
    return errorManagement("Completa los datos y dibuja al menos tres puntos sin cruces.");
  if (opsModel.zones.some((z) => z.tenant === site && z.id !== zoneDraft.id && z.route === route))
    return errorManagement("Ese código de ruta ya existe.");
  const overlapping = opsModel.zones.find(
    (z) => z.tenant === site && z.id !== zoneDraft.id && polygonOverlap(points, z.points),
  );
  if (overlapping)
    return errorManagement(
      "La zona se superpone con " + overlapping.name + ". Ajusta sus límites.",
    );
  const existing = opsModel.zones.find((z) => z.id === zoneDraft.id),
    before = existing ? opsSnapshot(existing) : {},
    next = {
      id: zoneDraft.id || crypto.randomUUID(),
      tenant: site,
      name,
      route,
      points: opsSnapshot(points),
      revision: (existing?.revision || 0) + 1,
    };
  if (
    existing &&
    existing.route !== route &&
    opsModel.trips.some((t) => t.tenant === site && t.route === existing.route)
  )
    return errorManagement("La ruta tiene viajes registrados. Conserva su código.");
  if (existing) Object.assign(existing, next);
  else opsModel.zones.push(next);
  recordOps("zone.saved", next.id, [site], before, next, reason);
  zoneDraft = opsSnapshot(next);
  saveOps();
  render();
  return true;
}
