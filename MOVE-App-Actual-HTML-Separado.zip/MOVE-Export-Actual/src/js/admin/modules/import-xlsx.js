/* Read standard .xlsx files locally using ZIP and browser XML APIs. No upload. */
async function readXLSX(buffer) {
  const bytes = new Uint8Array(buffer),
    view = new DataView(buffer);
  let end = -1;
  for (let i = bytes.length - 22; i >= Math.max(0, bytes.length - 65557); i--) {
    if (view.getUint32(i, true) === 0x06054b50) {
      end = i;
      break;
    }
  }
  if (end < 0) throw Error("El archivo no es un Excel .xlsx válido.");
  const count = view.getUint16(end + 10, true);
  if (count > 1000) throw Error("El archivo contiene demasiadas entradas.");
  let offset = view.getUint32(end + 16, true),
    total = 0;
  const entries = new Map(),
    decode = new TextDecoder();
  for (let i = 0; i < count; i++) {
    if (view.getUint32(offset, true) !== 0x02014b50) throw Error("El Excel está dañado.");
    const compression = view.getUint16(offset + 10, true),
      packed = view.getUint32(offset + 20, true),
      unpacked = view.getUint32(offset + 24, true),
      nameLength = view.getUint16(offset + 28, true),
      extra = view.getUint16(offset + 30, true),
      comment = view.getUint16(offset + 32, true),
      local = view.getUint32(offset + 42, true),
      name = decode.decode(bytes.slice(offset + 46, offset + 46 + nameLength));
    total += unpacked;
    if (total > 12 * 1024 * 1024) throw Error("El Excel descomprimido supera el límite permitido.");
    const start = local + 30 + view.getUint16(local + 26, true) + view.getUint16(local + 28, true);
    entries.set(name, {
      compression,
      data: bytes.slice(start, start + packed),
    });
    offset += 46 + nameLength + extra + comment;
  }
  async function xml(name) {
    const entry = entries.get(name);
    if (!entry) return null;
    let data = entry.data;
    if (entry.compression === 8) {
      try {
        const stream = new Blob([data])
          .stream()
          .pipeThrough(new DecompressionStream("deflate-raw"));
        data = new Uint8Array(await new Response(stream).arrayBuffer());
      } catch {
        throw Error(
          "No pudimos descomprimir el Excel. Usa un navegador actualizado o la plantilla CSV.",
        );
      }
    } else if (entry.compression !== 0) throw Error("Compresión de Excel no compatible.");
    const doc = new DOMParser().parseFromString(decode.decode(data), "application/xml");
    if (doc.querySelector("parsererror")) throw Error("El Excel contiene XML inválido.");
    return doc;
  }
  const sharedDoc = await xml("xl/sharedStrings.xml"),
    shared = sharedDoc
      ? [...sharedDoc.getElementsByTagName("si")].map((si) =>
          [...si.getElementsByTagName("t")].map((t) => t.textContent).join(""),
        )
      : [];
  const workbook = await xml("xl/workbook.xml"),
    rels = await xml("xl/_rels/workbook.xml.rels");
  let sheet = "xl/worksheets/sheet1.xml";
  const first = workbook?.getElementsByTagName("sheet")[0];
  if (first && rels) {
    const id = first.getAttribute("r:id"),
      rel = [...rels.getElementsByTagName("Relationship")].find((r) => r.getAttribute("Id") === id),
      target = rel?.getAttribute("Target");
    if (target)
      sheet = target.startsWith("/") ? target.slice(1) : "xl/" + target.replace(/^\.\//, "");
  }
  const doc = await xml(sheet);
  if (!doc) throw Error("No encontramos la primera hoja de Excel.");
  return [...doc.getElementsByTagName("row")]
    .map((row) => {
      const result = [];
      for (const cell of row.getElementsByTagName("c")) {
        const letters = (cell.getAttribute("r") || "A").replace(/[0-9]/g, "");
        let column = 0;
        for (const letter of letters) column = column * 26 + letter.charCodeAt(0) - 64;
        const value = cell.getElementsByTagName("v")[0]?.textContent || "";
        result[column - 1] =
          cell.getAttribute("t") === "s"
            ? shared[Number(value)] || ""
            : cell.getAttribute("t") === "inlineStr"
              ? [...cell.getElementsByTagName("t")].map((t) => t.textContent).join("")
              : value;
      }
      return result;
    })
    .filter((row) => row.some(Boolean));
}
