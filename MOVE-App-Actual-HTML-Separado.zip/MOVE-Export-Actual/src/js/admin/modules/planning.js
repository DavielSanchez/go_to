/* Transport planning: fleet snapshots, cutoff and administrator-approved revisions. */
function fleetFor(site) {
  return opsModel.fleet.filter((type) => type.tenant === site && type.active);
}
function vehicleAllocation(site, count) {
  const types = fleetFor(site);
  if (!types.length) throw Error("Registra al menos un tipo de vehículo activo.");
  if (!count) return [];
  const max = Math.max(...types.map((t) => t.capacity - t.gap));
  const minTrips = Math.ceil(count / max);
  // Select the smallest available capacity combination with the minimum number of trips.
  let states = new Map([[0, []]]);
  for (let i = 0; i < minTrips; i++) {
    const next = new Map();
    for (const [seats, combo] of states)
      for (const type of types) {
        const total = seats + type.capacity - type.gap;
        if (!next.has(total)) next.set(total, [...combo, type]);
      }
    states = next;
  }
  const candidates = [...states].filter(([seats]) => seats >= count).sort((a, b) => a[0] - b[0]);
  if (!candidates.length) throw Error("No pudimos calcular la capacidad.");
  return candidates[0][1].map((type) => ({
    type: type.id,
    name: type.name,
    capacity: type.capacity,
    gap: type.gap,
  }));
}
function requestsFor(site, journey, window) {
  return opsModel.requests.filter(
    (r) => r.tenant === site && r.journey === journey && r.window === window,
  );
}
function cutoffTimestamp(site, journey) {
  return new Date(
    journey + "T" + opsTenant(site).config.cutoff + ":00" + (opsTenant(site).utcOffset || "-04:00"),
  ).getTime();
}
function beforeCutoff(site, journey) {
  return new Date(opsModel.clock).getTime() < cutoffTimestamp(site, journey);
}
function planPassengers(plan) {
  return requestsFor(plan.tenant, plan.journey, plan.window).filter(
    (r) => r.status === "confirmed" && plan.routes.some((zone) => zone.id === r.route),
  );
}
function pendingForPlan(plan) {
  return requestsFor(plan.tenant, plan.journey, plan.window).filter((r) => r.status === "pending");
}
function routeBreakdown(plan) {
  return plan.routes.map((route) => ({
    route: route.id,
    count:
      plan.routeDemands?.find((d) => d.route === route.id)?.count ??
      Math.floor(plan.demand / plan.routes.length),
  }));
}
opsPlannedVehicles = function (plan) {
  try {
    return routeBreakdown(plan).reduce(
      (n, r) => n + vehicleAllocation(plan.tenant, r.count).length,
      0,
    );
  } catch {
    return "—";
  }
};
opsPlansView = function () {
  const plans = opsPlans();
  const intro = canOpsManage()
    ? htmlTemplate("administration/admin-modules-planning/intro.html")
    : htmlTemplate("administration/admin-modules-planning/intro-02.html");
  return intro + htmlTemplate("administration/admin-modules-planning/ops-plans-view.html");
};
function launchPlanForm() {
  const site = manageSite(),
    config = opsTenant(site).config;
  return htmlTemplate("administration/admin-modules-planning/launch-plan-form.html");
}
function launchPlan(event) {
  const d = formData(event),
    site = manageSite(),
    window = String(d.get("window")),
    journey = opsModel.date,
    reason = managementReason(d);
  if (
    !authorizedWrite(site) ||
    !d.get("ack") ||
    reason.length < 8 ||
    !opsTenant(site).config.windows.includes(window)
  )
    return errorManagement("Revisa la ventana, el aviso y el motivo.");
  if (opsModel.plans.some((p) => p.tenant === site && p.journey === journey && p.window === window))
    return errorManagement("Ya existe un plan para esta salida. Actualiza ese plan.");
  if (!fleetFor(site).length)
    return errorManagement("Registra un tipo activo de vehículo antes de generar el plan.");
  const requests = requestsFor(site, journey, window).filter((r) => r.status === "confirmed");
  const zones = opsModel.zones.filter((z) => z.tenant === site);
  if (!zones.length) return errorManagement("Crea las zonas antes de planificar.");
  const included = requests.filter((r) => zones.some((z) => z.route === r.route));
  if (!included.length) return errorManagement("No hay demanda confirmada para esta ventana.");
  const plan = {
    id: "PLAN-" + crypto.randomUUID().slice(0, 8),
    tenant: site,
    journey,
    window,
    status: "draft",
    revision: 1,
    gap: "Por tipo",
    demand: included.length,
    exceptionCount: 0,
    routes: zones
      .filter((z) => included.some((r) => r.route === z.route))
      .map((z) => ({ id: z.route, name: z.name })),
    requestIds: included.map((r) => r.id),
    routeDemands: zones
      .filter((z) => included.some((r) => r.route === z.route))
      .map((z) => ({
        route: z.route,
        count: included.filter((r) => r.route === z.route).length,
      })),
    createdAt: new Date().toISOString(),
    early: beforeCutoff(site, journey),
  };
  opsModel.plans.push(plan);
  recordOps("plan.generated", plan.id, [site], {}, plan, reason);
  opsDrawer = { type: "plan", id: plan.id };
  saveOps();
  render();
  return true;
}
function tripDateFor(plan) {
  return plan.window < "06:00" ? opsShiftDate(plan.journey, 1) : plan.journey;
}
function makePlannedTrip(plan, route, vehicle, passengers) {
  const id = plan.id + "-R" + route.id + "-" + crypto.randomUUID().slice(0, 6);
  return {
    id,
    plan: plan.id,
    tenant: plan.tenant,
    journey: plan.journey,
    date: tripDateFor(plan),
    window: plan.window,
    route: route.id,
    routeName: route.name,
    status: "boarding",
    driver: null,
    unit: String(opsModel.trips.length + 1),
    vehicleType: vehicle.name,
    capacity: vehicle.capacity,
    gap: vehicle.gap,
    grace: opsTenant(plan.tenant).config.grace,
    passengers,
    progress: 0,
    eta: "Por calcular",
    incidents: [],
    driverChanges: [],
  };
}
function requestPassenger(request, index) {
  const user = opsModel.users.find((u) => u.id === request.user);
  return {
    id: request.user,
    request: request.id,
    name: user?.name || "Pasajero registrado",
    boarded: false,
    absent: false,
    stop: index % 3,
  };
}
confirmOpsPlan = function (id, reason) {
  const plan = opsModel.plans.find((p) => p.id === id);
  if (
    !plan ||
    !authorizedWrite(plan.tenant) ||
    plan.status !== "draft" ||
    String(reason).trim().length < 8
  )
    return false;
  const before = opsSnapshot(plan),
    created = [];
  try {
    const demand = planPassengers(plan);
    if (!demand.length) return errorManagement("Ya no hay pasajeros confirmados para este plan.");
    const proposals = plan.routes.map((route) => ({
      route,
      requests: demand.filter((r) => r.route === route.id),
      vehicles: vehicleAllocation(plan.tenant, demand.filter((r) => r.route === route.id).length),
    }));
    proposals.forEach(({ route, requests, vehicles }) => {
      let offset = 0;
      vehicles.forEach((vehicle) => {
        const passengers = requests
          .slice(offset, offset + vehicle.capacity - vehicle.gap)
          .map(requestPassenger);
        offset += passengers.length;
        const trip = makePlannedTrip(plan, route, vehicle, passengers);
        created.push(trip);
      });
    });
    plan.demand = demand.length;
    plan.requestIds = demand.map((r) => r.id);
    plan.routeDemands = plan.routes.map((route) => ({
      route: route.id,
      count: demand.filter((r) => r.route === route.id).length,
    }));
    plan.status = "confirmed";
    plan.confirmedAt = new Date().toISOString();
    plan.fleetSnapshot = opsSnapshot(fleetFor(plan.tenant));
    opsModel.trips.push(...created);
    recordOps(
      "plan.confirmed",
      plan.id,
      [plan.tenant],
      before,
      {
        ...plan,
        generatedTrips: created.map((t) => t.id),
        pendingEmployees: pendingForPlan(plan).map((r) => r.user),
      },
      String(reason),
    );
    finishManagement();
    toast("Plan confirmado. Viajes y códigos QR disponibles.");
    return true;
  } catch (e) {
    return errorManagement(e.message);
  }
};
function planNewRequests(plan) {
  if (plan.status !== "confirmed") return [];
  const existing = new Set(plan.requestIds || []);
  if (!plan.requestIds) {
    opsModel.trips
      .filter(
        (t) =>
          t.plan === plan.id ||
          (t.tenant === plan.tenant && t.journey === plan.journey && t.window === plan.window),
      )
      .forEach((t) =>
        t.passengers.forEach((p) => {
          if (p.request) existing.add(p.request);
        }),
      );
  }
  return planPassengers(plan).filter((r) => !existing.has(r.id));
}
function planUpdateForm(id) {
  const plan = opsModel.plans.find((p) => p.id === id);
  if (!plan || !authorizedWrite(plan.tenant)) return "";
  const requests = planNewRequests(plan);
  return htmlTemplate("administration/admin-modules-planning/plan-update-form.html");
}
function approvePlanUpdate(event, id) {
  const d = formData(event);
  return applyPlanUpdate(id, managementReason(d));
}
function applyPlanUpdate(id, reason) {
  const plan = opsModel.plans.find((p) => p.id === id);
  if (!plan || !authorizedWrite(plan.tenant) || String(reason).trim().length < 8) return false;
  const requests = planNewRequests(plan);
  if (!requests.length) return false;
  const before = opsSnapshot({
      plan,
      trips: opsModel.trips.filter((t) => t.plan === id),
    }),
    created = [],
    changes = [];
  try {
    // Work on copies so a failed calculation cannot partially update an existing plan.
    const copies = opsModel.trips
      .filter(
        (t) =>
          t.plan === id ||
          (t.tenant === plan.tenant && t.journey === plan.journey && t.window === plan.window),
      )
      .map(opsSnapshot);
    for (const route of plan.routes) {
      let remaining = requests.filter((r) => r.route === route.id);
      for (const trip of copies.filter((t) => t.route === route.id && t.status === "boarding")) {
        const seats = Math.max(0, trip.capacity - (trip.gap || 0) - trip.passengers.length);
        const added = remaining.slice(0, seats);
        remaining = remaining.slice(added.length);
        trip.passengers.push(...added.map(requestPassenger));
        if (added.length) changes.push(trip.id);
      }
      const vehicles = vehicleAllocation(plan.tenant, remaining.length);
      let offset = 0;
      for (const vehicle of vehicles) {
        const passengers = remaining
          .slice(offset, offset + vehicle.capacity - vehicle.gap)
          .map(requestPassenger);
        offset += passengers.length;
        created.push(makePlannedTrip(plan, route, vehicle, passengers));
      }
    }
    copies.forEach((copy) => {
      if (changes.includes(copy.id))
        Object.assign(
          opsModel.trips.find((t) => t.id === copy.id),
          copy,
        );
    });
    opsModel.trips.push(...created);
    plan.requestIds = [...new Set([...(plan.requestIds || []), ...requests.map((r) => r.id)])];
    plan.demand += requests.length;
    plan.routeDemands = plan.routes.map((route) => ({
      route: route.id,
      count:
        (plan.routeDemands?.find((r) => r.route === route.id)?.count || 0) +
        requests.filter((r) => r.route === route.id).length,
    }));
    plan.revision = (plan.revision || 1) + 1;
    recordOps(
      "plan.updated",
      plan.id,
      [plan.tenant],
      before,
      {
        plan,
        addedRequests: requests.map((r) => r.id),
        updatedTrips: changes,
        newTrips: created.map((t) => t.id),
      },
      reason,
    );
    finishManagement();
    return true;
  } catch (e) {
    return errorManagement(e.message);
  }
}
function simulatePendingConfirmations(planId) {
  const plan = opsModel.plans.find((p) => p.id === planId);
  if (!plan || !authorizedWrite(plan.tenant)) return false;
  if (!beforeCutoff(plan.tenant, plan.journey))
    return errorManagement(
      "El cutoff ya pasó. No se admiten nuevas confirmaciones de esta jornada.",
    );
  const pending = pendingForPlan(plan).slice(0, 3);
  pending.forEach((r) => {
    r.status = "confirmed";
    r.confirmedAt = new Date(opsModel.clock).toISOString();
  });
  recordOps(
    "demo.confirmations.received",
    plan.id,
    [plan.tenant],
    { pending: pending.map((r) => r.id) },
    { confirmed: pending.map((r) => r.id) },
    "Simulación de respuestas recibidas antes del cutoff",
  );
  saveOps();
  render();
  return true;
}
const planningDrawer = opsDrawerHTML;
opsDrawerHTML = function () {
  let html = planningDrawer();
  if (opsDrawer?.type === "plan") {
    const plan = opsModel.plans.find((p) => p.id === opsDrawer.id);
    if (plan) {
      const pending = pendingForPlan(plan);
      html = html.replace(
        htmlTemplate("administration/admin-modules-planning/html.html"),
        htmlTemplate("administration/admin-modules-planning/html-02.html"),
      );
    }
  }
  return html;
};
const originalManagementPlansView = opsPlansView;
opsPlansView = function () {
  const html = originalManagementPlansView();
  return (
    html +
    (canOpsManage()
      ? htmlTemplate("administration/admin-modules-planning/ops-plans-view-10.html") +
        opsPlans()
          .filter((p) => p.status === "confirmed")
          .map((p) => htmlTemplate("administration/admin-modules-planning/ops-plans-view-11.html"))
          .join("") +
        "</details>"
      : "")
  );
};
