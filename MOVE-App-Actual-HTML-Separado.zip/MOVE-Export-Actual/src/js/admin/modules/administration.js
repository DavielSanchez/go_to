/* Administrative modules. Demo records stay in the current browser session. */
const managementLabels = {
  "ops-zones": ["GEOGRAFÍA", "Zonas y rutas", "Delimita el área de servicio de cada ruta."],
  "ops-users": [
    "PERSONAS",
    "Usuarios y preregistro",
    "Autoriza el registro y administra los roles de tu operación.",
  ],
  "ops-fleet": [
    "CAPACIDAD",
    "Tipos de vehículo",
    "Capacidad y asientos de reserva para calcular los viajes.",
  ],
  "ops-history": [
    "TRAZABILIDAD",
    "Historial de viajes",
    "Recorridos, pasajeros, conductores y decisiones en una vista.",
  ],
  "ops-incidents": [
    "SEGUIMIENTO",
    "Incidencias",
    "Gestiona los casos reportados durante la operación.",
  ],
  "ops-reviews": [
    "EXPERIENCIA",
    "Reseñas",
    "Escucha a los pasajeros y consulta la calidad del servicio.",
  ],
  "ops-events": [
    "VIAJES ESPECIALES",
    "Eventos",
    "Traslados personalizados para empleados e invitados.",
  ],
  "ops-qr": ["DESPACHO", "Catálogo QR", "Un código por ruta y salida, compartido entre sus trips."],
};
const managementViews = {
  "ops-zones": () => zonesView(),
  "ops-users": () => usersView(),
  "ops-fleet": () => fleetView(),
  "ops-history": () => historyView(),
  "ops-incidents": () => incidentsView(),
  "ops-reviews": () => reviewsView(),
  "ops-events": () => eventsView(),
  "ops-qr": () => catalogView(),
};
let managementSite = "";
let managementSearch = "";
let importDraft = [];
let importErrors = [];
let managementMore = false;
let managementMap = null;
let managementMapDestroy = null;
let historyStatus = "all";

function initializeManagement() {
  if (opsModel.managementVersion === 2) return;
  opsModel.managementVersion = 2;
  opsModel.fleet = opsModel.tenants.flatMap((site) => [
    {
      id: site.id + "-van",
      tenant: site.id,
      name: "Van estándar",
      capacity: 15,
      gap: 2,
      active: true,
    },
    {
      id: site.id + "-bus",
      tenant: site.id,
      name: "Minibús",
      capacity: 28,
      gap: 3,
      active: true,
    },
  ]);
  opsModel.zones = opsModel.tenants.flatMap((site) => [
    {
      id: site.id + "-07",
      tenant: site.id,
      route: "07",
      name: "Los Girasoles",
      revision: 1,
      points: [
        [18.49, -69.985],
        [18.52, -69.985],
        [18.52, -70.025],
        [18.49, -70.025],
      ],
    },
    {
      id: site.id + "-04",
      tenant: site.id,
      route: "04",
      name: "Pantoja",
      revision: 1,
      points: [
        [18.523, -70.032],
        [18.554, -70.037],
        [18.566, -70.071],
        [18.528, -70.073],
      ],
    },
  ]);
  opsModel.users = opsModel.tenants.flatMap((site) =>
    Array.from({ length: 48 }, (_, i) => ({
      id: site.id + "-U" + i,
      tenant: site.id,
      name:
        [
          "Ana Pérez",
          "Carlos Mejía",
          "Laura Díaz",
          "Miguel Santos",
          "Sofía Rodríguez",
          "Juan Reyes",
        ][i % 6] +
        " " +
        (i + 1),
      email: `empleado${i + 1}.${site.id}@example.com`,
      role: i === 0 ? "supervisor" : i === 1 ? "coordinator" : i === 2 ? "tenant-admin" : "agent",
      status: i < 35 ? "active" : "invited",
      address: { lat: i % 2 ? 18.542 : 18.51, lng: i % 2 ? -70.05 : -70.01 },
      zone: i % 2 ? "04" : "07",
    })),
  );
  opsModel.requests = opsModel.tenants.flatMap((site) =>
    [opsModel.date, today()].flatMap((journey) =>
      Array.from({ length: 40 }, (_, i) => ({
        id: site.id + "-REQ-" + journey + "-" + i,
        tenant: site.id,
        journey,
        window: i < 30 ? "00:30" : "21:30",
        route: i % 2 ? "04" : "07",
        user: site.id + "-U" + i,
        status:
          i < 24 || (i >= 30 && i < 35) ? "confirmed" : i < 30 || i < 38 ? "pending" : "declined",
      })),
    ),
  );
  opsModel.events = [];
  opsModel.cases = opsModel.tenants.flatMap((site, i) => [
    {
      id: "INC-" + (501 + i),
      tenant: site.id,
      trip: "TR-" + (1040 + i * 10),
      type: "Tráfico",
      detail: "Retraso de 8 minutos por congestión. Pasajeros informados.",
      status: "open",
      at: new Date().toISOString(),
      comments: [],
    },
  ]);
  opsModel.reviews = opsModel.tenants.flatMap((site, i) =>
    Array.from({ length: 4 }, (_, n) => ({
      id: site.id + "-REV" + n,
      tenant: site.id,
      trip: "TR-" + (1042 + i * 10),
      rating: [5, 4, 5, 3][n],
      comment: [
        "Buen trato y viaje cómodo.",
        "El conductor fue muy amable.",
        "Llegamos a tiempo.",
        "Podemos mejorar la puntualidad.",
      ][n],
      name: ["Ana Pérez", "Carlos Mejía", "Laura Díaz", "Miguel Santos"][n],
      at: new Date().toISOString(),
    })),
  );
  opsModel.trips.forEach((trip) => {
    if (trip.driver === "José Ramírez" && !driver.linkedTrip) trip.driver = "Ángel Ramírez";
    trip.vehicleType = trip.vehicleType || "Van estándar";
    trip.gap = 2;
    trip.grace = trip.grace ?? 10;
    trip.driverChanges = [];
  });
  opsModel.plans.forEach((plan) => {
    plan.revision = 1;
    plan.routeDemands = plan.routes.map((r, i) => ({
      route: r.id,
      count:
        Math.floor(plan.demand / plan.routes.length) +
        (i === 0 ? plan.demand % plan.routes.length : 0),
    }));
  });
  opsModel.plans
    .filter((plan) => plan.status === "confirmed")
    .forEach((plan) => {
      const ids = [];
      plan.routes.forEach((route) => {
        const requests = opsModel.requests.filter(
          (r) =>
            r.tenant === plan.tenant &&
            r.journey === plan.journey &&
            r.window === plan.window &&
            r.route === route.id &&
            r.status === "confirmed",
        );
        let offset = 0;
        opsModel.trips
          .filter(
            (t) =>
              t.tenant === plan.tenant &&
              t.journey === plan.journey &&
              t.window === plan.window &&
              t.route === route.id,
          )
          .forEach((trip) => {
            trip.plan = plan.id;
            trip.passengers.forEach((p) => {
              const request = requests[offset++];
              if (request) {
                p.request = request.id;
                ids.push(request.id);
              }
            });
          });
      });
      plan.requestIds = ids;
      plan.demand = ids.length;
      plan.routeDemands = plan.routes.map((r) => ({
        route: r.id,
        count: ids.filter((id) => opsModel.requests.find((q) => q.id === id)?.route === r.id)
          .length,
      }));
    });
  saveOps();
}
initializeManagement();
function multiSite() {
  return ["platform", "company-admin"].includes(opsPrincipal()?.role);
}
function manageSite() {
  const allowed = opsScope();
  if (!allowed.includes(managementSite)) managementSite = allowed[0];
  return managementSite;
}
function selectedSiteControl() {
  if (!multiSite()) return "";
  return htmlTemplate("administration/admin-modules-administration/selected-site-control.html");
}
function setManagementSite(id) {
  if (!opsInScope(id)) return;
  managementSite = id;
  managementSearch = "";
  render();
}
function authorizedWrite(id) {
  return canOpsManage() && opsInScope(id);
}
function managementTable(headers, rows) {
  return htmlTemplate("administration/admin-modules-administration/management-table.html");
}
function moduleCard(title, content) {
  return htmlTemplate("administration/admin-modules-administration/module-card.html");
}
function siteCell(id) {
  return multiSite()
    ? htmlTemplate("administration/admin-modules-administration/site-cell.html")
    : "";
}
function roleLabel(role) {
  return (
    {
      agent: "Empleado",
      supervisor: "Supervisor",
      coordinator: "Coordinador",
      "tenant-admin": "Administrador",
    }[role] || role
  );
}
function drawerFrame(title, content) {
  return htmlTemplate("administration/admin-modules-administration/drawer-frame.html");
}
function openManagementDrawer(type, id = "") {
  opsDrawer = { type, id };
  opsFocusAfterRender = true;
  render();
}
function errorManagement(message) {
  const el = document.getElementById("managementError");
  if (el) el.textContent = message;
  else toast(message);
  return false;
}
function formData(event) {
  event.preventDefault();
  return new FormData(event.target);
}
function reasonInput() {
  return htmlTemplate("administration/admin-modules-administration/reason-input.html");
}
function managementReason(data) {
  return String(data.get("reason") || "").trim();
}
function finishManagement() {
  opsDrawer = null;
  saveOps();
  render();
}

function usersView() {
  const users = opsModel.users.filter(
    (u) =>
      opsInScope(u.tenant) &&
      `${u.name} ${u.email}`.toLowerCase().includes(managementSearch.toLowerCase()),
  );
  const toolbar = htmlTemplate("administration/admin-modules-administration/toolbar.html");
  return moduleCard(
    "Cuentas y acceso",
    toolbar + htmlTemplate("administration/admin-modules-administration/users-view.html"),
  );
}
function usersTable(users) {
  return managementTable(
    ["Persona", "Correo", "Rol", "Estado", ...(multiSite() ? ["Site"] : []), ""],
    users
      .map((u) => htmlTemplate("administration/admin-modules-administration/users-table.html"))
      .join(""),
  );
}
function updateUsersList() {
  document.getElementById("usersList").innerHTML = usersTable(
    opsModel.users.filter(
      (u) =>
        opsInScope(u.tenant) &&
        `${u.name} ${u.email}`.toLowerCase().includes(managementSearch.toLowerCase()),
    ),
  );
}
function userForm(id) {
  const user = opsModel.users.find((u) => u.id === id);
  if (user && !authorizedWrite(user.tenant)) return "";
  return htmlTemplate("administration/admin-modules-administration/user-form.html");
}
function saveManagementUser(event, id) {
  const data = formData(event);
  const user = opsModel.users.find((u) => u.id === id);
  const site = user?.tenant || manageSite();
  if (!authorizedWrite(site)) return false;
  const next = {
    id: user?.id || crypto.randomUUID(),
    tenant: site,
    name: String(data.get("name") || "").trim(),
    email: String(data.get("email") || "")
      .trim()
      .toLowerCase(),
    role: String(data.get("role")),
    status: user ? String(data.get("status")) : "invited",
  };
  const reason = managementReason(data);
  if (
    !next.name ||
    !/^\S+@\S+\.\S+$/.test(next.email) ||
    !["agent", "supervisor", "coordinator", "tenant-admin"].includes(next.role) ||
    !["active", "invited", "suspended"].includes(next.status) ||
    reason.length < 8
  )
    return errorManagement("Revisa los campos y escribe un motivo de al menos 8 caracteres.");
  if (opsModel.users.some((u) => u.id !== id && u.tenant === site && u.email === next.email))
    return errorManagement("Ese correo ya está registrado en este site.");
  const before = user ? opsSnapshot(user) : {};
  if (user) Object.assign(user, next);
  else opsModel.users.push(next);
  recordOps(user ? "user.updated" : "user.preregistered", next.id, [site], before, next, reason);
  syncUserWhitelist();
  finishManagement();
  return true;
}
function syncUserWhitelist() {
  opsModel.users.forEach((u) => {
    const existing = corporateWhitelist.find((w) => w.email === u.email);
    if (u.status === "suspended") {
      if (existing) corporateWhitelist.splice(corporateWhitelist.indexOf(existing), 1);
      return;
    }
    const allowed = {
      email: u.email,
      name: u.name,
      role: u.role,
      tenant: opsTenant(u.tenant).company,
      site: u.tenant,
    };
    if (existing) Object.assign(existing, allowed);
    else corporateWhitelist.push(allowed);
  });
}
function importForm() {
  return htmlTemplate("administration/admin-modules-administration/import-form.html");
}
function downloadData(name, data, mime = "application/json") {
  const url = URL.createObjectURL(new Blob([data], { type: mime }));
  const a = document.createElement("a");
  a.href = url;
  a.download = name;
  a.click();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}
function downloadUserTemplate() {
  downloadData(
    "MOVE-preregistro.csv",
    "\ufeffnombre,correo,rol\nEmpleado Demo,empleado.personal@example.com,empleado\n",
    "text/csv;charset=utf-8",
  );
}
function parseCSV(text) {
  const rows = [];
  let row = [],
    field = "",
    quoted = false;
  const delimiter = text.split("\n")[0].includes(";") ? ";" : ",";
  for (let i = 0; i < text.length; i++) {
    const c = text[i];
    if (c === '"') {
      if (quoted && text[i + 1] === '"') {
        field += '"';
        i++;
      } else quoted = !quoted;
    } else if (c === delimiter && !quoted) {
      row.push(field.trim());
      field = "";
    } else if ((c === "\n" || c === "\r") && !quoted) {
      if (c === "\r" && text[i + 1] === "\n") i++;
      row.push(field.trim());
      if (row.some(Boolean)) rows.push(row);
      row = [];
      field = "";
    } else field += c;
  }
  if (quoted) throw Error("Hay comillas sin cerrar en el CSV.");
  row.push(field.trim());
  if (row.some(Boolean)) rows.push(row);
  return rows;
}
async function readUserImport(file) {
  importDraft = [];
  importErrors = [];
  if (!file) return;
  if (file.size > 4 * 1024 * 1024) return errorManagement("Máximo 4 MB por archivo.");
  try {
    let rows;
    if (/\.xlsx$/i.test(file.name)) {
      rows = await readXLSX(await file.arrayBuffer());
    } else if (/\.csv$/i.test(file.name))
      rows = parseCSV((await file.text()).replace(/^\ufeff/, ""));
    else throw Error("Usa un archivo CSV o Excel .xlsx.");
    validateUserImport(rows);
    document.getElementById("importPreview").innerHTML = htmlTemplate(
      "administration/admin-modules-administration/read-user-import.html",
    );
    document.getElementById("importCommit").disabled = !importDraft.length || !!importErrors.length;
  } catch (error) {
    errorManagement(error.message);
  }
}
function validateUserImport(rows) {
  importDraft = [];
  importErrors = [];
  if (!rows.length) throw Error("El archivo está vacío.");
  if (rows.length > 1001) throw Error("Máximo 1,000 registros por importación.");
  const headers = rows[0].map((v) => String(v).trim().toLowerCase());
  const ni = headers.findIndex((h) => ["nombre", "name"].includes(h)),
    ei = headers.findIndex((h) => ["correo", "email"].includes(h)),
    ri = headers.findIndex((h) => ["rol", "role"].includes(h));
  if (ni < 0 || ei < 0 || ri < 0) throw Error("Faltan las columnas nombre, correo y rol.");
  const seen = new Set(opsModel.users.filter((u) => u.tenant === manageSite()).map((u) => u.email));
  const roleMap = {
    empleado: "agent",
    agent: "agent",
    supervisor: "supervisor",
    coordinador: "coordinator",
    coordinator: "coordinator",
    administrador: "tenant-admin",
    admin: "tenant-admin",
  };
  rows.slice(1).forEach((r, i) => {
    const name = String(r[ni] || "").trim(),
      email = String(r[ei] || "")
        .trim()
        .toLowerCase(),
      role =
        roleMap[
          String(r[ri] || "")
            .trim()
            .toLowerCase()
        ];
    if (!name || !/^\S+@\S+\.\S+$/.test(email) || !role || seen.has(email)) {
      importErrors.push(`Fila ${i + 2}: nombre, correo o rol inválido, o correo duplicado.`);
      return;
    }
    seen.add(email);
    importDraft.push({ name, email, role });
  });
}
function commitUserImport(event) {
  const d = formData(event),
    reason = managementReason(d),
    site = manageSite();
  if (!authorizedWrite(site) || !importDraft.length || importErrors.length || reason.length < 8)
    return errorManagement("Revisa el archivo y el motivo del preregistro.");
  if (
    importDraft.some((u) =>
      opsModel.users.some((existing) => existing.tenant === site && existing.email === u.email),
    )
  )
    return errorManagement("Los correos cambiaron. Vuelve a cargar el archivo.");
  const users = importDraft.map((u) => ({
    ...u,
    id: crypto.randomUUID(),
    tenant: site,
    status: "invited",
  }));
  opsModel.users.push(...users);
  recordOps(
    "users.imported",
    "users",
    [site],
    { count: 0 },
    { count: users.length, users },
    reason,
  );
  importDraft = [];
  syncUserWhitelist();
  finishManagement();
  return true;
}

function fleetView() {
  return moduleCard(
    "Catálogo de capacidad",
    htmlTemplate("administration/admin-modules-administration/fleet-view.html") +
      managementTable(
        [
          "Tipo",
          "Capacidad",
          "Gap",
          "Asientos útiles",
          ...(multiSite() ? ["Site"] : []),
          "Estado",
          "",
        ],
        opsModel.fleet
          .filter((v) => opsInScope(v.tenant))
          .map((v) =>
            htmlTemplate("administration/admin-modules-administration/fleet-view-02.html"),
          )
          .join(""),
      ),
  );
}
function fleetForm(id) {
  const type = opsModel.fleet.find((t) => t.id === id);
  return htmlTemplate("administration/admin-modules-administration/fleet-form.html");
}
function saveFleetType(event, id) {
  const d = formData(event),
    type = opsModel.fleet.find((t) => t.id === id),
    site = type?.tenant || manageSite();
  if (!authorizedWrite(site)) return false;
  const next = {
      id: type?.id || crypto.randomUUID(),
      tenant: site,
      name: String(d.get("name") || "").trim(),
      capacity: Number(d.get("capacity")),
      gap: Number(d.get("gap")),
      active: d.get("active") === "true",
    },
    reason = managementReason(d);
  if (
    !next.name ||
    !Number.isInteger(next.capacity) ||
    !Number.isInteger(next.gap) ||
    next.capacity < 2 ||
    next.capacity > 80 ||
    next.gap < 0 ||
    next.gap >= next.capacity ||
    reason.length < 8
  )
    return errorManagement("La capacidad debe superar el gap. Revisa los campos y el motivo.");
  const before = type ? opsSnapshot(type) : {};
  if (type) Object.assign(type, next);
  else opsModel.fleet.push(next);
  recordOps("fleet.type.saved", next.id, [site], before, next, reason);
  finishManagement();
  return true;
}

function historyView() {
  const trips = opsModel.trips.filter(
    (t) => opsInScope(t.tenant) && (historyStatus === "all" || t.status === historyStatus),
  );
  return moduleCard(
    "Todos los viajes",
    htmlTemplate("administration/admin-modules-administration/history-view.html") +
      managementTable(
        [
          "Viaje",
          "Jornada / salida",
          "Ruta",
          "Pasajeros",
          "Estado",
          ...(multiSite() ? ["Site"] : []),
          "",
        ],
        trips
          .map((t) =>
            htmlTemplate("administration/admin-modules-administration/history-view-03.html"),
          )
          .join(""),
      ),
  );
}
function incidentsView() {
  const cases = opsModel.cases.filter((c) => opsInScope(c.tenant));
  return (
    htmlTemplate("administration/admin-modules-administration/incidents-view.html") +
    moduleCard(
      "Casos de la operación",
      htmlTemplate("administration/admin-modules-administration/incidents-view-02.html") +
        managementTable(
          ["Caso", "Viaje", "Tipo", "Estado", ...(multiSite() ? ["Site"] : []), ""],
          cases
            .map((c) =>
              htmlTemplate("administration/admin-modules-administration/incidents-view-03.html"),
            )
            .join(""),
        ),
    )
  );
}
function incidentForm(id) {
  const c = opsModel.cases.find((c) => c.id === id);
  return htmlTemplate("administration/admin-modules-administration/incident-form.html");
}
function saveIncident(event, id) {
  const d = formData(event),
    item = opsModel.cases.find((c) => c.id === id),
    trip = opsModel.trips.find((t) => t.id === String(d.get("trip"))),
    site = item?.tenant || trip?.tenant,
    reason = managementReason(d);
  if (!canOpsCoordinate() || !site || !opsInScope(site) || reason.length < 8)
    return errorManagement("Revisa el viaje y el motivo.");
  if (item) {
    const before = opsSnapshot(item);
    item.status = String(d.get("status"));
    if (!["open", "tracking", "resolved"].includes(item.status)) {
      item.status = before.status;
      return false;
    }
    item.comments.push({
      at: new Date().toISOString(),
      text: reason,
      actor: opsPrincipal().name,
    });
    recordOps("incident.updated", item.id, [site], before, item, reason);
  } else {
    const detail = String(d.get("detail") || "").trim();
    if (!detail) return errorManagement("Describe la incidencia.");
    const next = {
      id: crypto.randomUUID(),
      tenant: site,
      trip: trip.id,
      type: String(d.get("type")),
      detail,
      status: "open",
      at: new Date().toISOString(),
      comments: [],
    };
    opsModel.cases.push(next);
    recordOps("incident.created", next.id, [site], {}, next, reason);
  }
  finishManagement();
  return true;
}
function reviewsView() {
  const reviews = opsModel.reviews.filter((r) => opsInScope(r.tenant));
  const avg = reviews.length
    ? (reviews.reduce((n, r) => n + r.rating, 0) / reviews.length).toFixed(1)
    : "—";
  return htmlTemplate("administration/admin-modules-administration/reviews-view.html");
}

const priorOpsScope = opsScope;
opsScope = function () {
  return multiSite() ? priorOpsScope() : opsAllowed().slice(0, 1);
};
const priorScopeControl = opsScopeControl;
opsScopeControl = function () {
  return multiSite() ? priorScopeControl() : "";
};
const priorToggleTenant = toggleOpsTenant;
toggleOpsTenant = function (id, checked) {
  if (multiSite()) priorToggleTenant(id, checked);
};
const priorSelectAll = selectAllOpsTenants;
selectAllOpsTenants = function () {
  if (multiSite()) priorSelectAll();
};
opsNavigation = function () {
  const items = [
    ["ops-overview", "home", "Resumen"],
    ["ops-operation", "bus", "Operación en vivo"],
    ["ops-plans", "ticket", "Planificación"],
    ["ops-qr", "ticket", "Catálogo QR"],
  ];
  if (canOpsManage())
    items.push(
      ["ops-zones", "pin", "Zonas y rutas"],
      ["ops-users", "user", "Usuarios"],
      ["ops-fleet", "bus", "Flotilla"],
      ["ops-events", "clock", "Eventos"],
    );
  items.push(["ops-history", "clock", "Historial"], ["ops-incidents", "info", "Incidencias"]);
  if (canOpsManage() || canOpsPlatform())
    items.push(["ops-reviews", "star", "Reseñas"], ["ops-statistics", "clock", "Estadísticas"]);
  if (canOpsManage()) items.push(["ops-configuration", "shield", "Configuración"]);
  if (canOpsPlatform()) items.unshift(["ops-platform", "shield", "Plataforma / tenants"]);
  items.push(["ops-audit", "shield", "Auditoría"]);
  return items;
};
function managementMobileNavigation() {
  const nav = opsNavigation(),
    ids =
      opsPrincipal()?.role === "coordinator"
        ? ["ops-overview", "ops-operation", "ops-qr", "ops-incidents"]
        : ["ops-overview", "ops-plans", "ops-operation", "ops-events"];
  const items = ids.map((id) => nav.find((n) => n[0] === id)).filter(Boolean);
  return htmlTemplate(
    "administration/admin-modules-administration/management-mobile-navigation.html",
  );
}
function humanizeAdministration() {
  if (opsPrincipal()?.role === "platform") return;
  const walker = document.createTreeWalker(app, NodeFilter.SHOW_TEXT);
  let node;
  while ((node = walker.nextNode())) {
    if (node.parentElement.closest("script,style,textarea")) continue;
    node.nodeValue = node.nodeValue
      .replace(/tenants/gi, "sites")
      .replace(/tenant/gi, "site")
      .replace(/TENANT/g, "SITE");
  }
  if (!multiSite()) {
    const walkerSingle = document.createTreeWalker(app, NodeFilter.SHOW_TEXT);
    let n;
    while ((n = walkerSingle.nextNode())) {
      n.nodeValue = n.nodeValue
        .replace(/1 sites seleccionados/g, "Tu operación")
        .replace(/Tus sites, en una vista/g, "Resumen de tu operación");
    }
    app.querySelector(".ops-breadcrumb").innerHTML =
      opsText(opsTenant(opsScope()[0]).name) +
      htmlTemplate("administration/admin-modules-administration/humanize-administration.html");
    const subtitle = app.querySelector(".ops-title p");
    if (page === "ops-overview") subtitle.textContent = "Prioridades y despacho de tu operación.";
    app.querySelector(".ops-config-grid>section select")?.replaceWith(
      Object.assign(document.createElement("strong"), {
        textContent: opsTenant(opsScope()[0]).name,
      }),
    );
  }
}
function managementAfterRender() {
  humanizeAdministration();
  syncAdministrativeHeader();
  if (opsPrincipal()?.role === "coordinator")
    app.querySelectorAll('[onclick*="performOpsTripAction"]').forEach((button) => {
      if (button.getAttribute("onclick").includes("'start'")) button.remove();
    });
  if (page === "ops-zones") initializeZoneMap();
  if (page === "ops-events" && opsDrawer?.type === "event-create") initializeEventMap();
  if (opsDrawer?.type === "trip") {
    const trip = opsModel.trips.find((t) => t.id === opsDrawer.id);
    if (trip) {
      const detail = app.querySelector(".ops-drawer");
      detail.insertAdjacentHTML("beforeend", tripHistoryDetails(trip));
    }
  }
  if (page === "ops-configuration") {
    document.querySelector("[name=gap]")?.closest("label")?.remove();
    const controls = document.querySelector(".ops-config-grid>section");
    if (controls && !multiSite()) {
      controls.querySelector(".ops-label")?.remove();
      controls.querySelector("h2").textContent = "Tu operación";
    }
  }
  syncUserWhitelist();
}

function tripHistoryDetails(trip) {
  const cases = opsModel.cases.filter((c) => c.trip === trip.id),
    reviews = opsModel.reviews.filter((r) => r.trip === trip.id),
    audit = opsModel.audit.filter((a) => a.entity === trip.id);
  return htmlTemplate("administration/admin-modules-administration/trip-history-details.html");
}
const baseManagementRender = renderOpsPortal;
renderOpsPortal = function () {
  if (managementMapDestroy) {
    managementMapDestroy();
    managementMapDestroy = null;
  }
  baseManagementRender();
};
const baseManagementDrawer = opsDrawerHTML;
opsDrawerHTML = function () {
  if (!opsDrawer) return "";
  const { type, id } = opsDrawer;
  const views = {
    "user-create": () => userForm(""),
    "user-edit": () => userForm(id),
    "user-import": importForm,
    "fleet-create": () => fleetForm(""),
    "fleet-edit": () => fleetForm(id),
    "incident-create": () => incidentForm(""),
    "incident-edit": () => incidentForm(id),
    "event-create": eventForm,
    "event-details": () => eventDetails(id),
    "plan-launch": launchPlanForm,
    "plan-update": () => planUpdateForm(id),
    more: () => htmlTemplate("administration/admin-modules-administration/more.html"),
  };
  return views[type]
    ? drawerFrame(
        {
          "user-create": "Preregistrar empleado",
          "user-edit": "Editar cuenta",
          "user-import": "Importación de cuentas",
          "fleet-create": "Nuevo tipo de vehículo",
          "fleet-edit": "Editar tipo",
          "incident-create": "Registrar incidencia",
          "incident-edit": "Gestionar incidencia",
          "event-create": "Crear evento",
          "event-details": "Detalle del evento",
          "plan-launch": "Generar planificación",
          "plan-update": "Actualizar plan",
          more: "Todas las opciones",
        }[type],
        views[type](),
      )
    : baseManagementDrawer();
};
const baseManagementMobileWarning = opsMobileWarning;
opsMobileWarning = function () {
  if (opsPrincipal()?.role === "coordinator") return "";
  return baseManagementMobileWarning();
};

syncUserWhitelist();
/* Preregistered management roles use their verified registration password. */
const manageRegisteredBinding = bindLogin;
bindLogin = function () {
  manageRegisteredBinding();
  const form = document.getElementById("sharedLogin");
  form?.parentElement.addEventListener(
    "submit",
    (event) => {
      const email = document.getElementById("loginId").value.trim().toLowerCase(),
        user = opsModel.users.find((u) => u.email === email);
      if (!user) {
        delete access.registrationUser;
        return;
      }
      if (user.status === "suspended") {
        event.preventDefault();
        event.stopImmediatePropagation();
        toast("Esta cuenta está suspendida. Contacta a administración.");
        return;
      }
      access.registrationUser = user.id;
    },
    true,
  );
};
const manageRegisteredRender = render;
render = function () {
  if (access.logged && access.registrationUser) {
    const user = opsModel.users.find((u) => u.id === access.registrationUser);
    if (user?.status === "suspended") {
      access.logged = false;
      delete access.adminAccount;
      saveDriver();
    } else if (user) {
      access.corporateRole = user.role;
      if (["tenant-admin", "coordinator"].includes(user.role)) {
        const account = {
          id: user.id,
          email: user.email,
          name: user.name,
          role: user.role,
          tenants: [user.tenant],
          company: opsTenant(user.tenant).company,
        };
        const existing = opsAccounts.find((a) => a.id === user.id);
        if (existing) Object.assign(existing, account);
        else opsAccounts.push(account);
        access.adminAccount = user.id;
      } else {
        delete access.adminAccount;
      }
      saveDriver();
    }
  }
  manageRegisteredRender();
};
const managedLogout = logoutMove;
logoutMove = function () {
  delete access.registrationUser;
  managedLogout();
};
const managedDemoLogin = loginDemo;
loginDemo = function () {
  delete access.registrationUser;
  managedDemoLogin();
};
const managementTripAction = changeOpsTrip;
changeOpsTrip = function (id, action, reason, driverName = "") {
  const result = managementTripAction(id, action, reason, driverName);
  if (result.ok) {
    const trip = opsModel.trips.find((t) => t.id === id);
    if (action === "pause") {
      opsModel.cases.push({
        id: crypto.randomUUID(),
        tenant: trip.tenant,
        trip: id,
        type: "Operación",
        detail: reason,
        status: "open",
        at: new Date().toISOString(),
        comments: [],
      });
    }
    if (action === "start") trip.startedAt = new Date(opsModel.clock).toISOString();
    saveOps();
  }
  return result;
};
const managementAuditExport = exportOpsAudit;
exportOpsAudit = function () {
  if (opsPrincipal()?.role === "platform") return managementAuditExport();
  const records = opsVisibleAudit();
  const readable = JSON.stringify(records, null, 2)
    .replace(/tenants/gi, "sites")
    .replace(/tenant/gi, "site");
  downloadData("MOVE-auditoria.json", readable);
  recordOps(
    "audit.exported",
    "audit",
    opsScope(),
    { records: records.length },
    { format: "JSON" },
    "Exportación del historial visible",
  );
  render();
};
const managementHistoryDetail = tripHistoryDetails;
tripHistoryDetails = function (trip) {
  const duration =
    trip.startedAt && trip.completedAt
      ? Math.round((new Date(trip.completedAt) - new Date(trip.startedAt)) / 60000)
      : null;
  const departure = new Date(
    trip.date + "T" + trip.window + ":00" + (opsTenant(trip.tenant).utcOffset || "-04:00"),
  );
  const delay = trip.startedAt
    ? Math.max(0, Math.round((new Date(trip.startedAt) - departure) / 60000))
    : null;
  return (
    managementHistoryDetail(trip) +
    htmlTemplate("administration/admin-modules-administration/trip-history-details-08.html")
  );
};
Object.assign(enTranslations, {
  Administrador: "Administrator",
  "Country Admin": "Country Admin",
  Planificación: "Planning",
  "Catálogo QR": "QR catalog",
  "Zonas y rutas": "Zones and routes",
  Usuarios: "Users",
  Flotilla: "Fleet",
  Eventos: "Events",
  Incidencias: "Incidents",
  Reseñas: "Reviews",
  Más: "More",
  GEOGRAFÍA: "GEOGRAPHY",
  PERSONAS: "PEOPLE",
  CAPACIDAD: "CAPACITY",
  SEGUIMIENTO: "TRACKING",
  EXPERIENCIA: "EXPERIENCE",
  "VIAJES ESPECIALES": "SPECIAL TRIPS",
  "Usuarios y preregistro": "Users and preregistration",
  "Tipos de vehículo": "Vehicle types",
  "Historial de viajes": "Trip history",
  "Preregistrar empleado": "Preregister employee",
  "Importar Excel / CSV": "Import Excel / CSV",
  "Cuentas y acceso": "Accounts and access",
  Correo: "Email",
  Rol: "Role",
  Estado: "Status",
  Persona: "Person",
  "Site de trabajo": "Working site",
  "Editar cuenta": "Edit account",
  "Preregistrar empleado": "Preregister employee",
  "Autorizar registro": "Authorize registration",
  "Agregar tipo": "Add type",
  "Catálogo de capacidad": "Capacity catalog",
  Tipo: "Type",
  Capacidad: "Capacity",
  "Asientos útiles": "Usable seats",
  Activo: "Active",
  Inactivo: "Inactive",
  "Guardar tipo": "Save type",
  "Nombre del tipo": "Type name",
  "Generar planificación": "Generate plan",
  "Revisar y confirmar": "Review and confirm",
  "Generar propuesta": "Generate proposal",
  "Ventana de salida": "Departure window",
  "Confirmar y generar viajes": "Confirm and create trips",
  "Aprobar actualización": "Approve update",
  "Crear evento": "Create event",
  "Guardar propuesta de evento": "Save event proposal",
  "Nombre del evento": "Event name",
  Fecha: "Date",
  Hora: "Time",
  Trayecto: "Journey",
  Origen: "Origin",
  Destino: "Destination",
  Empleados: "Employees",
  Invitados: "Guests",
  "Agregar invitado": "Add guest",
  "Costo estimado": "Estimated cost",
  "Costo final": "Final cost",
  Moneda: "Currency",
  "Registrar costo final": "Record final cost",
  "Detalle del evento": "Event details",
  "Desde los domicilios a un destino": "From homes to a destination",
  "Desde un origen a los domicilios": "From an origin to homes",
  "Origen y destino comunes": "Shared origin and destination",
  "Marcar origen": "Mark origin",
  "Marcar destino": "Mark destination",
  "Nueva zona": "New zone",
  "Rutas de servicio": "Service routes",
  "Por puntos": "Points",
  "Trazo libre": "Freehand",
  "Mover mapa": "Pan map",
  Deshacer: "Undo",
  Limpiar: "Clear",
  "Guardar zona": "Save zone",
  "Nombre de la zona": "Zone name",
  "Código de ruta": "Route code",
  Editar: "Edit",
  "Imprimir / Guardar PDF": "Print / Save PDF",
  "Exportar catálogo": "Export catalog",
  "Mostrar QR": "Show QR",
  "Abrir enlace": "Open link",
  "Todos los viajes": "All trips",
  "Ver viaje": "View trip",
  "Casos abiertos": "Open cases",
  "En seguimiento": "In progress",
  Resueltos: "Resolved",
  "Casos de la operación": "Operational cases",
  "Registrar incidencia": "Report incident",
  Gestionar: "Manage",
  Caso: "Case",
  Viaje: "Trip",
  "Guardar incidencia": "Save incident",
  Descripción: "Description",
  "Calificación promedio": "Average rating",
  "Reseñas recibidas": "Reviews received",
  "Todas las opciones": "All options",
  "Prioridades y despacho de tu operación.": "Priorities and dispatch for your operations.",
  "Tu operación": "Your operations",
  "Tu operación, conectada.": "Your operations, connected.",
  "Tu operación y sus reglas.": "Your operations and rules.",
  "ADMINISTRACIÓN DEL site": "SITE ADMINISTRATION",
  "Reglas de tu operación": "Your operating rules",
  "Configuración aplicada por site, con trazabilidad de cambios.":
    "Site settings with a full change history.",
});
const managementRegistration = finishRegistration;
finishRegistration = async function (data) {
  const success = await managementRegistration(data);
  if (success) {
    const user = opsModel.users.find((u) => u.email === registration.email);
    if (user && user.status !== "suspended") {
      const before = opsSnapshot(user);
      user.status = "active";
      opsModel.audit.unshift({
        id: crypto.randomUUID(),
        timestamp: new Date().toISOString(),
        actor: { id: user.id, name: user.name, email: user.email },
        effective: {
          id: user.id,
          name: user.name,
          email: user.email,
          role: user.role,
        },
        action: "user.registration.completed",
        entity: user.id,
        tenants: [user.tenant],
        before,
        after: opsSnapshot(user),
        reason: "Registro completado tras verificar OTP",
        impersonation: null,
        session: opsSessionId,
        source: "Web · demostración",
        timezone: opsTenant(user.tenant).timezone,
        demo: true,
      });
      saveOps();
    }
  }
  return success;
};

/* Reuse the passenger/driver header and account controls instead of a mobile clone. */
function syncAdministrativeHeader() {
  const principal = opsPrincipal();
  if (!principal) return;
  syncHeader();
  const header = document.querySelector(".shell > header");
  const brand = header.querySelector(".brand-collab");
  brand.innerHTML = principal.company === "move" ? moveBrand() : tenantBrand(principal.company);
  brand.setAttribute(
    "aria-label",
    principal.company === "move" ? "MOVE" : tenants[principal.company].name + " × MOVE",
  );
  brand.href = principal.role === "platform" ? "#ops-platform" : "#ops-overview";
  const avatar = header.querySelector(".avatar");
  avatar.textContent = principal.name
    .split(" ")
    .map((n) => n[0])
    .slice(0, 2)
    .join("");
  document.documentElement.dataset.tenant =
    principal.company === "move" ? "move" : principal.company;
  updateAccountControls();
}
const administrativeAccountMenu = accountMenuHTML;
accountMenuHTML = function () {
  if (!isOpsUser()) return administrativeAccountMenu();
  const principal = opsPrincipal();
  return htmlTemplate("administration/admin-modules-administration/account-menu-html.html");
};
managementLabels["ops-account"] = ["CUENTA", "Mi perfil", "Tu identidad y acceso a MOVE."];
managementViews["ops-account"] = function () {
  const principal = opsPrincipal();
  return moduleCard(
    "Datos de tu cuenta",
    htmlTemplate("administration/admin-modules-administration/fragment.html"),
  );
};
const accountAdministrativeNavigation = opsNavigation;
opsNavigation = function () {
  const links = accountAdministrativeNavigation();
  links.push(["ops-account", "user", "Mi perfil"]);
  return links;
};
