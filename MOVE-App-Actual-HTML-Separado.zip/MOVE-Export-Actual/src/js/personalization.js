// Tenant branding and preferences are local prototype data; no identity server is connected.
const tenants = {
  tp: { name: "TP", logo: "tp-logo.svg", color: "#ef0054", campus: "TP · Campus Churchill" },
  alorica: {
    name: "Alorica",
    logo: "alorica-logo.png",
    color: "#006b93",
    campus: "Alorica · Campus Santo Domingo",
  },
  trueshore: {
    name: "TrueShore",
    logo: "trueshore-logo.svg",
    color: "#c63b00",
    campus: "TrueShore · Campus Santo Domingo",
  },
  concentrix: {
    name: "Concentrix",
    logo: "concentrix-logo.webp",
    color: "#087b85",
    campus: "Concentrix · Campus Santo Domingo",
  },
};
const departureWindows = [
  { value: "21:30", label: "9:30 p. m." },
  { value: "22:30", label: "10:30 p. m." },
  { value: "23:30", label: "11:30 p. m." },
  { value: "00:30", label: "12:30 a. m.", next: true },
];
// Upgrade daily reservations from the former departure schedule.
if (
  state.ticket?.source === "daily" &&
  !departureWindows.some((w) => w.value === state.ticket.time)
) {
  state.departureTime = "22:30";
  issueTicket(state.ticket.date, "22:30", "daily");
}
const tenantDemoUsers = [
  { tenant: "alorica", email: "alorica.demo@gmail.com", name: "Alex Martínez" },
  { tenant: "trueshore", email: "trueshore.demo@gmail.com", name: "Valeria Santos" },
  { tenant: "concentrix", email: "concentrix.demo@gmail.com", name: "Daniel Cruz" },
];
corporateWhitelist.push(...tenantDemoUsers.map((u) => ({ ...u, role: "agent" })));
function currentTenant() {
  return access.logged && Object.hasOwn(tenants, access.tenant) ? access.tenant : "tp";
}
function tenantBrand(key = currentTenant()) {
  const tenant = tenants[key];
  return htmlTemplate("personalization/personalization/tenant-brand.html");
}
function moveBrand() {
  return htmlTemplate("personalization/personalization/move-brand.html");
}
function applyTenantBrand() {
  const key = currentTenant(),
    guest = ["login", "register"].includes(page) || !access.logged;
  document.documentElement.dataset.tenant = guest ? "move" : key;
  applyTenantPalette(guest || page === "landing" ? "tp" : key);
  const brand = document.querySelector("header .brand-collab");
  brand.innerHTML =
    guest && page !== "landing" ? moveBrand() : tenantBrand(page === "landing" ? "tp" : key);
  brand.setAttribute(
    "aria-label",
    guest && page !== "landing" ? "MOVE" : `${tenants[key].name} × MOVE`,
  );
  document.querySelector(".bytp").innerHTML = htmlTemplate(
    "personalization/personalization/apply-tenant-brand.html",
  );
  document
    .querySelector('meta[name="theme-color"]')
    ?.setAttribute("content", guest ? "#ef0054" : tenants[key].color);
  if (access.logged && page !== "landing") {
    const walker = document.createTreeWalker(app, NodeFilter.SHOW_TEXT);
    let n;
    while ((n = walker.nextNode())) {
      if (n.parentElement.closest("script,style,input,textarea,[data-user-content]")) continue;
      n.nodeValue = n.nodeValue
        .replace(/TP · Campus Churchill/g, tenants[key].campus)
        .replace(/Transporte TP/g, "Transporte " + tenants[key].name)
        .replace(/TP Santo Domingo/g, tenants[key].name + " Santo Domingo")
        .replace(/Daviel Sánchez/g, access.name || "Daviel Sánchez")
        .replace(/Hola, Daviel/g, "Hola, " + (access.name || "Daviel").split(" ")[0]);
    }
  }
}
const personalizationLoginView = loginView;
loginView = function () {
  return personalizationLoginView().replace(
    "</form>",
    htmlTemplate("personalization/personalization/login-view.html"),
  );
};
function fillTenantLogin(key) {
  const user = tenantDemoUsers.find((u) => u.tenant === key);
  if (!user) return;
  access.role = "corporate";
  access.corporateRole = "agent";
  render();
  document.getElementById("loginId").value = user.email;
  document.getElementById("loginPassword").value = "MoveDemo123";
  document.getElementById("loginPassword").focus();
}
function fillAloricaLogin() {
  fillTenantLogin("alorica");
}
const personalizationBindLogin = bindLogin;
bindLogin = function () {
  personalizationBindLogin();
  document.getElementById("sharedLogin")?.addEventListener(
    "submit",
    (e) => {
      const email = document.getElementById("loginId").value.trim().toLowerCase();
      const user = tenantDemoUsers.find((u) => u.email === email);
      if (!user || demoAccounts.some((a) => a.email === email)) return;
      e.preventDefault();
      e.stopImmediatePropagation();
      if (
        access.role !== "corporate" ||
        document.getElementById("loginPassword").value !== "MoveDemo123"
      ) {
        toast(t("Correo o contraseña incorrectos."));
        return;
      }
      access.tenant = user.tenant;
      access.name = user.name;
      access.corporateRole = "agent";
      access.logged = true;
      saveDriver();
      navigate("home");
      render();
    },
    true,
  );
};
function applyTenantPalette(key) {
  const colors = {
    tp: { soft: "#fff1f5", dark: "#38202e", hero: "#17171b" },
    alorica: { soft: "#e6f4fa", dark: "#143548", hero: "#102f46" },
    trueshore: { soft: "#fff0e9", dark: "#402b28", hero: "#401b32" },
    concentrix: { soft: "#e3f7f6", dark: "#123b40", hero: "#003d46" },
  };
  const palette = colors[key] || colors.tp;
  const root = document.documentElement;
  root.style.setProperty("--pink", tenants[key]?.color || tenants.tp.color);
  root.style.setProperty("--tint", theme === "dark" ? palette.dark : palette.soft);
  root.style.setProperty("--tenant-soft", theme === "dark" ? palette.dark : palette.soft);
  root.style.setProperty("--tenant-hero", palette.hero);
}
let splashActive = false,
  splashDone = !!access.logged;
const personalizationLogout = logoutMove;
logoutMove = function () {
  splashDone = false;
  splashActive = false;
  personalizationLogout();
};
function showTenantSplash() {
  splashActive = true;
  splashDone = true;
  page = "brand-loading";
  document.body.classList.remove("landing-screen", "login-screen", "registration-screen");
  document.body.classList.add("brand-loading");
  document.getElementById("landingMenu")?.remove();
  drawWorkspace(htmlTemplate("personalization/personalization/show-tenant-splash.html"), []);
  document.querySelector("header .avatar").hidden = true;
  applyTenantBrand();
  translateInterface();
  setTimeout(
    () => {
      splashActive = false;
      document.body.classList.remove("brand-loading");
      render();
    },
    reducedMotion() ? 150 : 1600,
  );
}
function preferenceKey() {
  return "move-preferences-" + currentTenant() + "-" + access.role;
}
const defaultPreferences = {
  window: "22:30",
  motion: false,
  compact: false,
  largeText: false,
  reminders: true,
  tripAlerts: true,
  exceptionAlerts: true,
  reviewReminder: true,
  vibration: false,
};
function preferences() {
  try {
    return { ...defaultPreferences, ...JSON.parse(localStorage.getItem(preferenceKey()) || "{}") };
  } catch {
    return { ...defaultPreferences };
  }
}
function reducedMotion() {
  return preferences().motion || window.matchMedia?.("(prefers-reduced-motion: reduce)").matches;
}
function applyPreferences() {
  const p = preferences();
  document.documentElement.classList.toggle("reduce-motion", !!reducedMotion());
  document.documentElement.classList.toggle("compact-ui", !!p.compact);
  document.documentElement.classList.toggle("large-text", !!p.largeText);
}
function setPreference(key, value) {
  if (!(key in defaultPreferences)) return;
  if (key === "window" && !departureWindows.some((w) => w.value === value)) return;
  const next = { ...preferences(), [key]: value };
  try {
    localStorage.setItem(preferenceKey(), JSON.stringify(next));
  } catch {
    toast(t("No pudimos guardar la configuración."));
    return;
  }
  applyPreferences();
  toast(t("Configuración guardada."));
}
function preferenceSwitch(key, title, detail) {
  return htmlTemplate("personalization/personalization/preference-switch.html");
}
function windowOptions(value) {
  return departureWindows
    .map((w) => htmlTemplate("personalization/personalization/window-options.html"))
    .join("");
}
function settingsView() {
  return htmlTemplate("personalization/personalization/settings-view.html");
}
function resetPreferences() {
  localStorage.removeItem(preferenceKey());
  applyPreferences();
  render();
  toast(t("Preferencias restablecidas."));
}
const personalizationAccountMenu = accountMenuHTML;
accountMenuHTML = function () {
  return personalizationAccountMenu().replace(
    htmlTemplate("personalization/personalization/account-menu-html.html"),
    htmlTemplate("personalization/personalization/account-menu-html-02.html"),
  );
};
function departureView() {
  const value = state.departureDraft || preferences().window;
  return htmlTemplate("personalization/personalization/departure-view.html");
}
confirmRide = function () {
  if (!state.eligible) {
    toast(t("Solicita una excepción para usar transporte hoy."));
    navigate("exception");
    return;
  }
  if (!state.addressPoint) {
    navigate("address");
    toast(t("Agrega tu dirección antes de confirmar."));
    return;
  }
  state.departureDraft = state.departureTime || preferences().window;
  navigate("departure");
  render();
};
function chooseDeparture(value) {
  if (!departureWindows.some((w) => w.value === value)) return;
  state.departureDraft = value;
  render();
}
function departureDate(time) {
  const date = today();
  if (time !== "00:30") return date;
  const d = new Date(date + "T12:00:00Z");
  d.setUTCDate(d.getUTCDate() + 1);
  return d.toISOString().slice(0, 10);
}
function completeDeparture() {
  const value = state.departureDraft || preferences().window;
  if (!departureWindows.some((w) => w.value === value) || !state.eligible || !state.addressPoint)
    return;
  state.confirmed = true;
  state.declined = false;
  state.departureTime = value;
  issueTicket(departureDate(value), value, "daily");
  save();
  if (preferences().vibration) navigator.vibrate?.(35);
  navigate("ticket");
  render();
  toast(t("Tu transporte para hoy está confirmado."));
}
function workspaceNav() {
  return access.role === "driver"
    ? driverNav
    : isSupervisor()
      ? [...navs.slice(0, 3), ["approvals", "shield", "Mi equipo"], ...navs.slice(3)]
      : navs;
}
const personalizationRender = render;
render = function () {
  if (!access.logged) {
    splashDone = false;
    splashActive = false;
    document.body.classList.remove("brand-loading");
  }
  if (access.logged && !splashDone) {
    showTenantSplash();
    return;
  }
  if (splashActive) return;
  const requested = location.hash.slice(1);
  if (
    access.logged &&
    ["settings", "departure"].includes(requested) &&
    (requested !== "departure" || access.role === "corporate")
  ) {
    stopScanner();
    routeAbort?.abort();
    page = requested;
    document.body.classList.remove("landing-screen", "login-screen", "registration-screen");
    document.getElementById("landingMenu")?.remove();
    syncHeader();
    drawWorkspace(requested === "settings" ? settingsView() : departureView(), workspaceNav());
    updateAccountControls();
    const selected =
      requested === "settings" ? (access.role === "driver" ? "driver-profile" : "profile") : "home";
    setNavigation(
      workspaceNav()
        .map(([p, i, l]) => htmlTemplate("personalization/personalization/render.html"))
        .join(""),
    );
    decorateNavigation();
  } else personalizationRender();
  if (access.logged && ["profile", "driver-profile"].includes(page)) {
    app.insertAdjacentHTML(
      "beforeend",
      htmlTemplate("personalization/personalization/render-02.html"),
    );
  }
  if (page === "home" || page === "trip") {
    const time = state.ticket?.time || state.departureTime || preferences().window;
    const w = departureWindows.find((w) => w.value === time);
    if (w) {
      app.innerHTML = app.innerHTML
        .replace(
          /10:30 <span style="font-size:14px">p\. m\.<\/span>/g,
          w.label.replace(
            / (p|a)\. m\./,
            htmlTemplate("personalization/personalization/render-03.html"),
          ),
        )
        .replace(/22:30/g, time);
      bind();
    }
    if (page === "home" && preferences().reminders && !state.confirmed)
      app.insertAdjacentHTML(
        "beforeend",
        htmlTemplate("personalization/personalization/render-04.html") +
          icon("clock") +
          htmlTemplate("personalization/personalization/render-05.html"),
      );
    if (page === "trip" && preferences().tripAlerts)
      app.insertAdjacentHTML(
        "beforeend",
        htmlTemplate("personalization/personalization/render-06.html") +
          icon("bus") +
          htmlTemplate("personalization/personalization/render-07.html"),
      );
  }
  if (
    page === "exception" &&
    preferences().exceptionAlerts &&
    state.exception &&
    state.exceptionStatus !== "approved"
  )
    app.insertAdjacentHTML(
      "beforeend",
      htmlTemplate("personalization/personalization/render-08.html") +
        icon("clock") +
        htmlTemplate("personalization/personalization/render-09.html"),
    );
  if (page === "review" && preferences().reviewReminder && !state.reviewed)
    app.insertAdjacentHTML(
      "beforeend",
      htmlTemplate("personalization/personalization/render-10.html") +
        icon("check") +
        htmlTemplate("personalization/personalization/render-11.html"),
    );
  applyTenantBrand();
  applyPreferences();
  translateInterface();
};
Object.assign(enTranslations, {
  "Escanea el QR de tu ruta.": "Scan your route’s QR code.",
  "El QR de tu proveedor identifica la ruta, la fecha y la ventana de salida. Al escanearlo recibirás tus pasajeros.":
    "Your provider’s QR code identifies the route, date and departure window. Scan it to receive your passengers.",
  "Escanear QR de ruta": "Scan route QR",
  "Cada salida de la ruta 04 tiene su propio QR.":
    "Each departure on route 04 has its own QR code.",
  "Simular escaneo de este QR": "Simulate scanning this QR",
  "Escanear ruta": "Scan route",
  "QR de ruta no válido": "Invalid route QR",
  "Escanea el QR de la ruta, fecha y salida indicada por tu proveedor.":
    "Scan the QR for the route, date and departure provided by your transport company.",
  "Escanea el QR de tu ruta para recibir los pasajeros de esa salida.":
    "Scan your route’s QR to receive the passengers for that departure.",
  "La hora de esta ruta está fijada por su QR.":
    "This route’s departure time is fixed by its QR code.",
  "QR de ruta no válido. Revisa la fecha y la salida con tu proveedor.":
    "Invalid route QR. Check the date and departure with your provider.",
  "Ya tienes una ruta asignada. Su hora no se puede cambiar.":
    "You already have an assigned route. Its departure time cannot change.",
  "Ruta asignada. La hora de salida queda fijada por su QR.":
    "Route assigned. The QR fixes its departure time.",
  "Personalización de demostración": "Demo customization",
  "Prueba otra empresa": "Try another company",
  "Alorica · Personalización de demostración": "Alorica · Demo customization",
  "Usar cuenta demo de Alorica": "Use Alorica demo account",
  "TU EMPRESA. TU REGRESO.": "YOUR COMPANY. YOUR WAY HOME.",
  "Unidos para llevarte a casa.": "Together, taking you home.",
  Configuración: "Settings",
  "Haz que MOVE se adapte a tu día.": "Make MOVE fit your day.",
  "Volver a mi perfil": "Back to my profile",
  "Apariencia y accesibilidad": "Appearance and accessibility",
  "Reducir movimiento": "Reduce motion",
  "Animaciones suaves o una experiencia más tranquila.":
    "Gentle animations or a calmer experience.",
  "Texto más grande": "Larger text",
  "Mejora la lectura de la información del viaje.": "Make trip information easier to read.",
  "Vista compacta": "Compact view",
  "Reduce el espacio entre tarjetas en pantallas grandes.":
    "Reduce spacing between cards on large screens.",
  "Preferencias de transporte": "Transport preferences",
  "Ventana preferida": "Preferred departure window",
  "Se propondrá al confirmar. Puedes elegir otra hora cada día.":
    "Suggested when confirming. Choose a different time each day.",
  "Avisos dentro de la app": "In-app notices",
  "Confirmación diaria": "Daily confirmation",
  "Recordatorio para reservar tu transporte.": "A reminder to reserve your transport.",
  "Actualizaciones del viaje": "Trip updates",
  "Avisos del viaje y del abordaje.": "Trip and boarding notices.",
  "Estado de excepciones": "Exception status",
  "Recordatorios de solicitudes pendientes.": "Reminders about pending requests.",
  "Recordatorio de reseña": "Review reminder",
  "Invitación a evaluar el viaje al finalizar.": "An invitation to rate your completed trip.",
  "Respuesta háptica": "Haptic feedback",
  "Vibración al reservar, si el dispositivo la permite.": "Vibrate when booking, if supported.",
  "Preferencias de demostración. No se envían notificaciones push ni correos.":
    "Demo preferences. No push notifications or emails are sent.",
  "Cuenta y privacidad": "Account and privacy",
  Empresa: "Company",
  Perfil: "Profile",
  "Tus preferencias se guardan en este navegador.": "Your preferences are saved in this browser.",
  "Restablecer preferencias": "Reset preferences",
  "Preferencias restablecidas.": "Preferences reset.",
  "Configuración guardada.": "Settings saved.",
  "No pudimos guardar la configuración.": "We could not save your settings.",
  "¿Quieres cambiar de hora?": "Would you like to change your departure time?",
  "Elige la ventana para tu transporte de hoy.": "Choose a departure window for today’s transport.",
  "CONFIRMACIÓN DIARIA": "DAILY CONFIRMATION",
  "Tu salida, a tu ritmo.": "Your departure, your way.",
  "Puedes mantener tu hora preferida o elegir otra de las ventanas disponibles.":
    "Keep your preferred time or choose another available window.",
  "Día siguiente": "Next day",
  "Esta noche": "Tonight",
  "El ticket tendrá la fecha del día siguiente.": "Your ticket will show the next day’s date.",
  "Llega al punto de encuentro 10 minutos antes.": "Arrive at the meeting point 10 minutes early.",
  "Confirmar esta salida": "Confirm this departure",
  "Volver sin confirmar": "Go back without confirming",
  "Ventanas disponibles": "Available departure windows",
  "Idioma, apariencia, avisos y preferencias.": "Language, appearance, notices and preferences.",
  "Ventana de tu ruta · Demo": "Your route’s departure window · Demo",
  "Cada ventana tiene su propio abordaje. No cambia mientras haya pasajeros a bordo.":
    "Each departure window has its own boarding. It cannot change with passengers aboard.",
  "Recuerda confirmar tu transporte de hoy.": "Remember to confirm your transport today.",
  "Los cambios del viaje aparecerán aquí durante la demostración.":
    "Trip updates will appear here during the demo.",
  "Tu excepción está pendiente de revisión.": "Your exception is awaiting review.",
  "Tu opinión ayuda a mejorar el próximo viaje.": "Your feedback helps improve the next trip.",
});
const tenantTranslation = t;
t = function (value) {
  if (interfaceLanguage === "en") {
    if (/^Preparando tu espacio en /.test(value))
      return value.replace("Preparando tu espacio en ", "Preparing your workspace at ");
    if (/^TRANSPORTE PARA /.test(value)) return value.replace("TRANSPORTE PARA ", "TRANSPORT FOR ");
    if (/^\d+:30 [pa]\. m\./.test(value))
      return value
        .replace("p. m.", "PM")
        .replace("a. m.", "AM")
        .replace("Día siguiente", "Next day");
  }
  return tenantTranslation(value);
};
render();
