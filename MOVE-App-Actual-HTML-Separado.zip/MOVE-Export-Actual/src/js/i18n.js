// Presentation translations; employee names, document values and free text remain untouched.
const enTranslations = {
  "Escanea su QR al llegar para recibir los pasajeros asignados a tu vehículo.":
    "Scan its QR on arrival to receive the passengers assigned to your vehicle.",
  "Valida el ticket de cada empleado antes de darle entrada.":
    "Validate each employee’s ticket before allowing them to board.",
  "Comprueba fecha, vehículo, horario y autorización.":
    "Check the date, vehicle, departure time and authorization.",
  "Escanea el QR de la zona para recibir tus pasajeros y empezar a abordar.":
    "Scan the zone QR to receive your passengers and begin boarding.",
  "Tu abordaje está disponible junto al de las demás unidades de la zona.":
    "Your boarding is available alongside the other vehicles in this zone.",
  "Todos los empleados asignados abordaron.": "All assigned employees have boarded.",
  "Hay empleados que aún no han abordado. Solo los validados se registrarán como pasajeros.":
    "Some employees have not boarded yet. Only validated employees are recorded as passengers.",
  "Tu zona y tus pasajeros ya están asignados.": "Your zone and passengers are already assigned.",
  "Pasajeros asignados. Puedes comenzar el abordaje de inmediato.":
    "Passengers assigned. You can start boarding immediately.",
  "Datos del vehículo actualizados.": "Vehicle details updated.",
  "Completa todos los campos del vehículo.": "Complete all vehicle fields.",
  "Introduce un año de vehículo válido.": "Enter a valid vehicle year.",
  "Tu confirmación es diaria. Nos ayuda a organizar las rutas y reducir tu tiempo de espera.":
    "Your daily confirmation helps organize routes and reduce waiting time.",
  "No aplicas para transporte hoy": "You are not eligible for transport today",
  "Sin dirección registrada": "No address on file",
  "Tu dirección de destino": "Your destination address",
  "Agrega una dirección para organizar tu ruta.": "Add an address to organize your route.",
  "Agregar dirección": "Add address",
  "Cambiar dirección": "Change address",
  "Mi dirección": "My address",
  "Guardar dirección": "Save address",
  "Usar mi ubicación": "Use my location",
  "Destino guardado.": "Destination saved.",
  "La unidad asignada a tu viaje conserva su identificación. Estas modificaciones actualizan tu ficha del vehículo.":
    "Your assigned vehicle keeps its trip identification. These changes update your vehicle record.",
  Inicio: "Home",
  "Mi viaje": "My trip",
  Excepciones: "Exceptions",
  Historial: "History",
  Perfil: "Profile",
  "Mi equipo": "My team",
  Corporativo: "Corporate",
  Conductores: "Drivers",
  Conductor: "Driver",
  Colaborador: "Employee",
  Supervisor: "Supervisor",
  "Agente / Colaborador": "Agent / Employee",
  "Perfil corporativo de demostración": "Demo corporate role",
  "BIENVENIDO A MOVE": "WELCOME TO MOVE",
  "Tu jornada empieza aquí": "Your workday starts here",
  "Accede como colaborador o conductor de un proveedor de transporte.":
    "Sign in as an employee or a transport provider’s driver.",
  "Cédula o correo electrónico": "ID number or email",
  "Correo corporativo o ID de empleado": "Corporate email or employee ID",
  Contraseña: "Password",
  "Contraseña de prueba": "Demo password",
  "Tu identificación": "Your ID",
  "Tu correo o ID": "Your email or ID",
  "Iniciar sesión simulada": "Simulated sign in",
  "Entrar como corporativo demo": "Enter corporate demo",
  "Entrar como conductor demo": "Enter driver demo",
  "Entrar como supervisor demo": "Enter supervisor demo",
  "Acceso de demostración. Usa datos ficticios: todavía no hay autenticación conectada.":
    "Demo access. Use fictional information: authentication is not connected yet.",
  "El acceso corporativo reúne a los empleados de todos los roles.":
    "Corporate access includes employees in all roles.",
  "¿Es tu primera vez? Inicia sesión para completar tu registro, o entra con el conductor demo ya registrado.":
    "First visit? Sign in to complete registration or use the registered demo driver.",
  "Vista de demostración · Datos de ejemplo": "Demo view · Sample data",
  "Opciones de cuenta": "Account options",
  "Mi perfil": "My profile",
  Tema: "Theme",
  Claro: "Light",
  Oscuro: "Dark",
  Idioma: "Language",
  Español: "Spanish",
  "Cerrar sesión": "Sign out",
  "Cambiar tema": "Change theme",
  "Activar modo claro": "Enable light mode",
  "Activar modo oscuro": "Enable dark mode",
  "Modo oscuro": "Dark mode",
  Activado: "Enabled",
  Desactivado: "Disabled",
  "Preferencia en este dispositivo.": "Preference on this device.",
  "Tu regreso a casa, organizado.": "Your ride home, organized.",
  "Tu transporte de hoy": "Your transport today",
  "TU TRANSPORTE DE HOY": "YOUR TRANSPORT TODAY",
  "Reserva confirmada": "Reservation confirmed",
  "¿Te llevamos a casa hoy?": "Need a ride home today?",
  "Todo listo para tu regreso.": "Everything is ready for your ride home.",
  "Confirma tu transporte y asegura tu asiento para esta noche.":
    "Confirm your transport and reserve your seat for tonight.",
  "Tu asiento está reservado. Llega al punto de encuentro 10 minutos antes.":
    "Your seat is reserved. Arrive at the meeting point 10 minutes early.",
  "Salida de tu turno": "End of your shift",
  "Salida del transporte": "Shuttle departure",
  "Sí, usaré el transporte": "Yes, I need transport",
  "Ver mi viaje": "View my trip",
  "Confirma antes de las 8:00 p. m.": "Confirm before 8:00 p.m.",
  "Cancelar mi confirmación": "Cancel my confirmation",
  "Hoy no necesito transporte": "I do not need transport today",
  "Tu ruta asignada": "Your assigned route",
  "Punto de encuentro": "Meeting point",
  "Tiempo estimado": "Estimated time",
  "¿Cambió tu jornada?": "Did your schedule change?",
  "Solicitar una excepción": "Request an exception",
  "Horas extra, cambio de turno u otro motivo.": "Overtime, shift change or another reason.",
  "Revisa tu parada": "Check your stop",
  "Tu confirmación es diaria. Nos ayuda a organizar las rutas y reducir tu tiempo de espera.":
    "Confirm daily to help organize routes and reduce waiting time.",
  "No usarás transporte hoy": "You will not use transport today",
  "Nos vemos en tu próximo viaje.": "See you on your next ride.",
  "Puedes cambiar tu decisión antes del cierre de confirmaciones.":
    "You can change your decision before confirmations close.",
  "Excepción de transporte": "Transport exception",
  "Si tu jornada cambió, cuéntanos qué pasó.": "Tell us why your work schedule changed.",
  "¿Por qué necesitas transporte?": "Why do you need transport?",
  "Selecciona el motivo que corresponde a tu jornada.":
    "Select the reason that applies to your workday.",
  "Horas extra": "Overtime",
  "Cambio de turno": "Shift change",
  Capacitación: "Training",
  "Apoyo operativo": "Operational support",
  "Otro motivo": "Other reason",
  "Tu turno se extendió.": "Your shift was extended.",
  "Tu horario de salida cambió.": "Your departure time changed.",
  "Participaste en una formación.": "You attended training.",
  "Te quedaste apoyando a tu equipo.": "You stayed to support your team.",
  "Cuéntanos tu situación.": "Tell us about your situation.",
  "Fecha del viaje": "Trip date",
  "Fecha de salida": "Departure date",
  "Hora de salida": "Departure time",
  Supervisor: "Supervisor",
  "Detalles de la solicitud": "Request details",
  "Describe brevemente por qué necesitas la excepción…":
    "Briefly explain why you need an exception…",
  "Enviar solicitud": "Submit request",
  "Pendiente de revisión": "Pending review",
  "Solicitud enviada": "Request submitted",
  "Volver al inicio": "Back to home",
  "La solicitud estará sujeta a aprobación y disponibilidad del servicio.":
    "Requests are subject to approval and service availability.",
  "Nueva solicitud": "New request",
  "Aprobar excepción (demo)": "Approve exception (demo)",
  "Mi ticket": "My ticket",
  "Preséntalo al conductor al abordar.": "Show it to your driver when boarding.",
  Autorizado: "Authorized",
  Vehículo: "Vehicle",
  Ruta: "Route",
  "Sin autorización": "Unauthorized",
  "Aún no tienes un ticket": "You do not have a ticket yet",
  "Ver mi ticket QR": "View my QR ticket",
  "Salida asignada": "Assigned departure",
  Abordaje: "Boarding",
  "Vehículo incorrecto": "Wrong vehicle",
  "Horario incorrecto": "Wrong departure time",
  "Fecha incorrecta": "Wrong date",
  "Vehículo y hora correctos": "Correct vehicle and time",
  "Ticket válido": "Valid ticket",
  "Ticket sin autorización": "Unauthorized ticket",
  "Ticket ya utilizado": "Ticket already used",
  "Abordaje autorizado": "Boarding authorized",
  "Empleado no asignado": "Employee not assigned",
  "Abordaje cerrado": "Boarding closed",
  "Tu ruta, a un vistazo.": "Your route at a glance.",
  Simulación: "Simulation",
  "VIAJE FINALIZADO": "TRIP COMPLETED",
  "LLEGADA A TU PARADA": "ARRIVAL AT YOUR STOP",
  Llegaste: "You arrived",
  minutos: "minutes",
  "Tu próxima parada": "Your next stop",
  "Gracias por viajar con MOVE.": "Thank you for traveling with MOVE.",
  Identificación: "Identification",
  Soporte: "Support",
  "Simular llegada a mi parada": "Simulate arrival at my stop",
  "Calificar mi viaje": "Rate my trip",
  "Ver mi reseña": "View my review",
  "¿Cómo estuvo tu viaje?": "How was your trip?",
  "Llegaste a casa. Ahora cuéntanos tu experiencia.":
    "You made it home. Tell us about your experience.",
  "Selecciona una calificación": "Choose a rating",
  "Muy malo": "Very poor",
  Malo: "Poor",
  Regular: "Fair",
  Bueno: "Good",
  "¡Excelente!": "Excellent!",
  "¿Qué destacarías?": "What stood out?",
  Puntualidad: "Punctuality",
  "Buen trato": "Friendly service",
  Comodidad: "Comfort",
  "Conducción segura": "Safe driving",
  "Un comentario más": "Additional feedback",
  "(opcional)": "(optional)",
  "¿Qué podemos mejorar?": "What can we improve?",
  "Enviar reseña": "Submit review",
  "Lo haré después": "I will do it later",
  "¡Gracias, Daviel!": "Thank you, Daviel!",
  "Mis viajes": "My trips",
  "Un registro de tus regresos a casa.": "A record of your rides home.",
  Finalizado: "Completed",
  Calificar: "Rate",
  "Sin reseña": "Not rated",
  "Mi perfil de conductor": "My driver profile",
  "ID de empleado: 104582": "Employee ID: 104582",
  Campus: "Campus",
  "Horario de salida": "Departure time",
  "Contactar a transporte": "Contact transport",
  "Reiniciar demostración": "Reset demo",
  "Registro del conductor": "Driver registration",
  "Completa tus datos antes de recibir una ruta.":
    "Complete your details before receiving a route.",
  Identidad: "Identity",
  Revisión: "Review",
  "Tu identificación": "Your identification",
  "Nombre completo": "Full name",
  Cédula: "ID number",
  "Foto de cédula": "ID photo",
  "Foto de licencia": "Driver’s license photo",
  "Tu vehículo": "Your vehicle",
  Marca: "Make",
  Modelo: "Model",
  Año: "Year",
  "Placa escrita": "License plate number",
  "Foto de la placa": "License plate photo",
  "Tomar foto": "Take photo",
  Galería: "Gallery",
  "Sin foto": "No photo",
  "Foto seleccionada": "Photo selected",
  Continuar: "Continue",
  Anterior: "Back",
  "Completar registro": "Complete registration",
  "Revisa tu registro": "Review your registration",
  Nombre: "Name",
  Placa: "License plate",
  "REGISTRA TU LLEGADA": "CHECK IN",
  "Escanea la zona de hoy.": "Scan today’s zone.",
  "Escanear QR de zona": "Scan zone QR",
  "Probar llegada de demostración": "Try demo check-in",
  "Simular escaneo de zona 04": "Simulate zone 04 scan",
  "Tu jornada": "Your workday",
  Abordaron: "Boarded",
  Incidencias: "Incidents",
  "Viajes completados": "Completed trips",
  "Reportar una incidencia": "Report an incident",
  "Avería, retraso, seguridad u otro problema.": "Breakdown, delay, safety or another issue.",
  "Tu grupo de pasajeros": "Your passenger group",
  "Abrir abordaje": "Open boarding",
  "Vehículos de la misma zona": "Vehicles in the same zone",
  "Probar abordaje simultáneo": "Try simultaneous boarding",
  "Escanear ticket de empleado": "Scan employee ticket",
  "Probar resultados de escaneo": "Try scan results",
  "Empleados asignados a tu unidad": "Employees assigned to your vehicle",
  "A bordo": "On board",
  Pendiente: "Pending",
  "Iniciar viaje": "Start trip",
  "Mi ruta": "My route",
  "En ruta": "On route",
  "En curso": "In progress",
  Pausado: "Paused",
  "Preparando salida": "Preparing to depart",
  "Próxima parada": "Next stop",
  "Paradas asignadas": "Assigned stops",
  "Abrir navegación en Google Maps": "Open navigation in Google Maps",
  "Pausar viaje": "Pause trip",
  "Reanudar viaje": "Resume trip",
  "Finalizar viaje": "Finish trip",
  "Registrar parada completada": "Mark stop complete",
  "Volver a abordaje": "Back to boarding",
  "Reportar incidencia": "Report incident",
  "Tipo de incidencia": "Incident type",
  "Selecciona un tipo": "Select a type",
  "Avería del vehículo": "Vehicle breakdown",
  "Retraso o tráfico": "Delay or traffic",
  "Problema con un pasajero": "Passenger issue",
  Seguridad: "Safety",
  Otro: "Other",
  "¿Qué ocurrió?": "What happened?",
  "Foto opcional": "Optional photo",
  "Registrar incidencia": "Submit incident",
  "Incidencias registradas": "Recorded incidents",
  "Aún no has reportado incidencias.": "You have not reported any incidents.",
  "Historial de viajes": "Trip history",
  "Tus rutas completadas.": "Your completed routes.",
  "Tu primer viaje empieza hoy": "Your first trip starts today",
  Pasajeros: "Passengers",
  Duración: "Duration",
  "Paradas completadas": "Completed stops",
  "Incidencias del viaje": "Trip incidents",
  "Conductor de proveedor externo": "External provider driver",
  "Editar datos del vehículo": "Edit vehicle details",
  "Editar vehículo": "Edit vehicle",
  "Actualiza la información de tu vehículo.": "Update your vehicle information.",
  Cancelar: "Cancel",
  "Guardar cambios": "Save changes",
  "Foto registrada": "Photo on file",
  "Opciones de demostración": "Demo options",
  "Repetir registro del conductor": "Repeat driver registration",
  "Excepciones de mi equipo": "My team’s exceptions",
  "Revisa las solicitudes de tus supervisados.": "Review requests from your direct reports.",
  Pendientes: "Pending",
  Aprobadas: "Approved",
  Rechazadas: "Rejected",
  Todas: "All",
  Aprobada: "Approved",
  Rechazada: "Rejected",
  Motivo: "Reason",
  "Salida solicitada": "Requested departure",
  "Comentario de la decisión": "Decision comment",
  "Opcional al aprobar; obligatorio al rechazar.": "Optional for approval; required for rejection.",
  Rechazar: "Reject",
  "Aprobar excepción": "Approve exception",
  "Aprobada por supervisor": "Approved by supervisor",
  "Rechazada por supervisor": "Rejected by supervisor",
  "Decisión de ejemplo": "Sample decision",
  "No hay solicitudes en esta vista": "No requests in this view",
  "Las solicitudes de tu equipo aparecerán aquí.": "Your team’s requests will appear here.",
  "Escribe el motivo del rechazo.": "Enter the reason for rejection.",
  "Excepción aprobada.": "Exception approved.",
  "Excepción rechazada.": "Exception rejected.",
  "Demostración: las decisiones se guardan en esta sesión. La aprobación habilita la excepción para que transporte asigne una salida; no asigna un vehículo automáticamente.":
    "Demo: decisions are saved for this session. Approval authorizes the exception for transport to assign a departure; it does not automatically assign a vehicle.",
  Acceder: "Sign in",
  Beneficios: "Benefits",
  Producto: "Product",
  Impacto: "Impact",
  "Explorar la solución": "Explore the solution",
  "Conoce cómo funciona": "See how it works",
  "Probar la demo completa": "Try the full demo",
  "Entrar a MOVE": "Enter MOVE",
  "TRANSPORTE EMPRESARIAL, CONECTADO": "CONNECTED EMPLOYEE TRANSPORT",
  "El buen trabajo": "Good work",
  "merece un": "deserves a",
  "buen regreso.": "good ride home.",
  "De la salida del turno a la última parada. MOVE conecta a tu gente, tus conductores y tu operación en una sola experiencia.":
    "From the end of a shift to the last stop. MOVE connects your people, drivers and operations in one experience.",
  "Para empresas con transporte de personal": "For companies offering employee transport",
  "Web app · Mobile first": "Web app · Mobile first",
  "TU TRANSPORTE ESTÁ LISTO": "YOUR TRANSPORT IS READY",
  "Tu turno termina. Tu regreso empieza.": "Your shift ends. Your ride home begins.",
  "MENOS INCERTIDUMBRE": "LESS UNCERTAINTY",
  "Más tranquilidad.": "More peace of mind.",
  "Dentro y fuera del trabajo.": "At work and beyond.",
  "HECHO PARA OPERACIONES QUE NO SE DETIENEN": "BUILT FOR OPERATIONS THAT KEEP MOVING",
  Manufactura: "Manufacturing",
  Logística: "Logistics",
  Servicios: "Services",
  "Tu transporte puede": "Your transport can",
  "trabajar mejor.": "work better.",
  "Tu gente sabe qué esperar.": "Your people know what to expect.",
  "Cada vehículo, con su grupo.": "Each vehicle has its group.",
  "Decisiones con contexto.": "Decisions with context.",
  "Una experiencia para cada": "An experience for every",
  "parte del recorrido.": "part of the journey.",
  "MENOS DUDAS AL FINAL DEL TURNO": "LESS UNCERTAINTY AT THE END OF A SHIFT",
  "Tu regreso, en tus manos.": "Your ride home, in your hands.",
  "Confirma tu transporte en segundos y consulta la información que necesitas para abordar.":
    "Confirm your transport in seconds and view the information you need to board.",
  "Confirmación diaria y ticket QR": "Daily confirmation and QR ticket",
  "Excepciones cuando cambia la jornada": "Exceptions when work schedules change",
  "Seguimiento del viaje y reseña final": "Trip tracking and final review",
  "Prototipo navegable con datos de demostración.": "Interactive prototype with demo data.",
  "CLARIDAD PARA QUIEN CONDUCE": "CLARITY FOR THE DRIVER",
  "Una ruta. Tu grupo.": "One route. Your group.",
  "Todo a la vista.": "Everything in view.",
  "Registro de conductor y vehículo": "Driver and vehicle registration",
  "Validación de tickets por unidad": "Ticket validation per vehicle",
  "Paradas, incidencias e historial": "Stops, incidents and history",
  "Un regreso organizado.": "An organized ride home.",
  "En cuatro momentos.": "In four steps.",
  Confirmar: "Confirm",
  Coordinar: "Coordinate",
  "Abordar y viajar": "Board and travel",
  "Escuchar y mejorar": "Listen and improve",
  "¿Cuánto cuestan": "How much do",
  "los asientos vacíos?": "empty seats cost?",
  "Vehículos por día": "Vehicles per day",
  "Asientos por vehículo": "Seats per vehicle",
  "Costo por vehículo / día": "Cost per vehicle / day",
  "Días de servicio al mes": "Service days per month",
  "Ocupación promedio": "Average occupancy",
  "Costo mensual asociado a asientos vacíos": "Monthly cost associated with empty seats",
  "Revisa los datos": "Check your inputs",
  "Preguntas frecuentes": "Frequently asked questions",
  "PREGUNTAS FRECUENTES": "FREQUENTLY ASKED QUESTIONS",
  "Antes de subir": "Before getting",
  "a bordo.": "on board.",
  "Tu gente se mueve.": "Your people move.",
  "Tu empresa también.": "Your company does too.",
  "Transporte empresarial, conectado.": "Connected employee transport.",
  "Volver a explorar": "Explore again",
};
const languageOriginals = new WeakMap(),
  attributeOriginals = new WeakMap();
function t(value) {
  if (interfaceLanguage !== "en") return value;
  if (enTranslations[value]) return enTranslations[value];
  return value
    .replace(/^Hola, /, "Hello, ")
    .replace(/\bRuta (\d+)/g, "Route $1")
    .replace(/\bUnidad (\d+)/g, "Vehicle $1")
    .replace(/\bZona (\d+)/g, "Zone $1")
    .replace(
      /^(\d+)\. (Identidad|Vehículo|Revisión)$/,
      (m, n, s) => n + ". " + (enTranslations[s] || s),
    )
    .replace(/^(\d+) de (\d+) a bordo\.$/, "$1 of $2 on board.")
    .replace(
      /^(\d+) asientos vacíos por día · Estimación en RD\$$/,
      "$1 empty seats per day · Estimate in RD$",
    );
}
function setInterfaceLanguage(lang) {
  if (!["es", "en"].includes(lang)) return;
  interfaceLanguage = lang;
  try {
    localStorage.setItem("move-language", lang);
  } catch {}
  document.documentElement.lang = lang;
  if (typeof updateAccountControls === "function") updateAccountControls();
  translateInterface();
}
function translateInterface() {
  document.documentElement.lang = interfaceLanguage;
  const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
  let node;
  while ((node = walker.nextNode())) {
    const parent = node.parentElement;
    if (!parent || parent.closest("script,style,textarea,[data-user-content]")) continue;
    const current = node.nodeValue;
    let saved = languageOriginals.get(node);
    if (!saved || current !== saved.last) {
      saved = { source: current, last: current };
    }
    const clean = saved.source.trim();
    const translated = t(clean);
    const next = saved.source.replace(clean, translated);
    if (node.nodeValue !== next) node.nodeValue = next;
    saved.last = next;
    languageOriginals.set(node, saved);
  }
  document.querySelectorAll("[placeholder],[aria-label],[title]").forEach((el) => {
    if (el.closest("[data-user-content]")) return;
    let memo = attributeOriginals.get(el) || {};
    for (const attr of ["placeholder", "aria-label", "title"]) {
      if (!el.hasAttribute(attr)) continue;
      const current = el.getAttribute(attr);
      if (!memo[attr] || current !== memo[attr].last)
        memo[attr] = { source: current, last: current };
      const next = t(memo[attr].source);
      if (current !== next) el.setAttribute(attr, next);
      memo[attr].last = next;
    }
    attributeOriginals.set(el, memo);
  });
}
let translationScheduled = false;
const translationObserver = new MutationObserver(() => {
  if (translationScheduled || typeof interfaceLanguage === "undefined") return;
  translationScheduled = true;
  queueMicrotask(() => {
    translationScheduled = false;
    translateInterface();
  });
});
translationObserver.observe(document.body, { subtree: true, childList: true, characterData: true });
