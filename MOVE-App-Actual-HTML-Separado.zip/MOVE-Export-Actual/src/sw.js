const CACHE = "move-export-v17-readable";
const ASSETS = [
  "./",
  "./index.html",
  "./style.css?v=17",
  "./app.js?v=17",
  "./tp-logo.svg",
  "./vendor/leaflet.js",
  "./vendor/leaflet.css",
  "./vendor/qrcode.js",
  "./vendor/jsqr.js",
  "./driver.js?v=17",
  "./landing.js?v=17",
  "./landing.css?v=17",
  "./transport.webp",
  "./i18n.js?v=17",
  "./experience.js?v=17",
  "./experience.css?v=17",
  "./registration.js?v=17",
  "./polish.js?v=17",
  "./polish.css?v=17",
  "./personalization.js?v=17",
  "./personalization.css?v=17",
  "./alorica-logo.png",
  "./trueshore-logo.svg",
  "./concentrix-logo.webp",
  "./icon.svg",
  "./manifest.webmanifest",
  "./admin/management.css?v=17",
  "./admin/modules/administration.js?v=17",
  "./admin/modules/planning.js?v=17",
  "./admin/modules/zones.js?v=17",
  "./admin/modules/events.js?v=17",
  "./admin/modules/import-xlsx.js?v=17",
  "./admin/modules/qr-link.js?v=17",
  "./admin/dashboard.js?v=17",
  "./admin/dashboard.css?v=17",
  "./admin/shell.html?v=17",
  "./admin/overview.html?v=17",
  "./admin/operation.html?v=17",
  "./admin/plans.html?v=17",
  "./admin/statistics.html?v=17",
  "./admin/configuration.html?v=17",
  "./admin/audit.html?v=17",
  "./admin/platform.html?v=17",
];
self.addEventListener("install", (e) => {
  e.waitUntil(caches.open(CACHE).then((c) => c.addAll(ASSETS)));
  self.skipWaiting();
});
self.addEventListener("activate", (e) => {
  e.waitUntil(
    caches
      .keys()
      .then((keys) => Promise.all(keys.filter((k) => k !== CACHE).map((k) => caches.delete(k)))),
  );
  self.clients.claim();
});
self.addEventListener("fetch", (e) => {
  if (e.request.method !== "GET" || new URL(e.request.url).origin !== self.location.origin) return;
  e.respondWith(
    fetch(e.request)
      .then((r) => {
        if (r.ok) {
          const copy = r.clone();
          caches.open(CACHE).then((c) => c.put(e.request, copy));
        }
        return r;
      })
      .catch(() => caches.match(e.request)),
  );
});
