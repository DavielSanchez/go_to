import assert from "node:assert/strict";
import fs from "node:fs/promises";
import vm from "node:vm";
import path from "node:path";
import { webcrypto } from "node:crypto";
import { JSDOM } from "jsdom";
const root = path.resolve(import.meta.dirname, "../dist");
const dom = new JSDOM(await fs.readFile(root + "/index.html", "utf8"), {
  url: "http://localhost/",
  runScripts: "outside-only",
  pretendToBeVisual: true,
});
const w = dom.window;
w.scrollTo = () => {};
w.matchMedia = () => ({ matches: false, addEventListener() {}, removeEventListener() {} });
w.DecompressionStream = DecompressionStream;
w.Response = Response;
w.Blob = Blob;
w.TextDecoder = TextDecoder;
w.TextEncoder = TextEncoder;
Object.defineProperty(w, "crypto", { value: webcrypto });
w.fetch = async (url) => ({
  ok: true,
  text: () => fs.readFile(root + "/" + url.split("?")[0], "utf8"),
});
const context = dom.getInternalVMContext();
const run = (s) => vm.runInContext(s, context);
for (const file of [
  "vendor/leaflet.js",
  "vendor/qrcode.js",
  "app.js",
  "driver.js",
  "landing.js",
  "i18n.js",
  "experience.js",
  "registration.js",
  "polish.js",
  "personalization.js",
  "admin/dashboard.js",
  "admin/modules/administration.js",
  "admin/modules/planning.js",
  "admin/modules/zones.js",
  "admin/modules/events.js",
  "admin/modules/import-xlsx.js",
  "admin/modules/qr-link.js",
])
  vm.runInContext(await fs.readFile(root + "/" + file, "utf8"), context, { filename: file });
w.L.Browser.svg = true;
await run("window.opsTemplatesPromise");
await new Promise((r) => setTimeout(r, 50));
const submit = () =>
  w.document
    .querySelector("#sharedLogin")
    .dispatchEvent(new w.Event("submit", { bubbles: true, cancelable: true }));
function login(id) {
  run(`logoutMove();navigate('login');render();fillOpsLogin('${id}')`);
  submit();
  run(
    "splashActive=false;splashDone=true;document.body.classList.remove('brand-loading');render()",
  );
  assert.equal(run("opsActor()?.id"), id);
  assert(w.document.querySelector(".ops-shell"));
}
try {
  const xlsxBytes = await fs.readFile(
    path.resolve(import.meta.dirname, "fixtures/users-test.xlsx"),
  );
  w.testXlsxBuffer = xlsxBytes.buffer.slice(
    xlsxBytes.byteOffset,
    xlsxBytes.byteOffset + xlsxBytes.byteLength,
  );
  const xlsxRows = await run("readXLSX(testXlsxBuffer)");
  assert.equal(xlsxRows[1][1], "excel@example.com");
  login("coordinator");
  assert(w.document.querySelector(".ops-sidebar .ops-collaboration .tp-logo"));
  assert(w.document.querySelector(".shell>header .brand-collab .tp-logo"));
  assert.equal(w.document.querySelector(".shell>header .avatar").textContent, "LM");
  run("toggleAccountMenu()");
  assert(w.document.querySelector("#accountMenu"));
  assert(w.document.querySelector("#accountMenu").textContent.includes("Coordinación"));
  run("toggleAccountMenu()");
  assert.equal(run("opsScope().length"), 1);
  assert(!w.document.querySelector(".ops-scope"));
  assert(!w.document.querySelector(".ops-mobile-warning"));
  assert(w.document.querySelector(".ops-mobile-nav"));
  assert(!w.document.querySelector("#app").textContent.toLowerCase().includes("tenant"));
  assert.equal(run("changeOpsTrip('TR-1041','start','Coordinador intenta iniciar').ok"), false);
  run("openOpsTrip('TR-1041')");
  assert(!w.document.querySelector('[onclick*="start"]'));
  login("site-admin");
  assert.equal(run("opsScope().length"), 1);
  assert(!w.document.querySelector(".ops-scope"));
  for (const route of [
    "ops-overview",
    "ops-operation",
    "ops-plans",
    "ops-qr",
    "ops-zones",
    "ops-users",
    "ops-fleet",
    "ops-history",
    "ops-incidents",
    "ops-reviews",
    "ops-events",
    "ops-configuration",
    "ops-statistics",
    "ops-audit",
  ]) {
    run(`opsDrawer=null;navigate('${route}');render()`);
    assert(!w.document.querySelector("#app").textContent.toLowerCase().includes("tenant"), route);
    assert(!w.document.querySelector(".ops-scope"));
    assert(w.document.querySelector(".ops-mobile-nav"));
  }
  run("navigate('ops-plans');opsModel.date=today();render();openManagementDrawer('plan-launch')");
  let form = w.document.querySelector(".ops-drawer form");
  form.querySelector("[name=window]").value = "21:30";
  form.querySelector("[name=ack]").checked = true;
  form.querySelector("[name=reason]").value = "Planificación anticipada revisada";
  assert(run('launchPlan({preventDefault(){},target:document.querySelector(".ops-drawer form")})'));
  const plan = run("opsDrawer.id");
  assert(run(`confirmOpsPlan('${plan}','Confirmar demanda y capacidad')`));
  assert.equal(
    run(`opsModel.trips.filter(t=>t.plan==='${plan}').reduce((n,t)=>n+t.passengers.length,0)`),
    5,
  );
  assert(run(`opsModel.trips.filter(t=>t.plan==='${plan}').every(t=>t.capacity===15&&t.gap===2)`));
  assert(run(`simulatePendingConfirmations('${plan}')`));
  assert.equal(run(`planNewRequests(opsModel.plans.find(p=>p.id==='${plan}')).length`), 3);
  assert(run(`applyPlanUpdate('${plan}','Aprobar tres nuevas confirmaciones')`));
  assert.equal(run(`opsModel.plans.find(p=>p.id==='${plan}').revision`), 2);
  assert.equal(
    run(`opsModel.trips.filter(t=>t.plan==='${plan}').reduce((n,t)=>n+t.passengers.length,0)`),
    8,
  );
  assert.equal(run(`applyPlanUpdate('${plan}','No duplicar incorporaciones')`), false);
  run('opsModel.clock=today()+"T20:01:00-04:00"');
  assert.equal(run(`simulatePendingConfirmations('${plan}')`), false);
  run("navigate('ops-users');render();openManagementDrawer('user-create')");
  form = w.document.querySelector(".ops-drawer form");
  form.querySelector("[name=name]").value = "Nuevo empleado";
  form.querySelector("[name=email]").value = "nuevo.test@example.com";
  form.querySelector("[name=reason]").value = "Alta individual autorizada";
  assert(
    run(
      'saveManagementUser({preventDefault(){},target:document.querySelector(".ops-drawer form")},"")',
    ),
  );
  assert(run("corporateWhitelist.some(u=>u.email==='nuevo.test@example.com')"));
  run(
    "validateUserImport([['nombre','correo','rol'],['Ana importada','ana.import@example.com','empleado'],['Correo duplicado','ana.import@example.com','supervisor']])",
  );
  assert.equal(run("importErrors.length"), 1);
  run(
    "navigate('ops-zones');newZone();zoneDraft.points=[[18.57,-70.1],[18.59,-70.1],[18.59,-70.13],[18.57,-70.13]]",
  );
  form = w.document.querySelector(".zone-editor form");
  form.querySelector("[name=name]").value = "Nueva zona";
  form.querySelector("[name=route]").value = "08";
  form.querySelector("[name=reason]").value = "Ampliación de cobertura";
  assert(run('saveZone({preventDefault(){},target:document.querySelector(".zone-editor form")})'));
  assert(run("opsModel.zones.some(z=>z.route==='08')"));
  run(
    "navigate('ops-events');eventDraft=newEventDraft();eventDraft.name='Visita de trabajo';eventDraft.destinationName='Oficina central';eventDraft.users=['tp-churchill-U0','tp-churchill-U3'];eventDraft.guests=[{id:'guest1',name:'Invitado demo',contact:'guest@example.com'}];eventDraft.estimated=3000;openManagementDrawer('event-create')",
  );
  form = w.document.querySelector(".ops-drawer form");
  form.querySelector("[name=reason]").value = "Traslado de trabajo aprobado";
  assert(run('saveEvent({preventDefault(){},target:document.querySelector(".ops-drawer form")})'));
  const event = run("opsDrawer.id");
  assert(run(`confirmEventById('${event}','Capacidad y costo aprobados')`));
  assert.equal(
    run(`opsModel.trips.filter(t=>t.event==='${event}').reduce((n,t)=>n+t.passengers.length,0)`),
    3,
  );
  run(`navigate('ops-qr');opsDrawer=null;render()`);
  assert(w.document.querySelector(".qr-catalog-card .ops-qr svg"));
  const link = run(
    `routeLink(opsModel.plans.find(p=>p.event==='${event}'),opsModel.plans.find(p=>p.event==='${event}').routes[0])`,
  );
  assert(run(`!!parseRouteLink(${JSON.stringify(link)})`));
  login("company-admin");
  assert.equal(run("opsScope().length"), 3);
  assert(w.document.querySelector(".ops-scope"));
  assert(!w.document.querySelector("#app").textContent.toLowerCase().includes("tenant"));
  run("toggleOpsTenant('alorica-sd',true)");
  assert.equal(run("opsScope().includes('alorica-sd')"), false);
  login("platform");
  assert(!w.document.querySelector(".ops-sidebar .ops-collaboration .tenant-logo"));
  assert(w.document.querySelector("#app").textContent.toLowerCase().includes("tenant"));
  assert(run("beginOpsImpersonation('coordinator','Soporte para operación diaria')"));
  assert.equal(run("opsScope().length"), 1);
  assert.equal(run("changeOpsTrip('TR-1041','start','No iniciar como coordinador').ok"), false);
  run("endOpsImpersonation()");
  run("logoutMove();access.role='driver';loginDemo();splashActive=false;splashDone=true;render()");
  const result = run(`claimRoute(parseRouteLink(${JSON.stringify(link)}))`);
  assert(result.ok, result.error);
  assert(run("!!driver.linkedTrip"));
  run('navigate("driver-home");render()');
  assert(w.document.querySelector(".narrow").textContent.includes("Visita de trabajo"));
  const before = run("JSON.stringify(linkedTrip().passengers)");
  run("linkedDriverDetach()");
  assert.equal(
    run(`JSON.stringify(opsModel.trips.find(t=>t.event==='${event}').passengers)`),
    before,
  );
  run(
    `logoutMove();pendingRouteLink=parseRouteLink(${JSON.stringify(link)});access.role='driver';navigate('login');render()`,
  );
  assert(w.document.querySelector(".route-login-notice"));
  run("loginDemo();splashActive=false;splashDone=true;render()");
  assert.equal(run("pendingRouteLink"), null);
  assert(run("!!driver.linkedTrip"));
  run(
    "logoutMove();opsModel.users.push({id:'reg-coord',tenant:'tp-churchill',name:'Coordinador registrado',email:'coordinador.reg@example.com',role:'coordinator',status:'invited'});syncUserWhitelist();registration={role:'corporate',step:'password',email:'coordinador.reg@example.com',verified:true};render()",
  );
  assert(await run("finishRegistration({password:'ClaveDemo123',confirm:'ClaveDemo123'})"));
  assert.equal(run("opsModel.users.find(u=>u.id==='reg-coord').status"), "active");
  run("access.role='corporate';navigate('login');render()");
  w.document.querySelector("#loginId").value = "coordinador.reg@example.com";
  w.document.querySelector("#loginPassword").value = "ClaveDemo123";
  submit();
  await new Promise((r) => setTimeout(r, 80));
  run("splashActive=false;splashDone=true;render()");
  assert.equal(run("opsActor()?.id"), "reg-coord");
  assert.equal(run("opsScope().length"), 1);
  console.log(
    "PASS: single-site roles, multi-site country scope, navigation, cutoff, fleet calculations, approved revisions, preregistration, import validation, zone persistence, event trips, QR links and driver attachment.",
  );
} finally {
  dom.window.close();
}
