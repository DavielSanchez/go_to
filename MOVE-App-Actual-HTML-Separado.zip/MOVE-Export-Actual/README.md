# MOVE · Exportación actual y legible

Copia completa de la UI actual de **MOVE · Transporte TP**. Incluye los roles de empleado, supervisor, conductor, coordinador, administrador de site, Country Admin y administrador de MOVE, además de la landing y del registro.

La aplicación publicada no fue modificada durante esta exportación.

## Empezar

Necesitas **Node.js 22 o posterior** para trabajar con las fuentes y ejecutar las herramientas incluidas.

```bash
npm ci
npm start
```

Abre **http://localhost:5173**. `npm start` compila las fuentes y sirve `dist/`.

```bash
npm run dev     # recompila al guardar src/ o public/
npm run build   # genera dist/ desde las fuentes editables
npm test        # compila y ejecuta pruebas de empleados y administración
npm run format # formatea los archivos editables
```

Para abrir la copia ya compilada sin instalar dependencias de Node:

```bash
cd dist
python -m http.server 8080
```

En Windows puedes usar `py -m http.server 8080`. Abre **http://localhost:8080**.

Usa HTTP local, no doble clic en `dist/index.html`: el dashboard carga sus plantillas mediante fetch y la PWA usa un service worker.

## Dónde editar

| Carpeta                | Contenido                                                                           |
| ---------------------- | ----------------------------------------------------------------------------------- |
| `src/templates/`       | **361 plantillas HTML separadas**: pantallas, estados, filas y fragmentos dinámicos |
| `src/js/`              | JavaScript de interacción y lógica demo; referencias a las plantillas               |
| `src/css/`             | CSS de todos los temas, responsive y animaciones, incluidos los portales            |
| `src/index.html`       | Shell de la aplicación y orden de carga de scripts                                  |
| `src/sw.js`            | Service worker; cache independiente para esta exportación                           |
| `public/admin/*.html`  | Plantillas nativas del dashboard que se cargan en runtime                           |
| `public/vendor/`       | Leaflet, lector y generador QR; código local incluido y formateado                  |
| `public/`              | Logos, imágenes, íconos y manifest de la PWA                                        |
| `dist/`                | Versión compilada lista para ejecutar o desplegar                                   |
| `ui-library/`          | Biblioteca de componentes: HTML, React y React + Tailwind                           |
| `tools/`               | Compilación de plantillas, formato y servidor local                                 |
| `tests/`               | Pruebas funcionales de la demo y fixture XLSX                                       |
| `docs/`                | Pantallas, arquitectura, integración y validación                                   |
| `templates-index.json` | Mapa de cada HTML a su módulo JavaScript de origen                                  |

Edita **src/** y **public/**; `dist/` se regenera. La compilación no toma archivos de la aplicación publicada ni requiere acceso al proyecto de Sites.

## Cómo funcionan los HTML separados

El código utiliza una macro de compilación:

```js
function pageHeading(title, subtitle) {
  return htmlTemplate("employee/app/page-heading.html");
}
```

La plantilla HTML conserva sus expresiones dinámicas:

```html
<div class="page-top">
  <h1><%= title %></h1>
  <p class="sub"><%= subtitle %></p>
</div>
```

`npm run build` coloca esas expresiones en el mismo ámbito JavaScript original. **htmlTemplate no se ejecuta en el navegador**, no utiliza eval y no es EJS ni un endpoint de servidor. Las plantillas con sufijos `-02`, `-03`, etc. son fragmentos o estados del mismo bloque. No equivalen a cientos de pantallas distintas.

Los HTML de `src/templates/` son plantillas dinámicas, no páginas independientes para abrir directamente. Los ejemplos autónomos están en `ui-library/html/`.

## Accesos de demostración

En el login hay botones para rellenar las cuentas de los portales. Estos correos y claves son ficticios y no autorizan acceso a ningún sistema real.

| Perfil                | Acceso                                                   |
| --------------------- | -------------------------------------------------------- |
| Empleado TP           | Selector corporativo → agente → botón de acceso demo     |
| Supervisor TP         | Selector corporativo → supervisor → botón de acceso demo |
| Conductor             | Selector conductores → botón de acceso demo              |
| Administrador TP      | `admin.tp.demo@gmail.com`                                |
| Coordinador TP        | `coordinador.tp.demo@gmail.com`                          |
| Country Admin TP      | `country.tp.demo@gmail.com`                              |
| Administrador MOVE    | `move.admin.demo@gmail.com`                              |
| Administrador Alorica | `admin.alorica.demo@gmail.com`                           |
| Empleado Alorica      | `alorica.demo@gmail.com`                                 |
| Empleado TrueShore    | `trueshore.demo@gmail.com`                               |
| Empleado Concentrix   | `concentrix.demo@gmail.com`                              |

Los accesos con correo listados usan **MoveDemo123**. Para el empleado y conductor genéricos, usa sus botones demo; los valores del formulario son de simulación.

Preregistro/whitelist corporativa de ejemplo: `ana.perez@gmail.com`, `carlos.mejia@outlook.com`, `supervisor.demo@gmail.com`. Puedes agregar más desde el administrador. Los conductores pueden registrar cualquier correo válido en la demo. Ambos verifican con el OTP que muestra la interfaz; no se envía correo real.

Los estados y cuentas demo se guardan en este navegador. Para empezar limpio, usa los controles de reinicio de la app o borra los datos del sitio local.

## Biblioteca de componentes

Abre **ui-library/index.html** directamente para explorar 344 entradas, comparar claro/oscuro y copiar HTML, React o React + Tailwind. Tiene su propio README y no forma parte del motor de la app.

La variante Tailwind conserva CSS compartido para selectores y animaciones complejas. Los bloques compuestos exponen callbacks para conectar tu estado y backend; contienen datos demo. La aplicación completa exportada conserva su implementación actual en HTML/CSS/JavaScript y no ha sido convertida a React.

## Integración con tu aplicación

Consulta `docs/INTEGRATION.md` para localizar las funciones demo que debes conectar a tus servicios: autenticación, confirmaciones, excepciones, planes, viajes, QR, eventos y auditoría.

Mapas y direcciones usan servicios externos; las fuentes se cargan desde Google Fonts. Los logos, imágenes, CSS y librerías de cámara/QR/Leaflet están incluidos. La capacidad de cámara y GPS depende de los permisos del navegador y de un contexto seguro (localhost o HTTPS).

## Verificación de esta exportación

- Compilación de las 361 plantillas completada.
- Pruebas de landing, marcas, registro OTP, salida después de medianoche, preferencias, conductor, supervisor e idioma aprobadas.
- Pruebas de permisos, planificación/revisiones/cutoff, usuarios, CSV/XLSX, zonas, eventos, QR, conductor e impersonación aprobadas.
- Comparación de estructura y atributos de 66 vistas/bloques contra el código de origen, normalizando espacios de formato y fijando los tiempos de los datos demo: sin diferencias.
- Referencias de assets y archivos verificadas.

Las pruebas son de DOM y lógica con JSDOM. La revisión visual en un navegador real y las pruebas de cámara, GPS y mapas externos quedan pendientes en el entorno de destino.

Fuente: versión UI v17, commit **0ea7bd7e1dcdf6cf082b495e3ec37cde32c8db37**.
