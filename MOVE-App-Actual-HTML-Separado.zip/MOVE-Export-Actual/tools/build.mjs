/**
 * htmlTemplate("path.html") is a build macro, not a browser function.
 * Templates execute in their original JavaScript scope: no eval or remote calls.
 */
import fs from "node:fs/promises";
import path from "node:path";
import * as prettier from "prettier";
import { stripLayout } from "./template-utils.mjs";

const projectRoot = path.resolve(import.meta.dirname, "..");
const sourceRoot = path.join(projectRoot, "src");
const templateRoot = path.join(sourceRoot, "templates");
const outputRoot = path.join(projectRoot, "dist");
const formatOptions = JSON.parse(
  await fs.readFile(path.join(projectRoot, ".prettierrc.json"), "utf8"),
);
const templateCache = new Map();
const macroPattern = /\bhtmlTemplate\(\s*["']([^"']+)["']\s*,?\s*\)/g;

function escapeTemplateText(text) {
  // Remove indentation added between HTML tags. This preserves the exact
  // fragments used by the existing application's string replacements.
  return text
    .replace(/\r?\n/g, "")
    .replace(/\\/g, "\\\\")
    .replace(/`/g, "\\`")
    .replace(/\$\{/g, "\\${");
}

async function expandMacros(code, stack = []) {
  const matches = [...code.matchAll(macroPattern)];
  for (const match of matches.reverse()) {
    const replacement = await compileTemplate(match[1], stack);
    code = code.slice(0, match.index) + replacement + code.slice(match.index + match[0].length);
  }
  return code;
}

async function compileTemplate(name, stack) {
  if (stack.includes(name)) throw new Error(`Circular template: ${[...stack, name].join(" → ")}`);
  if (templateCache.has(name)) return templateCache.get(name);
  const filename = path.resolve(templateRoot, name);
  if (!filename.startsWith(templateRoot + path.sep))
    throw new Error(`Invalid template path: ${name}`);
  const html = stripLayout(await fs.readFile(filename, "utf8"));
  const placeholders = [...html.matchAll(/<%=([\s\S]*?)%>/g)];
  let output = "`";
  let cursor = 0;
  for (const placeholder of placeholders) {
    output += escapeTemplateText(html.slice(cursor, placeholder.index));
    output += "${" + (await expandMacros(placeholder[1].trim(), [...stack, name])) + "}";
    cursor = placeholder.index + placeholder[0].length;
  }
  output += escapeTemplateText(html.slice(cursor)) + "`";
  templateCache.set(name, output);
  return output;
}

await fs.rm(outputRoot, { recursive: true, force: true });
await fs.cp(path.join(projectRoot, "public"), outputRoot, { recursive: true });
await fs.copyFile(path.join(sourceRoot, "index.html"), path.join(outputRoot, "index.html"));
await fs.copyFile(path.join(sourceRoot, "sw.js"), path.join(outputRoot, "sw.js"));

async function compileDirectory(directory, relative = "", scripts = false) {
  for (const entry of await fs.readdir(directory, { withFileTypes: true })) {
    const rel = relative ? relative + "/" + entry.name : entry.name;
    const from = path.join(directory, entry.name);
    if (entry.isDirectory()) {
      await compileDirectory(from, rel, scripts);
      continue;
    }
    const target = path.join(outputRoot, rel);
    await fs.mkdir(path.dirname(target), { recursive: true });
    if (scripts) {
      const compiled = await expandMacros(await fs.readFile(from, "utf8"));
      await fs.writeFile(
        target,
        await prettier.format(compiled, { ...formatOptions, parser: "babel" }),
      );
    } else {
      await fs.copyFile(from, target);
    }
  }
}
await compileDirectory(path.join(sourceRoot, "css"));
await compileDirectory(path.join(sourceRoot, "js"), "", true);
console.log("MOVE built: " + templateCache.size + " HTML templates → dist/");
