/** Local static server. Development mode rebuilds when src/ or public/ changes. */
import http from "node:http";
import fs from "node:fs/promises";
import { watch, createReadStream } from "node:fs";
import path from "node:path";
import { spawn } from "node:child_process";

const root = path.resolve(import.meta.dirname, "..");
const output = path.join(root, "dist");
const port = Number(process.env.MOVE_PORT || 5173);
const development = process.argv.includes("--watch");
const contentTypes = {
  ".html": "text/html; charset=utf-8",
  ".js": "text/javascript; charset=utf-8",
  ".css": "text/css; charset=utf-8",
  ".json": "application/json; charset=utf-8",
  ".webmanifest": "application/manifest+json",
  ".svg": "image/svg+xml",
  ".png": "image/png",
  ".webp": "image/webp",
};

let building = false;
let pending = false;
async function build() {
  if (building) {
    pending = true;
    return;
  }
  building = true;
  try {
    await new Promise((resolve, reject) => {
      const child = spawn(process.execPath, [path.join(root, "tools/build.mjs")], {
        cwd: root,
        stdio: "inherit",
      });
      child.once("error", reject);
      child.once("exit", (code) =>
        code === 0 ? resolve() : reject(new Error(`Build exited ${code}`)),
      );
    });
  } finally {
    building = false;
    if (pending) {
      pending = false;
      await build();
    }
  }
}

if (development) {
  await build();
  let timer;
  for (const directory of ["src", "public"]) {
    watch(path.join(root, directory), { recursive: true }, () => {
      clearTimeout(timer);
      timer = setTimeout(() => build().catch(console.error), 200);
    });
  }
}

http
  .createServer(async (request, response) => {
    try {
      const url = new URL(request.url, `http://localhost:${port}`);
      const filename = path.resolve(output, "." + decodeURIComponent(url.pathname));
      if (filename !== output && !filename.startsWith(output + path.sep)) {
        response.writeHead(403).end("Forbidden");
        return;
      }
      const stat = await fs.stat(filename);
      const target = stat.isDirectory() ? path.join(filename, "index.html") : filename;
      response.writeHead(200, {
        "Content-Type": contentTypes[path.extname(target)] || "application/octet-stream",
        "Cache-Control": "no-cache",
      });
      createReadStream(target).pipe(response);
    } catch {
      response.writeHead(404).end("Not found");
    }
  })
  .listen(port, "127.0.0.1", () => {
    console.log(`MOVE: http://localhost:${port}${development ? " (watching source files)" : ""}`);
  });
