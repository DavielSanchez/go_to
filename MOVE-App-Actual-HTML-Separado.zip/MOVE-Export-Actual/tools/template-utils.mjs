/** Preserve meaningful spaces while removing template indentation. */
export function stripLayout(html) {
  const expressions = [];
  const masked = html.replace(/<%=([\s\S]*?)%>/g, (whole) => {
    expressions.push(whole);
    return `MOVE_EXPR_${expressions.length - 1}_TOKEN`;
  });
  const voids = new Set(
    "area base br col embed hr img input link meta param source track wbr".split(" "),
  );
  let depth = 0;
  const lines = masked.split(/\r?\n/).map((line) => {
    const tag = line.trimStart().match(/^<(\/)?([a-z][\w:-]*)/i);
    if (tag?.[1]) depth = Math.max(0, depth - 1);
    const leading = line.match(/^ */)[0].length;
    const result = line.slice(Math.min(leading, depth * 2));
    if (tag && !tag[1] && !voids.has(tag[2].toLowerCase()) && !line.trimEnd().endsWith("/>"))
      depth++;
    return result;
  });
  return lines.join("\n").replace(/MOVE_EXPR_(\d+)_TOKEN/g, (_, n) => expressions[Number(n)]);
}
