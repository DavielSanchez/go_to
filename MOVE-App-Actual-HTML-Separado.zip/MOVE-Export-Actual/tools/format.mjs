/** Format all editable text sources, including expressions inside HTML templates. */
import fs from "node:fs/promises";
import path from "node:path";
import * as prettier from "prettier";
import { stripLayout } from "./template-utils.mjs";
const root = path.resolve(import.meta.dirname, "..");
const options = JSON.parse(await fs.readFile(path.join(root, ".prettierrc.json"), "utf8"));

async function formatTemplate(html) {
  const expressions = [];
  const masked = stripLayout(html)
    .replace(/<%=([\s\S]*?)%>/g, (_, expression) => {
      expressions.push(expression.trim());
      return `MOVE_EXPR_${expressions.length - 1}_TOKEN`;
    })
    .replace(/\r?\n/g, "");
  const voids = new Set(
    "area base br col embed hr img input link meta param source track wbr".split(" "),
  );
  const parts = masked.match(/<(?:"[^"]*"|'[^']*'|[^'">])*>|MOVE_EXPR_\d+_TOKEN|[^<]+|</g) || [];
  let depth = 0;
  let output =
    parts
      .map((part) => {
        const tag = part.match(/^<(\/)?([a-z][\w:-]*)/i);
        if (tag?.[1]) depth = Math.max(0, depth - 1);
        const line = "  ".repeat(depth) + part;
        if (tag && !tag[1] && !voids.has(tag[2].toLowerCase()) && !part.endsWith("/>")) depth++;
        return line;
      })
      .join("\n") + "\n";
  for (const match of [...output.matchAll(/MOVE_EXPR_(\d+)_TOKEN/g)].reverse()) {
    const source = `const TEMPLATE_EXPRESSION = ${expressions[Number(match[1])]};`;
    const expression = (await prettier.format(source, { ...options, parser: "babel" }))
      .replace(/^const TEMPLATE_EXPRESSION\s*=\s*/, "")
      .trim()
      .replace(/;$/, "");
    const lineStart = output.lastIndexOf("\n", match.index) + 1;
    const indentation = output.slice(lineStart, match.index).match(/^ */)[0];
    const placeholder = expression.includes("\n")
      ? "<%=\n" +
        expression
          .split("\n")
          .map((line) => indentation + "  " + line)
          .join("\n") +
        "\n" +
        indentation +
        "%>"
      : `<%= ${expression} %>`;
    output =
      output.slice(0, match.index) + placeholder + output.slice(match.index + match[0].length);
  }
  return output;
}

async function walk(directory) {
  for (const entry of await fs.readdir(directory, { withFileTypes: true })) {
    const filename = path.join(directory, entry.name);
    if (entry.isDirectory()) {
      await walk(filename);
      continue;
    }
    const extension = path.extname(filename);
    const parsers = {
      ".js": "babel",
      ".mjs": "babel",
      ".css": "css",
      ".json": "json",
      ".webmanifest": "json",
      ".html": "html",
      ".svg": "html",
      ".md": "markdown",
    };
    if (!parsers[extension]) continue;
    const source = await fs.readFile(filename, "utf8");
    const formatted = filename.includes(path.sep + "templates" + path.sep)
      ? await formatTemplate(source)
      : await prettier.format(source, { ...options, parser: parsers[extension] });
    await fs.writeFile(filename, formatted);
  }
}
for (const directory of ["src", "public", "tools", "tests"]) await walk(path.join(root, directory));
for (const entry of await fs.readdir(root)) {
  if (!/\.(json|md)$/.test(entry)) continue;
  const filename = path.join(root, entry);
  await fs.writeFile(
    filename,
    await prettier.format(await fs.readFile(filename, "utf8"), { ...options, filepath: filename }),
  );
}
console.log("MOVE source files formatted.");
