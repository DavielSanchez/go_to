import React, { useRef } from 'react';
import { moveInteraction } from '../runtime.js';

const palettes = {
  tp: {
    light: ['#d9004c', '#fff0f5', '#17171b'],
    dark: ['#ef0054', '#3d2030', '#17171b'],
  },
  alorica: {
    light: ['#006b93', '#e6f4fa', '#102f46'],
    dark: ['#006b93', '#143548', '#102f46'],
  },
  trueshore: {
    light: ['#c63b00', '#fff0e9', '#401b32'],
    dark: ['#c63b00', '#402b28', '#401b32'],
  },
  concentrix: {
    light: ['#087b85', '#e3f7f6', '#003d46'],
    dark: ['#087b85', '#123b40', '#003d46'],
  },
};
/** Controlled theme and brand boundary. Import move.css and library-additions.css once. */
export function MoveSurface({
  theme = 'light',
  tenant = 'tp',
  reducedMotion = false,
  onAction,
  className = '',
  style,
  children,
  ...props
}) {
  const ref = useRef(null);
  const colors = (palettes[tenant] || palettes.tp)[
    theme === 'dark' ? 'dark' : 'light'
  ];
  const dispatch = (event) => moveInteraction(ref.current, event, onAction);
  return (
    <div
      ref={ref}
      data-move-root
      data-theme={theme}
      data-tenant={tenant}
      className={`${reducedMotion ? 'reduce-motion ' : ''}${className}`}
      style={{
        '--pink': colors[0],
        '--tint': colors[1],
        '--tenant-soft': colors[1],
        '--tenant-hero': colors[2],
        ...style,
      }}
      onClickCapture={dispatch}
      onChangeCapture={dispatch}
      onSubmitCapture={dispatch}
      {...props}
    >
      {children}
    </div>
  );
}
