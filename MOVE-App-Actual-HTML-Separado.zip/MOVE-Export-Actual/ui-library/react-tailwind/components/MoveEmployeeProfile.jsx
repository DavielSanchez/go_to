import React, { useId } from 'react';
import { MoveSurface } from '../MoveSurface.jsx';

/** Bloque extraído del diseño actual de MOVE. Los eventos se exponen mediante onAction. */
export function MoveEmployeeProfile({
  theme = 'light',
  tenant = 'tp',
  reducedMotion = false,
  onAction,
  className = '',
  style,
  children,
}) {
  const uid = useId();
  return (
    <MoveSurface
      theme={theme}
      tenant={tenant}
      reducedMotion={reducedMotion}
      onAction={onAction}
      className={'' + ' ' + className}
      style={style}
    >
      {children ?? (
        <>
          <div className="profile-wrap ">
            <div className="page-top ">
              <div>
                <h1>{'Mi perfil'}</h1>
              </div>
            </div>
            <div className="card mb-[18px] rounded-[var(--radius)] border border-[var(--line)] bg-[var(--surface)] p-6">
              <div className="profile-hero p-[18px] text-center">
                <span className="avatar grid h-10 w-10 place-items-center rounded-full border-0 text-[13px] font-bold">
                  {'DS'}
                </span>
                <h2>{'Daviel Sánchez'}</h2>
                <p className="sub mt-2 leading-[1.6] text-[var(--muted)]">
                  {'Colaborador · TP Santo Domingo'}
                </p>
                <span
                  className="pill inline-flex items-center gap-1.5 rounded-full px-[11px] py-[7px] text-xs font-bold"
                  style={{ marginTop: '14px' }}
                >
                  {'ID de empleado: 104582'}
                </span>
              </div>
              <div className="info-grid grid grid-cols-2 gap-4 border-t border-[var(--line)] pt-[18px]">
                <div>
                  <small>{'Campus'}</small>
                  <b>{'Churchill'}</b>
                </div>
                <div>
                  <small>{'Horario de salida'}</small>
                  <b>{'10:00 p. m.'}</b>
                </div>
              </div>
            </div>
            <div className="card address-card mb-[18px] rounded-[var(--radius)] border border-[var(--line)] bg-[var(--surface)] p-6">
              <div className="section-heading " style={{ marginTop: '0px' }}>
                <h2>{'Mi dirección'}</h2>
                <span className="icon-box ">
                  <svg
                    className="icon h-[22px] w-[22px] shrink-0 fill-none stroke-current align-middle"
                    viewBox="0 0 24 24"
                    aria-hidden="true"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path
                      d="M20 10c0 6-8 12-8 12S4 16 4 10a8 8 0 1 1 16 0M15 10a3 3 0 1 1-6 0 3 3 0 0 1 6 0"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    ></path>
                  </svg>
                </span>
              </div>
              <p className="address-value ">
                {'Entrada de Pantoja · Los Alcarrizos'}
              </p>
              <p className="small-info text-sm leading-[1.55] text-[var(--muted)]">
                {'Ubicación: 18.53000, -70.01000'}
              </p>
              <p
                className="small-info text-sm leading-[1.55] text-[var(--muted)]"
                style={{ marginTop: '12px' }}
              >
                {
                  '0 de 3 cambios automáticos utilizados. Desde el cuarto, transporte debe aprobar el cambio.'
                }
              </p>
              <button
                className="btn secondary flex min-h-[52px] w-full items-center justify-center gap-2.5 rounded-[14px] border-0 px-5 py-4 font-bold disabled:cursor-not-allowed disabled:opacity-45 bg-[var(--soft)] text-[var(--ink)]"
                style={{ marginTop: '18px' }}
                data-move-click="navigate('address')"
              >
                {'Cambiar dirección'}
              </button>
            </div>
            <div className="card mb-[18px] rounded-[var(--radius)] border border-[var(--line)] bg-[var(--surface)] p-6">
              <div className="setting-row ">
                <div>
                  <h3>{'Modo oscuro'}</h3>
                  <p className="small-info text-sm leading-[1.55] text-[var(--muted)]">
                    {'Tu preferencia se guarda en este dispositivo.'}
                  </p>
                </div>
                <button
                  className="btn secondary compact flex min-h-[52px] w-full items-center justify-center gap-2.5 rounded-[14px] border-0 px-5 py-4 font-bold disabled:cursor-not-allowed disabled:opacity-45 bg-[var(--soft)] text-[var(--ink)]"
                  aria-pressed="false"
                  data-move-click="toggleTheme();render()"
                >
                  {'Desactivado'}
                </button>
              </div>
            </div>
            <details className="card demo-controls mb-[18px] rounded-[var(--radius)] border border-[var(--line)] bg-[var(--surface)] p-6">
              <summary>{'Probar estados de demostración'}</summary>
              <label
                className="label mb-2.5 mt-[22px] block text-sm font-bold"
                htmlFor={uid + '-scenario'}
              >
                {'Situación del empleado'}
              </label>
              <select
                id={uid + '-scenario'}
                data-move-change="setScenario(this.value)"
                defaultValue="Selecciona un escenario"
              >
                <option value="" disabled>
                  {'Selecciona un escenario'}
                </option>
                <option value="eligible">{'Aplica para transporte'}</option>
                <option value="ineligible">
                  {'No aplica para transporte hoy'}
                </option>
                <option value="missing">{'Sin dirección registrada'}</option>
                <option value="third">
                  {'Dos cambios usados · Probar el tercero'}
                </option>
                <option value="fourth">
                  {'Tres cambios usados · Requiere aprobación'}
                </option>
              </select>
              <p
                className="small-info text-sm leading-[1.55] text-[var(--muted)]"
                style={{ marginTop: '12px' }}
              >
                {
                  'Estos escenarios usan datos de ejemplo. No envían solicitudes reales.'
                }
              </p>
              <button className="cancel " data-move-click="resetDemo()">
                {'Reiniciar demostración'}
              </button>
            </details>
            <p className="demo-note ">
              {'Vista de demostración · Datos de ejemplo'}
            </p>
          </div>
        </>
      )}
    </MoveSurface>
  );
}
