import React, { useId } from 'react';
import { MoveSurface } from '../MoveSurface.jsx';
import asset0 from '../../assets/alorica-logo.png';
/** Colaboración de empresa y MOVE. */
export function MoveBrandAlorica({
  theme = 'light',
  tenant = 'alorica',
  reducedMotion = false,
  onAction,
  className = '',
  style,
  children,
}) {
  const uid = useId();
  return (
    <MoveSurface
      theme={theme}
      tenant={tenant}
      reducedMotion={reducedMotion}
      onAction={onAction}
      className={'' + ' ' + className}
      style={style}
    >
      {children ?? (
        <>
          <div className="brand-collab ">
            <img
              className="tenant-logo partner-logo alorica-logo "
              src={asset0}
              alt="Alorica"
            />
            <span className="collab-cross " aria-hidden="true">
              {'×'}
            </span>
            <span className="brand ">
              {'MOVE'}
              <span className="brand-dot "></span>
            </span>
          </div>
        </>
      )}
    </MoveSurface>
  );
}
