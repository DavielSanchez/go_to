import React, { useId } from 'react';
import { MoveSurface } from '../MoveSurface.jsx';

/** Botón primario. Estados normal, hover, focus-visible y disabled. */
export function MoveButtonPrimary({
  theme = 'light',
  tenant = 'tp',
  reducedMotion = false,
  onAction,
  className = '',
  style,
  children,
}) {
  const uid = useId();
  return (
    <MoveSurface
      theme={theme}
      tenant={tenant}
      reducedMotion={reducedMotion}
      onAction={onAction}
      className={'' + ' ' + className}
      style={style}
    >
      {children ?? (
        <>
          <button className="btn flex min-h-[52px] w-full items-center justify-center gap-2.5 rounded-[14px] border-0 bg-[var(--pink)] px-5 py-4 font-bold text-white disabled:cursor-not-allowed disabled:opacity-45">
            <svg
              className="icon h-[22px] w-[22px] shrink-0 fill-none stroke-current align-middle"
              viewBox="0 0 24 24"
              aria-hidden="true"
              xmlns="http://www.w3.org/2000/svg"
            >
              <path
                d="M5 12l4 4L19 6"
                strokeLinecap="round"
                strokeLinejoin="round"
              ></path>
            </svg>
            {'Confirmar transporte'}
          </button>
        </>
      )}
    </MoveSurface>
  );
}
