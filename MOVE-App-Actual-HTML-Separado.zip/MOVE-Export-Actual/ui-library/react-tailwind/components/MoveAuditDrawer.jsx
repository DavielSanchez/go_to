import React, { useId } from 'react';
import { MoveSurface } from '../MoveSurface.jsx';

/** Bloque extraído del diseño actual de MOVE. Los eventos se exponen mediante onAction. */
export function MoveAuditDrawer({
  theme = 'light',
  tenant = 'tp',
  reducedMotion = false,
  onAction,
  className = '',
  style,
  children,
}) {
  const uid = useId();
  return (
    <MoveSurface
      theme={theme}
      tenant={tenant}
      reducedMotion={reducedMotion}
      onAction={onAction}
      className={'' + ' ' + className}
      style={style}
    >
      {children ?? (
        <>
          <div
            className="ops-drawer-backdrop "
            data-move-click="if(event.target===this)closeOpsDrawer()"
          >
            <section
              className="ops-drawer "
              role="dialog"
              aria-modal="true"
              aria-labelledby={uid + '-opsDrawerTitle'}
            >
              <div className="ops-drawer-top ">
                <h2 id={uid + '-opsDrawerTitle'}>{'Detalle de auditoría'}</h2>
                <button
                  className="ops-icon-button "
                  aria-label="Cerrar detalle"
                  data-move-click="closeOpsDrawer()"
                >
                  <svg
                    className="icon h-[22px] w-[22px] shrink-0 fill-none stroke-current align-middle"
                    viewBox="0 0 24 24"
                    aria-hidden="true"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path
                      d="M15 5l-7 7 7 7"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    ></path>
                  </svg>
                </button>
              </div>
              <div className="ops-detail-grid ">
                <div>
                  <small>{'Actor real'}</small>
                  <b>{'Daviel Sánchez'}</b>
                  <p className="ops-muted ">{'move.admin.demo@gmail.com'}</p>
                </div>
                <div>
                  <small>{'Usuario efectivo'}</small>
                  <b>{'María Rodríguez'}</b>
                  <p className="ops-muted ">{'admin.tp.demo@gmail.com'}</p>
                </div>
                <div>
                  <small>{'Fecha y hora · RD'}</small>
                  <b>{'03/10/2026, 20:07:31'}</b>
                </div>
                <div>
                  <small>{'Acción'}</small>
                  <b>{'configuration.updated'}</b>
                </div>
              </div>
              <section className="ops-drawer-section ">
                <h3>{'Motivo'}</h3>
                <p className="ops-muted ">
                  {'Ejemplo: ajuste de margen de asientos, ticket DEMO-184'}
                </p>
              </section>
              <section className="ops-drawer-section ">
                <h3>{'Antes'}</h3>
                <pre>{'{\n  "gap": 1\n}'}</pre>
                <h3>{'Después'}</h3>
                <pre>{'{\n  "gap": 2\n}'}</pre>
              </section>
              <section className="ops-drawer-section ">
                <h3>{'Trazabilidad'}</h3>
                <pre>
                  {
                    '{\n  "id": "AUD-DEMO-001",\n  "entity": "tp-churchill",\n  "tenants": [\n    "tp-churchill"\n  ],\n  "impersonation": "IMP-DEMO-001",\n  "session": "DEMO-SESSION",\n  "timestampUTC": "2026-10-04T00:07:31.000Z",\n  "timezone": "America/Santo_Domingo",\n  "source": "Web · demostración",\n  "demo": true\n}'
                  }
                </pre>
              </section>
            </section>
          </div>
        </>
      )}
    </MoveSurface>
  );
}
