import React, { useId } from 'react';
import { MoveSurface } from '../MoveSurface.jsx';

/** Patrón form-actions usado en approvalView(). */
export function MoveFormActions({
  theme = 'light',
  tenant = 'tp',
  reducedMotion = false,
  onAction,
  className = '',
  style,
  children,
}) {
  const uid = useId();
  return (
    <MoveSurface
      theme={theme}
      tenant={tenant}
      reducedMotion={reducedMotion}
      onAction={onAction}
      className={'' + ' ' + className}
      style={style}
    >
      {children ?? (
        <>
          <div className="form-actions ">
            <button
              className="btn outline flex min-h-[52px] w-full items-center justify-center gap-2.5 rounded-[14px] px-5 py-4 font-bold disabled:cursor-not-allowed disabled:opacity-45 border border-[var(--line)] bg-[var(--surface)] text-[var(--ink)]"
              data-move-click="decideException('EX-001','rejected')"
            >
              {'Rechazar'}
            </button>
            <button
              className="btn flex min-h-[52px] w-full items-center justify-center gap-2.5 rounded-[14px] border-0 bg-[var(--pink)] px-5 py-4 font-bold text-white disabled:cursor-not-allowed disabled:opacity-45"
              data-move-click="decideException('EX-001','approved')"
            >
              {'Aprobar excepción'}
            </button>
          </div>
        </>
      )}
    </MoveSurface>
  );
}
