import React, { useId } from 'react';
import { MoveSurface } from '../MoveSurface.jsx';

/** Bloque extraído del diseño actual de MOVE. Los eventos se exponen mediante onAction. */
export function MoveDriverOnboarding3({
  theme = 'light',
  tenant = 'tp',
  reducedMotion = false,
  onAction,
  className = '',
  style,
  children,
}) {
  const uid = useId();
  return (
    <MoveSurface
      theme={theme}
      tenant={tenant}
      reducedMotion={reducedMotion}
      onAction={onAction}
      className={'' + ' ' + className}
      style={style}
    >
      {children ?? (
        <>
          <div className="narrow ">
            <div className="page-top ">
              <div>
                <h1>{'Registro del conductor'}</h1>
                <p className="sub mt-2 leading-[1.6] text-[var(--muted)]">
                  {'Completa tus datos antes de recibir una ruta.'}
                </p>
              </div>
            </div>
            <div className="onboarding-steps ">
              <span className=" ">{'1. Identidad'}</span>
              <span className=" ">{'2. Vehículo'}</span>
              <span className="active ">{'3. Revisión'}</span>
            </div>
            <form
              id={uid + '-driverOnboarding'}
              className="card mb-[18px] rounded-[var(--radius)] border border-[var(--line)] bg-[var(--surface)] p-6"
              data-move-form=""
            >
              <h2>{'Revisa tu registro'}</h2>
              <div className="profile-data ">
                <div>
                  <small>{'Nombre'}</small>
                  <b>{'José Ramírez'}</b>
                </div>
                <div>
                  <small>{'Cédula'}</small>
                  <b>{'00000000000'}</b>
                </div>
                <div>
                  <small>{'Marca'}</small>
                  <b>{'Hyundai'}</b>
                </div>
                <div>
                  <small>{'Modelo'}</small>
                  <b>{'County'}</b>
                </div>
                <div>
                  <small>{'Año'}</small>
                  <b>{'2023'}</b>
                </div>
                <div>
                  <small>{'Placa'}</small>
                  <b>{'I078542'}</b>
                </div>
              </div>
              <div className="notice my-5 flex gap-2.5 rounded-2xl bg-[var(--notice-bg)] p-4 text-sm leading-[1.55] text-[var(--notice-ink)]">
                <svg
                  className="icon h-[22px] w-[22px] shrink-0 fill-none stroke-current align-middle"
                  viewBox="0 0 24 24"
                  aria-hidden="true"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    d="M5 12l4 4L19 6"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  ></path>
                </svg>
                <span>{'Cédula, licencia y placa: fotos seleccionadas.'}</span>
              </div>
              <p className="small-info text-sm leading-[1.55] text-[var(--muted)]">
                {
                  'En este prototipo las fotos se previsualizan en tu dispositivo. No se envían ni se validan documentos reales.'
                }
              </p>
              <p
                id={uid + '-onboardError'}
                className="form-error "
                role="alert"
              ></p>
              <div className="form-actions ">
                <button
                  className="btn secondary flex min-h-[52px] w-full items-center justify-center gap-2.5 rounded-[14px] border-0 px-5 py-4 font-bold disabled:cursor-not-allowed disabled:opacity-45 bg-[var(--soft)] text-[var(--ink)]"
                  type="button"
                  data-move-click="backOnboarding()"
                >
                  {'Anterior'}
                </button>
                <button
                  className="btn flex min-h-[52px] w-full items-center justify-center gap-2.5 rounded-[14px] border-0 bg-[var(--pink)] px-5 py-4 font-bold text-white disabled:cursor-not-allowed disabled:opacity-45"
                  type="submit"
                >
                  {'Completar registro'}
                </button>
              </div>
            </form>
            <p className="demo-note ">
              {'Vista de demostración · Datos de ejemplo'}
            </p>
          </div>
        </>
      )}
    </MoveSurface>
  );
}
