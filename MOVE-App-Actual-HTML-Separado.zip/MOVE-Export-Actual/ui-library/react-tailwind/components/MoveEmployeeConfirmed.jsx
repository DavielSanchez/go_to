import React, { useId } from 'react';
import { MoveSurface } from '../MoveSurface.jsx';

/** Bloque extraído del diseño actual de MOVE. Los eventos se exponen mediante onAction. */
export function MoveEmployeeConfirmed({
  theme = 'light',
  tenant = 'tp',
  reducedMotion = false,
  onAction,
  className = '',
  style,
  children,
}) {
  const uid = useId();
  return (
    <MoveSurface
      theme={theme}
      tenant={tenant}
      reducedMotion={reducedMotion}
      onAction={onAction}
      className={'' + ' ' + className}
      style={style}
    >
      {children ?? (
        <>
          <a
            className="card help-card ticket-link mb-[18px] rounded-[var(--radius)] border border-[var(--line)] bg-[var(--surface)] p-6"
            href="#ticket"
          >
            <span className="icon-box ">
              <svg
                className="icon h-[22px] w-[22px] shrink-0 fill-none stroke-current align-middle"
                viewBox="0 0 24 24"
                aria-hidden="true"
                xmlns="http://www.w3.org/2000/svg"
              >
                <path
                  d="M3 7h18v4a2 2 0 0 0 0 4v4H3v-4a2 2 0 0 0 0-4zM15 7v2m0 3v2m0 3v2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                ></path>
              </svg>
            </span>
            <div>
              <h3>{'Mi ticket de abordaje'}</h3>
              <p>{'4 de octubre de 2026 · Unidad 12 · 22:30'}</p>
            </div>
            <span className="chevron ">
              <svg
                className="icon h-[22px] w-[22px] shrink-0 fill-none stroke-current align-middle"
                viewBox="0 0 24 24"
                aria-hidden="true"
                xmlns="http://www.w3.org/2000/svg"
              >
                <path
                  d="M9 5l7 7-7 7"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                ></path>
              </svg>
            </span>
          </a>
          <div className="date ">{'4 DE OCTUBRE DE 2026'}</div>
          <div className="page-top ">
            <div>
              <h1>
                {'Hola, Daviel '}
                <span className="accent text-[var(--pink)]">{'.'}</span>
              </h1>
              <p className="sub mt-2 leading-[1.6] text-[var(--muted)]">
                {'Tu regreso a casa, organizado.'}
              </p>
            </div>
            <span className="desktop-date mobile-hide ">
              {'Santo Domingo, RD'}
            </span>
          </div>
          <div className="home-grid ">
            <section>
              <div className="card hero mb-[18px] rounded-[var(--radius)] border border-[var(--line)] bg-[var(--surface)] p-6">
                <span className="pill inline-flex items-center gap-1.5 rounded-full px-[11px] py-[7px] text-xs font-bold">
                  <svg
                    className="icon h-[22px] w-[22px] shrink-0 fill-none stroke-current align-middle"
                    viewBox="0 0 24 24"
                    aria-hidden="true"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path
                      d="M5 12l4 4L19 6"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    ></path>
                  </svg>
                  {'Reserva confirmada'}
                </span>
                <h2>{'Todo listo para tu regreso.'}</h2>
                <p>
                  {
                    'Tu asiento está reservado. Llega al punto de encuentro 10 minutos antes.'
                  }
                </p>
                <div className="time-row ">
                  <div>
                    <small>{'Salida de tu turno'}</small>
                    <strong>
                      {'10:00 '}
                      <span style={{ fontSize: '14px' }}>{'p. m.'}</span>
                    </strong>
                  </div>
                  <div>
                    <small>{'Salida del transporte'}</small>
                    <strong>
                      {'10:30 '}
                      <span style={{ fontSize: '14px' }}>{'p. m.'}</span>
                    </strong>
                  </div>
                </div>
                <button
                  className="btn flex min-h-[52px] w-full items-center justify-center gap-2.5 rounded-[14px] border-0 bg-[var(--pink)] px-5 py-4 font-bold text-white disabled:cursor-not-allowed disabled:opacity-45"
                  data-move-click="navigate('trip')"
                >
                  <svg
                    className="icon h-[22px] w-[22px] shrink-0 fill-none stroke-current align-middle"
                    viewBox="0 0 24 24"
                    aria-hidden="true"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path
                      d="M5 16V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2v11M5 11h14M8 3v8m8-8v8M5 16h14v3H5zM7 19v3m10-3v3M8 14h.01M16 14h.01"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    ></path>
                  </svg>
                  {'Ver mi viaje'}
                </button>
                <div className="hero-foot ">
                  <svg
                    className="icon h-[22px] w-[22px] shrink-0 fill-none stroke-current align-middle"
                    viewBox="0 0 24 24"
                    aria-hidden="true"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path
                      d="M12 8v5l3 2M22 12a10 10 0 1 1-20 0 10 10 0 0 1 20 0"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    ></path>
                  </svg>
                  {'Confirma antes de las 8:00 p. m.'}
                </div>
              </div>
              <button className="cancel " data-move-click="cancelRide()">
                {'Cancelar mi confirmación'}
              </button>
              <div className="notice my-5 flex gap-2.5 rounded-2xl bg-[var(--notice-bg)] p-4 text-sm leading-[1.55] text-[var(--notice-ink)]">
                <svg
                  className="icon h-[22px] w-[22px] shrink-0 fill-none stroke-current align-middle"
                  viewBox="0 0 24 24"
                  aria-hidden="true"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    d="M12 3l8 3v6c0 5-8 9-8 9s-8-4-8-9V6zM8 12l3 3 5-6"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  ></path>
                </svg>
                <span>
                  {
                    'Tu confirmación es diaria. Nos ayuda a organizar las rutas y reducir tu tiempo de espera.'
                  }
                </span>
              </div>
            </section>
            <section>
              <div className="section-heading " style={{ marginTop: '0px' }}>
                <h2>{'Tu ruta asignada'}</h2>
                <span className="pill inline-flex items-center gap-1.5 rounded-full px-[11px] py-[7px] text-xs font-bold">
                  {'Ruta 04'}
                </span>
              </div>
              <div className="card mb-[18px] rounded-[var(--radius)] border border-[var(--line)] bg-[var(--surface)] p-6">
                <div className="route relative my-5 pl-[34px]">
                  <div className="route-item ">
                    <b>{'TP · Campus Churchill'}</b>
                    <small>{'Salida por la puerta principal'}</small>
                  </div>
                  <div className="route-item ">
                    <b>{'Tu dirección de destino'}</b>
                    <small>{'Entrada de Pantoja · Los Alcarrizos'}</small>
                  </div>
                </div>
                <div className="info-grid grid grid-cols-2 gap-4 border-t border-[var(--line)] pt-[18px]">
                  <div>
                    <small>{'Punto de encuentro'}</small>
                    <b>{'Parqueo B · Zona 2'}</b>
                  </div>
                  <div>
                    <small>{'Tiempo estimado'}</small>
                    <b>{'35–45 minutos'}</b>
                  </div>
                </div>
              </div>
              <div className="section-heading ">
                <h2>{'¿Cambió tu jornada?'}</h2>
              </div>
              <a
                className="card help-card mb-[18px] rounded-[var(--radius)] border border-[var(--line)] bg-[var(--surface)] p-6"
                href="#exception"
              >
                <span className="icon-box ">
                  <svg
                    className="icon h-[22px] w-[22px] shrink-0 fill-none stroke-current align-middle"
                    viewBox="0 0 24 24"
                    aria-hidden="true"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path
                      d="M3 7h18v4a2 2 0 0 0 0 4v4H3v-4a2 2 0 0 0 0-4zM15 7v2m0 3v2m0 3v2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    ></path>
                  </svg>
                </span>
                <div>
                  <h3>{'Solicitar una excepción'}</h3>
                  <p>{'Horas extra, cambio de turno u otro motivo.'}</p>
                </div>
                <span className="chevron ">
                  <svg
                    className="icon h-[22px] w-[22px] shrink-0 fill-none stroke-current align-middle"
                    viewBox="0 0 24 24"
                    aria-hidden="true"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path
                      d="M9 5l7 7-7 7"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    ></path>
                  </svg>
                </span>
              </a>
              <div className="card address-card mb-[18px] rounded-[var(--radius)] border border-[var(--line)] bg-[var(--surface)] p-6">
                <div className="section-heading " style={{ marginTop: '0px' }}>
                  <h2>{'Mi dirección'}</h2>
                  <span className="icon-box ">
                    <svg
                      className="icon h-[22px] w-[22px] shrink-0 fill-none stroke-current align-middle"
                      viewBox="0 0 24 24"
                      aria-hidden="true"
                      xmlns="http://www.w3.org/2000/svg"
                    >
                      <path
                        d="M20 10c0 6-8 12-8 12S4 16 4 10a8 8 0 1 1 16 0M15 10a3 3 0 1 1-6 0 3 3 0 0 1 6 0"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                      ></path>
                    </svg>
                  </span>
                </div>
                <p className="address-value ">
                  {'Entrada de Pantoja · Los Alcarrizos'}
                </p>
                <p className="small-info text-sm leading-[1.55] text-[var(--muted)]">
                  {'Ubicación: 18.53000, -70.01000'}
                </p>
                <p
                  className="small-info text-sm leading-[1.55] text-[var(--muted)]"
                  style={{ marginTop: '12px' }}
                >
                  {
                    '0 de 3 cambios automáticos utilizados. Desde el cuarto, transporte debe aprobar el cambio.'
                  }
                </p>
                <button
                  className="btn secondary flex min-h-[52px] w-full items-center justify-center gap-2.5 rounded-[14px] border-0 px-5 py-4 font-bold disabled:cursor-not-allowed disabled:opacity-45 bg-[var(--soft)] text-[var(--ink)]"
                  style={{ marginTop: '18px' }}
                  data-move-click="navigate('address')"
                >
                  {'Cambiar dirección'}
                </button>
              </div>
            </section>
          </div>
          <p className="demo-note ">
            {'Vista de demostración · Datos de ejemplo'}
          </p>
        </>
      )}
    </MoveSurface>
  );
}
