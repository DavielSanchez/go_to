import React, { useId } from 'react';
import { MoveSurface } from '../MoveSurface.jsx';

/** Patrón approval-filter usado en approvalView(). */
export function MoveApprovalFilter({
  theme = 'light',
  tenant = 'tp',
  reducedMotion = false,
  onAction,
  className = '',
  style,
  children,
}) {
  const uid = useId();
  return (
    <MoveSurface
      theme={theme}
      tenant={tenant}
      reducedMotion={reducedMotion}
      onAction={onAction}
      className={'' + ' ' + className}
      style={style}
    >
      {children ?? (
        <>
          <div
            className="approval-filter "
            role="group"
            aria-label="Filtrar solicitudes"
          >
            <button
              className="selected "
              aria-pressed="true"
              data-move-click="setApprovalFilter('pending')"
            >
              {'Pendientes'}
            </button>
            <button
              className=" "
              aria-pressed="false"
              data-move-click="setApprovalFilter('approved')"
            >
              {'Aprobadas'}
            </button>
            <button
              className=" "
              aria-pressed="false"
              data-move-click="setApprovalFilter('rejected')"
            >
              {'Rechazadas'}
            </button>
            <button
              className=" "
              aria-pressed="false"
              data-move-click="setApprovalFilter('all')"
            >
              {'Todas'}
            </button>
          </div>
        </>
      )}
    </MoveSurface>
  );
}
