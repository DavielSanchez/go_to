import React, { useId } from 'react';
import { MoveSurface } from '../MoveSurface.jsx';

/** Bloque extraído del diseño actual de MOVE. Los eventos se exponen mediante onAction. */
export function MoveDriverOnboarding1({
  theme = 'light',
  tenant = 'tp',
  reducedMotion = false,
  onAction,
  className = '',
  style,
  children,
}) {
  const uid = useId();
  return (
    <MoveSurface
      theme={theme}
      tenant={tenant}
      reducedMotion={reducedMotion}
      onAction={onAction}
      className={'' + ' ' + className}
      style={style}
    >
      {children ?? (
        <>
          <div className="narrow ">
            <div className="page-top ">
              <div>
                <h1>{'Registro del conductor'}</h1>
                <p className="sub mt-2 leading-[1.6] text-[var(--muted)]">
                  {'Completa tus datos antes de recibir una ruta.'}
                </p>
              </div>
            </div>
            <div className="onboarding-steps ">
              <span className="active ">{'1. Identidad'}</span>
              <span className=" ">{'2. Vehículo'}</span>
              <span className=" ">{'3. Revisión'}</span>
            </div>
            <form
              id={uid + '-driverOnboarding'}
              className="card mb-[18px] rounded-[var(--radius)] border border-[var(--line)] bg-[var(--surface)] p-6"
              data-move-form=""
            >
              <h2>{'Tu identificación'}</h2>
              <label
                className="label mb-2.5 mt-[22px] block text-sm font-bold"
                htmlFor={uid + '-d-name'}
              >
                {'Nombre completo'}
              </label>
              <input
                id={uid + '-d-name'}
                name="name"
                type="text"
                defaultValue="José Ramírez"
                required
              />
              <label
                className="label mb-2.5 mt-[22px] block text-sm font-bold"
                htmlFor={uid + '-d-cedula'}
              >
                {'Cédula'}
              </label>
              <input
                id={uid + '-d-cedula'}
                name="cedula"
                type="text"
                defaultValue="00000000000"
                required
                inputMode="numeric"
                maxLength="13"
                placeholder="000-0000000-0"
              />
              <div className="photo-field ">
                <b>{'Foto de cédula'}</b>
                <div id={uid + '-preview-id'} className="photo-preview ">
                  <span>
                    <svg
                      className="icon h-[22px] w-[22px] shrink-0 fill-none stroke-current align-middle"
                      viewBox="0 0 24 24"
                      aria-hidden="true"
                      xmlns="http://www.w3.org/2000/svg"
                    >
                      <path
                        d="M5 3h4l2 5-3 2c2 3 3 4 6 6l2-3 5 2v4c-8 5-22-9-16-16"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                      ></path>
                    </svg>
                    {'Sin foto'}
                  </span>
                </div>
                <div className="photo-actions ">
                  <label className="btn secondary flex min-h-[52px] w-full items-center justify-center gap-2.5 rounded-[14px] border-0 px-5 py-4 font-bold disabled:cursor-not-allowed disabled:opacity-45 bg-[var(--soft)] text-[var(--ink)]">
                    {'Tomar foto'}
                    <input
                      type="file"
                      accept="image/*"
                      capture="environment"
                      data-photo="id"
                      hidden
                    />
                  </label>
                  <label className="btn secondary flex min-h-[52px] w-full items-center justify-center gap-2.5 rounded-[14px] border-0 px-5 py-4 font-bold disabled:cursor-not-allowed disabled:opacity-45 bg-[var(--soft)] text-[var(--ink)]">
                    {'Galería'}
                    <input
                      type="file"
                      accept="image/*"
                      data-photo="id"
                      hidden
                    />
                  </label>
                </div>
              </div>
              <div className="photo-field ">
                <b>{'Foto de licencia'}</b>
                <div id={uid + '-preview-license'} className="photo-preview ">
                  <span>
                    <svg
                      className="icon h-[22px] w-[22px] shrink-0 fill-none stroke-current align-middle"
                      viewBox="0 0 24 24"
                      aria-hidden="true"
                      xmlns="http://www.w3.org/2000/svg"
                    >
                      <path
                        d="M5 3h4l2 5-3 2c2 3 3 4 6 6l2-3 5 2v4c-8 5-22-9-16-16"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                      ></path>
                    </svg>
                    {'Sin foto'}
                  </span>
                </div>
                <div className="photo-actions ">
                  <label className="btn secondary flex min-h-[52px] w-full items-center justify-center gap-2.5 rounded-[14px] border-0 px-5 py-4 font-bold disabled:cursor-not-allowed disabled:opacity-45 bg-[var(--soft)] text-[var(--ink)]">
                    {'Tomar foto'}
                    <input
                      type="file"
                      accept="image/*"
                      capture="environment"
                      data-photo="license"
                      hidden
                    />
                  </label>
                  <label className="btn secondary flex min-h-[52px] w-full items-center justify-center gap-2.5 rounded-[14px] border-0 px-5 py-4 font-bold disabled:cursor-not-allowed disabled:opacity-45 bg-[var(--soft)] text-[var(--ink)]">
                    {'Galería'}
                    <input
                      type="file"
                      accept="image/*"
                      data-photo="license"
                      hidden
                    />
                  </label>
                </div>
              </div>
              <p
                id={uid + '-onboardError'}
                className="form-error "
                role="alert"
              ></p>
              <div className="form-actions ">
                <button
                  className="btn flex min-h-[52px] w-full items-center justify-center gap-2.5 rounded-[14px] border-0 bg-[var(--pink)] px-5 py-4 font-bold text-white disabled:cursor-not-allowed disabled:opacity-45"
                  type="submit"
                >
                  {'Continuar'}
                </button>
              </div>
            </form>
            <p className="demo-note ">
              {'Vista de demostración · Datos de ejemplo'}
            </p>
          </div>
        </>
      )}
    </MoveSurface>
  );
}
