import React, { useId } from 'react';
import { MoveSurface } from '../MoveSurface.jsx';

/** Patrón calculator-section usado en landing.js · landingView. */
export function MoveCalculatorSection({
  theme = 'light',
  tenant = 'tp',
  reducedMotion = false,
  onAction,
  className = '',
  style,
  children,
}) {
  const uid = useId();
  return (
    <MoveSurface
      theme={theme}
      tenant={tenant}
      reducedMotion={reducedMotion}
      onAction={onAction}
      className={'' + ' ' + className}
      style={style}
    >
      {children ?? (
        <>
          <section
            className="lp-section calculator-section "
            id={uid + '-calculator'}
          >
            <div className="calc-copy ">
              <span className="lp-kicker ">
                {'05 / ENCUENTRA TU PUNTO DE PARTIDA'}
              </span>
              <h2>
                {'¿Cuánto cuestan'}
                <br />
                {'los asientos vacíos?'}
              </h2>
              <p>
                {
                  'Haz una estimación con los datos de tu operación. El resultado pone en perspectiva el costo del espacio contratado que no se utiliza.'
                }
              </p>
              <p className="calc-disclaimer ">
                {
                  'Estimación orientativa: supone un costo uniforme por asiento y todas las salidas con la misma capacidad. No es una promesa de ahorro.'
                }
              </p>
            </div>
            <div className="calculator-card ">
              <div className="calc-fields ">
                <label>
                  {'Vehículos por día'}
                  <input
                    id={uid + '-calcVehicles'}
                    type="number"
                    defaultValue="12"
                    min="1"
                    max="10000"
                    data-move-input="calculateSeats()"
                  />
                </label>
                <label>
                  {'Asientos por vehículo'}
                  <input
                    id={uid + '-calcSeats'}
                    type="number"
                    defaultValue="20"
                    min="1"
                    max="100"
                    data-move-input="calculateSeats()"
                  />
                </label>
                <label>
                  {'Costo por vehículo / día'}
                  <input
                    id={uid + '-calcCost'}
                    type="number"
                    defaultValue="3500"
                    min="0"
                    max="1000000"
                    data-move-input="calculateSeats()"
                  />
                </label>
                <label>
                  {'Días de servicio al mes'}
                  <input
                    id={uid + '-calcDays'}
                    type="number"
                    defaultValue="22"
                    min="1"
                    max="31"
                    data-move-input="calculateSeats()"
                  />
                </label>
              </div>
              <div className="range-label ">
                <label htmlFor={uid + '-calcOccupancy'}>
                  {'Ocupación promedio'}
                </label>
                <b id={uid + '-occupancyValue'}>{'70%'}</b>
              </div>
              <input
                id={uid + '-calcOccupancy'}
                type="range"
                min="0"
                max="100"
                defaultValue="70"
                data-move-input="calculateSeats()"
              />
              <div className="calc-result " aria-live="polite">
                <span>{'Costo mensual asociado a asientos vacíos'}</span>
                <strong id={uid + '-emptyCost'}>{'RD$277,200'}</strong>
                <small id={uid + '-emptySeats'}>
                  {'72 asientos vacíos por día · Estimación en RD$'}
                </small>
              </div>
            </div>
          </section>
        </>
      )}
    </MoveSurface>
  );
}
