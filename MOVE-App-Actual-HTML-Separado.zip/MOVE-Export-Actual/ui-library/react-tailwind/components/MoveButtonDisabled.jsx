import React, { useId } from 'react';
import { MoveSurface } from '../MoveSurface.jsx';

/** Estado deshabilitado. */
export function MoveButtonDisabled({
  theme = 'light',
  tenant = 'tp',
  reducedMotion = false,
  onAction,
  className = '',
  style,
  children,
}) {
  const uid = useId();
  return (
    <MoveSurface
      theme={theme}
      tenant={tenant}
      reducedMotion={reducedMotion}
      onAction={onAction}
      className={'' + ' ' + className}
      style={style}
    >
      {children ?? (
        <>
          <button
            className="btn flex min-h-[52px] w-full items-center justify-center gap-2.5 rounded-[14px] border-0 bg-[var(--pink)] px-5 py-4 font-bold text-white disabled:cursor-not-allowed disabled:opacity-45"
            disabled
          >
            {'Confirmar transporte'}
          </button>
        </>
      )}
    </MoveSurface>
  );
}
