import React, { useId } from 'react';
import { MoveSurface } from '../MoveSurface.jsx';

/** Bloque extraído del diseño actual de MOVE. Los eventos se exponen mediante onAction. */
export function MoveExceptionForm({
  theme = 'light',
  tenant = 'tp',
  reducedMotion = false,
  onAction,
  className = '',
  style,
  children,
}) {
  const uid = useId();
  return (
    <MoveSurface
      theme={theme}
      tenant={tenant}
      reducedMotion={reducedMotion}
      onAction={onAction}
      className={'' + ' ' + className}
      style={style}
    >
      {children ?? (
        <>
          <div className="narrow ">
            <div className="page-top ">
              <div>
                <h1>{'Excepción de transporte'}</h1>
                <p className="sub mt-2 leading-[1.6] text-[var(--muted)]">
                  {'Solicítala para hoy o para otra fecha.'}
                </p>
              </div>
            </div>
            <form
              id={uid + '-datedExceptionForm'}
              className="card mb-[18px] rounded-[var(--radius)] border border-[var(--line)] bg-[var(--surface)] p-6"
              data-move-form=""
            >
              <span className="step-label ">{'NUEVA SOLICITUD'}</span>
              <div className="two-fields ">
                <div>
                  <label
                    className="label mb-2.5 mt-[22px] block text-sm font-bold"
                    htmlFor={uid + '-requestDate'}
                  >
                    {'Fecha del transporte'}
                  </label>
                  <input
                    id={uid + '-requestDate'}
                    name="date"
                    type="date"
                    defaultValue="2026-10-04"
                    min="2026-10-04"
                    required
                  />
                </div>
                <div>
                  <label
                    className="label mb-2.5 mt-[22px] block text-sm font-bold"
                    htmlFor={uid + '-requestTime'}
                  >
                    {'Hora de salida'}
                  </label>
                  <input
                    id={uid + '-requestTime'}
                    name="time"
                    type="time"
                    defaultValue="22:00"
                    required
                  />
                </div>
              </div>
              <h2
                style={{
                  marginTop: '24px',
                  marginRight: '0px',
                  marginBottom: '16px',
                  marginLeft: '0px',
                  margin: '24px 0px 16px',
                }}
              >
                {'¿Por qué necesitas transporte?'}
              </h2>
              <label className="choice ">
                <input
                  type="radio"
                  name="reason"
                  defaultValue="Horas extra"
                  required
                />
                <b>{'Horas extra'}</b>
              </label>
              <label className="choice ">
                <input
                  type="radio"
                  name="reason"
                  defaultValue="Cambio de turno"
                  required
                />
                <b>{'Cambio de turno'}</b>
              </label>
              <label className="choice ">
                <input
                  type="radio"
                  name="reason"
                  defaultValue="Capacitación"
                  required
                />
                <b>{'Capacitación'}</b>
              </label>
              <label className="choice ">
                <input
                  type="radio"
                  name="reason"
                  defaultValue="Apoyo operativo"
                  required
                />
                <b>{'Apoyo operativo'}</b>
              </label>
              <label className="choice ">
                <input
                  type="radio"
                  name="reason"
                  defaultValue="Otro motivo"
                  required
                />
                <b>{'Otro motivo'}</b>
              </label>
              <label
                className="label mb-2.5 mt-[22px] block text-sm font-bold"
                htmlFor={uid + '-detail'}
              >
                {'Detalles de la solicitud'}
              </label>
              <textarea
                id={uid + '-detail'}
                name="detail"
                required
                maxLength="500"
                placeholder="Cuéntanos por qué necesitas la excepción…"
                defaultValue=""
              />
              <div className="notice my-5 flex gap-2.5 rounded-2xl bg-[var(--notice-bg)] p-4 text-sm leading-[1.55] text-[var(--notice-ink)]">
                <svg
                  className="icon h-[22px] w-[22px] shrink-0 fill-none stroke-current align-middle"
                  viewBox="0 0 24 24"
                  aria-hidden="true"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    d="M12 11v6m0-10v.01M22 12a10 10 0 1 1-20 0 10 10 0 0 1 20 0"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  ></path>
                </svg>
                <span>
                  {
                    'La solicitud requiere aprobación y está sujeta a disponibilidad. Al aprobarse, recibirás el ticket del viaje asignado.'
                  }
                </span>
              </div>
              <button
                className="btn flex min-h-[52px] w-full items-center justify-center gap-2.5 rounded-[14px] border-0 bg-[var(--pink)] px-5 py-4 font-bold text-white disabled:cursor-not-allowed disabled:opacity-45"
                type="submit"
              >
                {'Enviar solicitud'}
              </button>
            </form>
            <p className="demo-note ">
              {'Vista de demostración · Datos de ejemplo'}
            </p>
          </div>
        </>
      )}
    </MoveSurface>
  );
}
