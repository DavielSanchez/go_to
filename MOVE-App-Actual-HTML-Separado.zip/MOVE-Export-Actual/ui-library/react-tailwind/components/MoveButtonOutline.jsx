import React, { useId } from 'react';
import { MoveSurface } from '../MoveSurface.jsx';

/** Acción con borde. */
export function MoveButtonOutline({
  theme = 'light',
  tenant = 'tp',
  reducedMotion = false,
  onAction,
  className = '',
  style,
  children,
}) {
  const uid = useId();
  return (
    <MoveSurface
      theme={theme}
      tenant={tenant}
      reducedMotion={reducedMotion}
      onAction={onAction}
      className={'' + ' ' + className}
      style={style}
    >
      {children ?? (
        <>
          <button className="btn outline flex min-h-[52px] w-full items-center justify-center gap-2.5 rounded-[14px] px-5 py-4 font-bold disabled:cursor-not-allowed disabled:opacity-45 border border-[var(--line)] bg-[var(--surface)] text-[var(--ink)]">
            {'Ver detalles'}
          </button>
        </>
      )}
    </MoveSurface>
  );
}
