import React, { useId } from 'react';
import { MoveSurface } from '../MoveSurface.jsx';

/** Superficie con borde y radio del producto. */
export function MoveCard({
  theme = 'light',
  tenant = 'tp',
  reducedMotion = false,
  onAction,
  className = '',
  style,
  children,
}) {
  const uid = useId();
  return (
    <MoveSurface
      theme={theme}
      tenant={tenant}
      reducedMotion={reducedMotion}
      onAction={onAction}
      className={'' + ' ' + className}
      style={style}
    >
      {children ?? (
        <>
          <section className="card mb-[18px] rounded-[var(--radius)] border border-[var(--line)] bg-[var(--surface)] p-6">
            <h2>{'Tu transporte'}</h2>
            <p className="sub mt-2 leading-[1.6] text-[var(--muted)]">
              {'Información de tu próximo regreso.'}
            </p>
          </section>
        </>
      )}
    </MoveSurface>
  );
}
