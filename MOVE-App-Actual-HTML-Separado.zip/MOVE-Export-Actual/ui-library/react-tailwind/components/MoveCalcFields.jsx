import React, { useId } from 'react';
import { MoveSurface } from '../MoveSurface.jsx';

/** Patrón calc-fields usado en landing.js · landingView. */
export function MoveCalcFields({
  theme = 'light',
  tenant = 'tp',
  reducedMotion = false,
  onAction,
  className = '',
  style,
  children,
}) {
  const uid = useId();
  return (
    <MoveSurface
      theme={theme}
      tenant={tenant}
      reducedMotion={reducedMotion}
      onAction={onAction}
      className={'' + ' ' + className}
      style={style}
    >
      {children ?? (
        <>
          <div className="calc-fields ">
            <label>
              {'Vehículos por día'}
              <input
                id={uid + '-calcVehicles'}
                type="number"
                defaultValue="12"
                min="1"
                max="10000"
                data-move-input="calculateSeats()"
              />
            </label>
            <label>
              {'Asientos por vehículo'}
              <input
                id={uid + '-calcSeats'}
                type="number"
                defaultValue="20"
                min="1"
                max="100"
                data-move-input="calculateSeats()"
              />
            </label>
            <label>
              {'Costo por vehículo / día'}
              <input
                id={uid + '-calcCost'}
                type="number"
                defaultValue="3500"
                min="0"
                max="1000000"
                data-move-input="calculateSeats()"
              />
            </label>
            <label>
              {'Días de servicio al mes'}
              <input
                id={uid + '-calcDays'}
                type="number"
                defaultValue="22"
                min="1"
                max="31"
                data-move-input="calculateSeats()"
              />
            </label>
          </div>
        </>
      )}
    </MoveSurface>
  );
}
