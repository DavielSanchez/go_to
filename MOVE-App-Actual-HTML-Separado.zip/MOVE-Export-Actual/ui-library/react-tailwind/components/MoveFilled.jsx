import React, { useId } from 'react';
import { MoveSurface } from '../MoveSurface.jsx';

/** Patrón filled usado en reviewsView(). */
export function MoveFilled({
  theme = 'light',
  tenant = 'tp',
  reducedMotion = false,
  onAction,
  className = '',
  style,
  children,
}) {
  const uid = useId();
  return (
    <MoveSurface
      theme={theme}
      tenant={tenant}
      reducedMotion={reducedMotion}
      onAction={onAction}
      className={'' + ' ' + className}
      style={style}
    >
      {children ?? (
        <>
          <span className="filled ">
            <svg
              className="icon h-[22px] w-[22px] shrink-0 fill-none stroke-current align-middle"
              viewBox="0 0 24 24"
              aria-hidden="true"
              xmlns="http://www.w3.org/2000/svg"
            >
              <path
                d="M12 3l3 6 7 1-5 5 1 7-6-3-6 3 1-7-5-5 7-1z"
                strokeLinecap="round"
                strokeLinejoin="round"
              ></path>
            </svg>
          </span>
        </>
      )}
    </MoveSurface>
  );
}
