import React, { useId } from 'react';
import { MoveSurface } from '../MoveSurface.jsx';

/** Patrón capability-grid usado en landing.js · landingView. */
export function MoveCapabilityGrid({
  theme = 'light',
  tenant = 'tp',
  reducedMotion = false,
  onAction,
  className = '',
  style,
  children,
}) {
  const uid = useId();
  return (
    <MoveSurface
      theme={theme}
      tenant={tenant}
      reducedMotion={reducedMotion}
      onAction={onAction}
      className={'' + ' ' + className}
      style={style}
    >
      {children ?? (
        <>
          <div className="capability-grid ">
            <article>
              <svg
                className="icon h-[22px] w-[22px] shrink-0 fill-none stroke-current align-middle"
                viewBox="0 0 24 24"
                aria-hidden="true"
                xmlns="http://www.w3.org/2000/svg"
              >
                <path
                  d="M3 7h18v4a2 2 0 0 0 0 4v4H3v-4a2 2 0 0 0 0-4zM15 7v2m0 3v2m0 3v2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                ></path>
              </svg>
              <h3>{'Excepciones sin perder el contexto'}</h3>
              <p>
                {
                  'Solicitudes por horas extra, capacitaciones y cambios de turno, con estado de aprobación.'
                }
              </p>
            </article>
            <article>
              <svg
                className="icon h-[22px] w-[22px] shrink-0 fill-none stroke-current align-middle"
                viewBox="0 0 24 24"
                aria-hidden="true"
                xmlns="http://www.w3.org/2000/svg"
              >
                <path
                  d="M20 10c0 6-8 12-8 12S4 16 4 10a8 8 0 1 1 16 0M15 10a3 3 0 1 1-6 0 3 3 0 0 1 6 0"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                ></path>
              </svg>
              <h3>{'Destinos y zonas organizados'}</h3>
              <p>
                {
                  'Ubicación de destino, paradas y asignación de vehículos para cada recorrido.'
                }
              </p>
            </article>
            <article>
              <svg
                className="icon h-[22px] w-[22px] shrink-0 fill-none stroke-current align-middle"
                viewBox="0 0 24 24"
                aria-hidden="true"
                xmlns="http://www.w3.org/2000/svg"
              >
                <path
                  d="M12 3l8 3v6c0 5-8 9-8 9s-8-4-8-9V6zM8 12l3 3 5-6"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                ></path>
              </svg>
              <h3>{'Validación antes de abordar'}</h3>
              <p>
                {
                  'Tickets por fecha, horario y unidad. Cada conductor valida a sus pasajeros asignados.'
                }
              </p>
            </article>
            <article>
              <svg
                className="icon h-[22px] w-[22px] shrink-0 fill-none stroke-current align-middle"
                viewBox="0 0 24 24"
                aria-hidden="true"
                xmlns="http://www.w3.org/2000/svg"
              >
                <path
                  d="M5 3h4l2 5-3 2c2 3 3 4 6 6l2-3 5 2v4c-8 5-22-9-16-16"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                ></path>
              </svg>
              <h3>{'Pensado para el celular'}</h3>
              <p>
                {
                  'Una PWA para empleados y conductores, con una interfaz que se adapta a su jornada.'
                }
              </p>
            </article>
            <article>
              <svg
                className="icon h-[22px] w-[22px] shrink-0 fill-none stroke-current align-middle"
                viewBox="0 0 24 24"
                aria-hidden="true"
                xmlns="http://www.w3.org/2000/svg"
              >
                <path
                  d="M21 11a9 9 0 0 1-9 9H4l-3 2 2-6a9 9 0 1 1 18-5M7 11h10"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                ></path>
              </svg>
              <h3>{'Incidencias documentadas'}</h3>
              <p>
                {
                  'Un lugar para registrar retrasos, averías u otros problemas durante el servicio.'
                }
              </p>
            </article>
            <article>
              <svg
                className="icon h-[22px] w-[22px] shrink-0 fill-none stroke-current align-middle"
                viewBox="0 0 24 24"
                aria-hidden="true"
                xmlns="http://www.w3.org/2000/svg"
              >
                <path
                  d="M12 3l3 6 7 1-5 5 1 7-6-3-6 3 1-7-5-5 7-1z"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                ></path>
              </svg>
              <h3>{'La voz de quienes viajan'}</h3>
              <p>
                {
                  'Calificaciones y comentarios al terminar el recorrido para conocer la experiencia.'
                }
              </p>
            </article>
          </div>
        </>
      )}
    </MoveSurface>
  );
}
