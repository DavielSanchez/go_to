import React, { useId } from 'react';
import { MoveSurface } from '../MoveSurface.jsx';
import asset0 from '../../assets/trueshore-logo.svg';
/** Colaboración de empresa y MOVE. */
export function MoveBrandTrueshore({
  theme = 'light',
  tenant = 'trueshore',
  reducedMotion = false,
  onAction,
  className = '',
  style,
  children,
}) {
  const uid = useId();
  return (
    <MoveSurface
      theme={theme}
      tenant={tenant}
      reducedMotion={reducedMotion}
      onAction={onAction}
      className={'' + ' ' + className}
      style={style}
    >
      {children ?? (
        <>
          <div className="brand-collab ">
            <img
              className="tenant-logo partner-logo trueshore-logo "
              src={asset0}
              alt="TrueShore"
            />
            <span className="collab-cross " aria-hidden="true">
              {'×'}
            </span>
            <span className="brand ">
              {'MOVE'}
              <span className="brand-dot "></span>
            </span>
          </div>
        </>
      )}
    </MoveSurface>
  );
}
