import React, { useId } from 'react';
import { MoveSurface } from '../MoveSurface.jsx';

/** Patrón history-wrap usado en views.history(). */
export function MoveHistoryWrap({
  theme = 'light',
  tenant = 'tp',
  reducedMotion = false,
  onAction,
  className = '',
  style,
  children,
}) {
  const uid = useId();
  return (
    <MoveSurface
      theme={theme}
      tenant={tenant}
      reducedMotion={reducedMotion}
      onAction={onAction}
      className={'' + ' ' + className}
      style={style}
    >
      {children ?? (
        <>
          <div className="history-wrap ">
            <div className="page-top ">
              <div>
                <h1>{'Mis viajes'}</h1>
                <p className="sub mt-2 leading-[1.6] text-[var(--muted)]">
                  {'Un registro de tus regresos a casa.'}
                </p>
              </div>
            </div>
            <div className="section-heading ">
              <h2>{'Octubre 2026'}</h2>
              <span className="pill inline-flex items-center gap-1.5 rounded-full px-[11px] py-[7px] text-xs font-bold">
                {'2 viajes'}
              </span>
            </div>
            <div className="card mb-[18px] rounded-[var(--radius)] border border-[var(--line)] bg-[var(--surface)] p-6">
              <div className="history-item ">
                <span className="icon-box ">
                  <svg
                    className="icon h-[22px] w-[22px] shrink-0 fill-none stroke-current align-middle"
                    viewBox="0 0 24 24"
                    aria-hidden="true"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path
                      d="M5 16V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2v11M5 11h14M8 3v8m8-8v8M5 16h14v3H5zM7 19v3m10-3v3M8 14h.01M16 14h.01"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    ></path>
                  </svg>
                </span>
                <div>
                  <h3>{'Jueves, 1 de octubre'}</h3>
                  <p>{'Churchill → Los Alcarrizos'}</p>
                  <p>{'10:30 p. m. · Ruta 04'}</p>
                </div>
                <div className="history-end ">
                  <span className="pill green inline-flex items-center gap-1.5 rounded-full px-[11px] py-[7px] text-xs font-bold">
                    {'Finalizado'}
                  </span>
                  <div style={{ marginTop: '8px' }}>{'★ 5.0'}</div>
                </div>
              </div>
              <div className="history-item ">
                <span className="icon-box ">
                  <svg
                    className="icon h-[22px] w-[22px] shrink-0 fill-none stroke-current align-middle"
                    viewBox="0 0 24 24"
                    aria-hidden="true"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path
                      d="M5 16V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2v11M5 11h14M8 3v8m8-8v8M5 16h14v3H5zM7 19v3m10-3v3M8 14h.01M16 14h.01"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    ></path>
                  </svg>
                </span>
                <div>
                  <h3>{'Miércoles, 30 de septiembre'}</h3>
                  <p>{'Churchill → Los Alcarrizos'}</p>
                  <p>{'10:30 p. m. · Ruta 04'}</p>
                </div>
                <div className="history-end ">
                  <span className="pill green inline-flex items-center gap-1.5 rounded-full px-[11px] py-[7px] text-xs font-bold">
                    {'Finalizado'}
                  </span>
                  <div style={{ marginTop: '8px' }}>{'★ 4.0'}</div>
                </div>
              </div>
            </div>
            <p className="demo-note ">
              {'Vista de demostración · Datos de ejemplo'}
            </p>
          </div>
        </>
      )}
    </MoveSurface>
  );
}
