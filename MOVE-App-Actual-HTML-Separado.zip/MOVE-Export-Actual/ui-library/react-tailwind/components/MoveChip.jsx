import React, { useId } from 'react';
import { MoveSurface } from '../MoveSurface.jsx';

/** Chip seleccionable. */
export function MoveChip({
  theme = 'light',
  tenant = 'tp',
  reducedMotion = false,
  onAction,
  className = '',
  style,
  children,
}) {
  const uid = useId();
  return (
    <MoveSurface
      theme={theme}
      tenant={tenant}
      reducedMotion={reducedMotion}
      onAction={onAction}
      className={'' + ' ' + className}
      style={style}
    >
      {children ?? (
        <>
          <div className="tags my-[18px] flex flex-wrap justify-center gap-[9px]">
            <button
              className="tag selected rounded-full border border-[var(--line)] bg-[var(--surface)] px-[13px] py-2.5 text-[13px]"
              aria-pressed="true"
            >
              {'Puntualidad'}
            </button>
            <button
              className="tag rounded-full border border-[var(--line)] bg-[var(--surface)] px-[13px] py-2.5 text-[13px]"
              aria-pressed="false"
            >
              {'Comodidad'}
            </button>
          </div>
        </>
      )}
    </MoveSurface>
  );
}
