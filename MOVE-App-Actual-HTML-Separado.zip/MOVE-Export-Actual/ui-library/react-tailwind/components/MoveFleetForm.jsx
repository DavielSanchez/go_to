import React, { useId } from 'react';
import { MoveSurface } from '../MoveSurface.jsx';

/** Bloque extraído del diseño actual de MOVE. Los eventos se exponen mediante onAction. */
export function MoveFleetForm({
  theme = 'light',
  tenant = 'tp',
  reducedMotion = false,
  onAction,
  className = '',
  style,
  children,
}) {
  const uid = useId();
  return (
    <MoveSurface
      theme={theme}
      tenant={tenant}
      reducedMotion={reducedMotion}
      onAction={onAction}
      className={'' + ' ' + className}
      style={style}
    >
      {children ?? (
        <>
          <form data-move-submit="saveFleetType(event,'')" data-move-form="">
            <p className="ops-muted ">{'TP · Churchill'}</p>
            <label className="ops-label ">
              {'Nombre del tipo'}
              <input name="name" required defaultValue="" />
            </label>
            <div className="ops-form-grid ">
              <label className="ops-label ">
                {'Capacidad'}
                <input
                  type="number"
                  min="2"
                  max="80"
                  name="capacity"
                  required
                  defaultValue="15"
                />
              </label>
              <label className="ops-label ">
                {'Gap'}
                <input
                  type="number"
                  min="0"
                  max="79"
                  name="gap"
                  required
                  defaultValue="2"
                />
              </label>
            </div>
            <label className="ops-label ">
              {'Estado'}
              <select name="active">
                <option value="true">{'Activo'}</option>
                <option value="false">{'Inactivo'}</option>
              </select>
            </label>
            <label className="ops-label ">
              {'Motivo'}
              <textarea
                name="reason"
                required
                minLength="8"
                maxLength="500"
                placeholder="Describe el motivo de este cambio."
                defaultValue=""
              />
            </label>
            <p
              className="ops-form-error "
              role="alert"
              id={uid + '-managementError'}
            ></p>
            <button className="ops-button ">{'Guardar tipo'}</button>
          </form>
        </>
      )}
    </MoveSurface>
  );
}
