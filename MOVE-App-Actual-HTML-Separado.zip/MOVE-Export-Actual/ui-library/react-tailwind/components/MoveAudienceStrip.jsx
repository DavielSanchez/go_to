import React, { useId } from 'react';
import { MoveSurface } from '../MoveSurface.jsx';

/** Patrón audience-strip usado en landing.js · landingView. */
export function MoveAudienceStrip({
  theme = 'light',
  tenant = 'tp',
  reducedMotion = false,
  onAction,
  className = '',
  style,
  children,
}) {
  const uid = useId();
  return (
    <MoveSurface
      theme={theme}
      tenant={tenant}
      reducedMotion={reducedMotion}
      onAction={onAction}
      className={'' + ' ' + className}
      style={style}
    >
      {children ?? (
        <>
          <div className="audience-strip ">
            <span>{'HECHO PARA OPERACIONES QUE NO SE DETIENEN'}</span>
            <div>{'Contact centers'}</div>
            <div>{'Manufactura'}</div>
            <div>{'Logística'}</div>
            <div>{'Servicios'}</div>
          </div>
        </>
      )}
    </MoveSurface>
  );
}
