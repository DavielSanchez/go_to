import React, { useId } from 'react';
import { MoveSurface } from '../MoveSurface.jsx';

/** Patrón faq-section usado en landing.js · landingView. */
export function MoveFaqSection({
  theme = 'light',
  tenant = 'tp',
  reducedMotion = false,
  onAction,
  className = '',
  style,
  children,
}) {
  const uid = useId();
  return (
    <MoveSurface
      theme={theme}
      tenant={tenant}
      reducedMotion={reducedMotion}
      onAction={onAction}
      className={'' + ' ' + className}
      style={style}
    >
      {children ?? (
        <>
          <section className="lp-section faq-section ">
            <div>
              <span className="lp-kicker ">{'PREGUNTAS FRECUENTES'}</span>
              <h2>
                {'Antes de subir'}
                <br />
                {'a bordo.'}
              </h2>
            </div>
            <div className="faq-list ">
              <details>
                <summary>
                  {'¿MOVE es una empresa de transporte?'}
                  <span>{'+'}</span>
                </summary>
                <p>
                  {
                    'MOVE es la solución digital que organiza el servicio. Tu empresa y sus proveedores conservan la operación de los vehículos y conductores.'
                  }
                </p>
              </details>
              <details>
                <summary>
                  {'¿Puede usarse en otras empresas además de TP?'}
                  <span>{'+'}</span>
                </summary>
                <p>
                  {
                    'Sí. La propuesta está pensada para empresas que ofrecen transporte de personal. El prototipo usa un contexto de TP para mostrar los recorridos y experiencias.'
                  }
                </p>
              </details>
              <details>
                <summary>
                  {'¿Qué puedo probar ahora?'}
                  <span>{'+'}</span>
                </summary>
                <p>
                  {
                    'Puedes explorar el login simulado, confirmar transporte, solicitar excepciones y recorrer el flujo del conductor: registro, zona, abordaje, viaje y perfil.'
                  }
                </p>
              </details>
              <details>
                <summary>
                  {'¿Los datos y resultados son reales?'}
                  <span>{'+'}</span>
                </summary>
                <p>
                  {
                    'No. Esta presentación y el prototipo utilizan datos mock. Las métricas son ilustrativas y no corresponden a resultados comprobados de un cliente.'
                  }
                </p>
              </details>
              <details>
                <summary>
                  {'¿Ya incluye autenticación e integraciones empresariales?'}
                  <span>{'+'}</span>
                </summary>
                <p>
                  {
                    'El prototipo muestra la experiencia del producto. La autenticación real, las integraciones y la operación sincronizada entre dispositivos se definirán para la implementación.'
                  }
                </p>
              </details>
            </div>
          </section>
        </>
      )}
    </MoveSurface>
  );
}
