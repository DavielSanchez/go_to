import React, { useId } from 'react';
import { MoveSurface } from '../MoveSurface.jsx';

/** Bloque extraído del diseño actual de MOVE. Los eventos se exponen mediante onAction. */
export function MoveAddressEditor({
  theme = 'light',
  tenant = 'tp',
  reducedMotion = false,
  onAction,
  className = '',
  style,
  children,
}) {
  const uid = useId();
  return (
    <MoveSurface
      theme={theme}
      tenant={tenant}
      reducedMotion={reducedMotion}
      onAction={onAction}
      className={'' + ' ' + className}
      style={style}
    >
      {children ?? (
        <>
          <div className="narrow ">
            <button
              className="back mb-[18px] flex items-center gap-[7px] border-0 bg-transparent p-0 text-sm text-[var(--muted)]"
              data-move-click="navigate('profile')"
            >
              <svg
                className="icon h-[22px] w-[22px] shrink-0 fill-none stroke-current align-middle"
                viewBox="0 0 24 24"
                aria-hidden="true"
                xmlns="http://www.w3.org/2000/svg"
              >
                <path
                  d="M15 5l-7 7 7 7"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                ></path>
              </svg>
              {'Mi perfil'}
            </button>
            <div className="page-top ">
              <div>
                <h1>{'Cambiar mi dirección'}</h1>
                <p className="sub mt-2 leading-[1.6] text-[var(--muted)]">
                  {'Marca tu destino en el mapa.'}
                </p>
              </div>
            </div>
            <form
              id={uid + '-pinAddressForm'}
              className="card mb-[18px] rounded-[var(--radius)] border border-[var(--line)] bg-[var(--surface)] p-6"
              data-move-form=""
            >
              <span className="pill  inline-flex items-center gap-1.5 rounded-full px-[11px] py-[7px] text-xs font-bold">
                {'3 cambios automáticos disponibles'}
              </span>
              <label
                className="label mb-2.5 mt-[22px] block text-sm font-bold"
                htmlFor={uid + '-destinationMap'}
              >
                {'Ubicación en el mapa · Obligatoria'}
              </label>
              <p className="small-info text-sm leading-[1.55] text-[var(--muted)]">
                {
                  'Toca el mapa para colocar el pin o arrástralo para ajustar tu destino.'
                }
              </p>
              <button
                id={uid + '-gpsButton'}
                type="button"
                className="btn secondary flex min-h-[52px] w-full items-center justify-center gap-2.5 rounded-[14px] border-0 px-5 py-4 font-bold disabled:cursor-not-allowed disabled:opacity-45 bg-[var(--soft)] text-[var(--ink)]"
                style={{
                  marginTop: '14px',
                  marginRight: '0px',
                  marginBottom: '14px',
                  marginLeft: '0px',
                  margin: '14px 0px',
                }}
                data-move-click="useGPS()"
              >
                <svg
                  className="icon h-[22px] w-[22px] shrink-0 fill-none stroke-current align-middle"
                  viewBox="0 0 24 24"
                  aria-hidden="true"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    d="M20 10c0 6-8 12-8 12S4 16 4 10a8 8 0 1 1 16 0M15 10a3 3 0 1 1-6 0 3 3 0 0 1 6 0"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  ></path>
                </svg>
                {'Usar mi ubicación actual'}
              </button>
              <div
                id={uid + '-destinationMap'}
                role="region"
                aria-label="Mapa para seleccionar el destino"
                tabIndex="0"
              ></div>
              <p
                id={uid + '-pinStatus'}
                className="small-info text-sm leading-[1.55] text-[var(--muted)]"
                role="status"
                style={{ marginTop: '12px' }}
              >
                {'Selecciona una ubicación en el mapa.'}
              </p>
              <p
                className="small-info text-sm leading-[1.55] text-[var(--muted)]"
                style={{ marginTop: '6px' }}
              >
                {
                  'Con teclado: usa las flechas para mover el centro y Enter para colocar el pin.'
                }
              </p>
              <label
                className="label mb-2.5 mt-[22px] block text-sm font-bold"
                htmlFor={uid + '-destination'}
              >
                {'Dirección escrita '}
                <span className="small-info text-sm leading-[1.55] text-[var(--muted)]">
                  {'· Opcional'}
                </span>
              </label>
              <textarea
                id={uid + '-destination'}
                name="destination"
                maxLength="250"
                placeholder="Calle, número, sector o una referencia…"
                defaultValue="Entrada de Pantoja · Los Alcarrizos"
              />
              <div className="notice my-5 flex gap-2.5 rounded-2xl bg-[var(--notice-bg)] p-4 text-sm leading-[1.55] text-[var(--notice-ink)]">
                <svg
                  className="icon h-[22px] w-[22px] shrink-0 fill-none stroke-current align-middle"
                  viewBox="0 0 24 24"
                  aria-hidden="true"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    d="M12 11v6m0-10v.01M22 12a10 10 0 1 1-20 0 10 10 0 0 1 20 0"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  ></path>
                </svg>
                <span>{'Este será tu cambio automático 1 de 3.'}</span>
              </div>
              <button
                id={uid + '-savePin'}
                className="btn flex min-h-[52px] w-full items-center justify-center gap-2.5 rounded-[14px] border-0 bg-[var(--pink)] px-5 py-4 font-bold text-white disabled:cursor-not-allowed disabled:opacity-45"
                type="submit"
                disabled
              >
                {'Guardar dirección'}
              </button>
            </form>
            <p className="demo-note ">
              {'Vista de demostración · Datos de ejemplo'}
            </p>
          </div>
        </>
      )}
    </MoveSurface>
  );
}
