import React, { useId } from 'react';
import { MoveSurface } from '../MoveSurface.jsx';

/** Patrón eta usado en views.trip(). */
export function MoveEta({
  theme = 'light',
  tenant = 'tp',
  reducedMotion = false,
  onAction,
  className = '',
  style,
  children,
}) {
  const uid = useId();
  return (
    <MoveSurface
      theme={theme}
      tenant={tenant}
      reducedMotion={reducedMotion}
      onAction={onAction}
      className={'' + ' ' + className}
      style={style}
    >
      {children ?? (
        <>
          <div className="eta ">
            {'12'}
            <small>{'minutos'}</small>
          </div>
        </>
      )}
    </MoveSurface>
  );
}
