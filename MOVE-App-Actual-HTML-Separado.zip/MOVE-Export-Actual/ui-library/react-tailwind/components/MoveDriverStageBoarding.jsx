import React, { useId } from 'react';
import { MoveSurface } from '../MoveSurface.jsx';

/** Bloque extraído del diseño actual de MOVE. Los eventos se exponen mediante onAction. */
export function MoveDriverStageBoarding({
  theme = 'light',
  tenant = 'tp',
  reducedMotion = false,
  onAction,
  className = '',
  style,
  children,
}) {
  const uid = useId();
  return (
    <MoveSurface
      theme={theme}
      tenant={tenant}
      reducedMotion={reducedMotion}
      onAction={onAction}
      className={'' + ' ' + className}
      style={style}
    >
      {children ?? (
        <>
          <div className="date ">{'4 DE OCTUBRE DE 2026'}</div>
          <div className="page-top ">
            <div>
              <h1>
                {'Hola, José '}
                <span className="accent text-[var(--pink)]">{'.'}</span>
              </h1>
              <p className="sub mt-2 leading-[1.6] text-[var(--muted)]">
                {'Transporte externo · Proveedor asignado'}
              </p>
            </div>
          </div>
          <div className="home-grid ">
            <section>
              <div className="card mb-[18px] rounded-[var(--radius)] border border-[var(--line)] bg-[var(--surface)] p-6">
                <div className="section-heading " style={{ marginTop: '0px' }}>
                  <h2>{'Ruta 04 · Los Alcarrizos'}</h2>
                  <span className="pill inline-flex items-center gap-1.5 rounded-full px-[11px] py-[7px] text-xs font-bold">
                    {'Unidad 12'}
                  </span>
                </div>
                <div className="info-grid grid grid-cols-2 gap-4 border-t border-[var(--line)] pt-[18px]">
                  <div>
                    <small>{'Salida asignada'}</small>
                    <b>{'22:30 · 4 de octubre de 2026'}</b>
                  </div>
                  <div>
                    <small>{'Tu grupo de pasajeros'}</small>
                    <b>{'6 · 3 paradas'}</b>
                  </div>
                </div>
                <div className="stop-list ">
                  <div className="stop-row ">
                    <span className="stop-number ">{'1'}</span>
                    <div>
                      <b>{'Los Girasoles'}</b>
                      <p className="small-info text-sm leading-[1.55] text-[var(--muted)]">
                        {'Ana Pérez · Carlos Mejía'}
                      </p>
                    </div>
                  </div>
                  <div className="stop-row ">
                    <span className="stop-number ">{'2'}</span>
                    <div>
                      <b>{'Ciudad Real'}</b>
                      <p className="small-info text-sm leading-[1.55] text-[var(--muted)]">
                        {'Laura Díaz · Miguel Santos'}
                      </p>
                    </div>
                  </div>
                  <div className="stop-row ">
                    <span className="stop-number ">{'3'}</span>
                    <div>
                      <b>{'Entrada de Pantoja'}</b>
                      <p className="small-info text-sm leading-[1.55] text-[var(--muted)]">
                        {'Daviel Sánchez · Sofía Rodríguez'}
                      </p>
                    </div>
                  </div>
                </div>
                <p className="route-locked ">
                  <svg
                    className="icon h-[22px] w-[22px] shrink-0 fill-none stroke-current align-middle"
                    viewBox="0 0 24 24"
                    aria-hidden="true"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path
                      d="M12 3l8 3v6c0 5-8 9-8 9s-8-4-8-9V6zM8 12l3 3 5-6"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    ></path>
                  </svg>
                  {'La hora de esta ruta está fijada por su QR.'}
                </p>
                <p
                  className="small-info text-sm leading-[1.55] text-[var(--muted)]"
                  style={{ marginBottom: '18px' }}
                >
                  {
                    'Tu abordaje está disponible junto al de las demás unidades de la zona.'
                  }
                </p>
                <button
                  className="btn flex min-h-[52px] w-full items-center justify-center gap-2.5 rounded-[14px] border-0 bg-[var(--pink)] px-5 py-4 font-bold text-white disabled:cursor-not-allowed disabled:opacity-45"
                  data-move-click="navigate('driver-board')"
                >
                  <svg
                    className="icon h-[22px] w-[22px] shrink-0 fill-none stroke-current align-middle"
                    viewBox="0 0 24 24"
                    aria-hidden="true"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path
                      d="M3 7h18v4a2 2 0 0 0 0 4v4H3v-4a2 2 0 0 0 0-4zM15 7v2m0 3v2m0 3v2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    ></path>
                  </svg>
                  {'Abrir abordaje'}
                </button>
              </div>
            </section>
            <section>
              <div className="card mb-[18px] rounded-[var(--radius)] border border-[var(--line)] bg-[var(--surface)] p-6">
                <h2>{'Vehículos de la misma zona'}</h2>
                <p
                  className="small-info text-sm leading-[1.55] text-[var(--muted)]"
                  style={{ marginTop: '10px' }}
                >
                  {
                    'Zona 04 · Los Alcarrizos. El orden de llegada reparte los pasajeros entre unidades; cada conductor escanea su grupo al mismo tiempo.'
                  }
                </p>
                <div className="zone-vehicle ">
                  <div>
                    <b>{'Unidad 10'}</b>
                    <p className="small-info text-sm leading-[1.55] text-[var(--muted)]">
                      {'Llegada 1 · 6 pasajeros asignados'}
                    </p>
                  </div>
                  <span className="pill green inline-flex items-center gap-1.5 rounded-full px-[11px] py-[7px] text-xs font-bold">
                    {'0/6 a bordo'}
                  </span>
                </div>
                <div className="zone-vehicle ">
                  <div>
                    <b>{'Unidad 11'}</b>
                    <p className="small-info text-sm leading-[1.55] text-[var(--muted)]">
                      {'Llegada 2 · 6 pasajeros asignados'}
                    </p>
                  </div>
                  <span className="pill green inline-flex items-center gap-1.5 rounded-full px-[11px] py-[7px] text-xs font-bold">
                    {'0/6 a bordo'}
                  </span>
                </div>
                <div className="zone-vehicle ">
                  <div>
                    <b>{'Unidad 12 · Tú'}</b>
                    <p className="small-info text-sm leading-[1.55] text-[var(--muted)]">
                      {'Llegada 3 · 6 pasajeros asignados'}
                    </p>
                  </div>
                  <span className="pill green inline-flex items-center gap-1.5 rounded-full px-[11px] py-[7px] text-xs font-bold">
                    {'0/6 a bordo'}
                  </span>
                </div>
                <details style={{ marginTop: '18px' }}>
                  <summary>{'Probar abordaje simultáneo'}</summary>
                  <p
                    className="small-info text-sm leading-[1.55] text-[var(--muted)]"
                    style={{
                      marginTop: '12px',
                      marginRight: '0px',
                      marginBottom: '12px',
                      marginLeft: '0px',
                      margin: '12px 0px',
                    }}
                  >
                    {
                      'Simula escaneos en las otras unidades. Sus registros no cambian tus pasajeros ni bloquean tu escáner.'
                    }
                  </p>
                  <div className="form-actions ">
                    <button
                      className="btn secondary flex min-h-[52px] w-full items-center justify-center gap-2.5 rounded-[14px] border-0 px-5 py-4 font-bold disabled:cursor-not-allowed disabled:opacity-45 bg-[var(--soft)] text-[var(--ink)]"
                      data-move-click="scanOtherVehicle('10')"
                    >
                      {'Escanear en unidad 10'}
                    </button>
                    <button
                      className="btn secondary flex min-h-[52px] w-full items-center justify-center gap-2.5 rounded-[14px] border-0 px-5 py-4 font-bold disabled:cursor-not-allowed disabled:opacity-45 bg-[var(--soft)] text-[var(--ink)]"
                      data-move-click="scanOtherVehicle('11')"
                    >
                      {'Escanear en unidad 11'}
                    </button>
                  </div>
                </details>
              </div>
              <div className="card mb-[18px] rounded-[var(--radius)] border border-[var(--line)] bg-[var(--surface)] p-6">
                <h2>{'Tu jornada'}</h2>
                <div className="metric-row ">
                  <div>
                    <strong>{'0'}</strong>
                    <small>{'Abordaron'}</small>
                  </div>
                  <div>
                    <strong>{'0'}</strong>
                    <small>{'Incidencias'}</small>
                  </div>
                  <div>
                    <strong>{'0'}</strong>
                    <small>{'Viajes completados'}</small>
                  </div>
                </div>
              </div>
              <a
                className="card help-card mb-[18px] rounded-[var(--radius)] border border-[var(--line)] bg-[var(--surface)] p-6"
                href="#driver-incident"
              >
                <span className="icon-box ">
                  <svg
                    className="icon h-[22px] w-[22px] shrink-0 fill-none stroke-current align-middle"
                    viewBox="0 0 24 24"
                    aria-hidden="true"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path
                      d="M12 11v6m0-10v.01M22 12a10 10 0 1 1-20 0 10 10 0 0 1 20 0"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    ></path>
                  </svg>
                </span>
                <div>
                  <h3>{'Reportar una incidencia'}</h3>
                  <p>{'Avería, retraso, seguridad u otro problema.'}</p>
                </div>
                <svg
                  className="icon h-[22px] w-[22px] shrink-0 fill-none stroke-current align-middle"
                  viewBox="0 0 24 24"
                  aria-hidden="true"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    d="M9 5l7 7-7 7"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  ></path>
                </svg>
              </a>
              <div className="notice my-5 flex gap-2.5 rounded-2xl bg-[var(--notice-bg)] p-4 text-sm leading-[1.55] text-[var(--notice-ink)]">
                <svg
                  className="icon h-[22px] w-[22px] shrink-0 fill-none stroke-current align-middle"
                  viewBox="0 0 24 24"
                  aria-hidden="true"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    d="M12 11v6m0-10v.01M22 12a10 10 0 1 1-20 0 10 10 0 0 1 20 0"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  ></path>
                </svg>
                <span>
                  {
                    'Proveedor y asignaciones de ejemplo. El registro inicial no sustituye la revisión de documentos del proveedor.'
                  }
                </span>
              </div>
            </section>
          </div>
          <p className="demo-note ">
            {'Vista de demostración · Datos de ejemplo'}
          </p>
        </>
      )}
    </MoveSurface>
  );
}
