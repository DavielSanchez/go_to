import React, { useId } from 'react';
import { MoveSurface } from '../MoveSurface.jsx';

/** Patrón dashboard-title usado en landing.js · landingView. */
export function MoveDashboardTitle({
  theme = 'light',
  tenant = 'tp',
  reducedMotion = false,
  onAction,
  className = '',
  style,
  children,
}) {
  const uid = useId();
  return (
    <MoveSurface
      theme={theme}
      tenant={tenant}
      reducedMotion={reducedMotion}
      onAction={onAction}
      className={'' + ' ' + className}
      style={style}
    >
      {children ?? (
        <>
          <div className="dashboard-title ">
            <b>{'Ocupación por salida'}</b>
            <span>{'Datos mock'}</span>
          </div>
        </>
      )}
    </MoveSurface>
  );
}
