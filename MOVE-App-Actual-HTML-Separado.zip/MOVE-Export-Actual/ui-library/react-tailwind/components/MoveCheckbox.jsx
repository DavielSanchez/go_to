import React, { useId } from 'react';
import { MoveSurface } from '../MoveSurface.jsx';

/** Checkbox y texto explicativo. */
export function MoveCheckbox({
  theme = 'light',
  tenant = 'tp',
  reducedMotion = false,
  onAction,
  className = '',
  style,
  children,
}) {
  const uid = useId();
  return (
    <MoveSurface
      theme={theme}
      tenant={tenant}
      reducedMotion={reducedMotion}
      onAction={onAction}
      className={'' + ' ' + className}
      style={style}
    >
      {children ?? (
        <>
          <label className="choice ">
            <input type="checkbox" />
            <span>
              <b>{'He revisado los pendientes'}</b>
              <small>
                {'Confirmar el plan no cierra la recepción antes del cutoff.'}
              </small>
            </span>
          </label>
        </>
      )}
    </MoveSurface>
  );
}
