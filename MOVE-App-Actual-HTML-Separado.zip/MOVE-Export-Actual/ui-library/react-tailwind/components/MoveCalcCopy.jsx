import React, { useId } from 'react';
import { MoveSurface } from '../MoveSurface.jsx';

/** Patrón calc-copy usado en landing.js · landingView. */
export function MoveCalcCopy({
  theme = 'light',
  tenant = 'tp',
  reducedMotion = false,
  onAction,
  className = '',
  style,
  children,
}) {
  const uid = useId();
  return (
    <MoveSurface
      theme={theme}
      tenant={tenant}
      reducedMotion={reducedMotion}
      onAction={onAction}
      className={'' + ' ' + className}
      style={style}
    >
      {children ?? (
        <>
          <div className="calc-copy ">
            <span className="lp-kicker ">
              {'05 / ENCUENTRA TU PUNTO DE PARTIDA'}
            </span>
            <h2>
              {'¿Cuánto cuestan'}
              <br />
              {'los asientos vacíos?'}
            </h2>
            <p>
              {
                'Haz una estimación con los datos de tu operación. El resultado pone en perspectiva el costo del espacio contratado que no se utiliza.'
              }
            </p>
            <p className="calc-disclaimer ">
              {
                'Estimación orientativa: supone un costo uniforme por asiento y todas las salidas con la misma capacidad. No es una promesa de ahorro.'
              }
            </p>
          </div>
        </>
      )}
    </MoveSurface>
  );
}
