import React, { useId } from 'react';
import { MoveSurface } from '../MoveSurface.jsx';

/** Bloque extraído del diseño actual de MOVE. Los eventos se exponen mediante onAction. */
export function MoveDepartureSelection({
  theme = 'light',
  tenant = 'tp',
  reducedMotion = false,
  onAction,
  className = '',
  style,
  children,
}) {
  const uid = useId();
  return (
    <MoveSurface
      theme={theme}
      tenant={tenant}
      reducedMotion={reducedMotion}
      onAction={onAction}
      className={'' + ' ' + className}
      style={style}
    >
      {children ?? (
        <>
          <div className="narrow departure-wrap ">
            <div className="page-top ">
              <div>
                <h1>{'¿Quieres cambiar de hora?'}</h1>
                <p className="sub mt-2 leading-[1.6] text-[var(--muted)]">
                  {'Elige la ventana para tu transporte de hoy.'}
                </p>
              </div>
            </div>
            <div className="card mb-[18px] rounded-[var(--radius)] border border-[var(--line)] bg-[var(--surface)] p-6">
              <span className="pill inline-flex items-center gap-1.5 rounded-full px-[11px] py-[7px] text-xs font-bold">
                {'CONFIRMACIÓN DIARIA'}
              </span>
              <h2 style={{ marginTop: '18px' }}>{'Tu salida, a tu ritmo.'}</h2>
              <p className="sub mt-2 leading-[1.6] text-[var(--muted)]">
                {
                  'Puedes mantener tu hora preferida o elegir otra de las ventanas disponibles.'
                }
              </p>
              <div
                className="departure-options "
                role="group"
                aria-label="Ventanas disponibles"
              >
                <button
                  className="departure-option  "
                  aria-pressed="false"
                  data-move-click="chooseDeparture('21:30')"
                >
                  <span>
                    <svg
                      className="icon h-[22px] w-[22px] shrink-0 fill-none stroke-current align-middle"
                      viewBox="0 0 24 24"
                      aria-hidden="true"
                      xmlns="http://www.w3.org/2000/svg"
                    >
                      <path
                        d="M12 8v5l3 2M22 12a10 10 0 1 1-20 0 10 10 0 0 1 20 0"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                      ></path>
                    </svg>
                    <b>{'9:30 p. m.'}</b>
                  </span>
                  <small>{'Esta noche'}</small>
                </button>
                <button
                  className="departure-option selected "
                  aria-pressed="true"
                  data-move-click="chooseDeparture('22:30')"
                >
                  <span>
                    <svg
                      className="icon h-[22px] w-[22px] shrink-0 fill-none stroke-current align-middle"
                      viewBox="0 0 24 24"
                      aria-hidden="true"
                      xmlns="http://www.w3.org/2000/svg"
                    >
                      <path
                        d="M12 8v5l3 2M22 12a10 10 0 1 1-20 0 10 10 0 0 1 20 0"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                      ></path>
                    </svg>
                    <b>{'10:30 p. m.'}</b>
                  </span>
                  <small>{'Esta noche'}</small>
                  <svg
                    className="icon h-[22px] w-[22px] shrink-0 fill-none stroke-current align-middle"
                    viewBox="0 0 24 24"
                    aria-hidden="true"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path
                      d="M5 12l4 4L19 6"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    ></path>
                  </svg>
                </button>
                <button
                  className="departure-option  "
                  aria-pressed="false"
                  data-move-click="chooseDeparture('23:30')"
                >
                  <span>
                    <svg
                      className="icon h-[22px] w-[22px] shrink-0 fill-none stroke-current align-middle"
                      viewBox="0 0 24 24"
                      aria-hidden="true"
                      xmlns="http://www.w3.org/2000/svg"
                    >
                      <path
                        d="M12 8v5l3 2M22 12a10 10 0 1 1-20 0 10 10 0 0 1 20 0"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                      ></path>
                    </svg>
                    <b>{'11:30 p. m.'}</b>
                  </span>
                  <small>{'Esta noche'}</small>
                </button>
                <button
                  className="departure-option  "
                  aria-pressed="false"
                  data-move-click="chooseDeparture('00:30')"
                >
                  <span>
                    <svg
                      className="icon h-[22px] w-[22px] shrink-0 fill-none stroke-current align-middle"
                      viewBox="0 0 24 24"
                      aria-hidden="true"
                      xmlns="http://www.w3.org/2000/svg"
                    >
                      <path
                        d="M12 8v5l3 2M22 12a10 10 0 1 1-20 0 10 10 0 0 1 20 0"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                      ></path>
                    </svg>
                    <b>{'12:30 a. m.'}</b>
                  </span>
                  <small>{'Día siguiente'}</small>
                </button>
              </div>
              <p className="small-info text-sm leading-[1.55] text-[var(--muted)]">
                {'Llega al punto de encuentro 10 minutos antes.'}
              </p>
              <button
                className="btn flex min-h-[52px] w-full items-center justify-center gap-2.5 rounded-[14px] border-0 bg-[var(--pink)] px-5 py-4 font-bold text-white disabled:cursor-not-allowed disabled:opacity-45"
                data-move-click="completeDeparture()"
              >
                {'Confirmar esta salida'}
              </button>
              <button
                className="text-btn border-0 bg-transparent px-1 py-3.5 text-sm font-bold text-[var(--pink)]"
                data-move-click="navigate('home')"
              >
                {'Volver sin confirmar'}
              </button>
            </div>
            <p className="demo-note ">
              {'Vista de demostración · Datos de ejemplo'}
            </p>
          </div>
        </>
      )}
    </MoveSurface>
  );
}
