import React, { useId } from 'react';
import { MoveSurface } from '../MoveSurface.jsx';

/** Patrón footer-about usado en landing.js · landingView. */
export function MoveFooterAbout({
  theme = 'light',
  tenant = 'tp',
  reducedMotion = false,
  onAction,
  className = '',
  style,
  children,
}) {
  const uid = useId();
  return (
    <MoveSurface
      theme={theme}
      tenant={tenant}
      reducedMotion={reducedMotion}
      onAction={onAction}
      className={'' + ' ' + className}
      style={style}
    >
      {children ?? (
        <>
          <div className="footer-about ">
            <p>{'Una app de TP.'}</p>
            <small>{'Transporte empresarial, conectado.'}</small>
          </div>
        </>
      )}
    </MoveSurface>
  );
}
