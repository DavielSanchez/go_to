import React, { useId } from 'react';
import { MoveSurface } from '../MoveSurface.jsx';

/** Bloque extraído del diseño actual de MOVE. Los eventos se exponen mediante onAction. */
export function MoveDriverOnboarding2({
  theme = 'light',
  tenant = 'tp',
  reducedMotion = false,
  onAction,
  className = '',
  style,
  children,
}) {
  const uid = useId();
  return (
    <MoveSurface
      theme={theme}
      tenant={tenant}
      reducedMotion={reducedMotion}
      onAction={onAction}
      className={'' + ' ' + className}
      style={style}
    >
      {children ?? (
        <>
          <div className="narrow ">
            <div className="page-top ">
              <div>
                <h1>{'Registro del conductor'}</h1>
                <p className="sub mt-2 leading-[1.6] text-[var(--muted)]">
                  {'Completa tus datos antes de recibir una ruta.'}
                </p>
              </div>
            </div>
            <div className="onboarding-steps ">
              <span className=" ">{'1. Identidad'}</span>
              <span className="active ">{'2. Vehículo'}</span>
              <span className=" ">{'3. Revisión'}</span>
            </div>
            <form
              id={uid + '-driverOnboarding'}
              className="card mb-[18px] rounded-[var(--radius)] border border-[var(--line)] bg-[var(--surface)] p-6"
              data-move-form=""
            >
              <h2>{'Tu vehículo'}</h2>
              <label
                className="label mb-2.5 mt-[22px] block text-sm font-bold"
                htmlFor={uid + '-d-brand'}
              >
                {'Marca'}
              </label>
              <input
                id={uid + '-d-brand'}
                name="brand"
                type="text"
                defaultValue="Hyundai"
                required
              />
              <label
                className="label mb-2.5 mt-[22px] block text-sm font-bold"
                htmlFor={uid + '-d-model'}
              >
                {'Modelo'}
              </label>
              <input
                id={uid + '-d-model'}
                name="model"
                type="text"
                defaultValue="County"
                required
              />
              <label
                className="label mb-2.5 mt-[22px] block text-sm font-bold"
                htmlFor={uid + '-d-year'}
              >
                {'Año'}
              </label>
              <input
                id={uid + '-d-year'}
                name="year"
                type="number"
                defaultValue="2023"
                required
                min="1980"
                max="2027"
              />
              <label
                className="label mb-2.5 mt-[22px] block text-sm font-bold"
                htmlFor={uid + '-d-plate'}
              >
                {'Placa escrita'}
              </label>
              <input
                id={uid + '-d-plate'}
                name="plate"
                type="text"
                defaultValue="I078542"
                required
                maxLength="12"
              />
              <div className="photo-field ">
                <b>{'Foto de la placa'}</b>
                <div id={uid + '-preview-plate'} className="photo-preview ">
                  <span>
                    <svg
                      className="icon h-[22px] w-[22px] shrink-0 fill-none stroke-current align-middle"
                      viewBox="0 0 24 24"
                      aria-hidden="true"
                      xmlns="http://www.w3.org/2000/svg"
                    >
                      <path
                        d="M5 3h4l2 5-3 2c2 3 3 4 6 6l2-3 5 2v4c-8 5-22-9-16-16"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                      ></path>
                    </svg>
                    {'Sin foto'}
                  </span>
                </div>
                <div className="photo-actions ">
                  <label className="btn secondary flex min-h-[52px] w-full items-center justify-center gap-2.5 rounded-[14px] border-0 px-5 py-4 font-bold disabled:cursor-not-allowed disabled:opacity-45 bg-[var(--soft)] text-[var(--ink)]">
                    {'Tomar foto'}
                    <input
                      type="file"
                      accept="image/*"
                      capture="environment"
                      data-photo="plate"
                      hidden
                    />
                  </label>
                  <label className="btn secondary flex min-h-[52px] w-full items-center justify-center gap-2.5 rounded-[14px] border-0 px-5 py-4 font-bold disabled:cursor-not-allowed disabled:opacity-45 bg-[var(--soft)] text-[var(--ink)]">
                    {'Galería'}
                    <input
                      type="file"
                      accept="image/*"
                      data-photo="plate"
                      hidden
                    />
                  </label>
                </div>
              </div>
              <p
                id={uid + '-onboardError'}
                className="form-error "
                role="alert"
              ></p>
              <div className="form-actions ">
                <button
                  className="btn secondary flex min-h-[52px] w-full items-center justify-center gap-2.5 rounded-[14px] border-0 px-5 py-4 font-bold disabled:cursor-not-allowed disabled:opacity-45 bg-[var(--soft)] text-[var(--ink)]"
                  type="button"
                  data-move-click="backOnboarding()"
                >
                  {'Anterior'}
                </button>
                <button
                  className="btn flex min-h-[52px] w-full items-center justify-center gap-2.5 rounded-[14px] border-0 bg-[var(--pink)] px-5 py-4 font-bold text-white disabled:cursor-not-allowed disabled:opacity-45"
                  type="submit"
                >
                  {'Continuar'}
                </button>
              </div>
            </form>
            <p className="demo-note ">
              {'Vista de demostración · Datos de ejemplo'}
            </p>
          </div>
        </>
      )}
    </MoveSurface>
  );
}
