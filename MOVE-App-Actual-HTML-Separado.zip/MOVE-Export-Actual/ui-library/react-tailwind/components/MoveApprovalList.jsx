import React, { useId } from 'react';
import { MoveSurface } from '../MoveSurface.jsx';

/** Patrón approval-list usado en approvalView(). */
export function MoveApprovalList({
  theme = 'light',
  tenant = 'tp',
  reducedMotion = false,
  onAction,
  className = '',
  style,
  children,
}) {
  const uid = useId();
  return (
    <MoveSurface
      theme={theme}
      tenant={tenant}
      reducedMotion={reducedMotion}
      onAction={onAction}
      className={'' + ' ' + className}
      style={style}
    >
      {children ?? (
        <>
          <div className="approval-list ">
            <article className="card mb-[18px] rounded-[var(--radius)] border border-[var(--line)] bg-[var(--surface)] p-6">
              <div className="request-heading ">
                <div>
                  <h2>{'Ana Pérez'}</h2>
                  <p className="small-info text-sm leading-[1.55] text-[var(--muted)]">
                    {'ID 104601 · EX-001'}
                  </p>
                </div>
                <span className="pill amber inline-flex items-center gap-1.5 rounded-full px-[11px] py-[7px] text-xs font-bold">
                  {'Pendiente'}
                </span>
              </div>
              <div className="request-summary ">
                <div>
                  <small>{'Motivo'}</small>
                  <b>{'Horas extra'}</b>
                </div>
                <div>
                  <small>{'Salida solicitada'}</small>
                  <b>{'4 de octubre de 2026 · 23:00'}</b>
                </div>
              </div>
              <p className="request-detail " data-user-content="">
                {'Mi jornada se extendió por cierre de operación.'}
              </p>
              <label
                className="label mb-2.5 mt-[22px] block text-sm font-bold"
                htmlFor={uid + '-decision-EX-001'}
              >
                {'Comentario de la decisión'}
              </label>
              <textarea
                id={uid + '-decision-EX-001'}
                placeholder="Opcional al aprobar; obligatorio al rechazar."
                maxLength="500"
                defaultValue=""
              />
              <div className="form-actions ">
                <button
                  className="btn outline flex min-h-[52px] w-full items-center justify-center gap-2.5 rounded-[14px] px-5 py-4 font-bold disabled:cursor-not-allowed disabled:opacity-45 border border-[var(--line)] bg-[var(--surface)] text-[var(--ink)]"
                  data-move-click="decideException('EX-001','rejected')"
                >
                  {'Rechazar'}
                </button>
                <button
                  className="btn flex min-h-[52px] w-full items-center justify-center gap-2.5 rounded-[14px] border-0 bg-[var(--pink)] px-5 py-4 font-bold text-white disabled:cursor-not-allowed disabled:opacity-45"
                  data-move-click="decideException('EX-001','approved')"
                >
                  {'Aprobar excepción'}
                </button>
              </div>
              <p
                id={uid + '-decision-error-EX-001'}
                className="form-error "
                role="alert"
              ></p>
            </article>
            <article className="card mb-[18px] rounded-[var(--radius)] border border-[var(--line)] bg-[var(--surface)] p-6">
              <div className="request-heading ">
                <div>
                  <h2>{'Carlos Mejía'}</h2>
                  <p className="small-info text-sm leading-[1.55] text-[var(--muted)]">
                    {'ID 104612 · EX-002'}
                  </p>
                </div>
                <span className="pill amber inline-flex items-center gap-1.5 rounded-full px-[11px] py-[7px] text-xs font-bold">
                  {'Pendiente'}
                </span>
              </div>
              <div className="request-summary ">
                <div>
                  <small>{'Motivo'}</small>
                  <b>{'Capacitación'}</b>
                </div>
                <div>
                  <small>{'Salida solicitada'}</small>
                  <b>{'4 de octubre de 2026 · 22:30'}</b>
                </div>
              </div>
              <p className="request-detail " data-user-content="">
                {'Capacitación del equipo después del turno.'}
              </p>
              <label
                className="label mb-2.5 mt-[22px] block text-sm font-bold"
                htmlFor={uid + '-decision-EX-002'}
              >
                {'Comentario de la decisión'}
              </label>
              <textarea
                id={uid + '-decision-EX-002'}
                placeholder="Opcional al aprobar; obligatorio al rechazar."
                maxLength="500"
                defaultValue=""
              />
              <div className="form-actions ">
                <button
                  className="btn outline flex min-h-[52px] w-full items-center justify-center gap-2.5 rounded-[14px] px-5 py-4 font-bold disabled:cursor-not-allowed disabled:opacity-45 border border-[var(--line)] bg-[var(--surface)] text-[var(--ink)]"
                  data-move-click="decideException('EX-002','rejected')"
                >
                  {'Rechazar'}
                </button>
                <button
                  className="btn flex min-h-[52px] w-full items-center justify-center gap-2.5 rounded-[14px] border-0 bg-[var(--pink)] px-5 py-4 font-bold text-white disabled:cursor-not-allowed disabled:opacity-45"
                  data-move-click="decideException('EX-002','approved')"
                >
                  {'Aprobar excepción'}
                </button>
              </div>
              <p
                id={uid + '-decision-error-EX-002'}
                className="form-error "
                role="alert"
              ></p>
            </article>
          </div>
        </>
      )}
    </MoveSurface>
  );
}
