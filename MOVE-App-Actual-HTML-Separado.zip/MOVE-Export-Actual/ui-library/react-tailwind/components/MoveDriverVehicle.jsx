import React, { useId } from 'react';
import { MoveSurface } from '../MoveSurface.jsx';

/** Bloque extraído del diseño actual de MOVE. Los eventos se exponen mediante onAction. */
export function MoveDriverVehicle({
  theme = 'light',
  tenant = 'tp',
  reducedMotion = false,
  onAction,
  className = '',
  style,
  children,
}) {
  const uid = useId();
  return (
    <MoveSurface
      theme={theme}
      tenant={tenant}
      reducedMotion={reducedMotion}
      onAction={onAction}
      className={'' + ' ' + className}
      style={style}
    >
      {children ?? (
        <>
          <div className="narrow ">
            <button
              className="back mb-[18px] flex items-center gap-[7px] border-0 bg-transparent p-0 text-sm text-[var(--muted)]"
              data-move-click="cancelVehicleEdit()"
            >
              <svg
                className="icon h-[22px] w-[22px] shrink-0 fill-none stroke-current align-middle"
                viewBox="0 0 24 24"
                aria-hidden="true"
                xmlns="http://www.w3.org/2000/svg"
              >
                <path
                  d="M15 5l-7 7 7 7"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                ></path>
              </svg>
              {'Mi perfil'}
            </button>
            <div className="page-top ">
              <div>
                <h1>{'Editar vehículo'}</h1>
                <p className="sub mt-2 leading-[1.6] text-[var(--muted)]">
                  {'Actualiza la información de tu vehículo.'}
                </p>
              </div>
            </div>
            <form
              id={uid + '-vehicleEditForm'}
              className="card mb-[18px] rounded-[var(--radius)] border border-[var(--line)] bg-[var(--surface)] p-6"
              data-move-form=""
            >
              <label
                className="label mb-2.5 mt-[22px] block text-sm font-bold"
                htmlFor={uid + '-vehicle-brand'}
              >
                {'Marca'}
              </label>
              <input
                id={uid + '-vehicle-brand'}
                name="brand"
                type="text"
                defaultValue="Hyundai"
                required
              />
              <label
                className="label mb-2.5 mt-[22px] block text-sm font-bold"
                htmlFor={uid + '-vehicle-model'}
              >
                {'Modelo'}
              </label>
              <input
                id={uid + '-vehicle-model'}
                name="model"
                type="text"
                defaultValue="County"
                required
              />
              <label
                className="label mb-2.5 mt-[22px] block text-sm font-bold"
                htmlFor={uid + '-vehicle-year'}
              >
                {'Año'}
              </label>
              <input
                id={uid + '-vehicle-year'}
                name="year"
                type="number"
                defaultValue="2023"
                required
                min="1980"
                max="2027"
              />
              <label
                className="label mb-2.5 mt-[22px] block text-sm font-bold"
                htmlFor={uid + '-vehicle-plate'}
              >
                {'Placa'}
              </label>
              <input
                id={uid + '-vehicle-plate'}
                name="plate"
                type="text"
                defaultValue="I078542"
                required
                maxLength="12"
              />
              <div className="photo-field ">
                <b>{'Foto de la placa'}</b>
                <div
                  id={uid + '-vehiclePhotoPreview'}
                  className="photo-preview "
                >
                  <span>{'Sin foto'}</span>
                </div>
                <div className="photo-actions ">
                  <label className="btn secondary flex min-h-[52px] w-full items-center justify-center gap-2.5 rounded-[14px] border-0 px-5 py-4 font-bold disabled:cursor-not-allowed disabled:opacity-45 bg-[var(--soft)] text-[var(--ink)]">
                    {'Tomar foto'}
                    <input
                      type="file"
                      accept="image/*"
                      capture="environment"
                      data-vehicle-photo=""
                      hidden
                    />
                  </label>
                  <label className="btn secondary flex min-h-[52px] w-full items-center justify-center gap-2.5 rounded-[14px] border-0 px-5 py-4 font-bold disabled:cursor-not-allowed disabled:opacity-45 bg-[var(--soft)] text-[var(--ink)]">
                    {'Galería'}
                    <input
                      type="file"
                      accept="image/*"
                      data-vehicle-photo=""
                      hidden
                    />
                  </label>
                </div>
              </div>
              <p className="small-info text-sm leading-[1.55] text-[var(--muted)]">
                {
                  'La unidad asignada a tu viaje conserva su identificación. Estas modificaciones actualizan tu ficha del vehículo.'
                }
              </p>
              <p
                id={uid + '-vehicleEditError'}
                className="form-error "
                role="alert"
              ></p>
              <div className="form-actions ">
                <button
                  className="btn secondary flex min-h-[52px] w-full items-center justify-center gap-2.5 rounded-[14px] border-0 px-5 py-4 font-bold disabled:cursor-not-allowed disabled:opacity-45 bg-[var(--soft)] text-[var(--ink)]"
                  type="button"
                  data-move-click="cancelVehicleEdit()"
                >
                  {'Cancelar'}
                </button>
                <button
                  className="btn flex min-h-[52px] w-full items-center justify-center gap-2.5 rounded-[14px] border-0 bg-[var(--pink)] px-5 py-4 font-bold text-white disabled:cursor-not-allowed disabled:opacity-45"
                  type="submit"
                >
                  {'Guardar cambios'}
                </button>
              </div>
            </form>
            <p className="demo-note ">
              {'Vista de demostración · Datos de ejemplo'}
            </p>
          </div>
        </>
      )}
    </MoveSurface>
  );
}
