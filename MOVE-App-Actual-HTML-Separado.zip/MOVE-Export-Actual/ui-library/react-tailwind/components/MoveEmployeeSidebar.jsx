import React, { useId } from 'react';
import { MoveSurface } from '../MoveSurface.jsx';

/** Navegación compartida con agentes y conductores. */
export function MoveEmployeeSidebar({
  theme = 'light',
  tenant = 'tp',
  reducedMotion = false,
  onAction,
  className = '',
  style,
  children,
}) {
  const uid = useId();
  return (
    <MoveSurface
      theme={theme}
      tenant={tenant}
      reducedMotion={reducedMotion}
      onAction={onAction}
      className={'' + ' ' + className}
      style={style}
    >
      {children ?? (
        <>
          <aside className="desktop ">
            <a className="brand " href="#home">
              {'MOVE'}
              <span className="brand-dot "></span>
            </a>
            <div className="bytp ">
              {'TRANSPORTE PARA '}
              <b>{'TP'}</b>
            </div>
            <div className="side-nav ">
              <a href="#home" className="nav-item active " aria-current="page">
                <span className="nav-icon ">
                  <svg
                    className="icon h-[22px] w-[22px] shrink-0 fill-none stroke-current align-middle"
                    viewBox="0 0 24 24"
                    aria-hidden="true"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path
                      d="M3 10l9-7 9 7v10a1 1 0 0 1-1 1h-5v-7H9v7H4a1 1 0 0 1-1-1z"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    ></path>
                  </svg>
                </span>
                {'Inicio'}
              </a>
              <a href="#trip" className="nav-item  ">
                <span className="nav-icon ">
                  <svg
                    className="icon h-[22px] w-[22px] shrink-0 fill-none stroke-current align-middle"
                    viewBox="0 0 24 24"
                    aria-hidden="true"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path
                      d="M5 16V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2v11M5 11h14M8 3v8m8-8v8M5 16h14v3H5zM7 19v3m10-3v3M8 14h.01M16 14h.01"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    ></path>
                  </svg>
                </span>
                {'Mi viaje'}
              </a>
              <a href="#exception" className="nav-item  ">
                <span className="nav-icon ">
                  <svg
                    className="icon h-[22px] w-[22px] shrink-0 fill-none stroke-current align-middle"
                    viewBox="0 0 24 24"
                    aria-hidden="true"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path
                      d="M3 7h18v4a2 2 0 0 0 0 4v4H3v-4a2 2 0 0 0 0-4zM15 7v2m0 3v2m0 3v2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    ></path>
                  </svg>
                </span>
                {'Excepciones'}
              </a>
              <a href="#history" className="nav-item  ">
                <span className="nav-icon ">
                  <svg
                    className="icon h-[22px] w-[22px] shrink-0 fill-none stroke-current align-middle"
                    viewBox="0 0 24 24"
                    aria-hidden="true"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path
                      d="M12 8v5l3 2M22 12a10 10 0 1 1-20 0 10 10 0 0 1 20 0"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    ></path>
                  </svg>
                </span>
                {'Historial'}
              </a>
              <a href="#profile" className="nav-item  ">
                <span className="nav-icon ">
                  <svg
                    className="icon h-[22px] w-[22px] shrink-0 fill-none stroke-current align-middle"
                    viewBox="0 0 24 24"
                    aria-hidden="true"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path
                      d="M20 21v-2a6 6 0 0 0-6-6h-4a6 6 0 0 0-6 6v2M16 6a4 4 0 1 1-8 0 4 4 0 0 1 8 0"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    ></path>
                  </svg>
                </span>
                {'Perfil'}
              </a>
              <button className="cancel " data-move-click="logoutMove()">
                {'Cerrar sesión'}
              </button>
            </div>
            <div className="side-bottom ">
              <span className="avatar grid h-10 w-10 place-items-center rounded-full border-0 text-[13px] font-bold">
                {'DS'}
              </span>
              <div>
                <b>{'Daviel Sánchez'}</b>
                <small>{'Colaborador · TP'}</small>
              </div>
            </div>
          </aside>
        </>
      )}
    </MoveSurface>
  );
}
