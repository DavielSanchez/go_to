import React, { useId } from 'react';
import { MoveSurface } from '../MoveSurface.jsx';

/** Patrón demo-badge usado en landing.js · landingView. */
export function MoveDemoBadge({
  theme = 'light',
  tenant = 'tp',
  reducedMotion = false,
  onAction,
  className = '',
  style,
  children,
}) {
  const uid = useId();
  return (
    <MoveSurface
      theme={theme}
      tenant={tenant}
      reducedMotion={reducedMotion}
      onAction={onAction}
      className={'' + ' ' + className}
      style={style}
    >
      {children ?? (
        <>
          <div className="demo-badge ">
            <svg
              className="icon h-[22px] w-[22px] shrink-0 fill-none stroke-current align-middle"
              viewBox="0 0 24 24"
              aria-hidden="true"
              xmlns="http://www.w3.org/2000/svg"
            >
              <path
                d="M12 11v6m0-10v.01M22 12a10 10 0 1 1-20 0 10 10 0 0 1 20 0"
                strokeLinecap="round"
                strokeLinejoin="round"
              ></path>
            </svg>
            {
              ' Escenario de demostración · No representa resultados de clientes'
            }
          </div>
        </>
      )}
    </MoveSurface>
  );
}
