import React, { useId } from 'react';
import { MoveSurface } from '../MoveSurface.jsx';

/** Bloque extraído del diseño actual de MOVE. Los eventos se exponen mediante onAction. */
export function MoveFleet({
  theme = 'light',
  tenant = 'tp',
  reducedMotion = false,
  onAction,
  className = '',
  style,
  children,
}) {
  const uid = useId();
  return (
    <MoveSurface
      theme={theme}
      tenant={tenant}
      reducedMotion={reducedMotion}
      onAction={onAction}
      className={'' + ' ' + className}
      style={style}
    >
      {children ?? (
        <>
          <section className="ops-card ">
            <div className="ops-section-title ">
              <h2>{'Catálogo de capacidad'}</h2>
            </div>
            <div className="management-controls ">
              <button
                className="ops-button "
                data-move-click="openManagementDrawer('fleet-create')"
              >
                {'Agregar tipo'}
              </button>
            </div>
            <p className="ops-muted ">
              {
                'Los planes utilizan todos los tipos activos de este site. Los viajes confirmados conservan su capacidad original.'
              }
            </p>
            <div className="ops-table-scroll ">
              <table className="ops-table ">
                <thead>
                  <tr>
                    <th>{'Tipo'}</th>
                    <th>{'Capacidad'}</th>
                    <th>{'Gap'}</th>
                    <th>{'Asientos útiles'}</th>
                    <th>{'Estado'}</th>
                    <th></th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td>
                      <b>{'Van estándar'}</b>
                    </td>
                    <td>{'15'}</td>
                    <td>{'2'}</td>
                    <td>
                      <b>{'13'}</b>
                    </td>
                    <td>{'Activo'}</td>
                    <td>
                      <button
                        className="ops-button secondary bg-[var(--soft)] text-[var(--ink)]"
                        data-move-click="openManagementDrawer('fleet-edit','tp-churchill-van')"
                      >
                        {'Editar'}
                      </button>
                    </td>
                  </tr>
                  <tr>
                    <td>
                      <b>{'Minibús'}</b>
                    </td>
                    <td>{'28'}</td>
                    <td>{'3'}</td>
                    <td>
                      <b>{'25'}</b>
                    </td>
                    <td>{'Activo'}</td>
                    <td>
                      <button
                        className="ops-button secondary bg-[var(--soft)] text-[var(--ink)]"
                        data-move-click="openManagementDrawer('fleet-edit','tp-churchill-bus')"
                      >
                        {'Editar'}
                      </button>
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
          </section>
        </>
      )}
    </MoveSurface>
  );
}
