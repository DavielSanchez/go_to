import React, { useId } from 'react';
import { MoveSurface } from '../MoveSurface.jsx';

/** Bloque extraído del diseño actual de MOVE. Los eventos se exponen mediante onAction. */
export function MoveExceptionApproved({
  theme = 'light',
  tenant = 'tp',
  reducedMotion = false,
  onAction,
  className = '',
  style,
  children,
}) {
  const uid = useId();
  return (
    <MoveSurface
      theme={theme}
      tenant={tenant}
      reducedMotion={reducedMotion}
      onAction={onAction}
      className={'' + ' ' + className}
      style={style}
    >
      {children ?? (
        <>
          <div className="narrow ">
            <div className="page-top ">
              <div>
                <h1>{'Excepción de transporte'}</h1>
                <p className="sub mt-2 leading-[1.6] text-[var(--muted)]">
                  {'Solicítala para hoy o para otra fecha.'}
                </p>
              </div>
            </div>
            <div className="card success mb-[18px] rounded-[var(--radius)] border border-[var(--line)] bg-[var(--surface)] p-6">
              <span className="review-icon ">
                <svg
                  className="icon h-[22px] w-[22px] shrink-0 fill-none stroke-current align-middle"
                  viewBox="0 0 24 24"
                  aria-hidden="true"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    d="M5 12l4 4L19 6"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  ></path>
                </svg>
              </span>
              <span className="pill green inline-flex items-center gap-1.5 rounded-full px-[11px] py-[7px] text-xs font-bold">
                {'Aprobada'}
              </span>
              <h2>{'Tu transporte fue aprobado'}</h2>
              <div className="summary my-[22px] flex items-center gap-3 rounded-[15px] bg-[var(--soft)] p-[17px] text-left">
                <div>
                  <b>{'undefined'}</b>
                  <p>{'4 de octubre de 2026 · Salida undefined'}</p>
                </div>
              </div>
              <p className="small-info text-sm leading-[1.55] text-[var(--muted)]">
                {
                  'Presenta el ticket QR para abordar la unidad y salida asignadas.'
                }
              </p>
              <button
                className="btn flex min-h-[52px] w-full items-center justify-center gap-2.5 rounded-[14px] border-0 bg-[var(--pink)] px-5 py-4 font-bold text-white disabled:cursor-not-allowed disabled:opacity-45"
                style={{ marginTop: '20px' }}
                data-move-click="navigate('ticket')"
              >
                {'Ver mi ticket QR'}
              </button>
              <button
                className="btn secondary flex min-h-[52px] w-full items-center justify-center gap-2.5 rounded-[14px] border-0 px-5 py-4 font-bold disabled:cursor-not-allowed disabled:opacity-45 bg-[var(--soft)] text-[var(--ink)]"
                style={{ marginTop: '18px' }}
                data-move-click="newException()"
              >
                {'Solicitar para otra fecha'}
              </button>
            </div>
            <p className="demo-note ">
              {'Vista de demostración · Datos de ejemplo'}
            </p>
          </div>
        </>
      )}
    </MoveSurface>
  );
}
