import React, { useId } from 'react';
import { MoveSurface } from '../MoveSurface.jsx';

/** Patrón final-cta usado en landing.js · landingView. */
export function MoveFinalCta({
  theme = 'light',
  tenant = 'tp',
  reducedMotion = false,
  onAction,
  className = '',
  style,
  children,
}) {
  const uid = useId();
  return (
    <MoveSurface
      theme={theme}
      tenant={tenant}
      reducedMotion={reducedMotion}
      onAction={onAction}
      className={'' + ' ' + className}
      style={style}
    >
      {children ?? (
        <>
          <section className="final-cta ">
            <span className="lp-kicker ">
              {'LA PRÓXIMA PARADA ES UNA MEJOR OPERACIÓN'}
            </span>
            <h2>
              {'Tu gente se mueve.'}
              <br />
              <em>{'Tu empresa también.'}</em>
            </h2>
            <p>
              {'Descubre una forma más clara de coordinar'}
              <br />
              {'el transporte que acompaña a tu equipo.'}
            </p>
            <button className="lp-button white " data-move-click="enterMove()">
              {'Entrar a MOVE '}
              <svg
                className="icon h-[22px] w-[22px] shrink-0 fill-none stroke-current align-middle"
                viewBox="0 0 24 24"
                aria-hidden="true"
                xmlns="http://www.w3.org/2000/svg"
              >
                <path
                  d="M5 16V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2v11M5 11h14M8 3v8m8-8v8M5 16h14v3H5zM7 19v3m10-3v3M8 14h.01M16 14h.01"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                ></path>
              </svg>
            </button>
          </section>
        </>
      )}
    </MoveSurface>
  );
}
