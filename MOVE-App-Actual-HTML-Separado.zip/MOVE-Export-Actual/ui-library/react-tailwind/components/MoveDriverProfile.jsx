import React, { useId } from 'react';
import { MoveSurface } from '../MoveSurface.jsx';

/** Bloque extraído del diseño actual de MOVE. Los eventos se exponen mediante onAction. */
export function MoveDriverProfile({
  theme = 'light',
  tenant = 'tp',
  reducedMotion = false,
  onAction,
  className = '',
  style,
  children,
}) {
  const uid = useId();
  return (
    <MoveSurface
      theme={theme}
      tenant={tenant}
      reducedMotion={reducedMotion}
      onAction={onAction}
      className={'' + ' ' + className}
      style={style}
    >
      {children ?? (
        <>
          <div className="profile-wrap ">
            <div className="page-top ">
              <div>
                <h1>{'Mi perfil de conductor'}</h1>
              </div>
            </div>
            <div className="card mb-[18px] rounded-[var(--radius)] border border-[var(--line)] bg-[var(--surface)] p-6">
              <div className="profile-hero p-[18px] text-center">
                <span className="avatar grid h-10 w-10 place-items-center rounded-full border-0 text-[13px] font-bold">
                  {'JR'}
                </span>
                <h2>{'José Ramírez'}</h2>
                <p className="sub mt-2 leading-[1.6] text-[var(--muted)]">
                  {'Conductor de proveedor externo'}
                </p>
              </div>
              <div className="profile-data ">
                <div>
                  <small>{'Cédula'}</small>
                  <b>{'00000000000'}</b>
                </div>
                <div>
                  <small>{'Marca'}</small>
                  <b>{'Hyundai'}</b>
                </div>
                <div>
                  <small>{'Modelo'}</small>
                  <b>{'County'}</b>
                </div>
                <div>
                  <small>{'Año'}</small>
                  <b>{'2023'}</b>
                </div>
                <div>
                  <small>{'Placa'}</small>
                  <b>{'I078542'}</b>
                </div>
              </div>
              <div className="notice my-5 flex gap-2.5 rounded-2xl bg-[var(--notice-bg)] p-4 text-sm leading-[1.55] text-[var(--notice-ink)]">
                <svg
                  className="icon h-[22px] w-[22px] shrink-0 fill-none stroke-current align-middle"
                  viewBox="0 0 24 24"
                  aria-hidden="true"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    d="M12 3l8 3v6c0 5-8 9-8 9s-8-4-8-9V6zM8 12l3 3 5-6"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  ></path>
                </svg>
                <span>
                  {
                    'Registro completado en esta demostración. Los documentos requieren revisión antes de operar en un servicio real.'
                  }
                </span>
              </div>
              <button
                className="btn outline flex min-h-[52px] w-full items-center justify-center gap-2.5 rounded-[14px] px-5 py-4 font-bold disabled:cursor-not-allowed disabled:opacity-45 border border-[var(--line)] bg-[var(--surface)] text-[var(--ink)]"
                data-move-click="navigate('driver-vehicle')"
              >
                {'Editar datos del vehículo'}
              </button>
            </div>
            <div className="card setting-row mb-[18px] rounded-[var(--radius)] border border-[var(--line)] bg-[var(--surface)] p-6">
              <div>
                <h3>{'Modo oscuro'}</h3>
                <p className="small-info text-sm leading-[1.55] text-[var(--muted)]">
                  {'Preferencia en este dispositivo.'}
                </p>
              </div>
              <button
                className="btn secondary compact flex min-h-[52px] w-full items-center justify-center gap-2.5 rounded-[14px] border-0 px-5 py-4 font-bold disabled:cursor-not-allowed disabled:opacity-45 bg-[var(--soft)] text-[var(--ink)]"
                data-move-click="toggleTheme();render()"
              >
                {'Desactivado'}
              </button>
            </div>
            <button
              className="btn secondary flex min-h-[52px] w-full items-center justify-center gap-2.5 rounded-[14px] border-0 px-5 py-4 font-bold disabled:cursor-not-allowed disabled:opacity-45 bg-[var(--soft)] text-[var(--ink)]"
              data-move-click="logoutMove()"
            >
              {'Cerrar sesión'}
            </button>
            <details
              className="card mb-[18px] rounded-[var(--radius)] border border-[var(--line)] bg-[var(--surface)] p-6"
              style={{ marginTop: '18px' }}
            >
              <summary>{'Opciones de demostración'}</summary>
              <button className="cancel " data-move-click="resetDriver()">
                {'Repetir registro del conductor'}
              </button>
            </details>
            <p className="demo-note ">
              {'Vista de demostración · Datos de ejemplo'}
            </p>
          </div>
        </>
      )}
    </MoveSurface>
  );
}
