import React, { useId } from 'react';
import { MoveSurface } from '../MoveSurface.jsx';

/** Accordion nativo details/summary. */
export function MoveAccordion({
  theme = 'light',
  tenant = 'tp',
  reducedMotion = false,
  onAction,
  className = '',
  style,
  children,
}) {
  const uid = useId();
  return (
    <MoveSurface
      theme={theme}
      tenant={tenant}
      reducedMotion={reducedMotion}
      onAction={onAction}
      className={'' + ' ' + className}
      style={style}
    >
      {children ?? (
        <>
          <details className="card mb-[18px] rounded-[var(--radius)] border border-[var(--line)] bg-[var(--surface)] p-6">
            <summary>{'Detalles del recorrido'}</summary>
            <p className="sub mt-2 leading-[1.6] text-[var(--muted)]">
              {'Churchill → Los Girasoles → Pantoja.'}
            </p>
          </details>
        </>
      )}
    </MoveSurface>
  );
}
