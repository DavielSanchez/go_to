import React, { useId } from 'react';
import { MoveSurface } from '../MoveSurface.jsx';

/** Identidad MOVE para autenticación y plataforma. */
export function MoveBrand({
  theme = 'light',
  tenant = 'tp',
  reducedMotion = false,
  onAction,
  className = '',
  style,
  children,
}) {
  const uid = useId();
  return (
    <MoveSurface
      theme={theme}
      tenant={tenant}
      reducedMotion={reducedMotion}
      onAction={onAction}
      className={'' + ' ' + className}
      style={style}
    >
      {children ?? (
        <>
          <div className="brand-collab ">
            <span className="brand ">
              {'MOVE'}
              <span className="brand-dot "></span>
            </span>
          </div>
        </>
      )}
    </MoveSurface>
  );
}
