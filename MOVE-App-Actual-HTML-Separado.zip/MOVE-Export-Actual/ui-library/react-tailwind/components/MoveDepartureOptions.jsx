import React, { useId } from 'react';
import { MoveSurface } from '../MoveSurface.jsx';

/** Patrón departure-options usado en departureView(). */
export function MoveDepartureOptions({
  theme = 'light',
  tenant = 'tp',
  reducedMotion = false,
  onAction,
  className = '',
  style,
  children,
}) {
  const uid = useId();
  return (
    <MoveSurface
      theme={theme}
      tenant={tenant}
      reducedMotion={reducedMotion}
      onAction={onAction}
      className={'' + ' ' + className}
      style={style}
    >
      {children ?? (
        <>
          <div
            className="departure-options "
            role="group"
            aria-label="Ventanas disponibles"
          >
            <button
              className="departure-option  "
              aria-pressed="false"
              data-move-click="chooseDeparture('21:30')"
            >
              <span>
                <svg
                  className="icon h-[22px] w-[22px] shrink-0 fill-none stroke-current align-middle"
                  viewBox="0 0 24 24"
                  aria-hidden="true"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    d="M12 8v5l3 2M22 12a10 10 0 1 1-20 0 10 10 0 0 1 20 0"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  ></path>
                </svg>
                <b>{'9:30 p. m.'}</b>
              </span>
              <small>{'Esta noche'}</small>
            </button>
            <button
              className="departure-option selected "
              aria-pressed="true"
              data-move-click="chooseDeparture('22:30')"
            >
              <span>
                <svg
                  className="icon h-[22px] w-[22px] shrink-0 fill-none stroke-current align-middle"
                  viewBox="0 0 24 24"
                  aria-hidden="true"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    d="M12 8v5l3 2M22 12a10 10 0 1 1-20 0 10 10 0 0 1 20 0"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  ></path>
                </svg>
                <b>{'10:30 p. m.'}</b>
              </span>
              <small>{'Esta noche'}</small>
              <svg
                className="icon h-[22px] w-[22px] shrink-0 fill-none stroke-current align-middle"
                viewBox="0 0 24 24"
                aria-hidden="true"
                xmlns="http://www.w3.org/2000/svg"
              >
                <path
                  d="M5 12l4 4L19 6"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                ></path>
              </svg>
            </button>
            <button
              className="departure-option  "
              aria-pressed="false"
              data-move-click="chooseDeparture('23:30')"
            >
              <span>
                <svg
                  className="icon h-[22px] w-[22px] shrink-0 fill-none stroke-current align-middle"
                  viewBox="0 0 24 24"
                  aria-hidden="true"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    d="M12 8v5l3 2M22 12a10 10 0 1 1-20 0 10 10 0 0 1 20 0"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  ></path>
                </svg>
                <b>{'11:30 p. m.'}</b>
              </span>
              <small>{'Esta noche'}</small>
            </button>
            <button
              className="departure-option  "
              aria-pressed="false"
              data-move-click="chooseDeparture('00:30')"
            >
              <span>
                <svg
                  className="icon h-[22px] w-[22px] shrink-0 fill-none stroke-current align-middle"
                  viewBox="0 0 24 24"
                  aria-hidden="true"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    d="M12 8v5l3 2M22 12a10 10 0 1 1-20 0 10 10 0 0 1 20 0"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  ></path>
                </svg>
                <b>{'12:30 a. m.'}</b>
              </span>
              <small>{'Día siguiente'}</small>
            </button>
          </div>
        </>
      )}
    </MoveSurface>
  );
}
