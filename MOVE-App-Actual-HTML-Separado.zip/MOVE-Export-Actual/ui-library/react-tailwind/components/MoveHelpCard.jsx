import React, { useId } from 'react';
import { MoveSurface } from '../MoveSurface.jsx';

/** Patrón help-card usado en views.home(). */
export function MoveHelpCard({
  theme = 'light',
  tenant = 'tp',
  reducedMotion = false,
  onAction,
  className = '',
  style,
  children,
}) {
  const uid = useId();
  return (
    <MoveSurface
      theme={theme}
      tenant={tenant}
      reducedMotion={reducedMotion}
      onAction={onAction}
      className={'' + ' ' + className}
      style={style}
    >
      {children ?? (
        <>
          <a
            className="card help-card mb-[18px] rounded-[var(--radius)] border border-[var(--line)] bg-[var(--surface)] p-6"
            href="#exception"
          >
            <span className="icon-box ">
              <svg
                className="icon h-[22px] w-[22px] shrink-0 fill-none stroke-current align-middle"
                viewBox="0 0 24 24"
                aria-hidden="true"
                xmlns="http://www.w3.org/2000/svg"
              >
                <path
                  d="M3 7h18v4a2 2 0 0 0 0 4v4H3v-4a2 2 0 0 0 0-4zM15 7v2m0 3v2m0 3v2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                ></path>
              </svg>
            </span>
            <div>
              <h3>{'Solicitar una excepción'}</h3>
              <p>{'Horas extra, cambio de turno u otro motivo.'}</p>
            </div>
            <span className="chevron ">
              <svg
                className="icon h-[22px] w-[22px] shrink-0 fill-none stroke-current align-middle"
                viewBox="0 0 24 24"
                aria-hidden="true"
                xmlns="http://www.w3.org/2000/svg"
              >
                <path
                  d="M9 5l7 7-7 7"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                ></path>
              </svg>
            </span>
          </a>
        </>
      )}
    </MoveSurface>
  );
}
