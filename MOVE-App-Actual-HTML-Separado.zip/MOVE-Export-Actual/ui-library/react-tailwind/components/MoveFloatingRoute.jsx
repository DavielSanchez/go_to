import React, { useId } from 'react';
import { MoveSurface } from '../MoveSurface.jsx';

/** Patrón floating-route usado en landing.js · landingView. */
export function MoveFloatingRoute({
  theme = 'light',
  tenant = 'tp',
  reducedMotion = false,
  onAction,
  className = '',
  style,
  children,
}) {
  const uid = useId();
  return (
    <MoveSurface
      theme={theme}
      tenant={tenant}
      reducedMotion={reducedMotion}
      onAction={onAction}
      className={'' + ' ' + className}
      style={style}
    >
      {children ?? (
        <>
          <div className="floating-route ">
            <span className="float-icon ">
              <svg
                className="icon h-[22px] w-[22px] shrink-0 fill-none stroke-current align-middle"
                viewBox="0 0 24 24"
                aria-hidden="true"
                xmlns="http://www.w3.org/2000/svg"
              >
                <path
                  d="M5 16V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2v11M5 11h14M8 3v8m8-8v8M5 16h14v3H5zM7 19v3m10-3v3M8 14h.01M16 14h.01"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                ></path>
              </svg>
            </span>
            <div>
              <small>{'TU TRANSPORTE ESTÁ LISTO'}</small>
              <b>{'Tu turno termina. Tu regreso empieza.'}</b>
              <span>{'Ruta 04 · 22:15 · Asiento confirmado'}</span>
            </div>
            <span className="float-check ">
              <svg
                className="icon h-[22px] w-[22px] shrink-0 fill-none stroke-current align-middle"
                viewBox="0 0 24 24"
                aria-hidden="true"
                xmlns="http://www.w3.org/2000/svg"
              >
                <path
                  d="M5 12l4 4L19 6"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                ></path>
              </svg>
            </span>
          </div>
        </>
      )}
    </MoveSurface>
  );
}
