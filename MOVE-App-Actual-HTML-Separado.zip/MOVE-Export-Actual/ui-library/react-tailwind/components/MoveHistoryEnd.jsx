import React, { useId } from 'react';
import { MoveSurface } from '../MoveSurface.jsx';

/** Patrón history-end usado en views.history(). */
export function MoveHistoryEnd({
  theme = 'light',
  tenant = 'tp',
  reducedMotion = false,
  onAction,
  className = '',
  style,
  children,
}) {
  const uid = useId();
  return (
    <MoveSurface
      theme={theme}
      tenant={tenant}
      reducedMotion={reducedMotion}
      onAction={onAction}
      className={'' + ' ' + className}
      style={style}
    >
      {children ?? (
        <>
          <div className="history-end ">
            <span className="pill green inline-flex items-center gap-1.5 rounded-full px-[11px] py-[7px] text-xs font-bold">
              {'Finalizado'}
            </span>
            <div style={{ marginTop: '8px' }}>{'★ 5.0'}</div>
          </div>
        </>
      )}
    </MoveSurface>
  );
}
