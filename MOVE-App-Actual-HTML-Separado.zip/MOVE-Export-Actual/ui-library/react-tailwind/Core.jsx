import React, { forwardRef, useEffect, useId, useRef, useState } from 'react';
import { MoveSurface } from './MoveSurface.jsx';
export { MoveSurface };
export const MoveButton = forwardRef(function MoveButton(
  { variant = 'primary', size = 'normal', className = '', children, ...props },
  ref,
) {
  return (
    <button
      ref={ref}
      type="button"
      className={`btn ${variant === 'primary' ? '' : variant} ${size === 'compact' ? 'compact' : ''} ${className}`}
      {...props}
    >
      {children}
    </button>
  );
});
export function MoveInput({
  label,
  helperText,
  error,
  id: suppliedId,
  ...props
}) {
  const generated = useId();
  const id = suppliedId || generated;
  return (
    <div>
      <label
        className="label mb-2.5 mt-[22px] block text-sm font-bold"
        htmlFor={id}
      >
        {label}
      </label>
      <input
        id={id}
        aria-invalid={!!error}
        aria-describedby={error || helperText ? `${id}-message` : undefined}
        {...props}
      />
      {(error || helperText) && (
        <p
          id={`${id}-message`}
          className={error ? 'form-error' : 'small-info'}
          role={error ? 'alert' : undefined}
        >
          {error || helperText}
        </p>
      )}
    </div>
  );
}
export function MoveSwitchControl({
  label,
  description,
  checked,
  defaultChecked = false,
  onChange,
  disabled = false,
}) {
  const [local, setLocal] = useState(defaultChecked);
  const value = checked ?? local;
  return (
    <label className="preference-row ">
      <span>
        <b>{label}</b>
        <small>{description}</small>
      </span>
      <input
        type="checkbox"
        role="switch"
        aria-label={label}
        checked={value}
        disabled={disabled}
        onChange={(e) => {
          setLocal(e.target.checked);
          onChange?.(e.target.checked);
        }}
      />
      <span className="switch-track " aria-hidden="true" />
    </label>
  );
}
export function MoveTabs({ items, value, onChange, label = 'Opciones' }) {
  return (
    <div className="access-tabs " role="group" aria-label={label}>
      {items.map((item) => (
        <button
          key={item.value}
          type="button"
          className={item.value === value ? 'selected' : ''}
          aria-pressed={item.value === value}
          onClick={() => onChange(item.value)}
        >
          {item.label}
        </button>
      ))}
    </div>
  );
}
export function MoveRating({ value = 0, onChange, readOnly = false }) {
  return (
    <div
      className="stars mb-3 mt-[25px] flex justify-center gap-2.5"
      aria-label="Calificación"
    >
      {[1, 2, 3, 4, 5].map((n) => (
        <button
          key={n}
          type="button"
          className={n <= value ? 'selected' : ''}
          aria-label={`${n} estrellas`}
          aria-pressed={n === value}
          disabled={readOnly}
          onClick={() => onChange?.(n)}
        >
          ★
        </button>
      ))}
    </div>
  );
}
export function MoveNavigation({
  items,
  value,
  onChange,
  orientation = 'bottom',
  label = 'Navegación',
}) {
  const previous = useRef(value);
  const index = Math.max(
    0,
    items.findIndex((item) => item.value === value),
  );
  const from = Math.max(
    0,
    items.findIndex((item) => item.value === previous.current),
  );
  useEffect(() => {
    previous.current = value;
  }, [value]);
  return (
    <nav
      aria-label={label}
      style={{
        '--nav-count': items.length,
        '--nav-index': index,
        '--nav-from': from,
      }}
      className={orientation === 'bottom' ? 'bottom-nav move-nav' : 'side-nav'}
    >
      {items.map((item) => (
        <button
          key={item.value}
          type="button"
          className={`nav-item ${item.value === value ? 'active' : ''}`}
          aria-current={item.value === value ? 'page' : undefined}
          onClick={() => onChange(item.value)}
        >
          <span className="nav-icon ">{item.icon}</span>
          {item.label}
        </button>
      ))}
      {orientation === 'bottom' && (
        <span key={value} className="nav-indicator " aria-hidden="true" />
      )}
    </nav>
  );
}
/** Native dialog: focus containment, Escape, backdrop close and focus restoration. */
export function MoveDialog({ open, title, children, onClose, actions }) {
  const ref = useRef(null);
  const id = useId();
  useEffect(() => {
    const d = ref.current;
    if (open && !d.open) d.showModal();
    if (!open && d.open) d.close();
  }, [open]);
  return (
    <dialog
      ref={ref}
      aria-labelledby={id}
      className="move-dialog "
      onCancel={(e) => {
        e.preventDefault();
        onClose?.();
      }}
      onClick={(e) => {
        if (e.target === ref.current) onClose?.();
      }}
    >
      <div className="card mb-[18px] rounded-[var(--radius)] border border-[var(--line)] bg-[var(--surface)] p-6">
        <div className="section-heading ">
          <h2 id={id}>{title}</h2>
          <button
            type="button"
            className="text-btn border-0 bg-transparent px-1 py-3.5 text-sm font-bold text-[var(--pink)]"
            onClick={onClose}
          >
            Cerrar
          </button>
        </div>
        {children}
        {actions}
      </div>
    </dialog>
  );
}
export function MoveToastMessage({ message, onDismiss, duration = 3500 }) {
  useEffect(() => {
    if (!message) return;
    const id = setTimeout(() => onDismiss?.(), duration);
    return () => clearTimeout(id);
  }, [message, duration, onDismiss]);
  return message ? (
    <div className="move-library-toast " role="status">
      {message}
    </div>
  ) : null;
}
