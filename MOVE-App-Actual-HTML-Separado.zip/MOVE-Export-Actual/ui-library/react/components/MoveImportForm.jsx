import React, { useId } from 'react';
import { MoveSurface } from '../MoveSurface.jsx';

/** Bloque extraído del diseño actual de MOVE. Los eventos se exponen mediante onAction. */
export function MoveImportForm({
  theme = 'light',
  tenant = 'tp',
  reducedMotion = false,
  onAction,
  className = '',
  style,
  children,
}) {
  const uid = useId();
  return (
    <MoveSurface
      theme={theme}
      tenant={tenant}
      reducedMotion={reducedMotion}
      onAction={onAction}
      className={'' + ' ' + className}
      style={style}
    >
      {children ?? (
        <>
          <p className="ops-muted">
            {
              'TP · Churchill · Columnas: nombre, correo, rol. Roles: empleado, supervisor, coordinador, administrador.'
            }
          </p>
          <button
            className="ops-button secondary"
            data-move-click="downloadUserTemplate()"
          >
            {'Descargar plantilla CSV'}
          </button>
          <label className="ops-label">
            {'Archivo'}
            <input
              type="file"
              accept=".csv,.xlsx"
              data-move-change="readUserImport(this.files[0])"
            />
          </label>
          <div id={uid + '-importPreview'}></div>
          <form data-move-submit="commitUserImport(event)" data-move-form="">
            <label className="ops-label">
              {'Motivo'}
              <textarea
                name="reason"
                required
                minLength="8"
                maxLength="500"
                placeholder="Describe el motivo de este cambio."
                defaultValue=""
              />
            </label>
            <p
              className="ops-form-error"
              role="alert"
              id={uid + '-managementError'}
            ></p>
            <button id={uid + '-importCommit'} className="ops-button" disabled>
              {'Confirmar preregistro'}
            </button>
          </form>
        </>
      )}
    </MoveSurface>
  );
}
