import React, { useId } from 'react';
import { MoveSurface } from '../MoveSurface.jsx';

/** Patrón driver usado en views.trip(). */
export function MoveDriver({
  theme = 'light',
  tenant = 'tp',
  reducedMotion = false,
  onAction,
  className = '',
  style,
  children,
}) {
  const uid = useId();
  return (
    <MoveSurface
      theme={theme}
      tenant={tenant}
      reducedMotion={reducedMotion}
      onAction={onAction}
      className={'' + ' ' + className}
      style={style}
    >
      {children ?? (
        <>
          <div className="driver">
            <span className="avatar">{'JR'}</span>
            <div>
              <b>{'José Ramírez'}</b>
              <small>{'Conductor · Transporte TP'}</small>
            </div>
            <span className="rating">
              <span className="star">{'★'}</span>
              {' 4.9'}
            </span>
          </div>
        </>
      )}
    </MoveSurface>
  );
}
