import React, { useId } from 'react';
import { MoveSurface } from '../MoveSurface.jsx';

/** SVG original de MOVE, vectorial y personalizable. */
export function MoveIconPhone({
  theme = 'light',
  tenant = 'tp',
  reducedMotion = false,
  onAction,
  className = '',
  style,
  children,
}) {
  const uid = useId();
  return (
    <MoveSurface
      theme={theme}
      tenant={tenant}
      reducedMotion={reducedMotion}
      onAction={onAction}
      className={'' + ' ' + className}
      style={style}
    >
      {children ?? (
        <>
          <svg
            className="icon"
            viewBox="0 0 24 24"
            aria-hidden="true"
            xmlns="http://www.w3.org/2000/svg"
          >
            <path
              d="M5 3h4l2 5-3 2c2 3 3 4 6 6l2-3 5 2v4c-8 5-22-9-16-16"
              strokeLinecap="round"
              strokeLinejoin="round"
            ></path>
          </svg>
        </>
      )}
    </MoveSurface>
  );
}
