import React, { useId } from 'react';
import { MoveSurface } from '../MoveSurface.jsx';

/** Selector de ventanas, incluidas salidas después de medianoche. */
export function MoveSelect({
  theme = 'light',
  tenant = 'tp',
  reducedMotion = false,
  onAction,
  className = '',
  style,
  children,
}) {
  const uid = useId();
  return (
    <MoveSurface
      theme={theme}
      tenant={tenant}
      reducedMotion={reducedMotion}
      onAction={onAction}
      className={'' + ' ' + className}
      style={style}
    >
      {children ?? (
        <>
          <div>
            <label className="label" htmlFor={uid + '-window-field'}>
              {'Ventana de salida'}
            </label>
            <select id={uid + '-window-field'} defaultValue="22:30">
              <option value="21:30">{'9:30 p. m.'}</option>
              <option value="22:30">{'10:30 p. m.'}</option>
              <option value="23:30">{'11:30 p. m.'}</option>
              <option value="00:30">{'12:30 a. m. · Día siguiente'}</option>
            </select>
          </div>
        </>
      )}
    </MoveSurface>
  );
}
