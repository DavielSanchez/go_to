import React, { useId } from 'react';
import { MoveSurface } from '../MoveSurface.jsx';

/** Bloque extraído del diseño actual de MOVE. Los eventos se exponen mediante onAction. */
export function MoveOpsStatistics({
  theme = 'light',
  tenant = 'tp',
  reducedMotion = false,
  onAction,
  className = '',
  style,
  children,
}) {
  const uid = useId();
  return (
    <MoveSurface
      theme={theme}
      tenant={tenant}
      reducedMotion={reducedMotion}
      onAction={onAction}
      className={'' + ' ' + className}
      style={style}
    >
      {children ?? (
        <>
          <div className="ops-metrics">
            <article className="ops-metric">
              <small>{'Ocupación'}</small>
              <strong>{'88%'}</strong>
              <p>{'Promedio ponderado de la demo'}</p>
              <span>
                <svg
                  className="icon"
                  viewBox="0 0 24 24"
                  aria-hidden="true"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    d="M5 16V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2v11M5 11h14M8 3v8m8-8v8M5 16h14v3H5zM7 19v3m10-3v3M8 14h.01M16 14h.01"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  ></path>
                </svg>
              </span>
            </article>
            <article className="ops-metric">
              <small>{'Pasajeros abordados'}</small>
              <strong>{'30'}</strong>
              <p>{'Trips de la jornada y viajes activos'}</p>
              <span>
                <svg
                  className="icon"
                  viewBox="0 0 24 24"
                  aria-hidden="true"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    d="M20 21v-2a6 6 0 0 0-6-6h-4a6 6 0 0 0-6 6v2M16 6a4 4 0 1 1-8 0 4 4 0 0 1 8 0"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  ></path>
                </svg>
              </span>
            </article>
            <article className="ops-metric">
              <small>{'Viajes completados'}</small>
              <strong>{'1'}</strong>
              <p>{'Jornada seleccionada'}</p>
              <span>
                <svg
                  className="icon"
                  viewBox="0 0 24 24"
                  aria-hidden="true"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    d="M5 12l4 4L19 6"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  ></path>
                </svg>
              </span>
            </article>
            <article className="ops-metric">
              <small>{'Ausencias'}</small>
              <strong>{'0'}</strong>
              <p>{'Registradas en esta operación'}</p>
              <span>
                <svg
                  className="icon"
                  viewBox="0 0 24 24"
                  aria-hidden="true"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    d="M12 8v5l3 2M22 12a10 10 0 1 1-20 0 10 10 0 0 1 20 0"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  ></path>
                </svg>
              </span>
            </article>
          </div>
          <div className="ops-overview-grid">
            <section className="ops-card">
              <div className="ops-section-title">
                <div>
                  <span className="ops-eyebrow">{'7 JORNADAS · MOCK'}</span>
                  <h2>{'Ocupación del transporte'}</h2>
                </div>
                <b className="ops-chart-summary">{'88%'}</b>
              </div>
              <div
                className="ops-column-chart"
                aria-label="Ocupación de las últimas siete jornadas"
              >
                <div className="ops-column">
                  <b>{'81%'}</b>
                  <span style={{ height: '81%' }}></span>
                  <small>{'D-6'}</small>
                </div>
                <div className="ops-column">
                  <b>{'85%'}</b>
                  <span style={{ height: '85%' }}></span>
                  <small>{'D-5'}</small>
                </div>
                <div className="ops-column">
                  <b>{'83%'}</b>
                  <span style={{ height: '83%' }}></span>
                  <small>{'D-4'}</small>
                </div>
                <div className="ops-column">
                  <b>{'86%'}</b>
                  <span style={{ height: '86%' }}></span>
                  <small>{'D-3'}</small>
                </div>
                <div className="ops-column">
                  <b>{'87%'}</b>
                  <span style={{ height: '87%' }}></span>
                  <small>{'D-2'}</small>
                </div>
                <div className="ops-column">
                  <b>{'84%'}</b>
                  <span style={{ height: '84%' }}></span>
                  <small>{'D-1'}</small>
                </div>
                <div className="ops-column">
                  <b>{'88%'}</b>
                  <span style={{ height: '88%' }}></span>
                  <small>{'Jornada'}</small>
                </div>
              </div>
              <p className="ops-muted">
                {
                  '\n      Ocupación sobre asientos planificados. Serie ilustrativa para los tenants\n      seleccionados.\n    '
                }
              </p>
            </section>
            <section className="ops-card">
              <div className="ops-section-title">
                <div>
                  <span className="ops-eyebrow">{'COMPARATIVA'}</span>
                  <h2>{'Desempeño por tenant'}</h2>
                </div>
              </div>
              <div className="ops-comparison">
                <div>
                  <b>{'TP · Churchill'}</b>
                  <span>{'88%'}</span>
                </div>
                <div className="ops-bar">
                  <span style={{ width: '88%' }}></span>
                </div>
                <p className="ops-muted">
                  {'84 confirmaciones · 116 elegibles'}
                </p>
              </div>
            </section>
          </div>
          <section className="ops-card">
            <h2>{'Lectura de la jornada'}</h2>
            <div className="ops-insight-grid">
              <div>
                <b>{'1'}</b>
                <p>
                  {
                    'Tenants incluidos en la comparativa. El alcance cambia todos los indicadores.'
                  }
                </p>
              </div>
              <div>
                <b>{'3'}</b>
                <p>
                  {
                    'Excepciones aprobadas incluidas en los planes de esta jornada.'
                  }
                </p>
              </div>
              <div>
                <b>{'1'}</b>
                <p>{'Trips abiertos que aún necesitan un conductor.'}</p>
              </div>
            </div>
          </section>
        </>
      )}
    </MoveSurface>
  );
}
