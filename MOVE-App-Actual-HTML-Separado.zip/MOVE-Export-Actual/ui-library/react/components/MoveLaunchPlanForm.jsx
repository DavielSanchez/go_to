import React, { useId } from 'react';
import { MoveSurface } from '../MoveSurface.jsx';

/** Bloque extraído del diseño actual de MOVE. Los eventos se exponen mediante onAction. */
export function MoveLaunchPlanForm({
  theme = 'light',
  tenant = 'tp',
  reducedMotion = false,
  onAction,
  className = '',
  style,
  children,
}) {
  const uid = useId();
  return (
    <MoveSurface
      theme={theme}
      tenant={tenant}
      reducedMotion={reducedMotion}
      onAction={onAction}
      className={'' + ' ' + className}
      style={style}
    >
      {children ?? (
        <>
          <form data-move-submit="launchPlan(event)" data-move-form="">
            <p className="ops-muted">
              {'TP · Churchill · Jornada 3 de octubre de 2026'}
            </p>
            <div className="ops-callout warning">
              <b>{'El cutoff está configurado a las 20:00.'}</b>
              <p>
                {
                  'Generar antes del cierre puede dejar empleados pendientes. Revisa su listado al confirmar; las incorporaciones posteriores requieren aprobación.'
                }
              </p>
            </div>
            <label className="ops-label">
              {'Ventana de salida'}
              <select name="window">
                <option>{'21:30'}</option>
                <option>{'22:30'}</option>
                <option>{'23:30'}</option>
                <option>{'00:30'}</option>
              </select>
            </label>
            <p className="ops-muted">
              {
                'Tipos activos: Van estándar (13 asientos útiles), Minibús (25 asientos útiles)'
              }
            </p>
            <label className="management-check">
              <input type="checkbox" name="ack" required />
              {'Entiendo el cutoff y la demanda pendiente.'}
            </label>
            <label className="ops-label">
              {'Motivo'}
              <textarea
                name="reason"
                required
                minLength="8"
                maxLength="500"
                placeholder="Describe el motivo de este cambio."
                defaultValue=""
              />
            </label>
            <p
              className="ops-form-error"
              role="alert"
              id={uid + '-managementError'}
            ></p>
            <button className="ops-button">{'Generar propuesta'}</button>
          </form>
        </>
      )}
    </MoveSurface>
  );
}
