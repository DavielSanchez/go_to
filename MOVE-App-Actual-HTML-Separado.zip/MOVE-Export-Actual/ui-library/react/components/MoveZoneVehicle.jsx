import React, { useId } from 'react';
import { MoveSurface } from '../MoveSurface.jsx';

/** Patrón zone-vehicle usado en driverViews['driver-home'](). */
export function MoveZoneVehicle({
  theme = 'light',
  tenant = 'tp',
  reducedMotion = false,
  onAction,
  className = '',
  style,
  children,
}) {
  const uid = useId();
  return (
    <MoveSurface
      theme={theme}
      tenant={tenant}
      reducedMotion={reducedMotion}
      onAction={onAction}
      className={'' + ' ' + className}
      style={style}
    >
      {children ?? (
        <>
          <div className="zone-vehicle">
            <div>
              <b>{'Unidad 10'}</b>
              <p className="small-info">
                {'Llegada 1 · 6 pasajeros asignados'}
              </p>
            </div>
            <span className="pill green">{'0/6 a bordo'}</span>
          </div>
        </>
      )}
    </MoveSurface>
  );
}
