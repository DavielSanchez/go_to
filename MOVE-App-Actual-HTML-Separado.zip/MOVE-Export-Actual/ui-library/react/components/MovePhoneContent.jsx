import React, { useId } from 'react';
import { MoveSurface } from '../MoveSurface.jsx';

/** Patrón phone-content usado en landing.js · landingView. */
export function MovePhoneContent({
  theme = 'light',
  tenant = 'tp',
  reducedMotion = false,
  onAction,
  className = '',
  style,
  children,
}) {
  const uid = useId();
  return (
    <MoveSurface
      theme={theme}
      tenant={tenant}
      reducedMotion={reducedMotion}
      onAction={onAction}
      className={'' + ' ' + className}
      style={style}
    >
      {children ?? (
        <>
          <div className="phone-content">
            <small>{'VIERNES, 2 DE OCTUBRE'}</small>
            <h3>
              {'Hola, Daviel'}
              <span>{'.'}</span>
            </h3>
            <p>{'Tu regreso a casa, organizado.'}</p>
            <div className="phone-hero">
              <span>{'✓ RESERVA CONFIRMADA'}</span>
              <h4>
                {'Todo listo para'}
                <br />
                {'tu regreso.'}
              </h4>
              <div>
                <small>{'Salida del transporte'}</small>
                <b>{'10:15 p. m.'}</b>
              </div>
              <button data-move-click="enterMove()">{'Ver mi viaje'}</button>
            </div>
            <h4>{'Tu ruta asignada'}</h4>
            <div className="phone-route">
              <b>{'TP · Campus Churchill'}</b>
              <span>{'↓'}</span>
              <b>{'Los Alcarrizos'}</b>
              <small>{'Unidad 12 · Ruta 04'}</small>
            </div>
          </div>
        </>
      )}
    </MoveSurface>
  );
}
