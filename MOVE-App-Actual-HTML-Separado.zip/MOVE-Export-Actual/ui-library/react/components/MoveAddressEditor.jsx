import React, { useId } from 'react';
import { MoveSurface } from '../MoveSurface.jsx';

/** Bloque extraído del diseño actual de MOVE. Los eventos se exponen mediante onAction. */
export function MoveAddressEditor({
  theme = 'light',
  tenant = 'tp',
  reducedMotion = false,
  onAction,
  className = '',
  style,
  children,
}) {
  const uid = useId();
  return (
    <MoveSurface
      theme={theme}
      tenant={tenant}
      reducedMotion={reducedMotion}
      onAction={onAction}
      className={'' + ' ' + className}
      style={style}
    >
      {children ?? (
        <>
          <div className="narrow">
            <button className="back" data-move-click="navigate('profile')">
              <svg
                className="icon"
                viewBox="0 0 24 24"
                aria-hidden="true"
                xmlns="http://www.w3.org/2000/svg"
              >
                <path
                  d="M15 5l-7 7 7 7"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                ></path>
              </svg>
              {'Mi perfil'}
            </button>
            <div className="page-top">
              <div>
                <h1>{'Cambiar mi dirección'}</h1>
                <p className="sub">{'Marca tu destino en el mapa.'}</p>
              </div>
            </div>
            <form
              id={uid + '-pinAddressForm'}
              className="card"
              data-move-form=""
            >
              <span className="pill ">
                {'3 cambios automáticos disponibles'}
              </span>
              <label className="label" htmlFor={uid + '-destinationMap'}>
                {'Ubicación en el mapa · Obligatoria'}
              </label>
              <p className="small-info">
                {
                  'Toca el mapa para colocar el pin o arrástralo para ajustar tu destino.'
                }
              </p>
              <button
                id={uid + '-gpsButton'}
                type="button"
                className="btn secondary"
                style={{
                  marginTop: '14px',
                  marginRight: '0px',
                  marginBottom: '14px',
                  marginLeft: '0px',
                  margin: '14px 0px',
                }}
                data-move-click="useGPS()"
              >
                <svg
                  className="icon"
                  viewBox="0 0 24 24"
                  aria-hidden="true"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    d="M20 10c0 6-8 12-8 12S4 16 4 10a8 8 0 1 1 16 0M15 10a3 3 0 1 1-6 0 3 3 0 0 1 6 0"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  ></path>
                </svg>
                {'Usar mi ubicación actual'}
              </button>
              <div
                id={uid + '-destinationMap'}
                role="region"
                aria-label="Mapa para seleccionar el destino"
                tabIndex="0"
              ></div>
              <p
                id={uid + '-pinStatus'}
                className="small-info"
                role="status"
                style={{ marginTop: '12px' }}
              >
                {'Selecciona una ubicación en el mapa.'}
              </p>
              <p className="small-info" style={{ marginTop: '6px' }}>
                {
                  'Con teclado: usa las flechas para mover el centro y Enter para colocar el pin.'
                }
              </p>
              <label className="label" htmlFor={uid + '-destination'}>
                {'Dirección escrita '}
                <span className="small-info">{'· Opcional'}</span>
              </label>
              <textarea
                id={uid + '-destination'}
                name="destination"
                maxLength="250"
                placeholder="Calle, número, sector o una referencia…"
                defaultValue="Entrada de Pantoja · Los Alcarrizos"
              />
              <div className="notice">
                <svg
                  className="icon"
                  viewBox="0 0 24 24"
                  aria-hidden="true"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    d="M12 11v6m0-10v.01M22 12a10 10 0 1 1-20 0 10 10 0 0 1 20 0"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  ></path>
                </svg>
                <span>{'Este será tu cambio automático 1 de 3.'}</span>
              </div>
              <button
                id={uid + '-savePin'}
                className="btn"
                type="submit"
                disabled
              >
                {'Guardar dirección'}
              </button>
            </form>
            <p className="demo-note">
              {'Vista de demostración · Datos de ejemplo'}
            </p>
          </div>
        </>
      )}
    </MoveSurface>
  );
}
