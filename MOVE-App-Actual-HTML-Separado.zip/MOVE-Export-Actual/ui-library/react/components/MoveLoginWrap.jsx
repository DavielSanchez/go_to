import React, { useId } from 'react';
import { MoveSurface } from '../MoveSurface.jsx';
import asset0 from '../../assets/alorica-logo.png';
import asset1 from '../../assets/trueshore-logo.svg';
import asset2 from '../../assets/concentrix-logo.webp';
/** Patrón login-wrap usado en loginView(). */
export function MoveLoginWrap({
  theme = 'light',
  tenant = 'tp',
  reducedMotion = false,
  onAction,
  className = '',
  style,
  children,
}) {
  const uid = useId();
  return (
    <MoveSurface
      theme={theme}
      tenant={tenant}
      reducedMotion={reducedMotion}
      onAction={onAction}
      className={'' + ' ' + className}
      style={style}
    >
      {children ?? (
        <>
          <div className="login-wrap">
            <div className="login-intro">
              <span className="pill">{'BIENVENIDO A MOVE'}</span>
              <h1>
                {'Tu jornada empieza aquí'}
                <span className="accent">{'.'}</span>
              </h1>
              <p className="sub">
                {
                  'Accede como colaborador o conductor de un proveedor de transporte.'
                }
              </p>
            </div>
            <form id={uid + '-sharedLogin'} className="card" data-move-form="">
              <div
                className="access-tabs"
                role="group"
                aria-label="Tipo de acceso"
              >
                <button
                  type="button"
                  className="selected"
                  data-move-click="switchRole('corporate')"
                >
                  <svg
                    className="icon"
                    viewBox="0 0 24 24"
                    aria-hidden="true"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path
                      d="M20 21v-2a6 6 0 0 0-6-6h-4a6 6 0 0 0-6 6v2M16 6a4 4 0 1 1-8 0 4 4 0 0 1 8 0"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    ></path>
                  </svg>
                  {'Corporativo'}
                </button>
                <button
                  type="button"
                  className=""
                  data-move-click="switchRole('driver')"
                >
                  <svg
                    className="icon"
                    viewBox="0 0 24 24"
                    aria-hidden="true"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path
                      d="M5 16V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2v11M5 11h14M8 3v8m8-8v8M5 16h14v3H5zM7 19v3m10-3v3M8 14h.01M16 14h.01"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    ></path>
                  </svg>
                  {'Conductores'}
                </button>
              </div>
              <label className="label" htmlFor={uid + '-corporateRole'}>
                {'Perfil corporativo de demostración'}
              </label>
              <select
                id={uid + '-corporateRole'}
                data-move-change="selectCorporateRole(this.value)"
                defaultValue="agent"
              >
                <option value="agent">{'Agente / Colaborador'}</option>
                <option value="supervisor">{'Supervisor'}</option>
              </select>
              <label className="label" htmlFor={uid + '-loginId'}>
                {'Correo corporativo o ID de empleado'}
              </label>
              <input
                id={uid + '-loginId'}
                required
                defaultValue="empleado.demo"
                placeholder="Tu correo o ID"
                autoComplete="username"
              />
              <label className="label" htmlFor={uid + '-loginPassword'}>
                {'Contraseña'}
              </label>
              <input
                id={uid + '-loginPassword'}
                type="password"
                defaultValue="move-demo"
                placeholder="Contraseña de prueba"
                required
                autoComplete="off"
              />
              <div className="notice">
                <svg
                  className="icon"
                  viewBox="0 0 24 24"
                  aria-hidden="true"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    d="M12 11v6m0-10v.01M22 12a10 10 0 1 1-20 0 10 10 0 0 1 20 0"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  ></path>
                </svg>
                <span>
                  {
                    'Acceso de demostración. Usa datos ficticios: todavía no hay autenticación conectada.'
                  }
                </span>
              </div>
              <button className="btn" type="submit">
                {'Iniciar sesión simulada'}
              </button>
              <button
                className="btn secondary"
                type="button"
                style={{ marginTop: '12px' }}
                data-move-click="loginDemo()"
              >
                {'Entrar como corporativo demo'}
              </button>
              <p className="small-info" style={{ marginTop: '16px' }}>
                {
                  'El acceso corporativo reúne a los empleados de todos los roles.'
                }
              </p>
              <div className="register-prompt">
                <span>{'¿Primera vez en MOVE?'}</span>
                <button
                  type="button"
                  data-move-click="startRegistration(access.role)"
                >
                  {'Crear mi cuenta'}
                </button>
              </div>
              <div className="tenant-demo">
                <b>{'Prueba otra empresa'}</b>
                <span>{'Personalización de demostración'}</span>
                <div className="tenant-demo-grid">
                  <button
                    type="button"
                    data-move-click="fillTenantLogin('alorica')"
                  >
                    <img className="alorica-logo" src={asset0} alt="Alorica" />
                    <span>{'Alorica'}</span>
                  </button>
                  <button
                    type="button"
                    data-move-click="fillTenantLogin('trueshore')"
                  >
                    <img
                      className="trueshore-logo"
                      src={asset1}
                      alt="TrueShore"
                    />
                    <span>{'TrueShore'}</span>
                  </button>
                  <button
                    type="button"
                    data-move-click="fillTenantLogin('concentrix')"
                  >
                    <img
                      className="concentrix-logo"
                      src={asset2}
                      alt="Concentrix"
                    />
                    <span>{'Concentrix'}</span>
                  </button>
                </div>
              </div>
              <section className="ops-admin-demo">
                <b>{'Portales de operación'}</b>
                <p>
                  {'Accesos de demostración para revisar roles y alcances.'}
                </p>
                <div className="ops-admin-demo-buttons">
                  <button
                    type="button"
                    data-move-click="fillOpsLogin('site-admin')"
                  >
                    {'Administrador'}
                    <small>{'1 site de TP'}</small>
                  </button>
                  <button
                    type="button"
                    data-move-click="fillOpsLogin('coordinator')"
                  >
                    {'Coordinación de transporte'}
                    <small>{'1 site de TP'}</small>
                  </button>
                  <button
                    type="button"
                    data-move-click="fillOpsLogin('company-admin')"
                  >
                    {'Country Admin'}
                    <small>{'3 sites de TP'}</small>
                  </button>
                  <button
                    type="button"
                    data-move-click="fillOpsLogin('platform')"
                  >
                    {'Administrador de MOVE'}
                    <small>{'MOVE · todas las empresas'}</small>
                  </button>
                </div>
              </section>
            </form>
            <p className="demo-note">
              {'Vista de demostración · Datos de ejemplo'}
            </p>
          </div>
        </>
      )}
    </MoveSurface>
  );
}
