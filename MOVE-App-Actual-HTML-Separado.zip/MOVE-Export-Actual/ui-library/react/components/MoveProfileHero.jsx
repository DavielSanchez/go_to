import React, { useId } from 'react';
import { MoveSurface } from '../MoveSurface.jsx';

/** Patrón profile-hero usado en views.profile(). */
export function MoveProfileHero({
  theme = 'light',
  tenant = 'tp',
  reducedMotion = false,
  onAction,
  className = '',
  style,
  children,
}) {
  const uid = useId();
  return (
    <MoveSurface
      theme={theme}
      tenant={tenant}
      reducedMotion={reducedMotion}
      onAction={onAction}
      className={'' + ' ' + className}
      style={style}
    >
      {children ?? (
        <>
          <div className="profile-hero">
            <span className="avatar">{'DS'}</span>
            <h2>{'Daviel Sánchez'}</h2>
            <p className="sub">{'Colaborador · TP Santo Domingo'}</p>
            <span className="pill" style={{ marginTop: '14px' }}>
              {'ID de empleado: 104582'}
            </span>
          </div>
        </>
      )}
    </MoveSurface>
  );
}
