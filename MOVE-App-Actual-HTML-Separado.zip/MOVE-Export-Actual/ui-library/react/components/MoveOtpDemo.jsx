import React, { useId } from 'react';
import { MoveSurface } from '../MoveSurface.jsx';

/** Patrón otp-demo usado en registrationView(). */
export function MoveOtpDemo({
  theme = 'light',
  tenant = 'tp',
  reducedMotion = false,
  onAction,
  className = '',
  style,
  children,
}) {
  const uid = useId();
  return (
    <MoveSurface
      theme={theme}
      tenant={tenant}
      reducedMotion={reducedMotion}
      onAction={onAction}
      className={'' + ' ' + className}
      style={style}
    >
      {children ?? (
        <>
          <div className="otp-demo">
            <span>{'OTP de demostración'}</span>
            <b data-user-content="">{'123456'}</b>
            <small>
              {'No se envió un correo real. Este código vence en 5 minutos.'}
            </small>
          </div>
        </>
      )}
    </MoveSurface>
  );
}
