import React, { useId } from 'react';
import { MoveSurface } from '../MoveSurface.jsx';

/** Patrón demo-controls usado en views.profile(). */
export function MoveDemoControls({
  theme = 'light',
  tenant = 'tp',
  reducedMotion = false,
  onAction,
  className = '',
  style,
  children,
}) {
  const uid = useId();
  return (
    <MoveSurface
      theme={theme}
      tenant={tenant}
      reducedMotion={reducedMotion}
      onAction={onAction}
      className={'' + ' ' + className}
      style={style}
    >
      {children ?? (
        <>
          <details className="card demo-controls">
            <summary>{'Probar estados de demostración'}</summary>
            <label className="label" htmlFor={uid + '-scenario'}>
              {'Situación del empleado'}
            </label>
            <select
              id={uid + '-scenario'}
              data-move-change="setScenario(this.value)"
              defaultValue="Selecciona un escenario"
            >
              <option value="" disabled>
                {'Selecciona un escenario'}
              </option>
              <option value="eligible">{'Aplica para transporte'}</option>
              <option value="ineligible">
                {'No aplica para transporte hoy'}
              </option>
              <option value="missing">{'Sin dirección registrada'}</option>
              <option value="third">
                {'Dos cambios usados · Probar el tercero'}
              </option>
              <option value="fourth">
                {'Tres cambios usados · Requiere aprobación'}
              </option>
            </select>
            <p className="small-info" style={{ marginTop: '12px' }}>
              {
                'Estos escenarios usan datos de ejemplo. No envían solicitudes reales.'
              }
            </p>
            <button className="cancel" data-move-click="resetDemo()">
              {'Reiniciar demostración'}
            </button>
          </details>
        </>
      )}
    </MoveSurface>
  );
}
