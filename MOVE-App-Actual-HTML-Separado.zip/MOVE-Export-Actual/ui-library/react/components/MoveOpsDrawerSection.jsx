import React, { useId } from 'react';
import { MoveSurface } from '../MoveSurface.jsx';

/** Patrón ops-drawer-section usado en opsDrawerHTML(). */
export function MoveOpsDrawerSection({
  theme = 'light',
  tenant = 'tp',
  reducedMotion = false,
  onAction,
  className = '',
  style,
  children,
}) {
  const uid = useId();
  return (
    <MoveSurface
      theme={theme}
      tenant={tenant}
      reducedMotion={reducedMotion}
      onAction={onAction}
      className={'' + ' ' + className}
      style={style}
    >
      {children ?? (
        <>
          <section className="ops-drawer-section">
            <div className="ops-detail-grid">
              <div>
                <small>{'Fecha calendario / salida'}</small>
                <b>{'4 de octubre de 2026 · 00:30'}</b>
              </div>
              <div>
                <small>{'Conductor actual'}</small>
                <b>{'Sin conductor'}</b>
              </div>
              <div>
                <small>{'Vehículo / ruta'}</small>
                <b>{'Unidad 13 · Ruta 04'}</b>
              </div>
              <div>
                <small>{'Abordados / previstos'}</small>
                <b>{'6 / 8'}</b>
              </div>
            </div>
          </section>
        </>
      )}
    </MoveSurface>
  );
}
