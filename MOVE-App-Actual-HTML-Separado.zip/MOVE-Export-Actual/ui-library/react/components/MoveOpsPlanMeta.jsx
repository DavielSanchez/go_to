import React, { useId } from 'react';
import { MoveSurface } from '../MoveSurface.jsx';

/** Patrón ops-plan-meta usado en opsPlansView(). */
export function MoveOpsPlanMeta({
  theme = 'light',
  tenant = 'tp',
  reducedMotion = false,
  onAction,
  className = '',
  style,
  children,
}) {
  const uid = useId();
  return (
    <MoveSurface
      theme={theme}
      tenant={tenant}
      reducedMotion={reducedMotion}
      onAction={onAction}
      className={'' + ' ' + className}
      style={style}
    >
      {children ?? (
        <>
          <div className="ops-plan-meta">
            <span className="ops-eyebrow">{'TP · Churchill'}</span>
            <span className="ops-pill confirmed">{'Confirmado'}</span>
          </div>
        </>
      )}
    </MoveSurface>
  );
}
