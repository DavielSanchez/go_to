import React, { useId } from 'react';
import { MoveSurface } from '../MoveSurface.jsx';

/** Patrón stars usado en views.review(). */
export function MoveStars({
  theme = 'light',
  tenant = 'tp',
  reducedMotion = false,
  onAction,
  className = '',
  style,
  children,
}) {
  const uid = useId();
  return (
    <MoveSurface
      theme={theme}
      tenant={tenant}
      reducedMotion={reducedMotion}
      onAction={onAction}
      className={'' + ' ' + className}
      style={style}
    >
      {children ?? (
        <>
          <div className="stars" aria-label="Calificación del viaje">
            <button
              type="button"
              aria-label="1 estrella"
              aria-pressed="false"
              className=""
              data-move-click="setRating(1)"
            >
              {'★'}
            </button>
            <button
              type="button"
              aria-label="2 estrellas"
              aria-pressed="false"
              className=""
              data-move-click="setRating(2)"
            >
              {'★'}
            </button>
            <button
              type="button"
              aria-label="3 estrellas"
              aria-pressed="false"
              className=""
              data-move-click="setRating(3)"
            >
              {'★'}
            </button>
            <button
              type="button"
              aria-label="4 estrellas"
              aria-pressed="false"
              className=""
              data-move-click="setRating(4)"
            >
              {'★'}
            </button>
            <button
              type="button"
              aria-label="5 estrellas"
              aria-pressed="false"
              className=""
              data-move-click="setRating(5)"
            >
              {'★'}
            </button>
          </div>
        </>
      )}
    </MoveSurface>
  );
}
