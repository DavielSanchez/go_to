import React, { useId } from 'react';
import { MoveSurface } from '../MoveSurface.jsx';

/** Patrón management-check usado en launchPlanForm(). */
export function MoveManagementCheck({
  theme = 'light',
  tenant = 'tp',
  reducedMotion = false,
  onAction,
  className = '',
  style,
  children,
}) {
  const uid = useId();
  return (
    <MoveSurface
      theme={theme}
      tenant={tenant}
      reducedMotion={reducedMotion}
      onAction={onAction}
      className={'' + ' ' + className}
      style={style}
    >
      {children ?? (
        <>
          <label className="management-check">
            <input type="checkbox" name="ack" required />
            {'Entiendo el cutoff y la demanda pendiente.'}
          </label>
        </>
      )}
    </MoveSurface>
  );
}
