import React, { useId } from 'react';
import { MoveSurface } from '../MoveSurface.jsx';

/** Patrón scan-buttons usado en views.ticket(). */
export function MoveScanButtons({
  theme = 'light',
  tenant = 'tp',
  reducedMotion = false,
  onAction,
  className = '',
  style,
  children,
}) {
  const uid = useId();
  return (
    <MoveSurface
      theme={theme}
      tenant={tenant}
      reducedMotion={reducedMotion}
      onAction={onAction}
      className={'' + ' ' + className}
      style={style}
    >
      {children ?? (
        <>
          <div className="scan-buttons">
            <button
              className="btn secondary"
              data-move-click="simulateScan('ok')"
            >
              {'Vehículo y hora correctos'}
            </button>
            <button
              className="btn secondary"
              data-move-click="simulateScan('vehicle')"
            >
              {'Vehículo incorrecto'}
            </button>
            <button
              className="btn secondary"
              data-move-click="simulateScan('time')"
            >
              {'Horario incorrecto'}
            </button>
            <button
              className="btn secondary"
              data-move-click="simulateScan('date')"
            >
              {'Fecha incorrecta'}
            </button>
            <button
              className="btn secondary"
              data-move-click="simulateScan('revoked')"
            >
              {'Ticket sin autorización'}
            </button>
          </div>
        </>
      )}
    </MoveSurface>
  );
}
