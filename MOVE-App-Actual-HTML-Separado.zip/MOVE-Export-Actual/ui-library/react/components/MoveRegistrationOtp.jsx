import React, { useId } from 'react';
import { MoveSurface } from '../MoveSurface.jsx';

/** Bloque extraído del diseño actual de MOVE. Los eventos se exponen mediante onAction. */
export function MoveRegistrationOtp({
  theme = 'light',
  tenant = 'tp',
  reducedMotion = false,
  onAction,
  className = '',
  style,
  children,
}) {
  const uid = useId();
  return (
    <MoveSurface
      theme={theme}
      tenant={tenant}
      reducedMotion={reducedMotion}
      onAction={onAction}
      className={'' + ' ' + className}
      style={style}
    >
      {children ?? (
        <>
          <div className="signup-wrap">
            <button
              className="back"
              data-move-click="navigate('login');render()"
            >
              <svg
                className="icon"
                viewBox="0 0 24 24"
                aria-hidden="true"
                xmlns="http://www.w3.org/2000/svg"
              >
                <path
                  d="M15 5l-7 7 7 7"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                ></path>
              </svg>
              {'Volver al login'}
            </button>
            <div className="signup-title">
              <span className="pill">{'TU ACCESO A MOVE'}</span>
              <h1>{'Cada viaje empieza aquí.'}</h1>
              <p className="sub">
                {'Acceso corporativo con tu correo personal autorizado.'}
              </p>
            </div>
            <div className="signup-progress">
              <span className="done">
                <i>
                  <svg
                    className="icon"
                    viewBox="0 0 24 24"
                    aria-hidden="true"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path
                      d="M5 12l4 4L19 6"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    ></path>
                  </svg>
                </i>
                {'Correo'}
              </span>
              <span className="current">
                <i>{'2'}</i>
                {'Verificación'}
              </span>
              <span className="">
                <i>{'3'}</i>
                {'Contraseña'}
              </span>
            </div>
            <form
              className="card signup-card"
              id={uid + '-registrationForm'}
              data-move-form=""
            >
              <span className="signup-icon">
                <svg
                  className="icon"
                  viewBox="0 0 24 24"
                  aria-hidden="true"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    d="M12 3l8 3v6c0 5-8 9-8 9s-8-4-8-9V6zM8 12l3 3 5-6"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  ></path>
                </svg>
              </span>
              <h2>{'Verifica tu correo.'}</h2>
              <p className="small-info">
                {'Introduce el código de 6 dígitos para continuar.'}
              </p>
              <div className="signup-email" data-user-content="">
                {'ana.perez@gmail.com'}
              </div>
              <label className="label" htmlFor={uid + '-signupOTP'}>
                {'Código de verificación'}
              </label>
              <input
                id={uid + '-signupOTP'}
                name="otp"
                className="otp-input"
                type="text"
                inputMode="numeric"
                autoComplete="one-time-code"
                pattern="[0-9]{6}"
                minLength="6"
                maxLength="6"
                placeholder="000000"
                required
              />
              <div className="otp-demo">
                <span>{'OTP de demostración'}</span>
                <b data-user-content="">{'123456'}</b>
                <small>
                  {
                    'No se envió un correo real. Este código vence en 5 minutos.'
                  }
                </small>
              </div>
              <div
                id={uid + '-registrationError'}
                className="form-error"
                role="alert"
              ></div>
              <button className="btn" type="submit">
                {'Validar código'}
              </button>
              <div className="signup-links">
                <button type="button" data-move-click="resendRegistrationOTP()">
                  {'Reenviar código'}
                </button>
                <button
                  type="button"
                  data-move-click="backToRegistrationEmail()"
                >
                  {'Cambiar correo'}
                </button>
              </div>
            </form>
            <p className="demo-note">
              {'Vista de demostración · Datos de ejemplo'}
            </p>
          </div>
        </>
      )}
    </MoveSurface>
  );
}
