import React, { useId } from 'react';
import { MoveSurface } from '../MoveSurface.jsx';

/** Patrón photo-actions usado en onboardingView(). */
export function MovePhotoActions({
  theme = 'light',
  tenant = 'tp',
  reducedMotion = false,
  onAction,
  className = '',
  style,
  children,
}) {
  const uid = useId();
  return (
    <MoveSurface
      theme={theme}
      tenant={tenant}
      reducedMotion={reducedMotion}
      onAction={onAction}
      className={'' + ' ' + className}
      style={style}
    >
      {children ?? (
        <>
          <div className="photo-actions">
            <label className="btn secondary">
              {'Tomar foto'}
              <input
                type="file"
                accept="image/*"
                capture="environment"
                data-photo="id"
                hidden
              />
            </label>
            <label className="btn secondary">
              {'Galería'}
              <input type="file" accept="image/*" data-photo="id" hidden />
            </label>
          </div>
        </>
      )}
    </MoveSurface>
  );
}
