import React, { useId } from 'react';
import { MoveSurface } from '../MoveSurface.jsx';

/** Patrón lp-tabs usado en landing.js · landingView. */
export function MoveLpTabs({
  theme = 'light',
  tenant = 'tp',
  reducedMotion = false,
  onAction,
  className = '',
  style,
  children,
}) {
  const uid = useId();
  return (
    <MoveSurface
      theme={theme}
      tenant={tenant}
      reducedMotion={reducedMotion}
      onAction={onAction}
      className={'' + ' ' + className}
      style={style}
    >
      {children ?? (
        <>
          <div
            className="lp-tabs"
            role="tablist"
            aria-label="Experiencias MOVE"
          >
            <button
              id={uid + '-employeeTab'}
              role="tab"
              aria-selected="true"
              className="active"
              data-move-click="selectLandingRole('employee')"
            >
              {'Colaborador'}
            </button>
            <button
              id={uid + '-driverTab'}
              role="tab"
              aria-selected="false"
              className=""
              data-move-click="selectLandingRole('driver')"
            >
              {'Conductor'}
            </button>
          </div>
        </>
      )}
    </MoveSurface>
  );
}
