import React, { useId } from 'react';
import { MoveSurface } from '../MoveSurface.jsx';

/** Patrón hero usado en views.home(). */
export function MoveHero({
  theme = 'light',
  tenant = 'tp',
  reducedMotion = false,
  onAction,
  className = '',
  style,
  children,
}) {
  const uid = useId();
  return (
    <MoveSurface
      theme={theme}
      tenant={tenant}
      reducedMotion={reducedMotion}
      onAction={onAction}
      className={'' + ' ' + className}
      style={style}
    >
      {children ?? (
        <>
          <div className="card hero">
            <span className="pill">
              <svg
                className="icon"
                viewBox="0 0 24 24"
                aria-hidden="true"
                xmlns="http://www.w3.org/2000/svg"
              >
                <path
                  d="M5 16V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2v11M5 11h14M8 3v8m8-8v8M5 16h14v3H5zM7 19v3m10-3v3M8 14h.01M16 14h.01"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                ></path>
              </svg>
              {'TU TRANSPORTE DE HOY'}
            </span>
            <h2>{'¿Te llevamos a casa hoy?'}</h2>
            <p>
              {'Confirma tu transporte y asegura tu asiento para esta noche.'}
            </p>
            <div className="time-row">
              <div>
                <small>{'Salida de tu turno'}</small>
                <strong>
                  {'10:00 '}
                  <span style={{ fontSize: '14px' }}>{'p. m.'}</span>
                </strong>
              </div>
              <div>
                <small>{'Salida del transporte'}</small>
                <strong>
                  {'10:30 '}
                  <span style={{ fontSize: '14px' }}>{'p. m.'}</span>
                </strong>
              </div>
            </div>
            <button className="btn" data-move-click="confirmRide()">
              <svg
                className="icon"
                viewBox="0 0 24 24"
                aria-hidden="true"
                xmlns="http://www.w3.org/2000/svg"
              >
                <path
                  d="M5 12l4 4L19 6"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                ></path>
              </svg>
              {'Sí, usaré el transporte'}
            </button>
            <div className="hero-foot">
              <svg
                className="icon"
                viewBox="0 0 24 24"
                aria-hidden="true"
                xmlns="http://www.w3.org/2000/svg"
              >
                <path
                  d="M12 8v5l3 2M22 12a10 10 0 1 1-20 0 10 10 0 0 1 20 0"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                ></path>
              </svg>
              {'Confirma antes de las 8:00 p. m.'}
            </div>
          </div>
        </>
      )}
    </MoveSurface>
  );
}
