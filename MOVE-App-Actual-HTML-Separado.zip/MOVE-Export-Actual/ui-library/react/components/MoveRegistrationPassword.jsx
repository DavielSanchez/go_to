import React, { useId } from 'react';
import { MoveSurface } from '../MoveSurface.jsx';

/** Bloque extraído del diseño actual de MOVE. Los eventos se exponen mediante onAction. */
export function MoveRegistrationPassword({
  theme = 'light',
  tenant = 'tp',
  reducedMotion = false,
  onAction,
  className = '',
  style,
  children,
}) {
  const uid = useId();
  return (
    <MoveSurface
      theme={theme}
      tenant={tenant}
      reducedMotion={reducedMotion}
      onAction={onAction}
      className={'' + ' ' + className}
      style={style}
    >
      {children ?? (
        <>
          <div className="signup-wrap">
            <button
              className="back"
              data-move-click="navigate('login');render()"
            >
              <svg
                className="icon"
                viewBox="0 0 24 24"
                aria-hidden="true"
                xmlns="http://www.w3.org/2000/svg"
              >
                <path
                  d="M15 5l-7 7 7 7"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                ></path>
              </svg>
              {'Volver al login'}
            </button>
            <div className="signup-title">
              <span className="pill">{'TU ACCESO A MOVE'}</span>
              <h1>{'Cada viaje empieza aquí.'}</h1>
              <p className="sub">
                {'Acceso corporativo con tu correo personal autorizado.'}
              </p>
            </div>
            <div className="signup-progress">
              <span className="done">
                <i>
                  <svg
                    className="icon"
                    viewBox="0 0 24 24"
                    aria-hidden="true"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path
                      d="M5 12l4 4L19 6"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    ></path>
                  </svg>
                </i>
                {'Correo'}
              </span>
              <span className="done">
                <i>
                  <svg
                    className="icon"
                    viewBox="0 0 24 24"
                    aria-hidden="true"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path
                      d="M5 12l4 4L19 6"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    ></path>
                  </svg>
                </i>
                {'Verificación'}
              </span>
              <span className="current">
                <i>{'3'}</i>
                {'Contraseña'}
              </span>
            </div>
            <form
              className="card signup-card"
              id={uid + '-registrationForm'}
              data-move-form=""
            >
              <span className="signup-icon">
                <svg
                  className="icon"
                  viewBox="0 0 24 24"
                  aria-hidden="true"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    d="M20 21v-2a6 6 0 0 0-6-6h-4a6 6 0 0 0-6 6v2M16 6a4 4 0 1 1-8 0 4 4 0 0 1 8 0"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  ></path>
                </svg>
              </span>
              <h2>{'Correo verificado.'}</h2>
              <p className="small-info">
                {'Elige una contraseña para entrar a MOVE.'}
              </p>
              <div className="signup-email" data-user-content="">
                {'ana.perez@gmail.com'}
              </div>
              <label className="label" htmlFor={uid + '-signupPassword'}>
                {'Nueva contraseña'}
              </label>
              <input
                id={uid + '-signupPassword'}
                name="password"
                type="password"
                autoComplete="new-password"
                required
                minLength="8"
                maxLength="128"
                data-move-input="updatePasswordChecklist(this.value)"
              />
              <div className="password-checklist">
                <span id={uid + '-passwordLength'}>
                  <svg
                    className="icon"
                    viewBox="0 0 24 24"
                    aria-hidden="true"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path
                      d="M5 12l4 4L19 6"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    ></path>
                  </svg>
                  {'Al menos 8 caracteres'}
                </span>
                <span id={uid + '-passwordMix'}>
                  <svg
                    className="icon"
                    viewBox="0 0 24 24"
                    aria-hidden="true"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path
                      d="M5 12l4 4L19 6"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    ></path>
                  </svg>
                  {'Una letra y un número'}
                </span>
              </div>
              <label className="label" htmlFor={uid + '-signupConfirm'}>
                {'Confirmar contraseña'}
              </label>
              <input
                id={uid + '-signupConfirm'}
                name="confirm"
                type="password"
                autoComplete="new-password"
                required
                minLength="8"
                maxLength="128"
              />
              <div
                id={uid + '-registrationError'}
                className="form-error"
                role="alert"
              ></div>
              <button className="btn" type="submit">
                {'Crear cuenta'}
              </button>
              <p className="small-info signup-terms">
                {
                  'Registro de demostración. Tus datos se guardan únicamente en este navegador.'
                }
              </p>
            </form>
            <p className="demo-note">
              {'Vista de demostración · Datos de ejemplo'}
            </p>
          </div>
        </>
      )}
    </MoveSurface>
  );
}
