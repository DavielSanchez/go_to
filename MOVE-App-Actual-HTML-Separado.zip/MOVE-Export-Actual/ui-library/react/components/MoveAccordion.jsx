import React, { useId } from 'react';
import { MoveSurface } from '../MoveSurface.jsx';

/** Accordion nativo details/summary. */
export function MoveAccordion({
  theme = 'light',
  tenant = 'tp',
  reducedMotion = false,
  onAction,
  className = '',
  style,
  children,
}) {
  const uid = useId();
  return (
    <MoveSurface
      theme={theme}
      tenant={tenant}
      reducedMotion={reducedMotion}
      onAction={onAction}
      className={'' + ' ' + className}
      style={style}
    >
      {children ?? (
        <>
          <details className="card">
            <summary>{'Detalles del recorrido'}</summary>
            <p className="sub">{'Churchill → Los Girasoles → Pantoja.'}</p>
          </details>
        </>
      )}
    </MoveSurface>
  );
}
