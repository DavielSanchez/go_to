import React, { useId } from 'react';
import { MoveSurface } from '../MoveSurface.jsx';

/** Radio cards con estado seleccionado. */
export function MoveRadioChoice({
  theme = 'light',
  tenant = 'tp',
  reducedMotion = false,
  onAction,
  className = '',
  style,
  children,
}) {
  const uid = useId();
  return (
    <MoveSurface
      theme={theme}
      tenant={tenant}
      reducedMotion={reducedMotion}
      onAction={onAction}
      className={'' + ' ' + className}
      style={style}
    >
      {children ?? (
        <>
          <div>
            <label className="choice">
              <input type="radio" name="demo-reason" defaultChecked />
              <span>
                <b>{'Horas extra'}</b>
                <small>{'Tu turno se extendió.'}</small>
              </span>
            </label>
            <label className="choice">
              <input type="radio" name="demo-reason" />
              <span>
                <b>{'Capacitación'}</b>
                <small>{'Participaste en una formación.'}</small>
              </span>
            </label>
          </div>
        </>
      )}
    </MoveSurface>
  );
}
