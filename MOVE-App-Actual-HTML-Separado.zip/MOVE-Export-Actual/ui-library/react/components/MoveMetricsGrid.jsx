import React, { useId } from 'react';
import { MoveSurface } from '../MoveSurface.jsx';

/** Patrón metrics-grid usado en landing.js · landingView. */
export function MoveMetricsGrid({
  theme = 'light',
  tenant = 'tp',
  reducedMotion = false,
  onAction,
  className = '',
  style,
  children,
}) {
  const uid = useId();
  return (
    <MoveSurface
      theme={theme}
      tenant={tenant}
      reducedMotion={reducedMotion}
      onAction={onAction}
      className={'' + ' ' + className}
      style={style}
    >
      {children ?? (
        <>
          <div className="metrics-grid">
            <div>
              <strong>{'1,200'}</strong>
              <span>{'colaboradores en el escenario'}</span>
            </div>
            <div>
              <strong>{'42'}</strong>
              <span>{'vehículos coordinados'}</span>
            </div>
            <div>
              <strong>
                {'91'}
                <span>{'%'}</span>
              </strong>
              <span>{'ocupación ilustrativa'}</span>
            </div>
            <div>
              <strong>
                {'18'}
                <span>{'%'}</span>
              </strong>
              <span>{'reducción de costo hipotética'}</span>
            </div>
          </div>
        </>
      )}
    </MoveSurface>
  );
}
