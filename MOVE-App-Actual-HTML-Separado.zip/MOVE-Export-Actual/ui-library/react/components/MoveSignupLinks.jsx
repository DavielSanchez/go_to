import React, { useId } from 'react';
import { MoveSurface } from '../MoveSurface.jsx';

/** Patrón signup-links usado en registrationView(). */
export function MoveSignupLinks({
  theme = 'light',
  tenant = 'tp',
  reducedMotion = false,
  onAction,
  className = '',
  style,
  children,
}) {
  const uid = useId();
  return (
    <MoveSurface
      theme={theme}
      tenant={tenant}
      reducedMotion={reducedMotion}
      onAction={onAction}
      className={'' + ' ' + className}
      style={style}
    >
      {children ?? (
        <>
          <div className="signup-links">
            <button type="button" data-move-click="resendRegistrationOTP()">
              {'Reenviar código'}
            </button>
            <button type="button" data-move-click="backToRegistrationEmail()">
              {'Cambiar correo'}
            </button>
          </div>
        </>
      )}
    </MoveSurface>
  );
}
