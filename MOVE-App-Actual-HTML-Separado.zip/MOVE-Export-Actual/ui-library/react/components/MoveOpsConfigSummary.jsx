import React, { useId } from 'react';
import { MoveSurface } from '../MoveSurface.jsx';

/** Patrón ops-config-summary usado en opsConfigurationView(). */
export function MoveOpsConfigSummary({
  theme = 'light',
  tenant = 'tp',
  reducedMotion = false,
  onAction,
  className = '',
  style,
  children,
}) {
  const uid = useId();
  return (
    <MoveSurface
      theme={theme}
      tenant={tenant}
      reducedMotion={reducedMotion}
      onAction={onAction}
      className={'' + ' ' + className}
      style={style}
    >
      {children ?? (
        <>
          <div className="ops-config-summary">
            {'País: DO'}
            <br />
            {'Ciudad: Santo Domingo'}
            <br />
            {'Tenant: tp-churchill'}
            <br />
            {'Las integraciones mostradas son de demostración.'}
          </div>
        </>
      )}
    </MoveSurface>
  );
}
