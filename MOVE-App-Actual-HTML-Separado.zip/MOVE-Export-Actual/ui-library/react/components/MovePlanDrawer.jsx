import React, { useId } from 'react';
import { MoveSurface } from '../MoveSurface.jsx';

/** Bloque extraído del diseño actual de MOVE. Los eventos se exponen mediante onAction. */
export function MovePlanDrawer({
  theme = 'light',
  tenant = 'tp',
  reducedMotion = false,
  onAction,
  className = '',
  style,
  children,
}) {
  const uid = useId();
  return (
    <MoveSurface
      theme={theme}
      tenant={tenant}
      reducedMotion={reducedMotion}
      onAction={onAction}
      className={'' + ' ' + className}
      style={style}
    >
      {children ?? (
        <>
          <div
            className="ops-drawer-backdrop"
            data-move-click="if(event.target===this)closeOpsDrawer()"
          >
            <section
              className="ops-drawer"
              role="dialog"
              aria-modal="true"
              aria-labelledby={uid + '-opsDrawerTitle'}
            >
              <div className="ops-drawer-top">
                <h2 id={uid + '-opsDrawerTitle'}>{'Confirmar PLAN-100'}</h2>
                <button
                  className="ops-icon-button"
                  aria-label="Cerrar detalle"
                  data-move-click="closeOpsDrawer()"
                >
                  <svg
                    className="icon"
                    viewBox="0 0 24 24"
                    aria-hidden="true"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path
                      d="M15 5l-7 7 7 7"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    ></path>
                  </svg>
                </button>
              </div>
              <p className="ops-muted">{'TP · Churchill · Ventana 00:30'}</p>
              <div className="ops-plan-summary">
                <div>
                  <strong>{'20'}</strong>
                  <small>{'Pasajeros'}</small>
                </div>
                <div>
                  <strong>{'2'}</strong>
                  <small>{'Trips a generar'}</small>
                </div>
                <div>
                  <strong>{'2'}</strong>
                  <small>{'Asientos libres / vehículo'}</small>
                </div>
              </div>
              <div className="ops-callout">
                {
                  'Se crearán los trips de cada ruta. El QR de ruta será compartido por sus conductores y permitirá tomar un trip libre.'
                }
              </div>
              <div className="ops-callout warning">
                <b>{'6 empleados faltan por confirmar.'}</b>
                <p>
                  {
                    'Cutoff 20:00. La confirmación utilizará la demanda actual y los tipos de vehículo registrados.'
                  }
                </p>
                <details>
                  <summary>{'Ver pendientes'}</summary>
                  <p>{'Ana Pérez 25'}</p>
                  <p>{'Carlos Mejía 26'}</p>
                  <p>{'Laura Díaz 27'}</p>
                  <p>{'Miguel Santos 28'}</p>
                  <p>{'Sofía Rodríguez 29'}</p>
                  <p>{'Juan Reyes 30'}</p>
                </details>
              </div>
              <form
                data-move-submit="submitOpsPlan(event,'PLAN-100')"
                data-move-form=""
              >
                <label className="ops-label">
                  {'Motivo / validación del plan'}
                </label>
                <textarea
                  name="reason"
                  required
                  minLength="8"
                  maxLength="500"
                  placeholder="Ejemplo: demanda y capacidad revisadas con el proveedor."
                  defaultValue=""
                />
                <div className="ops-drawer-actions">
                  <button type="submit" className="ops-button">
                    {'Confirmar y generar trips'}
                  </button>
                </div>
                <p
                  id={uid + '-opsActionError'}
                  className="ops-form-error"
                  role="alert"
                ></p>
              </form>
            </section>
          </div>
        </>
      )}
    </MoveSurface>
  );
}
