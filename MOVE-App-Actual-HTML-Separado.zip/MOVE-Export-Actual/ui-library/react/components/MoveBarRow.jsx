import React, { useId } from 'react';
import { MoveSurface } from '../MoveSurface.jsx';

/** Patrón bar-row usado en landing.js · landingView. */
export function MoveBarRow({
  theme = 'light',
  tenant = 'tp',
  reducedMotion = false,
  onAction,
  className = '',
  style,
  children,
}) {
  const uid = useId();
  return (
    <MoveSurface
      theme={theme}
      tenant={tenant}
      reducedMotion={reducedMotion}
      onAction={onAction}
      className={'' + ' ' + className}
      style={style}
    >
      {children ?? (
        <>
          <div className="bar-row">
            <span>{'21:00'}</span>
            <div>
              <i style={{ width: '72%' }}></i>
            </div>
            <b>{'72%'}</b>
          </div>
        </>
      )}
    </MoveSurface>
  );
}
