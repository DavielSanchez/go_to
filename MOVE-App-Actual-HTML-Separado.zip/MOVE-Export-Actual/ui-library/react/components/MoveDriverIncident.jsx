import React, { useId } from 'react';
import { MoveSurface } from '../MoveSurface.jsx';

/** Bloque extraído del diseño actual de MOVE. Los eventos se exponen mediante onAction. */
export function MoveDriverIncident({
  theme = 'light',
  tenant = 'tp',
  reducedMotion = false,
  onAction,
  className = '',
  style,
  children,
}) {
  const uid = useId();
  return (
    <MoveSurface
      theme={theme}
      tenant={tenant}
      reducedMotion={reducedMotion}
      onAction={onAction}
      className={'' + ' ' + className}
      style={style}
    >
      {children ?? (
        <>
          <div className="narrow">
            <div className="page-top">
              <div>
                <h1>{'Reportar incidencia'}</h1>
                <p className="sub">
                  {'Informa lo ocurrido al equipo de transporte.'}
                </p>
              </div>
            </div>
            <form id={uid + '-incidentForm'} className="card" data-move-form="">
              <label className="label" htmlFor={uid + '-incidentType'}>
                {'Tipo de incidencia'}
              </label>
              <select name="type" id={uid + '-incidentType'} required>
                <option value="">{'Selecciona un tipo'}</option>
                <option>{'Avería del vehículo'}</option>
                <option>{'Retraso o tráfico'}</option>
                <option>{'Problema con un pasajero'}</option>
                <option>{'Seguridad'}</option>
                <option>{'Otro'}</option>
              </select>
              <label className="label" htmlFor={uid + '-incidentDetail'}>
                {'¿Qué ocurrió?'}
              </label>
              <textarea
                id={uid + '-incidentDetail'}
                name="detail"
                required
                maxLength="1000"
                placeholder="Describe la situación y dónde ocurrió…"
                defaultValue=""
              />
              <div className="photo-field">
                <b>{'Foto opcional'}</b>
                <div id={uid + '-preview-incident'} className="photo-preview">
                  <span>
                    <svg
                      className="icon"
                      viewBox="0 0 24 24"
                      aria-hidden="true"
                      xmlns="http://www.w3.org/2000/svg"
                    >
                      <path
                        d="M5 3h4l2 5-3 2c2 3 3 4 6 6l2-3 5 2v4c-8 5-22-9-16-16"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                      ></path>
                    </svg>
                    {'Sin foto'}
                  </span>
                </div>
                <div className="photo-actions">
                  <label className="btn secondary">
                    {'Tomar foto'}
                    <input
                      type="file"
                      accept="image/*"
                      capture="environment"
                      data-photo="incident"
                      hidden
                    />
                  </label>
                  <label className="btn secondary">
                    {'Galería'}
                    <input
                      type="file"
                      accept="image/*"
                      data-photo="incident"
                      hidden
                    />
                  </label>
                </div>
              </div>
              <div className="notice">
                <svg
                  className="icon"
                  viewBox="0 0 24 24"
                  aria-hidden="true"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    d="M12 11v6m0-10v.01M22 12a10 10 0 1 1-20 0 10 10 0 0 1 20 0"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  ></path>
                </svg>
                <span>
                  {
                    'En caso de emergencia, detente en un lugar seguro y contacta a los servicios de emergencia. Este formulario de demostración no envía alertas reales.'
                  }
                </span>
              </div>
              <button className="btn" type="submit">
                {'Registrar incidencia'}
              </button>
            </form>
            <div className="section-heading">
              <h2>{'Incidencias registradas'}</h2>
            </div>
            <p className="small-info">{'Aún no has reportado incidencias.'}</p>
            <p className="demo-note">
              {'Vista de demostración · Datos de ejemplo'}
            </p>
          </div>
        </>
      )}
    </MoveSurface>
  );
}
