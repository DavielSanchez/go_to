import React, { useId } from 'react';
import { MoveSurface } from '../MoveSurface.jsx';

/** Patrón ops-drawer usado en opsDrawerHTML(). */
export function MoveOpsDrawer({
  theme = 'light',
  tenant = 'tp',
  reducedMotion = false,
  onAction,
  className = '',
  style,
  children,
}) {
  const uid = useId();
  return (
    <MoveSurface
      theme={theme}
      tenant={tenant}
      reducedMotion={reducedMotion}
      onAction={onAction}
      className={'' + ' ' + className}
      style={style}
    >
      {children ?? (
        <>
          <section
            className="ops-drawer"
            role="dialog"
            aria-modal="true"
            aria-labelledby={uid + '-opsDrawerTitle'}
          >
            <div className="ops-drawer-top">
              <h2 id={uid + '-opsDrawerTitle'}>{'TR-1041 · Pantoja'}</h2>
              <button
                className="ops-icon-button"
                aria-label="Cerrar detalle"
                data-move-click="closeOpsDrawer()"
              >
                <svg
                  className="icon"
                  viewBox="0 0 24 24"
                  aria-hidden="true"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    d="M15 5l-7 7 7 7"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  ></path>
                </svg>
              </button>
            </div>
            <span className="ops-pill boarding">{'Abordaje'}</span>
            <p className="ops-muted" style={{ marginTop: '12px' }}>
              {'TP · Churchill · Jornada 3 de octubre de 2026'}
            </p>
            <section className="ops-drawer-section">
              <div className="ops-detail-grid">
                <div>
                  <small>{'Fecha calendario / salida'}</small>
                  <b>{'4 de octubre de 2026 · 00:30'}</b>
                </div>
                <div>
                  <small>{'Conductor actual'}</small>
                  <b>{'Sin conductor'}</b>
                </div>
                <div>
                  <small>{'Vehículo / ruta'}</small>
                  <b>{'Unidad 13 · Ruta 04'}</b>
                </div>
                <div>
                  <small>{'Abordados / previstos'}</small>
                  <b>{'6 / 8'}</b>
                </div>
              </div>
            </section>
            <section className="ops-drawer-section">
              <h3>{'Progreso del viaje · ETA 00:18'}</h3>
              <div
                data-ops-stop="TR-1041"
                data-stop-index="0"
                className="ops-stop done"
              >
                <span>{'1'}</span>
                <b>{'TP · Churchill'}</b>
                <small>{'00:30'}</small>
              </div>
              <div
                data-ops-stop="TR-1041"
                data-stop-index="1"
                className="ops-stop "
              >
                <span>{'2'}</span>
                <b>{'Entrada · Pantoja'}</b>
                <small>{'Parada 1'}</small>
              </div>
              <div
                data-ops-stop="TR-1041"
                data-stop-index="2"
                className="ops-stop "
              >
                <span>{'3'}</span>
                <b>{'Parada intermedia'}</b>
                <small>{'Parada 2'}</small>
              </div>
              <div
                data-ops-stop="TR-1041"
                data-stop-index="3"
                className="ops-stop "
              >
                <span>{'4'}</span>
                <b>{'Destino final'}</b>
                <small>{'00:18'}</small>
              </div>
              <div className="ops-bar">
                <span
                  data-ops-progress="TR-1041"
                  style={{ width: '0%' }}
                ></span>
              </div>
            </section>
            <section className="ops-drawer-section">
              <h3>{'Pasajeros del trip'}</h3>
              <div className="ops-passenger">
                <span>{'Ana Pérez'}</span>
                <span className="ops-pill confirmed">{'Abordado'}</span>
              </div>
              <div className="ops-passenger">
                <span>{'Carlos Mejía'}</span>
                <span className="ops-pill confirmed">{'Abordado'}</span>
              </div>
              <div className="ops-passenger">
                <span>{'Laura Díaz'}</span>
                <span className="ops-pill confirmed">{'Abordado'}</span>
              </div>
              <div className="ops-passenger">
                <span>{'Miguel Santos'}</span>
                <span className="ops-pill confirmed">{'Abordado'}</span>
              </div>
              <div className="ops-passenger">
                <span>{'Sofía Rodríguez'}</span>
                <span className="ops-pill confirmed">{'Abordado'}</span>
              </div>
              <div className="ops-passenger">
                <span>{'Juan Reyes'}</span>
                <span className="ops-pill confirmed">{'Abordado'}</span>
              </div>
              <div className="ops-passenger">
                <span>{'Diana Gómez'}</span>
                <span className="ops-pill draft">{'Pendiente'}</span>
              </div>
              <div className="ops-passenger">
                <span>{'Pedro Núñez'}</span>
                <span className="ops-pill draft">{'Pendiente'}</span>
              </div>
            </section>
            <section className="ops-drawer-section">
              <h3>{'Decisión operativa'}</h3>
              <label className="ops-label" htmlFor={uid + '-tripReason'}>
                {'Motivo de la acción'}
              </label>
              <textarea
                id={uid + '-tripReason'}
                minLength="8"
                maxLength="500"
                placeholder="La acción se aplicará de inmediato y quedará auditada."
                defaultValue=""
              />
              <label className="ops-label" htmlFor={uid + '-tripDriver'}>
                {'Conductor disponible'}
              </label>
              <select id={uid + '-tripDriver'}>
                <option value="">{'Seleccionar conductor…'}</option>
                <option value="Luis Santana">{'Luis Santana'}</option>
                <option value="Carlos Suárez">{'Carlos Suárez'}</option>
                <option value="Patricia Gil">{'Patricia Gil'}</option>
                <option value="Julia Vargas">{'Julia Vargas'}</option>
                <option value="Mario Reyes">{'Mario Reyes'}</option>
                <option value="Sara Santos">{'Sara Santos'}</option>
              </select>
              <div className="ops-drawer-actions">
                <button
                  className="ops-button"
                  data-move-click="performOpsTripAction('TR-1041','assign')"
                >
                  {'Asignar conductor'}
                </button>
              </div>
              <div className="ops-drawer-actions">
                <button
                  className="ops-button secondary"
                  data-move-click="performOpsTripAction('TR-1041','detach')"
                >
                  {'Desvincular conductor'}
                </button>
                <button
                  className="ops-button secondary"
                  data-move-click="performOpsTripAction('TR-1041','absent')"
                >
                  {'Marcar pendientes ausentes'}
                </button>
                <button
                  className="ops-button"
                  data-move-click="performOpsTripAction('TR-1041','start')"
                >
                  {'Iniciar viaje'}
                </button>
              </div>
              <p
                id={uid + '-opsActionError'}
                className="ops-form-error"
                role="alert"
              ></p>
              <p className="ops-muted" style={{ marginTop: '14px' }}>
                {
                  'El abordaje permanece en el trip cuando cambia el conductor. El inicio exige cerrar abordaje y superar salida + gracia.'
                }
              </p>
            </section>
          </section>
        </>
      )}
    </MoveSurface>
  );
}
