import React, { useId } from 'react';
import { MoveSurface } from '../MoveSurface.jsx';

/** Bloque extraído del diseño actual de MOVE. Los eventos se exponen mediante onAction. */
export function MoveDriverProfile({
  theme = 'light',
  tenant = 'tp',
  reducedMotion = false,
  onAction,
  className = '',
  style,
  children,
}) {
  const uid = useId();
  return (
    <MoveSurface
      theme={theme}
      tenant={tenant}
      reducedMotion={reducedMotion}
      onAction={onAction}
      className={'' + ' ' + className}
      style={style}
    >
      {children ?? (
        <>
          <div className="profile-wrap">
            <div className="page-top">
              <div>
                <h1>{'Mi perfil de conductor'}</h1>
              </div>
            </div>
            <div className="card">
              <div className="profile-hero">
                <span className="avatar">{'JR'}</span>
                <h2>{'José Ramírez'}</h2>
                <p className="sub">{'Conductor de proveedor externo'}</p>
              </div>
              <div className="profile-data">
                <div>
                  <small>{'Cédula'}</small>
                  <b>{'00000000000'}</b>
                </div>
                <div>
                  <small>{'Marca'}</small>
                  <b>{'Hyundai'}</b>
                </div>
                <div>
                  <small>{'Modelo'}</small>
                  <b>{'County'}</b>
                </div>
                <div>
                  <small>{'Año'}</small>
                  <b>{'2023'}</b>
                </div>
                <div>
                  <small>{'Placa'}</small>
                  <b>{'I078542'}</b>
                </div>
              </div>
              <div className="notice">
                <svg
                  className="icon"
                  viewBox="0 0 24 24"
                  aria-hidden="true"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    d="M12 3l8 3v6c0 5-8 9-8 9s-8-4-8-9V6zM8 12l3 3 5-6"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  ></path>
                </svg>
                <span>
                  {
                    'Registro completado en esta demostración. Los documentos requieren revisión antes de operar en un servicio real.'
                  }
                </span>
              </div>
              <button
                className="btn outline"
                data-move-click="navigate('driver-vehicle')"
              >
                {'Editar datos del vehículo'}
              </button>
            </div>
            <div className="card setting-row">
              <div>
                <h3>{'Modo oscuro'}</h3>
                <p className="small-info">
                  {'Preferencia en este dispositivo.'}
                </p>
              </div>
              <button
                className="btn secondary compact"
                data-move-click="toggleTheme();render()"
              >
                {'Desactivado'}
              </button>
            </div>
            <button className="btn secondary" data-move-click="logoutMove()">
              {'Cerrar sesión'}
            </button>
            <details className="card" style={{ marginTop: '18px' }}>
              <summary>{'Opciones de demostración'}</summary>
              <button className="cancel" data-move-click="resetDriver()">
                {'Repetir registro del conductor'}
              </button>
            </details>
            <p className="demo-note">
              {'Vista de demostración · Datos de ejemplo'}
            </p>
          </div>
        </>
      )}
    </MoveSurface>
  );
}
