import React, { useId } from 'react';
import { MoveSurface } from '../MoveSurface.jsx';

/** Estado en vivo. */
export function MoveLiveBadge({
  theme = 'light',
  tenant = 'tp',
  reducedMotion = false,
  onAction,
  className = '',
  style,
  children,
}) {
  const uid = useId();
  return (
    <MoveSurface
      theme={theme}
      tenant={tenant}
      reducedMotion={reducedMotion}
      onAction={onAction}
      className={'' + ' ' + className}
      style={style}
    >
      {children ?? (
        <>
          <span className="live">{'En camino'}</span>
        </>
      )}
    </MoveSurface>
  );
}
