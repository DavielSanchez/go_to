import React, { useId } from 'react';
import { MoveSurface } from '../MoveSurface.jsx';

/** Patrón signup-title usado en registrationView(). */
export function MoveSignupTitle({
  theme = 'light',
  tenant = 'tp',
  reducedMotion = false,
  onAction,
  className = '',
  style,
  children,
}) {
  const uid = useId();
  return (
    <MoveSurface
      theme={theme}
      tenant={tenant}
      reducedMotion={reducedMotion}
      onAction={onAction}
      className={'' + ' ' + className}
      style={style}
    >
      {children ?? (
        <>
          <div className="signup-title">
            <span className="pill">{'TU ACCESO A MOVE'}</span>
            <h1>{'Cada viaje empieza aquí.'}</h1>
            <p className="sub">
              {'Acceso corporativo con tu correo personal autorizado.'}
            </p>
          </div>
        </>
      )}
    </MoveSurface>
  );
}
