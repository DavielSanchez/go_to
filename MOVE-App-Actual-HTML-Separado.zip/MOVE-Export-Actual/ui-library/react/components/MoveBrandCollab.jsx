import React, { useId } from 'react';
import { MoveSurface } from '../MoveSurface.jsx';
import asset0 from '../../assets/tp-logo.svg';
/** Patrón brand-collab usado en landing.js · landingView. */
export function MoveBrandCollab({
  theme = 'light',
  tenant = 'tp',
  reducedMotion = false,
  onAction,
  className = '',
  style,
  children,
}) {
  const uid = useId();
  return (
    <MoveSurface
      theme={theme}
      tenant={tenant}
      reducedMotion={reducedMotion}
      onAction={onAction}
      className={'' + ' ' + className}
      style={style}
    >
      {children ?? (
        <>
          <a
            className="brand-collab footer-collab"
            href="#landing"
            aria-label="TP × MOVE"
          >
            <img className="tp-logo" src={asset0} alt="TP" />
            <span className="collab-cross" aria-hidden="true">
              {'×'}
            </span>
            <span className="brand">
              {'MOVE'}
              <span className="brand-dot"></span>
            </span>
          </a>
        </>
      )}
    </MoveSurface>
  );
}
