import React, { useId } from 'react';
import { MoveSurface } from '../MoveSurface.jsx';

/** Patrón hero-detail usado en landing.js · landingView. */
export function MoveHeroDetail({
  theme = 'light',
  tenant = 'tp',
  reducedMotion = false,
  onAction,
  className = '',
  style,
  children,
}) {
  const uid = useId();
  return (
    <MoveSurface
      theme={theme}
      tenant={tenant}
      reducedMotion={reducedMotion}
      onAction={onAction}
      className={'' + ' ' + className}
      style={style}
    >
      {children ?? (
        <>
          <div className="hero-detail">
            <span>
              <svg
                className="icon"
                viewBox="0 0 24 24"
                aria-hidden="true"
                xmlns="http://www.w3.org/2000/svg"
              >
                <path
                  d="M12 3l8 3v6c0 5-8 9-8 9s-8-4-8-9V6zM8 12l3 3 5-6"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                ></path>
              </svg>
              {' Para empresas con transporte de personal'}
            </span>
            <span>
              <svg
                className="icon"
                viewBox="0 0 24 24"
                aria-hidden="true"
                xmlns="http://www.w3.org/2000/svg"
              >
                <path
                  d="M5 3h4l2 5-3 2c2 3 3 4 6 6l2-3 5 2v4c-8 5-22-9-16-16"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                ></path>
              </svg>
              {' Web app · Mobile first'}
            </span>
          </div>
        </>
      )}
    </MoveSurface>
  );
}
