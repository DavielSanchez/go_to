import React, { useId } from 'react';
import { MoveSurface } from '../MoveSurface.jsx';

/** Patrón choice usado en views.exception(). */
export function MoveChoice({
  theme = 'light',
  tenant = 'tp',
  reducedMotion = false,
  onAction,
  className = '',
  style,
  children,
}) {
  const uid = useId();
  return (
    <MoveSurface
      theme={theme}
      tenant={tenant}
      reducedMotion={reducedMotion}
      onAction={onAction}
      className={'' + ' ' + className}
      style={style}
    >
      {children ?? (
        <>
          <label className="choice">
            <input
              type="radio"
              name="reason"
              defaultValue="Horas extra"
              required
            />
            <b>{'Horas extra'}</b>
          </label>
        </>
      )}
    </MoveSurface>
  );
}
