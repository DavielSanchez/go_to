import React, { useId } from 'react';
import { MoveSurface } from '../MoveSurface.jsx';

/** Patrón register-prompt usado en loginView(). */
export function MoveRegisterPrompt({
  theme = 'light',
  tenant = 'tp',
  reducedMotion = false,
  onAction,
  className = '',
  style,
  children,
}) {
  const uid = useId();
  return (
    <MoveSurface
      theme={theme}
      tenant={tenant}
      reducedMotion={reducedMotion}
      onAction={onAction}
      className={'' + ' ' + className}
      style={style}
    >
      {children ?? (
        <>
          <div className="register-prompt">
            <span>{'¿Primera vez en MOVE?'}</span>
            <button
              type="button"
              data-move-click="startRegistration(access.role)"
            >
              {'Crear mi cuenta'}
            </button>
          </div>
        </>
      )}
    </MoveSurface>
  );
}
