import React, { useId } from 'react';
import { MoveSurface } from '../MoveSurface.jsx';

/** Patrón profile-data usado en onboardingView(). */
export function MoveProfileData({
  theme = 'light',
  tenant = 'tp',
  reducedMotion = false,
  onAction,
  className = '',
  style,
  children,
}) {
  const uid = useId();
  return (
    <MoveSurface
      theme={theme}
      tenant={tenant}
      reducedMotion={reducedMotion}
      onAction={onAction}
      className={'' + ' ' + className}
      style={style}
    >
      {children ?? (
        <>
          <div className="profile-data">
            <div>
              <small>{'Nombre'}</small>
              <b>{'José Ramírez'}</b>
            </div>
            <div>
              <small>{'Cédula'}</small>
              <b>{'00000000000'}</b>
            </div>
            <div>
              <small>{'Marca'}</small>
              <b>{'Hyundai'}</b>
            </div>
            <div>
              <small>{'Modelo'}</small>
              <b>{'County'}</b>
            </div>
            <div>
              <small>{'Año'}</small>
              <b>{'2023'}</b>
            </div>
            <div>
              <small>{'Placa'}</small>
              <b>{'I078542'}</b>
            </div>
          </div>
        </>
      )}
    </MoveSurface>
  );
}
