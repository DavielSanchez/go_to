import React, { useId } from 'react';
import { MoveSurface } from '../MoveSurface.jsx';
import asset0 from '../../assets/transport.webp';
import asset1 from '../../assets/tp-logo.svg';
/** Landing actual de MOVE. */
export function MoveLanding({
  theme = 'light',
  tenant = 'tp',
  reducedMotion = false,
  onAction,
  className = '',
  style,
  children,
}) {
  const uid = useId();
  return (
    <MoveSurface
      theme={theme}
      tenant={tenant}
      reducedMotion={reducedMotion}
      onAction={onAction}
      className={'landing-screen' + ' ' + className}
      style={style}
    >
      {children ?? (
        <>
          <div className="marketing">
            <section className="landing-hero">
              <div className="hero-copy">
                <div className="lp-kicker">
                  <span></span>
                  {'TRANSPORTE EMPRESARIAL, CONECTADO'}
                </div>
                <h1>
                  {'El buen trabajo'}
                  <br />
                  {'merece un '}
                  <em>{'buen regreso.'}</em>
                </h1>
                <p>
                  {
                    'De la salida del turno a la última parada. MOVE conecta a tu gente, tus conductores y tu operación en una sola experiencia.'
                  }
                </p>
                <div className="lp-actions">
                  <button
                    className="lp-button pink"
                    data-move-click="enterMove()"
                  >
                    {'Explorar la solución '}
                    <svg
                      className="icon"
                      viewBox="0 0 24 24"
                      aria-hidden="true"
                      xmlns="http://www.w3.org/2000/svg"
                    >
                      <path
                        d="M5 16V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2v11M5 11h14M8 3v8m8-8v8M5 16h14v3H5zM7 19v3m10-3v3M8 14h.01M16 14h.01"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                      ></path>
                    </svg>
                  </button>
                  <button
                    className="lp-button ghost"
                    data-move-click="scrollLanding('product')"
                  >
                    {'Conoce cómo funciona'}
                  </button>
                </div>
                <div className="hero-detail">
                  <span>
                    <svg
                      className="icon"
                      viewBox="0 0 24 24"
                      aria-hidden="true"
                      xmlns="http://www.w3.org/2000/svg"
                    >
                      <path
                        d="M12 3l8 3v6c0 5-8 9-8 9s-8-4-8-9V6zM8 12l3 3 5-6"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                      ></path>
                    </svg>
                    {' Para empresas con transporte de personal'}
                  </span>
                  <span>
                    <svg
                      className="icon"
                      viewBox="0 0 24 24"
                      aria-hidden="true"
                      xmlns="http://www.w3.org/2000/svg"
                    >
                      <path
                        d="M5 3h4l2 5-3 2c2 3 3 4 6 6l2-3 5 2v4c-8 5-22-9-16-16"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                      ></path>
                    </svg>
                    {' Web app · Mobile first'}
                  </span>
                </div>
              </div>
              <div className="hero-visual">
                <img
                  src={asset0}
                  alt="Colaboradores abordando un transporte empresarial al salir de una oficina"
                  width="1536"
                  height="1024"
                />
                <div className="visual-shade"></div>
                <div className="floating-route">
                  <span className="float-icon">
                    <svg
                      className="icon"
                      viewBox="0 0 24 24"
                      aria-hidden="true"
                      xmlns="http://www.w3.org/2000/svg"
                    >
                      <path
                        d="M5 16V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2v11M5 11h14M8 3v8m8-8v8M5 16h14v3H5zM7 19v3m10-3v3M8 14h.01M16 14h.01"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                      ></path>
                    </svg>
                  </span>
                  <div>
                    <small>{'TU TRANSPORTE ESTÁ LISTO'}</small>
                    <b>{'Tu turno termina. Tu regreso empieza.'}</b>
                    <span>{'Ruta 04 · 22:15 · Asiento confirmado'}</span>
                  </div>
                  <span className="float-check">
                    <svg
                      className="icon"
                      viewBox="0 0 24 24"
                      aria-hidden="true"
                      xmlns="http://www.w3.org/2000/svg"
                    >
                      <path
                        d="M5 12l4 4L19 6"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                      ></path>
                    </svg>
                  </span>
                </div>
                <div className="visual-caption">
                  <span className="lp-kicker">{'MENOS INCERTIDUMBRE'}</span>
                  <p>
                    {'Más tranquilidad.'}
                    <br />
                    {'Dentro y fuera del trabajo.'}
                  </p>
                </div>
              </div>
            </section>
            <div className="audience-strip">
              <span>{'HECHO PARA OPERACIONES QUE NO SE DETIENEN'}</span>
              <div>{'Contact centers'}</div>
              <div>{'Manufactura'}</div>
              <div>{'Logística'}</div>
              <div>{'Servicios'}</div>
            </div>
            <section className="lp-section" id={uid + '-benefits'}>
              <div className="section-intro">
                <div>
                  <span className="lp-kicker">
                    {'01 / UNA MEJOR FORMA DE MOVERSE'}
                  </span>
                  <h2>
                    {'Tu transporte puede'}
                    <br />
                    {'trabajar mejor.'}
                  </h2>
                </div>
                <p>
                  {
                    'Las listas dispersas, los asientos vacíos y las llamadas de última hora no deberían definir el final de una jornada.'
                  }
                </p>
              </div>
              <div className="benefit-grid">
                <article>
                  <span className="benefit-number">{'01'}</span>
                  <span className="benefit-icon">
                    <svg
                      className="icon"
                      viewBox="0 0 24 24"
                      aria-hidden="true"
                      xmlns="http://www.w3.org/2000/svg"
                    >
                      <path
                        d="M20 21v-2a6 6 0 0 0-6-6h-4a6 6 0 0 0-6 6v2M16 6a4 4 0 1 1-8 0 4 4 0 0 1 8 0"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                      ></path>
                    </svg>
                  </span>
                  <h3>{'Tu gente sabe qué esperar.'}</h3>
                  <p>
                    {
                      'Confirmación diaria, ticket de abordaje y seguimiento del viaje. Una experiencia clara desde el celular.'
                    }
                  </p>
                  <span className="feature-label">
                    {'EXPERIENCIA DEL COLABORADOR'}
                  </span>
                </article>
                <article>
                  <span className="benefit-number">{'02'}</span>
                  <span className="benefit-icon">
                    <svg
                      className="icon"
                      viewBox="0 0 24 24"
                      aria-hidden="true"
                      xmlns="http://www.w3.org/2000/svg"
                    >
                      <path
                        d="M5 16V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2v11M5 11h14M8 3v8m8-8v8M5 16h14v3H5zM7 19v3m10-3v3M8 14h.01M16 14h.01"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                      ></path>
                    </svg>
                  </span>
                  <h3>{'Cada vehículo, con su grupo.'}</h3>
                  <p>
                    {
                      'Distribuye pasajeros entre unidades de la misma zona y permite el abordaje simultáneo, sin una cola de conductores.'
                    }
                  </p>
                  <span className="feature-label">
                    {'COORDINACIÓN OPERATIVA'}
                  </span>
                </article>
                <article>
                  <span className="benefit-number">{'03'}</span>
                  <span className="benefit-icon">
                    <svg
                      className="icon"
                      viewBox="0 0 24 24"
                      aria-hidden="true"
                      xmlns="http://www.w3.org/2000/svg"
                    >
                      <path
                        d="M12 8v5l3 2M22 12a10 10 0 1 1-20 0 10 10 0 0 1 20 0"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                      ></path>
                    </svg>
                  </span>
                  <h3>{'Decisiones con contexto.'}</h3>
                  <p>
                    {
                      'Visualiza confirmaciones, ocupación e incidencias. Identifica oportunidades para usar mejor tu servicio de transporte.'
                    }
                  </p>
                  <span className="feature-label">
                    {'VISIBILIDAD DEL SERVICIO'}
                  </span>
                </article>
              </div>
            </section>
            <section className="lp-product" id={uid + '-product'}>
              <div className="lp-section">
                <div className="section-intro">
                  <div>
                    <span className="lp-kicker">
                      {'02 / UN SERVICIO. TODOS CONECTADOS.'}
                    </span>
                    <h2>
                      {'Una experiencia para cada'}
                      <br />
                      {'parte del recorrido.'}
                    </h2>
                  </div>
                  <p>
                    {
                      'Explora cómo MOVE acompaña a quienes viajan y a quienes los llevan a casa.'
                    }
                  </p>
                </div>
                <div className="product-layout">
                  <div className="product-story">
                    <div
                      className="lp-tabs"
                      role="tablist"
                      aria-label="Experiencias MOVE"
                    >
                      <button
                        id={uid + '-employeeTab'}
                        role="tab"
                        aria-selected="true"
                        className="active"
                        data-move-click="selectLandingRole('employee')"
                      >
                        {'Colaborador'}
                      </button>
                      <button
                        id={uid + '-driverTab'}
                        role="tab"
                        aria-selected="false"
                        className=""
                        data-move-click="selectLandingRole('driver')"
                      >
                        {'Conductor'}
                      </button>
                    </div>
                    <div id={uid + '-roleStory'}>
                      <span className="lp-kicker">
                        {'MENOS DUDAS AL FINAL DEL TURNO'}
                      </span>
                      <h3>{'Tu regreso, en tus manos.'}</h3>
                      <p>
                        {
                          'Confirma tu transporte en segundos y consulta la información que necesitas para abordar.'
                        }
                      </p>
                      <ul>
                        <li>
                          <svg
                            className="icon"
                            viewBox="0 0 24 24"
                            aria-hidden="true"
                            xmlns="http://www.w3.org/2000/svg"
                          >
                            <path
                              d="M5 12l4 4L19 6"
                              strokeLinecap="round"
                              strokeLinejoin="round"
                            ></path>
                          </svg>
                          {'Confirmación diaria y ticket QR'}
                        </li>
                        <li>
                          <svg
                            className="icon"
                            viewBox="0 0 24 24"
                            aria-hidden="true"
                            xmlns="http://www.w3.org/2000/svg"
                          >
                            <path
                              d="M5 12l4 4L19 6"
                              strokeLinecap="round"
                              strokeLinejoin="round"
                            ></path>
                          </svg>
                          {'Excepciones cuando cambia la jornada'}
                        </li>
                        <li>
                          <svg
                            className="icon"
                            viewBox="0 0 24 24"
                            aria-hidden="true"
                            xmlns="http://www.w3.org/2000/svg"
                          >
                            <path
                              d="M5 12l4 4L19 6"
                              strokeLinecap="round"
                              strokeLinejoin="round"
                            ></path>
                          </svg>
                          {'Seguimiento del viaje y reseña final'}
                        </li>
                      </ul>
                    </div>
                    <button
                      className="lp-button dark"
                      data-move-click="enterMove()"
                    >
                      {'Probar la demo completa '}
                      <svg
                        className="icon"
                        viewBox="0 0 24 24"
                        aria-hidden="true"
                        xmlns="http://www.w3.org/2000/svg"
                      >
                        <path
                          d="M5 3h4l2 5-3 2c2 3 3 4 6 6l2-3 5 2v4c-8 5-22-9-16-16"
                          strokeLinecap="round"
                          strokeLinejoin="round"
                        ></path>
                      </svg>
                    </button>
                    <p className="product-footnote">
                      {'Prototipo navegable con datos de demostración.'}
                    </p>
                  </div>
                  <div className="phone-stage">
                    <div className="orbit-label">
                      {'MOVE / UNA JORNADA MÁS SIMPLE'}
                    </div>
                    <div className="product-phone">
                      <div className="phone-camera"></div>
                      <div className="phone-top">
                        <span className="brand">
                          {'MOVE'}
                          <span className="brand-dot"></span>
                        </span>
                        <span className="phone-avatar">{'DS'}</span>
                      </div>
                      <div id={uid + '-phonePreview'}>
                        <div className="phone-content">
                          <small>{'VIERNES, 2 DE OCTUBRE'}</small>
                          <h3>
                            {'Hola, Daviel'}
                            <span>{'.'}</span>
                          </h3>
                          <p>{'Tu regreso a casa, organizado.'}</p>
                          <div className="phone-hero">
                            <span>{'✓ RESERVA CONFIRMADA'}</span>
                            <h4>
                              {'Todo listo para'}
                              <br />
                              {'tu regreso.'}
                            </h4>
                            <div>
                              <small>{'Salida del transporte'}</small>
                              <b>{'10:15 p. m.'}</b>
                            </div>
                            <button data-move-click="enterMove()">
                              {'Ver mi viaje'}
                            </button>
                          </div>
                          <h4>{'Tu ruta asignada'}</h4>
                          <div className="phone-route">
                            <b>{'TP · Campus Churchill'}</b>
                            <span>{'↓'}</span>
                            <b>{'Los Alcarrizos'}</b>
                            <small>{'Unidad 12 · Ruta 04'}</small>
                          </div>
                        </div>
                      </div>
                      <div className="phone-nav">
                        <svg
                          className="icon"
                          viewBox="0 0 24 24"
                          aria-hidden="true"
                          xmlns="http://www.w3.org/2000/svg"
                        >
                          <path
                            d="M3 10l9-7 9 7v10a1 1 0 0 1-1 1h-5v-7H9v7H4a1 1 0 0 1-1-1z"
                            strokeLinecap="round"
                            strokeLinejoin="round"
                          ></path>
                        </svg>
                        <svg
                          className="icon"
                          viewBox="0 0 24 24"
                          aria-hidden="true"
                          xmlns="http://www.w3.org/2000/svg"
                        >
                          <path
                            d="M5 16V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2v11M5 11h14M8 3v8m8-8v8M5 16h14v3H5zM7 19v3m10-3v3M8 14h.01M16 14h.01"
                            strokeLinecap="round"
                            strokeLinejoin="round"
                          ></path>
                        </svg>
                        <svg
                          className="icon"
                          viewBox="0 0 24 24"
                          aria-hidden="true"
                          xmlns="http://www.w3.org/2000/svg"
                        >
                          <path
                            d="M3 7h18v4a2 2 0 0 0 0 4v4H3v-4a2 2 0 0 0 0-4zM15 7v2m0 3v2m0 3v2"
                            strokeLinecap="round"
                            strokeLinejoin="round"
                          ></path>
                        </svg>
                        <svg
                          className="icon"
                          viewBox="0 0 24 24"
                          aria-hidden="true"
                          xmlns="http://www.w3.org/2000/svg"
                        >
                          <path
                            d="M20 21v-2a6 6 0 0 0-6-6h-4a6 6 0 0 0-6 6v2M16 6a4 4 0 1 1-8 0 4 4 0 0 1 8 0"
                            strokeLinecap="round"
                            strokeLinejoin="round"
                          ></path>
                        </svg>
                      </div>
                    </div>
                    <div className="product-floating">
                      <span>
                        <svg
                          className="icon"
                          viewBox="0 0 24 24"
                          aria-hidden="true"
                          xmlns="http://www.w3.org/2000/svg"
                        >
                          <path
                            d="M5 12l4 4L19 6"
                            strokeLinecap="round"
                            strokeLinejoin="round"
                          ></path>
                        </svg>
                      </span>
                      <div>
                        <b>{'Confirmación recibida'}</b>
                        <small>{'Un asiento. Una preocupación menos.'}</small>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </section>
            <section className="lp-section flow-section">
              <div className="section-intro">
                <div>
                  <span className="lp-kicker">{'03 / DE PUNTA A PUNTA'}</span>
                  <h2>
                    {'Un regreso organizado.'}
                    <br />
                    {'En cuatro momentos.'}
                  </h2>
                </div>
                <button
                  className="lp-button ghost light"
                  data-move-click="enterMove()"
                >
                  {'Ver el flujo en la app'}
                </button>
              </div>
              <div className="flow-grid">
                <article>
                  <span>{'01'}</span>
                  <svg
                    className="icon"
                    viewBox="0 0 24 24"
                    aria-hidden="true"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path
                      d="M20 21v-2a6 6 0 0 0-6-6h-4a6 6 0 0 0-6 6v2M16 6a4 4 0 1 1-8 0 4 4 0 0 1 8 0"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    ></path>
                  </svg>
                  <h3>{'Confirmar'}</h3>
                  <p>
                    {
                      'El empleado indica si usará el transporte y recibe su ticket.'
                    }
                  </p>
                </article>
                <article>
                  <span>{'02'}</span>
                  <svg
                    className="icon"
                    viewBox="0 0 24 24"
                    aria-hidden="true"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path
                      d="M20 10c0 6-8 12-8 12S4 16 4 10a8 8 0 1 1 16 0M15 10a3 3 0 1 1-6 0 3 3 0 0 1 6 0"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    ></path>
                  </svg>
                  <h3>{'Coordinar'}</h3>
                  <p>
                    {
                      'Los conductores registran su zona y reciben un grupo de pasajeros.'
                    }
                  </p>
                </article>
                <article>
                  <span>{'03'}</span>
                  <svg
                    className="icon"
                    viewBox="0 0 24 24"
                    aria-hidden="true"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path
                      d="M5 16V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2v11M5 11h14M8 3v8m8-8v8M5 16h14v3H5zM7 19v3m10-3v3M8 14h.01M16 14h.01"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    ></path>
                  </svg>
                  <h3>{'Abordar y viajar'}</h3>
                  <p>
                    {
                      'Se validan los tickets y se inicia el recorrido con sus paradas.'
                    }
                  </p>
                </article>
                <article>
                  <span>{'04'}</span>
                  <svg
                    className="icon"
                    viewBox="0 0 24 24"
                    aria-hidden="true"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path
                      d="M12 3l3 6 7 1-5 5 1 7-6-3-6 3 1-7-5-5 7-1z"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    ></path>
                  </svg>
                  <h3>{'Escuchar y mejorar'}</h3>
                  <p>
                    {
                      'Reseñas, historial e incidencias completan la experiencia.'
                    }
                  </p>
                </article>
              </div>
            </section>
            <section className="data-section" id={uid + '-impact'}>
              <div className="lp-section">
                <div className="section-intro">
                  <div>
                    <span className="lp-kicker">
                      {'04 / LA OPERACIÓN, A SIMPLE VISTA'}
                    </span>
                    <h2>
                      {'Lo que puedes ver'}
                      <br />
                      {'también puedes mejorar.'}
                    </h2>
                  </div>
                  <p>
                    {
                      'Así podría verse un resumen del servicio en una operación empresarial. Las cifras siguientes son ilustrativas.'
                    }
                  </p>
                </div>
                <div className="demo-badge">
                  <svg
                    className="icon"
                    viewBox="0 0 24 24"
                    aria-hidden="true"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path
                      d="M12 11v6m0-10v.01M22 12a10 10 0 1 1-20 0 10 10 0 0 1 20 0"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    ></path>
                  </svg>
                  {
                    ' Escenario de demostración · No representa resultados de clientes'
                  }
                </div>
                <div className="metrics-grid">
                  <div>
                    <strong>{'1,200'}</strong>
                    <span>{'colaboradores en el escenario'}</span>
                  </div>
                  <div>
                    <strong>{'42'}</strong>
                    <span>{'vehículos coordinados'}</span>
                  </div>
                  <div>
                    <strong>
                      {'91'}
                      <span>{'%'}</span>
                    </strong>
                    <span>{'ocupación ilustrativa'}</span>
                  </div>
                  <div>
                    <strong>
                      {'18'}
                      <span>{'%'}</span>
                    </strong>
                    <span>{'reducción de costo hipotética'}</span>
                  </div>
                </div>
                <div className="data-bottom">
                  <div>
                    <h3>
                      {'Del “¿quién va hoy?”'}
                      <br />
                      {'a una operación visible.'}
                    </h3>
                    <p>
                      {
                        'Confirmaciones, asignaciones y abordajes permiten construir una vista compartida del servicio para tu equipo.'
                      }
                    </p>
                  </div>
                  <div className="mini-dashboard">
                    <div className="dashboard-title">
                      <b>{'Ocupación por salida'}</b>
                      <span>{'Datos mock'}</span>
                    </div>
                    <div className="bar-row">
                      <span>{'21:00'}</span>
                      <div>
                        <i style={{ width: '72%' }}></i>
                      </div>
                      <b>{'72%'}</b>
                    </div>
                    <div className="bar-row">
                      <span>{'22:00'}</span>
                      <div>
                        <i style={{ width: '91%' }}></i>
                      </div>
                      <b>{'91%'}</b>
                    </div>
                    <div className="bar-row">
                      <span>{'23:00'}</span>
                      <div>
                        <i style={{ width: '84%' }}></i>
                      </div>
                      <b>{'84%'}</b>
                    </div>
                    <div className="chart-foot">
                      {'Tres salidas · Ejemplo visual de seguimiento'}
                    </div>
                  </div>
                </div>
              </div>
            </section>
            <section
              className="lp-section calculator-section"
              id={uid + '-calculator'}
            >
              <div className="calc-copy">
                <span className="lp-kicker">
                  {'05 / ENCUENTRA TU PUNTO DE PARTIDA'}
                </span>
                <h2>
                  {'¿Cuánto cuestan'}
                  <br />
                  {'los asientos vacíos?'}
                </h2>
                <p>
                  {
                    'Haz una estimación con los datos de tu operación. El resultado pone en perspectiva el costo del espacio contratado que no se utiliza.'
                  }
                </p>
                <p className="calc-disclaimer">
                  {
                    'Estimación orientativa: supone un costo uniforme por asiento y todas las salidas con la misma capacidad. No es una promesa de ahorro.'
                  }
                </p>
              </div>
              <div className="calculator-card">
                <div className="calc-fields">
                  <label>
                    {'Vehículos por día'}
                    <input
                      id={uid + '-calcVehicles'}
                      type="number"
                      defaultValue="12"
                      min="1"
                      max="10000"
                      data-move-input="calculateSeats()"
                    />
                  </label>
                  <label>
                    {'Asientos por vehículo'}
                    <input
                      id={uid + '-calcSeats'}
                      type="number"
                      defaultValue="20"
                      min="1"
                      max="100"
                      data-move-input="calculateSeats()"
                    />
                  </label>
                  <label>
                    {'Costo por vehículo / día'}
                    <input
                      id={uid + '-calcCost'}
                      type="number"
                      defaultValue="3500"
                      min="0"
                      max="1000000"
                      data-move-input="calculateSeats()"
                    />
                  </label>
                  <label>
                    {'Días de servicio al mes'}
                    <input
                      id={uid + '-calcDays'}
                      type="number"
                      defaultValue="22"
                      min="1"
                      max="31"
                      data-move-input="calculateSeats()"
                    />
                  </label>
                </div>
                <div className="range-label">
                  <label htmlFor={uid + '-calcOccupancy'}>
                    {'Ocupación promedio'}
                  </label>
                  <b id={uid + '-occupancyValue'}>{'70%'}</b>
                </div>
                <input
                  id={uid + '-calcOccupancy'}
                  type="range"
                  min="0"
                  max="100"
                  defaultValue="70"
                  data-move-input="calculateSeats()"
                />
                <div className="calc-result" aria-live="polite">
                  <span>{'Costo mensual asociado a asientos vacíos'}</span>
                  <strong id={uid + '-emptyCost'}>{'RD$277,200'}</strong>
                  <small id={uid + '-emptySeats'}>
                    {'72 asientos vacíos por día · Estimación en RD$'}
                  </small>
                </div>
              </div>
            </section>
            <section
              className="lp-section capability-section"
              id={uid + '-service'}
            >
              <div className="section-intro">
                <div>
                  <span className="lp-kicker">
                    {'06 / EL SERVICIO, CON MÁS CONTROL'}
                  </span>
                  <h2>
                    {'Los detalles importan.'}
                    <br />
                    {'MOVE los conecta.'}
                  </h2>
                </div>
              </div>
              <div className="capability-grid">
                <article>
                  <svg
                    className="icon"
                    viewBox="0 0 24 24"
                    aria-hidden="true"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path
                      d="M3 7h18v4a2 2 0 0 0 0 4v4H3v-4a2 2 0 0 0 0-4zM15 7v2m0 3v2m0 3v2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    ></path>
                  </svg>
                  <h3>{'Excepciones sin perder el contexto'}</h3>
                  <p>
                    {
                      'Solicitudes por horas extra, capacitaciones y cambios de turno, con estado de aprobación.'
                    }
                  </p>
                </article>
                <article>
                  <svg
                    className="icon"
                    viewBox="0 0 24 24"
                    aria-hidden="true"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path
                      d="M20 10c0 6-8 12-8 12S4 16 4 10a8 8 0 1 1 16 0M15 10a3 3 0 1 1-6 0 3 3 0 0 1 6 0"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    ></path>
                  </svg>
                  <h3>{'Destinos y zonas organizados'}</h3>
                  <p>
                    {
                      'Ubicación de destino, paradas y asignación de vehículos para cada recorrido.'
                    }
                  </p>
                </article>
                <article>
                  <svg
                    className="icon"
                    viewBox="0 0 24 24"
                    aria-hidden="true"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path
                      d="M12 3l8 3v6c0 5-8 9-8 9s-8-4-8-9V6zM8 12l3 3 5-6"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    ></path>
                  </svg>
                  <h3>{'Validación antes de abordar'}</h3>
                  <p>
                    {
                      'Tickets por fecha, horario y unidad. Cada conductor valida a sus pasajeros asignados.'
                    }
                  </p>
                </article>
                <article>
                  <svg
                    className="icon"
                    viewBox="0 0 24 24"
                    aria-hidden="true"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path
                      d="M5 3h4l2 5-3 2c2 3 3 4 6 6l2-3 5 2v4c-8 5-22-9-16-16"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    ></path>
                  </svg>
                  <h3>{'Pensado para el celular'}</h3>
                  <p>
                    {
                      'Una PWA para empleados y conductores, con una interfaz que se adapta a su jornada.'
                    }
                  </p>
                </article>
                <article>
                  <svg
                    className="icon"
                    viewBox="0 0 24 24"
                    aria-hidden="true"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path
                      d="M21 11a9 9 0 0 1-9 9H4l-3 2 2-6a9 9 0 1 1 18-5M7 11h10"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    ></path>
                  </svg>
                  <h3>{'Incidencias documentadas'}</h3>
                  <p>
                    {
                      'Un lugar para registrar retrasos, averías u otros problemas durante el servicio.'
                    }
                  </p>
                </article>
                <article>
                  <svg
                    className="icon"
                    viewBox="0 0 24 24"
                    aria-hidden="true"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path
                      d="M12 3l3 6 7 1-5 5 1 7-6-3-6 3 1-7-5-5 7-1z"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    ></path>
                  </svg>
                  <h3>{'La voz de quienes viajan'}</h3>
                  <p>
                    {
                      'Calificaciones y comentarios al terminar el recorrido para conocer la experiencia.'
                    }
                  </p>
                </article>
              </div>
            </section>
            <section className="lp-section faq-section">
              <div>
                <span className="lp-kicker">{'PREGUNTAS FRECUENTES'}</span>
                <h2>
                  {'Antes de subir'}
                  <br />
                  {'a bordo.'}
                </h2>
              </div>
              <div className="faq-list">
                <details>
                  <summary>
                    {'¿MOVE es una empresa de transporte?'}
                    <span>{'+'}</span>
                  </summary>
                  <p>
                    {
                      'MOVE es la solución digital que organiza el servicio. Tu empresa y sus proveedores conservan la operación de los vehículos y conductores.'
                    }
                  </p>
                </details>
                <details>
                  <summary>
                    {'¿Puede usarse en otras empresas además de TP?'}
                    <span>{'+'}</span>
                  </summary>
                  <p>
                    {
                      'Sí. La propuesta está pensada para empresas que ofrecen transporte de personal. El prototipo usa un contexto de TP para mostrar los recorridos y experiencias.'
                    }
                  </p>
                </details>
                <details>
                  <summary>
                    {'¿Qué puedo probar ahora?'}
                    <span>{'+'}</span>
                  </summary>
                  <p>
                    {
                      'Puedes explorar el login simulado, confirmar transporte, solicitar excepciones y recorrer el flujo del conductor: registro, zona, abordaje, viaje y perfil.'
                    }
                  </p>
                </details>
                <details>
                  <summary>
                    {'¿Los datos y resultados son reales?'}
                    <span>{'+'}</span>
                  </summary>
                  <p>
                    {
                      'No. Esta presentación y el prototipo utilizan datos mock. Las métricas son ilustrativas y no corresponden a resultados comprobados de un cliente.'
                    }
                  </p>
                </details>
                <details>
                  <summary>
                    {'¿Ya incluye autenticación e integraciones empresariales?'}
                    <span>{'+'}</span>
                  </summary>
                  <p>
                    {
                      'El prototipo muestra la experiencia del producto. La autenticación real, las integraciones y la operación sincronizada entre dispositivos se definirán para la implementación.'
                    }
                  </p>
                </details>
              </div>
            </section>
            <section className="final-cta">
              <span className="lp-kicker">
                {'LA PRÓXIMA PARADA ES UNA MEJOR OPERACIÓN'}
              </span>
              <h2>
                {'Tu gente se mueve.'}
                <br />
                <em>{'Tu empresa también.'}</em>
              </h2>
              <p>
                {'Descubre una forma más clara de coordinar'}
                <br />
                {'el transporte que acompaña a tu equipo.'}
              </p>
              <button className="lp-button white" data-move-click="enterMove()">
                {'Entrar a MOVE '}
                <svg
                  className="icon"
                  viewBox="0 0 24 24"
                  aria-hidden="true"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    d="M5 16V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2v11M5 11h14M8 3v8m8-8v8M5 16h14v3H5zM7 19v3m10-3v3M8 14h.01M16 14h.01"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  ></path>
                </svg>
              </button>
            </section>
            <footer className="landing-footer">
              <a
                className="brand-collab footer-collab"
                href="#landing"
                aria-label="TP × MOVE"
              >
                <img className="tp-logo" src={asset1} alt="TP" />
                <span className="collab-cross" aria-hidden="true">
                  {'×'}
                </span>
                <span className="brand">
                  {'MOVE'}
                  <span className="brand-dot"></span>
                </span>
              </a>
              <div className="footer-about">
                <p>{'Una app de TP.'}</p>
                <small>{'Transporte empresarial, conectado.'}</small>
              </div>
              <span>{'© 2026 MOVE · Demostración del producto'}</span>
              <button data-move-click="scrollLanding('benefits')">
                {'Volver a explorar'}
              </button>
            </footer>
          </div>
        </>
      )}
    </MoveSurface>
  );
}
