import React, { useId } from 'react';
import { MoveSurface } from '../MoveSurface.jsx';

/** Bloque extraído del diseño actual de MOVE. Los eventos se exponen mediante onAction. */
export function MoveDriverVehicle({
  theme = 'light',
  tenant = 'tp',
  reducedMotion = false,
  onAction,
  className = '',
  style,
  children,
}) {
  const uid = useId();
  return (
    <MoveSurface
      theme={theme}
      tenant={tenant}
      reducedMotion={reducedMotion}
      onAction={onAction}
      className={'' + ' ' + className}
      style={style}
    >
      {children ?? (
        <>
          <div className="narrow">
            <button className="back" data-move-click="cancelVehicleEdit()">
              <svg
                className="icon"
                viewBox="0 0 24 24"
                aria-hidden="true"
                xmlns="http://www.w3.org/2000/svg"
              >
                <path
                  d="M15 5l-7 7 7 7"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                ></path>
              </svg>
              {'Mi perfil'}
            </button>
            <div className="page-top">
              <div>
                <h1>{'Editar vehículo'}</h1>
                <p className="sub">
                  {'Actualiza la información de tu vehículo.'}
                </p>
              </div>
            </div>
            <form
              id={uid + '-vehicleEditForm'}
              className="card"
              data-move-form=""
            >
              <label className="label" htmlFor={uid + '-vehicle-brand'}>
                {'Marca'}
              </label>
              <input
                id={uid + '-vehicle-brand'}
                name="brand"
                type="text"
                defaultValue="Hyundai"
                required
              />
              <label className="label" htmlFor={uid + '-vehicle-model'}>
                {'Modelo'}
              </label>
              <input
                id={uid + '-vehicle-model'}
                name="model"
                type="text"
                defaultValue="County"
                required
              />
              <label className="label" htmlFor={uid + '-vehicle-year'}>
                {'Año'}
              </label>
              <input
                id={uid + '-vehicle-year'}
                name="year"
                type="number"
                defaultValue="2023"
                required
                min="1980"
                max="2027"
              />
              <label className="label" htmlFor={uid + '-vehicle-plate'}>
                {'Placa'}
              </label>
              <input
                id={uid + '-vehicle-plate'}
                name="plate"
                type="text"
                defaultValue="I078542"
                required
                maxLength="12"
              />
              <div className="photo-field">
                <b>{'Foto de la placa'}</b>
                <div
                  id={uid + '-vehiclePhotoPreview'}
                  className="photo-preview"
                >
                  <span>{'Sin foto'}</span>
                </div>
                <div className="photo-actions">
                  <label className="btn secondary">
                    {'Tomar foto'}
                    <input
                      type="file"
                      accept="image/*"
                      capture="environment"
                      data-vehicle-photo=""
                      hidden
                    />
                  </label>
                  <label className="btn secondary">
                    {'Galería'}
                    <input
                      type="file"
                      accept="image/*"
                      data-vehicle-photo=""
                      hidden
                    />
                  </label>
                </div>
              </div>
              <p className="small-info">
                {
                  'La unidad asignada a tu viaje conserva su identificación. Estas modificaciones actualizan tu ficha del vehículo.'
                }
              </p>
              <p
                id={uid + '-vehicleEditError'}
                className="form-error"
                role="alert"
              ></p>
              <div className="form-actions">
                <button
                  className="btn secondary"
                  type="button"
                  data-move-click="cancelVehicleEdit()"
                >
                  {'Cancelar'}
                </button>
                <button className="btn" type="submit">
                  {'Guardar cambios'}
                </button>
              </div>
            </form>
            <p className="demo-note">
              {'Vista de demostración · Datos de ejemplo'}
            </p>
          </div>
        </>
      )}
    </MoveSurface>
  );
}
