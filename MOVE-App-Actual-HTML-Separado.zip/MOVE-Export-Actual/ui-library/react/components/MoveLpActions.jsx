import React, { useId } from 'react';
import { MoveSurface } from '../MoveSurface.jsx';

/** Patrón lp-actions usado en landing.js · landingView. */
export function MoveLpActions({
  theme = 'light',
  tenant = 'tp',
  reducedMotion = false,
  onAction,
  className = '',
  style,
  children,
}) {
  const uid = useId();
  return (
    <MoveSurface
      theme={theme}
      tenant={tenant}
      reducedMotion={reducedMotion}
      onAction={onAction}
      className={'' + ' ' + className}
      style={style}
    >
      {children ?? (
        <>
          <div className="lp-actions">
            <button className="lp-button pink" data-move-click="enterMove()">
              {'Explorar la solución '}
              <svg
                className="icon"
                viewBox="0 0 24 24"
                aria-hidden="true"
                xmlns="http://www.w3.org/2000/svg"
              >
                <path
                  d="M5 16V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2v11M5 11h14M8 3v8m8-8v8M5 16h14v3H5zM7 19v3m10-3v3M8 14h.01M16 14h.01"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                ></path>
              </svg>
            </button>
            <button
              className="lp-button ghost"
              data-move-click="scrollLanding('product')"
            >
              {'Conoce cómo funciona'}
            </button>
          </div>
        </>
      )}
    </MoveSurface>
  );
}
