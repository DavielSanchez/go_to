import React, { useId } from 'react';
import { MoveSurface } from '../MoveSurface.jsx';
import asset0 from '../../assets/tp-logo.svg';
import asset1 from '../../assets/alorica-logo.png';
import asset2 from '../../assets/trueshore-logo.svg';
import asset3 from '../../assets/concentrix-logo.webp';
/** Bloque extraído del diseño actual de MOVE. Los eventos se exponen mediante onAction. */
export function MovePlatformAdministration({
  theme = 'light',
  tenant = 'tp',
  reducedMotion = false,
  onAction,
  className = '',
  style,
  children,
}) {
  const uid = useId();
  return (
    <MoveSurface
      theme={theme}
      tenant={tenant}
      reducedMotion={reducedMotion}
      onAction={onAction}
      className={'' + ' ' + className}
      style={style}
    >
      {children ?? (
        <>
          <div className="ops-metrics">
            <article className="ops-metric">
              <small>{'Empresas'}</small>
              <strong>{'4'}</strong>
              <p>{'Clientes de demostración'}</p>
              <span>
                <svg
                  className="icon"
                  viewBox="0 0 24 24"
                  aria-hidden="true"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    d="M3 10l9-7 9 7v10a1 1 0 0 1-1 1h-5v-7H9v7H4a1 1 0 0 1-1-1z"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  ></path>
                </svg>
              </span>
            </article>
            <article className="ops-metric">
              <small>{'Tenants'}</small>
              <strong>{'7'}</strong>
              <p>{'Aislados por site'}</p>
              <span>
                <svg
                  className="icon"
                  viewBox="0 0 24 24"
                  aria-hidden="true"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    d="M20 10c0 6-8 12-8 12S4 16 4 10a8 8 0 1 1 16 0M15 10a3 3 0 1 1-6 0 3 3 0 0 1 6 0"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  ></path>
                </svg>
              </span>
            </article>
            <article className="ops-metric">
              <small>{'Países'}</small>
              <strong>{'2'}</strong>
              <p>{'Alcances DO / CO de demostración'}</p>
              <span>
                <svg
                  className="icon"
                  viewBox="0 0 24 24"
                  aria-hidden="true"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    d="M5 16V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2v11M5 11h14M8 3v8m8-8v8M5 16h14v3H5zM7 19v3m10-3v3M8 14h.01M16 14h.01"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  ></path>
                </svg>
              </span>
            </article>
            <article className="ops-metric">
              <small>{'Registros de auditoría'}</small>
              <strong>{'1'}</strong>
              <p>{'Actores reales y efectivos'}</p>
              <span>
                <svg
                  className="icon"
                  viewBox="0 0 24 24"
                  aria-hidden="true"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    d="M12 3l8 3v6c0 5-8 9-8 9s-8-4-8-9V6zM8 12l3 3 5-6"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  ></path>
                </svg>
              </span>
            </article>
          </div>
          <div className="ops-overview-grid">
            <section className="ops-card">
              <div className="ops-section-title">
                <div>
                  <span className="ops-eyebrow">{'EMPRESAS'}</span>
                  <h2>{'Operaciones conectadas'}</h2>
                </div>
              </div>
              <div className="ops-company-row">
                <img className="tp-logo" src={asset0} alt="TP" />
                <div>
                  <b>{'TP'}</b>
                  <small>{'4 tenants · DO / CO · Demostración'}</small>
                </div>
                <span className="ops-pill confirmed">{'Activo'}</span>
              </div>
              <div className="ops-company-row">
                <img className="alorica-logo" src={asset1} alt="Alorica" />
                <div>
                  <b>{'Alorica'}</b>
                  <small>{'1 tenants · DO · Demostración'}</small>
                </div>
                <span className="ops-pill confirmed">{'Activo'}</span>
              </div>
              <div className="ops-company-row">
                <img className="trueshore-logo" src={asset2} alt="TrueShore" />
                <div>
                  <b>{'TrueShore'}</b>
                  <small>{'1 tenants · DO · Demostración'}</small>
                </div>
                <span className="ops-pill confirmed">{'Activo'}</span>
              </div>
              <div className="ops-company-row">
                <img
                  className="concentrix-logo"
                  src={asset3}
                  alt="Concentrix"
                />
                <div>
                  <b>{'Concentrix'}</b>
                  <small>{'1 tenants · DO · Demostración'}</small>
                </div>
                <span className="ops-pill confirmed">{'Activo'}</span>
              </div>
            </section>
            <section className="ops-card">
              <div className="ops-section-title">
                <div>
                  <span className="ops-eyebrow">
                    {'ASISTENCIA CON TRAZABILIDAD'}
                  </span>
                  <h2>{'Impersonar administración'}</h2>
                </div>
              </div>
              <p className="ops-muted">
                {
                  '\n      La sesión conservará tu identidad real. Solo podrás hacer lo que permite\n      el usuario seleccionado.\n    '
                }
              </p>
              <form
                data-move-submit="startOpsImpersonation(event)"
                data-move-form=""
              >
                <label className="ops-label" htmlFor={uid + '-impersonateUser'}>
                  {'Usuario y rol'}
                </label>
                <select id={uid + '-impersonateUser'} name="target" required>
                  <option value="site-admin">
                    {'María Rodríguez · Administrador'}
                  </option>
                  <option value="coordinator">
                    {'Laura Méndez · Coordinación de transporte'}
                  </option>
                  <option value="company-admin">
                    {'Carolina Pérez · Country Admin'}
                  </option>
                  <option value="alorica-admin">
                    {'Ana Torres · Administrador'}
                  </option>
                </select>
                <label
                  className="ops-label"
                  htmlFor={uid + '-impersonateReason'}
                >
                  {'Motivo de la intervención'}
                </label>
                <textarea
                  id={uid + '-impersonateReason'}
                  name="reason"
                  required
                  minLength="8"
                  maxLength="500"
                  placeholder="Ticket o necesidad que justifica el acceso."
                  defaultValue=""
                />
                <div className="ops-session-note">
                  {
                    '\n        Sesión de 15 minutos · Inicio, acciones y cierre auditados\n      '
                  }
                </div>
                <button className="ops-button" type="submit">
                  {'Iniciar impersonación'}
                </button>
                <p
                  className="ops-form-error"
                  id={uid + '-impersonateError'}
                  role="alert"
                ></p>
              </form>
            </section>
          </div>
          <section className="ops-card">
            <div className="ops-section-title">
              <h2>{'Usuarios administrativos de demostración'}</h2>
            </div>
            <div className="ops-table-scroll">
              <table className="ops-table">
                <thead>
                  <tr>
                    <th>{'Usuario'}</th>
                    <th>{'Rol'}</th>
                    <th>{'Tenants autorizados'}</th>
                    <th></th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td>
                      <b>{'María Rodríguez'}</b>
                      <small>{'admin.tp.demo@gmail.com'}</small>
                    </td>
                    <td>{'Administrador'}</td>
                    <td>{'TP · Churchill'}</td>
                    <td>
                      <button
                        className="ops-button secondary"
                        data-move-click="selectImpersonationUser('site-admin')"
                      >
                        {'Seleccionar'}
                      </button>
                    </td>
                  </tr>
                  <tr>
                    <td>
                      <b>{'Laura Méndez'}</b>
                      <small>{'coordinador.tp.demo@gmail.com'}</small>
                    </td>
                    <td>{'Coordinación de transporte'}</td>
                    <td>{'TP · Churchill'}</td>
                    <td>
                      <button
                        className="ops-button secondary"
                        data-move-click="selectImpersonationUser('coordinator')"
                      >
                        {'Seleccionar'}
                      </button>
                    </td>
                  </tr>
                  <tr>
                    <td>
                      <b>{'Carolina Pérez'}</b>
                      <small>{'country.tp.demo@gmail.com'}</small>
                    </td>
                    <td>{'Country Admin'}</td>
                    <td>
                      {'TP · Churchill'}
                      <br />
                      {'TP · Sambil'}
                      <br />
                      {'TP · Santiago'}
                    </td>
                    <td>
                      <button
                        className="ops-button secondary"
                        data-move-click="selectImpersonationUser('company-admin')"
                      >
                        {'Seleccionar'}
                      </button>
                    </td>
                  </tr>
                  <tr>
                    <td>
                      <b>{'Ana Torres'}</b>
                      <small>{'admin.alorica.demo@gmail.com'}</small>
                    </td>
                    <td>{'Administrador'}</td>
                    <td>{'Alorica · Santo Domingo'}</td>
                    <td>
                      <button
                        className="ops-button secondary"
                        data-move-click="selectImpersonationUser('alorica-admin')"
                      >
                        {'Seleccionar'}
                      </button>
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
          </section>
        </>
      )}
    </MoveSurface>
  );
}
