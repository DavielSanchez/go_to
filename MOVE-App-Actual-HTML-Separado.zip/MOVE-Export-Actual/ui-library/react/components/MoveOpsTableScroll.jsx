import React, { useId } from 'react';
import { MoveSurface } from '../MoveSurface.jsx';

/** Patrón ops-table-scroll usado en opsOverviewView(). */
export function MoveOpsTableScroll({
  theme = 'light',
  tenant = 'tp',
  reducedMotion = false,
  onAction,
  className = '',
  style,
  children,
}) {
  const uid = useId();
  return (
    <MoveSurface
      theme={theme}
      tenant={tenant}
      reducedMotion={reducedMotion}
      onAction={onAction}
      className={'' + ' ' + className}
      style={style}
    >
      {children ?? (
        <>
          <div className="ops-table-scroll">
            <table className="ops-table">
              <thead>
                <tr>
                  <th>{'Tenant'}</th>
                  <th>{'Demanda'}</th>
                  <th>{'Abordados'}</th>
                  <th>{'Viajes activos'}</th>
                  <th>{'Plan'}</th>
                  <th>{'Operación'}</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td>
                    <b>{'TP · Churchill'}</b>
                    <small>{'DO · Santo Domingo'}</small>
                  </td>
                  <td>{'84'}</td>
                  <td>{'30'}</td>
                  <td>{'1'}</td>
                  <td>
                    <span className="ops-pill confirmed">{'Confirmado'}</span>
                  </td>
                  <td>
                    <button
                      className="ops-button secondary"
                      data-move-click="focusOpsTenant('tp-churchill')"
                    >
                      {'Ver tenant'}
                    </button>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </>
      )}
    </MoveSurface>
  );
}
