import React, { useId } from 'react';
import { MoveSurface } from '../MoveSurface.jsx';

/** Acción secundaria. */
export function MoveButtonSecondary({
  theme = 'light',
  tenant = 'tp',
  reducedMotion = false,
  onAction,
  className = '',
  style,
  children,
}) {
  const uid = useId();
  return (
    <MoveSurface
      theme={theme}
      tenant={tenant}
      reducedMotion={reducedMotion}
      onAction={onAction}
      className={'' + ' ' + className}
      style={style}
    >
      {children ?? (
        <>
          <button className="btn secondary">{'Volver'}</button>
        </>
      )}
    </MoveSurface>
  );
}
