import React, { useId } from 'react';
import { MoveSurface } from '../MoveSurface.jsx';

/** Patrón tags usado en views.review(). */
export function MoveTags({
  theme = 'light',
  tenant = 'tp',
  reducedMotion = false,
  onAction,
  className = '',
  style,
  children,
}) {
  const uid = useId();
  return (
    <MoveSurface
      theme={theme}
      tenant={tenant}
      reducedMotion={reducedMotion}
      onAction={onAction}
      className={'' + ' ' + className}
      style={style}
    >
      {children ?? (
        <>
          <div className="tags">
            <button
              className="tag "
              aria-pressed="false"
              data-move-click="toggleTag('Puntualidad')"
            >
              {'Puntualidad'}
            </button>
            <button
              className="tag "
              aria-pressed="false"
              data-move-click="toggleTag('Buen trato')"
            >
              {'Buen trato'}
            </button>
            <button
              className="tag "
              aria-pressed="false"
              data-move-click="toggleTag('Comodidad')"
            >
              {'Comodidad'}
            </button>
            <button
              className="tag "
              aria-pressed="false"
              data-move-click="toggleTag('Conducción segura')"
            >
              {'Conducción segura'}
            </button>
          </div>
        </>
      )}
    </MoveSurface>
  );
}
