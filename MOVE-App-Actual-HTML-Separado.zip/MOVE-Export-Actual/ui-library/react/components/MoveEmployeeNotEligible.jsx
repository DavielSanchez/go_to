import React, { useId } from 'react';
import { MoveSurface } from '../MoveSurface.jsx';

/** Bloque extraído del diseño actual de MOVE. Los eventos se exponen mediante onAction. */
export function MoveEmployeeNotEligible({
  theme = 'light',
  tenant = 'tp',
  reducedMotion = false,
  onAction,
  className = '',
  style,
  children,
}) {
  const uid = useId();
  return (
    <MoveSurface
      theme={theme}
      tenant={tenant}
      reducedMotion={reducedMotion}
      onAction={onAction}
      className={'' + ' ' + className}
      style={style}
    >
      {children ?? (
        <>
          <div className="date">{'4 DE OCTUBRE DE 2026'}</div>
          <div className="page-top">
            <div>
              <h1>
                {'Hola, Daviel '}
                <span className="accent">{'.'}</span>
              </h1>
              <p className="sub">{'Tu regreso a casa, organizado.'}</p>
            </div>
          </div>
          <div className="home-grid">
            <section>
              <div className="card hero">
                <span className="pill">
                  <svg
                    className="icon"
                    viewBox="0 0 24 24"
                    aria-hidden="true"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path
                      d="M12 11v6m0-10v.01M22 12a10 10 0 1 1-20 0 10 10 0 0 1 20 0"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    ></path>
                  </svg>
                  {'NO APLICA TRANSPORTE HOY'}
                </span>
                <h2>{'Hoy no tienes transporte asignado.'}</h2>
                <p>
                  {
                    'Tu jornada de hoy no cumple las condiciones del servicio. Si tu horario cambió o necesitas transporte por otro motivo, puedes solicitar una excepción.'
                  }
                </p>
                <div className="time-row">
                  <div>
                    <small>{'Salida de tu turno'}</small>
                    <strong>
                      {'6:00 '}
                      <span style={{ fontSize: '14px' }}>{'p. m.'}</span>
                    </strong>
                  </div>
                  <div>
                    <small>{'Disponibilidad'}</small>
                    <strong style={{ fontSize: '18px' }}>
                      {'Requiere excepción'}
                    </strong>
                  </div>
                </div>
                <button className="btn" data-move-click="navigate('exception')">
                  <svg
                    className="icon"
                    viewBox="0 0 24 24"
                    aria-hidden="true"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path
                      d="M3 7h18v4a2 2 0 0 0 0 4v4H3v-4a2 2 0 0 0 0-4zM15 7v2m0 3v2m0 3v2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    ></path>
                  </svg>
                  {'Solicitar una excepción'}
                </button>
              </div>
              <div className="notice">
                <svg
                  className="icon"
                  viewBox="0 0 24 24"
                  aria-hidden="true"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    d="M12 11v6m0-10v.01M22 12a10 10 0 1 1-20 0 10 10 0 0 1 20 0"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  ></path>
                </svg>
                <span>
                  {
                    'Una excepción debe ser aprobada antes de confirmar o abordar el transporte.'
                  }
                </span>
              </div>
            </section>
            <section>
              <div className="card address-card">
                <div className="section-heading" style={{ marginTop: '0px' }}>
                  <h2>{'Mi dirección'}</h2>
                  <span className="icon-box">
                    <svg
                      className="icon"
                      viewBox="0 0 24 24"
                      aria-hidden="true"
                      xmlns="http://www.w3.org/2000/svg"
                    >
                      <path
                        d="M20 10c0 6-8 12-8 12S4 16 4 10a8 8 0 1 1 16 0M15 10a3 3 0 1 1-6 0 3 3 0 0 1 6 0"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                      ></path>
                    </svg>
                  </span>
                </div>
                <p className="address-value">
                  {'Entrada de Pantoja · Los Alcarrizos'}
                </p>
                <p className="small-info">{'Ubicación: 18.53000, -70.01000'}</p>
                <p className="small-info" style={{ marginTop: '12px' }}>
                  {
                    '0 de 3 cambios automáticos utilizados. Desde el cuarto, transporte debe aprobar el cambio.'
                  }
                </p>
                <button
                  className="btn secondary"
                  style={{ marginTop: '18px' }}
                  data-move-click="navigate('address')"
                >
                  {'Cambiar dirección'}
                </button>
              </div>
            </section>
          </div>
          <p className="demo-note">
            {'Vista de demostración · Datos de ejemplo'}
          </p>
        </>
      )}
    </MoveSurface>
  );
}
