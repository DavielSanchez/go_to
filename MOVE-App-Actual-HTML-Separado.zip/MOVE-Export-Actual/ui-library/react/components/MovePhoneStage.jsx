import React, { useId } from 'react';
import { MoveSurface } from '../MoveSurface.jsx';

/** Patrón phone-stage usado en landing.js · landingView. */
export function MovePhoneStage({
  theme = 'light',
  tenant = 'tp',
  reducedMotion = false,
  onAction,
  className = '',
  style,
  children,
}) {
  const uid = useId();
  return (
    <MoveSurface
      theme={theme}
      tenant={tenant}
      reducedMotion={reducedMotion}
      onAction={onAction}
      className={'' + ' ' + className}
      style={style}
    >
      {children ?? (
        <>
          <div className="phone-stage">
            <div className="orbit-label">{'MOVE / UNA JORNADA MÁS SIMPLE'}</div>
            <div className="product-phone">
              <div className="phone-camera"></div>
              <div className="phone-top">
                <span className="brand">
                  {'MOVE'}
                  <span className="brand-dot"></span>
                </span>
                <span className="phone-avatar">{'DS'}</span>
              </div>
              <div id={uid + '-phonePreview'}>
                <div className="phone-content">
                  <small>{'VIERNES, 2 DE OCTUBRE'}</small>
                  <h3>
                    {'Hola, Daviel'}
                    <span>{'.'}</span>
                  </h3>
                  <p>{'Tu regreso a casa, organizado.'}</p>
                  <div className="phone-hero">
                    <span>{'✓ RESERVA CONFIRMADA'}</span>
                    <h4>
                      {'Todo listo para'}
                      <br />
                      {'tu regreso.'}
                    </h4>
                    <div>
                      <small>{'Salida del transporte'}</small>
                      <b>{'10:15 p. m.'}</b>
                    </div>
                    <button data-move-click="enterMove()">
                      {'Ver mi viaje'}
                    </button>
                  </div>
                  <h4>{'Tu ruta asignada'}</h4>
                  <div className="phone-route">
                    <b>{'TP · Campus Churchill'}</b>
                    <span>{'↓'}</span>
                    <b>{'Los Alcarrizos'}</b>
                    <small>{'Unidad 12 · Ruta 04'}</small>
                  </div>
                </div>
              </div>
              <div className="phone-nav">
                <svg
                  className="icon"
                  viewBox="0 0 24 24"
                  aria-hidden="true"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    d="M3 10l9-7 9 7v10a1 1 0 0 1-1 1h-5v-7H9v7H4a1 1 0 0 1-1-1z"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  ></path>
                </svg>
                <svg
                  className="icon"
                  viewBox="0 0 24 24"
                  aria-hidden="true"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    d="M5 16V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2v11M5 11h14M8 3v8m8-8v8M5 16h14v3H5zM7 19v3m10-3v3M8 14h.01M16 14h.01"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  ></path>
                </svg>
                <svg
                  className="icon"
                  viewBox="0 0 24 24"
                  aria-hidden="true"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    d="M3 7h18v4a2 2 0 0 0 0 4v4H3v-4a2 2 0 0 0 0-4zM15 7v2m0 3v2m0 3v2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  ></path>
                </svg>
                <svg
                  className="icon"
                  viewBox="0 0 24 24"
                  aria-hidden="true"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    d="M20 21v-2a6 6 0 0 0-6-6h-4a6 6 0 0 0-6 6v2M16 6a4 4 0 1 1-8 0 4 4 0 0 1 8 0"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  ></path>
                </svg>
              </div>
            </div>
            <div className="product-floating">
              <span>
                <svg
                  className="icon"
                  viewBox="0 0 24 24"
                  aria-hidden="true"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    d="M5 12l4 4L19 6"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  ></path>
                </svg>
              </span>
              <div>
                <b>{'Confirmación recibida'}</b>
                <small>{'Un asiento. Una preocupación menos.'}</small>
              </div>
            </div>
          </div>
        </>
      )}
    </MoveSurface>
  );
}
