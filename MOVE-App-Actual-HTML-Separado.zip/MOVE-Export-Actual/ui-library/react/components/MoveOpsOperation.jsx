import React, { useId } from 'react';
import { MoveSurface } from '../MoveSurface.jsx';

/** Bloque extraído del diseño actual de MOVE. Los eventos se exponen mediante onAction. */
export function MoveOpsOperation({
  theme = 'light',
  tenant = 'tp',
  reducedMotion = false,
  onAction,
  className = '',
  style,
  children,
}) {
  const uid = useId();
  return (
    <MoveSurface
      theme={theme}
      tenant={tenant}
      reducedMotion={reducedMotion}
      onAction={onAction}
      className={'' + ' ' + className}
      style={style}
    >
      {children ?? (
        <>
          <div className="ops-metrics">
            <article className="ops-metric">
              <small>{'Demanda confirmada'}</small>
              <strong>{'84'}</strong>
              <p>{'1 tenants seleccionados'}</p>
              <span>
                <svg
                  className="icon"
                  viewBox="0 0 24 24"
                  aria-hidden="true"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    d="M20 21v-2a6 6 0 0 0-6-6h-4a6 6 0 0 0-6 6v2M16 6a4 4 0 1 1-8 0 4 4 0 0 1 8 0"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  ></path>
                </svg>
              </span>
            </article>
            <article className="ops-metric">
              <small>{'Pasajeros abordados'}</small>
              <strong>{'30'}</strong>
              <p>{'Asignados al trip, no al conductor'}</p>
              <span>
                <svg
                  className="icon"
                  viewBox="0 0 24 24"
                  aria-hidden="true"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    d="M3 7h18v4a2 2 0 0 0 0 4v4H3v-4a2 2 0 0 0 0-4zM15 7v2m0 3v2m0 3v2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  ></path>
                </svg>
              </span>
            </article>
            <article className="ops-metric">
              <small>{'Viajes en curso'}</small>
              <strong>{'1'}</strong>
              <p>{'Incluye jornadas anteriores activas'}</p>
              <span>
                <svg
                  className="icon"
                  viewBox="0 0 24 24"
                  aria-hidden="true"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    d="M5 16V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2v11M5 11h14M8 3v8m8-8v8M5 16h14v3H5zM7 19v3m10-3v3M8 14h.01M16 14h.01"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  ></path>
                </svg>
              </span>
            </article>
            <article className="ops-metric">
              <small>{'Trips sin conductor'}</small>
              <strong>{'1'}</strong>
              <p>{'Necesitan atención'}</p>
              <span>
                <svg
                  className="icon"
                  viewBox="0 0 24 24"
                  aria-hidden="true"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    d="M12 11v6m0-10v.01M22 12a10 10 0 1 1-20 0 10 10 0 0 1 20 0"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  ></path>
                </svg>
              </span>
            </article>
          </div>
          <div className="ops-section-title">
            <div>
              <h2>{'Control de viajes'}</h2>
              <p className="ops-muted">
                {
                  '\n      Ruta, trip y conductor conservan identidades distintas.\n    '
                }
              </p>
            </div>
            <div className="ops-segmented" aria-label="Estado del viaje">
              <button
                className="active"
                data-move-click="setOpsTripFilter('all')"
              >
                {'Todos'}
              </button>
              <button
                className=""
                data-move-click="setOpsTripFilter('boarding')"
              >
                {'Abordaje'}
              </button>
              <button className="" data-move-click="setOpsTripFilter('active')">
                {'En viaje'}
              </button>
              <button className="" data-move-click="setOpsTripFilter('paused')">
                {'Pausados'}
              </button>
              <button
                className=""
                data-move-click="setOpsTripFilter('completed')"
              >
                {'Finalizados'}
              </button>
            </div>
          </div>
          <div className="ops-trip-grid">
            <article
              className="ops-trip-card"
              tabIndex="0"
              role="button"
              aria-label="Abrir TR-1040"
              data-move-click="openOpsTrip('TR-1040')"
              data-move-keydown="if(event.key==='Enter'||event.key===' '){event.preventDefault();openOpsTrip('TR-1040')}"
            >
              <div className="ops-trip-top">
                <small>{'TR-1040 · RUTA 07'}</small>
                <span className="ops-pill active">{'En viaje'}</span>
              </div>
              <h3>{'Los Girasoles'}</h3>
              <p className="ops-trip-site">
                {'TP · Churchill · Jornada anterior'}
              </p>
              <div className="ops-trip-stats">
                <div>
                  <small>{'Salida'}</small>
                  <b>{'00:30'}</b>
                </div>
                <div>
                  <small>{'A bordo'}</small>
                  <b>{'12 / 12'}</b>
                </div>
                <div>
                  <small>{'Unidad'}</small>
                  <b>{'12'}</b>
                </div>
              </div>
              <div className="ops-trip-driver">
                <svg
                  className="icon"
                  viewBox="0 0 24 24"
                  aria-hidden="true"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    d="M20 21v-2a6 6 0 0 0-6-6h-4a6 6 0 0 0-6 6v2M16 6a4 4 0 1 1-8 0 4 4 0 0 1 8 0"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  ></path>
                </svg>
                <b>{'Ángel Ramírez'}</b>
                <small>{'Asignación actual'}</small>
              </div>
              <div className="ops-trip-progress">
                <span>{'Progreso del recorrido'}</span>
                <span data-ops-progress-label="TR-1040">
                  {'43% · ETA 01:08'}
                </span>
              </div>
              <div className="ops-bar">
                <span
                  data-ops-progress="TR-1040"
                  style={{ width: '43%' }}
                ></span>
              </div>
            </article>
            <article
              className="ops-trip-card"
              tabIndex="0"
              role="button"
              aria-label="Abrir TR-1041"
              data-move-click="openOpsTrip('TR-1041')"
              data-move-keydown="if(event.key==='Enter'||event.key===' '){event.preventDefault();openOpsTrip('TR-1041')}"
            >
              <div className="ops-trip-top">
                <small>{'TR-1041 · RUTA 04'}</small>
                <span className="ops-pill boarding">{'Abordaje'}</span>
              </div>
              <h3>{'Pantoja'}</h3>
              <p className="ops-trip-site">{'TP · Churchill'}</p>
              <div className="ops-trip-stats">
                <div>
                  <small>{'Salida'}</small>
                  <b>{'00:30'}</b>
                </div>
                <div>
                  <small>{'A bordo'}</small>
                  <b>{'6 / 8'}</b>
                </div>
                <div>
                  <small>{'Unidad'}</small>
                  <b>{'13'}</b>
                </div>
              </div>
              <div className="ops-trip-driver">
                <svg
                  className="icon"
                  viewBox="0 0 24 24"
                  aria-hidden="true"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    d="M20 21v-2a6 6 0 0 0-6-6h-4a6 6 0 0 0-6 6v2M16 6a4 4 0 1 1-8 0 4 4 0 0 1 8 0"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  ></path>
                </svg>
                <b>{'Sin conductor'}</b>
                <small>{'Trip disponible'}</small>
              </div>
              <div className="ops-trip-progress">
                <span>{'Abordaje conservado'}</span>
                <span data-ops-progress-label="TR-1041">
                  {'0% · ETA 00:18'}
                </span>
              </div>
              <div className="ops-bar">
                <span
                  data-ops-progress="TR-1041"
                  style={{ width: '0%' }}
                ></span>
              </div>
            </article>
            <article
              className="ops-trip-card"
              tabIndex="0"
              role="button"
              aria-label="Abrir TR-1042"
              data-move-click="openOpsTrip('TR-1042')"
              data-move-keydown="if(event.key==='Enter'||event.key===' '){event.preventDefault();openOpsTrip('TR-1042')}"
            >
              <div className="ops-trip-top">
                <small>{'TR-1042 · RUTA 04'}</small>
                <span className="ops-pill completed">{'Finalizado'}</span>
              </div>
              <h3>{'Pantoja'}</h3>
              <p className="ops-trip-site">{'TP · Churchill'}</p>
              <div className="ops-trip-stats">
                <div>
                  <small>{'Salida'}</small>
                  <b>{'23:30'}</b>
                </div>
                <div>
                  <small>{'A bordo'}</small>
                  <b>{'12 / 12'}</b>
                </div>
                <div>
                  <small>{'Unidad'}</small>
                  <b>{'14'}</b>
                </div>
              </div>
              <div className="ops-trip-driver">
                <svg
                  className="icon"
                  viewBox="0 0 24 24"
                  aria-hidden="true"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    d="M20 21v-2a6 6 0 0 0-6-6h-4a6 6 0 0 0-6 6v2M16 6a4 4 0 1 1-8 0 4 4 0 0 1 8 0"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  ></path>
                </svg>
                <b>{'Pedro Castillo'}</b>
                <small>{'Asignación actual'}</small>
              </div>
              <div className="ops-trip-progress">
                <span>{'Progreso del recorrido'}</span>
                <span data-ops-progress-label="TR-1042">
                  {'100% · ETA 23:55'}
                </span>
              </div>
              <div className="ops-bar">
                <span
                  data-ops-progress="TR-1042"
                  style={{ width: '100%' }}
                ></span>
              </div>
            </article>
          </div>
        </>
      )}
    </MoveSurface>
  );
}
