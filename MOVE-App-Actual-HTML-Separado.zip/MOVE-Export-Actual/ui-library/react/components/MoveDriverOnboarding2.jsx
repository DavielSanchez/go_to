import React, { useId } from 'react';
import { MoveSurface } from '../MoveSurface.jsx';

/** Bloque extraído del diseño actual de MOVE. Los eventos se exponen mediante onAction. */
export function MoveDriverOnboarding2({
  theme = 'light',
  tenant = 'tp',
  reducedMotion = false,
  onAction,
  className = '',
  style,
  children,
}) {
  const uid = useId();
  return (
    <MoveSurface
      theme={theme}
      tenant={tenant}
      reducedMotion={reducedMotion}
      onAction={onAction}
      className={'' + ' ' + className}
      style={style}
    >
      {children ?? (
        <>
          <div className="narrow">
            <div className="page-top">
              <div>
                <h1>{'Registro del conductor'}</h1>
                <p className="sub">
                  {'Completa tus datos antes de recibir una ruta.'}
                </p>
              </div>
            </div>
            <div className="onboarding-steps">
              <span className="">{'1. Identidad'}</span>
              <span className="active">{'2. Vehículo'}</span>
              <span className="">{'3. Revisión'}</span>
            </div>
            <form
              id={uid + '-driverOnboarding'}
              className="card"
              data-move-form=""
            >
              <h2>{'Tu vehículo'}</h2>
              <label className="label" htmlFor={uid + '-d-brand'}>
                {'Marca'}
              </label>
              <input
                id={uid + '-d-brand'}
                name="brand"
                type="text"
                defaultValue="Hyundai"
                required
              />
              <label className="label" htmlFor={uid + '-d-model'}>
                {'Modelo'}
              </label>
              <input
                id={uid + '-d-model'}
                name="model"
                type="text"
                defaultValue="County"
                required
              />
              <label className="label" htmlFor={uid + '-d-year'}>
                {'Año'}
              </label>
              <input
                id={uid + '-d-year'}
                name="year"
                type="number"
                defaultValue="2023"
                required
                min="1980"
                max="2027"
              />
              <label className="label" htmlFor={uid + '-d-plate'}>
                {'Placa escrita'}
              </label>
              <input
                id={uid + '-d-plate'}
                name="plate"
                type="text"
                defaultValue="I078542"
                required
                maxLength="12"
              />
              <div className="photo-field">
                <b>{'Foto de la placa'}</b>
                <div id={uid + '-preview-plate'} className="photo-preview">
                  <span>
                    <svg
                      className="icon"
                      viewBox="0 0 24 24"
                      aria-hidden="true"
                      xmlns="http://www.w3.org/2000/svg"
                    >
                      <path
                        d="M5 3h4l2 5-3 2c2 3 3 4 6 6l2-3 5 2v4c-8 5-22-9-16-16"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                      ></path>
                    </svg>
                    {'Sin foto'}
                  </span>
                </div>
                <div className="photo-actions">
                  <label className="btn secondary">
                    {'Tomar foto'}
                    <input
                      type="file"
                      accept="image/*"
                      capture="environment"
                      data-photo="plate"
                      hidden
                    />
                  </label>
                  <label className="btn secondary">
                    {'Galería'}
                    <input
                      type="file"
                      accept="image/*"
                      data-photo="plate"
                      hidden
                    />
                  </label>
                </div>
              </div>
              <p
                id={uid + '-onboardError'}
                className="form-error"
                role="alert"
              ></p>
              <div className="form-actions">
                <button
                  className="btn secondary"
                  type="button"
                  data-move-click="backOnboarding()"
                >
                  {'Anterior'}
                </button>
                <button className="btn" type="submit">
                  {'Continuar'}
                </button>
              </div>
            </form>
            <p className="demo-note">
              {'Vista de demostración · Datos de ejemplo'}
            </p>
          </div>
        </>
      )}
    </MoveSurface>
  );
}
