import React, { useId } from 'react';
import { MoveSurface } from '../MoveSurface.jsx';

/** Patrón supervisor-workspace usado en approvalView(). */
export function MoveSupervisorWorkspace({
  theme = 'light',
  tenant = 'tp',
  reducedMotion = false,
  onAction,
  className = '',
  style,
  children,
}) {
  const uid = useId();
  return (
    <MoveSurface
      theme={theme}
      tenant={tenant}
      reducedMotion={reducedMotion}
      onAction={onAction}
      className={'' + ' ' + className}
      style={style}
    >
      {children ?? (
        <>
          <div className="supervisor-workspace">
            <div className="page-top">
              <div>
                <h1>{'Excepciones de mi equipo'}</h1>
                <p className="sub">
                  {'Revisa las solicitudes de tus supervisados.'}
                </p>
              </div>
            </div>
            <div className="approval-metrics">
              <div className="card">
                <strong>{'2'}</strong>
                <span>{'Pendientes'}</span>
              </div>
              <div className="card">
                <strong>{'1'}</strong>
                <span>{'Aprobadas'}</span>
              </div>
              <div className="card">
                <strong>{'0'}</strong>
                <span>{'Rechazadas'}</span>
              </div>
            </div>
            <div
              className="approval-filter"
              role="group"
              aria-label="Filtrar solicitudes"
            >
              <button
                className="selected"
                aria-pressed="true"
                data-move-click="setApprovalFilter('pending')"
              >
                {'Pendientes'}
              </button>
              <button
                className=""
                aria-pressed="false"
                data-move-click="setApprovalFilter('approved')"
              >
                {'Aprobadas'}
              </button>
              <button
                className=""
                aria-pressed="false"
                data-move-click="setApprovalFilter('rejected')"
              >
                {'Rechazadas'}
              </button>
              <button
                className=""
                aria-pressed="false"
                data-move-click="setApprovalFilter('all')"
              >
                {'Todas'}
              </button>
            </div>
            <div className="approval-list">
              <article className="card">
                <div className="request-heading">
                  <div>
                    <h2>{'Ana Pérez'}</h2>
                    <p className="small-info">{'ID 104601 · EX-001'}</p>
                  </div>
                  <span className="pill amber">{'Pendiente'}</span>
                </div>
                <div className="request-summary">
                  <div>
                    <small>{'Motivo'}</small>
                    <b>{'Horas extra'}</b>
                  </div>
                  <div>
                    <small>{'Salida solicitada'}</small>
                    <b>{'4 de octubre de 2026 · 23:00'}</b>
                  </div>
                </div>
                <p className="request-detail" data-user-content="">
                  {'Mi jornada se extendió por cierre de operación.'}
                </p>
                <label className="label" htmlFor={uid + '-decision-EX-001'}>
                  {'Comentario de la decisión'}
                </label>
                <textarea
                  id={uid + '-decision-EX-001'}
                  placeholder="Opcional al aprobar; obligatorio al rechazar."
                  maxLength="500"
                  defaultValue=""
                />
                <div className="form-actions">
                  <button
                    className="btn outline"
                    data-move-click="decideException('EX-001','rejected')"
                  >
                    {'Rechazar'}
                  </button>
                  <button
                    className="btn"
                    data-move-click="decideException('EX-001','approved')"
                  >
                    {'Aprobar excepción'}
                  </button>
                </div>
                <p
                  id={uid + '-decision-error-EX-001'}
                  className="form-error"
                  role="alert"
                ></p>
              </article>
              <article className="card">
                <div className="request-heading">
                  <div>
                    <h2>{'Carlos Mejía'}</h2>
                    <p className="small-info">{'ID 104612 · EX-002'}</p>
                  </div>
                  <span className="pill amber">{'Pendiente'}</span>
                </div>
                <div className="request-summary">
                  <div>
                    <small>{'Motivo'}</small>
                    <b>{'Capacitación'}</b>
                  </div>
                  <div>
                    <small>{'Salida solicitada'}</small>
                    <b>{'4 de octubre de 2026 · 22:30'}</b>
                  </div>
                </div>
                <p className="request-detail" data-user-content="">
                  {'Capacitación del equipo después del turno.'}
                </p>
                <label className="label" htmlFor={uid + '-decision-EX-002'}>
                  {'Comentario de la decisión'}
                </label>
                <textarea
                  id={uid + '-decision-EX-002'}
                  placeholder="Opcional al aprobar; obligatorio al rechazar."
                  maxLength="500"
                  defaultValue=""
                />
                <div className="form-actions">
                  <button
                    className="btn outline"
                    data-move-click="decideException('EX-002','rejected')"
                  >
                    {'Rechazar'}
                  </button>
                  <button
                    className="btn"
                    data-move-click="decideException('EX-002','approved')"
                  >
                    {'Aprobar excepción'}
                  </button>
                </div>
                <p
                  id={uid + '-decision-error-EX-002'}
                  className="form-error"
                  role="alert"
                ></p>
              </article>
            </div>
            <div className="notice">
              <svg
                className="icon"
                viewBox="0 0 24 24"
                aria-hidden="true"
                xmlns="http://www.w3.org/2000/svg"
              >
                <path
                  d="M12 11v6m0-10v.01M22 12a10 10 0 1 1-20 0 10 10 0 0 1 20 0"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                ></path>
              </svg>
              <span>
                {
                  'Demostración: las decisiones se guardan en esta sesión. La aprobación habilita la excepción para que transporte asigne una salida; no asigna un vehículo automáticamente.'
                }
              </span>
            </div>
            <p className="demo-note">
              {'Vista de demostración · Datos de ejemplo'}
            </p>
          </div>
        </>
      )}
    </MoveSurface>
  );
}
