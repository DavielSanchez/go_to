import React, { useId } from 'react';
import { MoveSurface } from '../MoveSurface.jsx';

/** Patrón stop-list usado en driverViews['driver-home'](). */
export function MoveStopList({
  theme = 'light',
  tenant = 'tp',
  reducedMotion = false,
  onAction,
  className = '',
  style,
  children,
}) {
  const uid = useId();
  return (
    <MoveSurface
      theme={theme}
      tenant={tenant}
      reducedMotion={reducedMotion}
      onAction={onAction}
      className={'' + ' ' + className}
      style={style}
    >
      {children ?? (
        <>
          <div className="stop-list">
            <div className="stop-row">
              <span className="stop-number">{'1'}</span>
              <div>
                <b>{'Los Girasoles'}</b>
                <p className="small-info">{'Ana Pérez · Carlos Mejía'}</p>
              </div>
            </div>
            <div className="stop-row">
              <span className="stop-number">{'2'}</span>
              <div>
                <b>{'Ciudad Real'}</b>
                <p className="small-info">{'Laura Díaz · Miguel Santos'}</p>
              </div>
            </div>
            <div className="stop-row">
              <span className="stop-number">{'3'}</span>
              <div>
                <b>{'Entrada de Pantoja'}</b>
                <p className="small-info">
                  {'Daviel Sánchez · Sofía Rodríguez'}
                </p>
              </div>
            </div>
          </div>
        </>
      )}
    </MoveSurface>
  );
}
