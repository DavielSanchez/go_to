import React, { useId } from 'react';
import { MoveSurface } from '../MoveSurface.jsx';

/** Chip seleccionable. */
export function MoveChip({
  theme = 'light',
  tenant = 'tp',
  reducedMotion = false,
  onAction,
  className = '',
  style,
  children,
}) {
  const uid = useId();
  return (
    <MoveSurface
      theme={theme}
      tenant={tenant}
      reducedMotion={reducedMotion}
      onAction={onAction}
      className={'' + ' ' + className}
      style={style}
    >
      {children ?? (
        <>
          <div className="tags">
            <button className="tag selected" aria-pressed="true">
              {'Puntualidad'}
            </button>
            <button className="tag" aria-pressed="false">
              {'Comodidad'}
            </button>
          </div>
        </>
      )}
    </MoveSurface>
  );
}
