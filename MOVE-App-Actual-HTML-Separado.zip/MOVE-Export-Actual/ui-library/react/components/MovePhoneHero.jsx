import React, { useId } from 'react';
import { MoveSurface } from '../MoveSurface.jsx';

/** Patrón phone-hero usado en landing.js · landingView. */
export function MovePhoneHero({
  theme = 'light',
  tenant = 'tp',
  reducedMotion = false,
  onAction,
  className = '',
  style,
  children,
}) {
  const uid = useId();
  return (
    <MoveSurface
      theme={theme}
      tenant={tenant}
      reducedMotion={reducedMotion}
      onAction={onAction}
      className={'' + ' ' + className}
      style={style}
    >
      {children ?? (
        <>
          <div className="phone-hero">
            <span>{'✓ RESERVA CONFIRMADA'}</span>
            <h4>
              {'Todo listo para'}
              <br />
              {'tu regreso.'}
            </h4>
            <div>
              <small>{'Salida del transporte'}</small>
              <b>{'10:15 p. m.'}</b>
            </div>
            <button data-move-click="enterMove()">{'Ver mi viaje'}</button>
          </div>
        </>
      )}
    </MoveSurface>
  );
}
