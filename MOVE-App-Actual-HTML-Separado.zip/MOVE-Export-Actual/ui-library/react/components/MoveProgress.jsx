import React, { useId } from 'react';
import { MoveSurface } from '../MoveSurface.jsx';

/** Barra de progreso. */
export function MoveProgress({
  theme = 'light',
  tenant = 'tp',
  reducedMotion = false,
  onAction,
  className = '',
  style,
  children,
}) {
  const uid = useId();
  return (
    <MoveSurface
      theme={theme}
      tenant={tenant}
      reducedMotion={reducedMotion}
      onAction={onAction}
      className={'' + ' ' + className}
      style={style}
    >
      {children ?? (
        <>
          <div
            className="progress"
            role="progressbar"
            aria-label="Progreso del viaje"
            aria-valuenow="64"
            aria-valuemin="0"
            aria-valuemax="100"
          >
            <span style={{ width: '64%' }}></span>
          </div>
        </>
      )}
    </MoveSurface>
  );
}
