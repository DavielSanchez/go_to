import React, { useId } from 'react';
import { MoveSurface } from '../MoveSurface.jsx';

/** Patrón route-item usado en views.home(). */
export function MoveRouteItem({
  theme = 'light',
  tenant = 'tp',
  reducedMotion = false,
  onAction,
  className = '',
  style,
  children,
}) {
  const uid = useId();
  return (
    <MoveSurface
      theme={theme}
      tenant={tenant}
      reducedMotion={reducedMotion}
      onAction={onAction}
      className={'' + ' ' + className}
      style={style}
    >
      {children ?? (
        <>
          <div className="route-item">
            <b>{'TP · Campus Churchill'}</b>
            <small>{'Salida por la puerta principal'}</small>
          </div>
        </>
      )}
    </MoveSurface>
  );
}
