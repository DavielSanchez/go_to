import React, { useId } from 'react';
import { MoveSurface } from '../MoveSurface.jsx';

/** Patrón ops-window-row usado en opsOverviewView(). */
export function MoveOpsWindowRow({
  theme = 'light',
  tenant = 'tp',
  reducedMotion = false,
  onAction,
  className = '',
  style,
  children,
}) {
  const uid = useId();
  return (
    <MoveSurface
      theme={theme}
      tenant={tenant}
      reducedMotion={reducedMotion}
      onAction={onAction}
      className={'' + ' ' + className}
      style={style}
    >
      {children ?? (
        <>
          <div className="ops-window-row">
            <div className="ops-window-time">{'21:30'}</div>
            <div>
              <b>{'0 trips · 0 abordados'}</b>
              <small>{'Ventana de la jornada seleccionada'}</small>
              <div className="ops-bar">
                <span style={{ width: '0%' }}></span>
              </div>
            </div>
            <span className="ops-pill completed">{'Sin viajes'}</span>
          </div>
        </>
      )}
    </MoveSurface>
  );
}
