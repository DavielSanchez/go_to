import React, { useId } from 'react';
import { MoveSurface } from '../MoveSurface.jsx';

/** Patrón account-setting usado en accountMenuHTML(). */
export function MoveAccountSetting({
  theme = 'light',
  tenant = 'tp',
  reducedMotion = false,
  onAction,
  className = '',
  style,
  children,
}) {
  const uid = useId();
  return (
    <MoveSurface
      theme={theme}
      tenant={tenant}
      reducedMotion={reducedMotion}
      onAction={onAction}
      className={'' + ' ' + className}
      style={style}
    >
      {children ?? (
        <>
          <div className="account-setting">
            <span>{'Tema'}</span>
            <div>
              <button
                aria-pressed="true"
                data-move-click="setAccountTheme('light')"
              >
                {'Claro'}
              </button>
              <button
                aria-pressed="false"
                data-move-click="setAccountTheme('dark')"
              >
                {'Oscuro'}
              </button>
            </div>
          </div>
        </>
      )}
    </MoveSurface>
  );
}
