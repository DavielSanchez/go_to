import React, { useId } from 'react';
import { MoveSurface } from '../MoveSurface.jsx';

/** Campo multilinea. */
export function MoveTextarea({
  theme = 'light',
  tenant = 'tp',
  reducedMotion = false,
  onAction,
  className = '',
  style,
  children,
}) {
  const uid = useId();
  return (
    <MoveSurface
      theme={theme}
      tenant={tenant}
      reducedMotion={reducedMotion}
      onAction={onAction}
      className={'' + ' ' + className}
      style={style}
    >
      {children ?? (
        <>
          <div>
            <label className="label" htmlFor={uid + '-comment-field'}>
              {'Comentario'}
            </label>
            <textarea
              id={uid + '-comment-field'}
              maxLength="500"
              placeholder="Cuéntanos tu experiencia…"
              defaultValue=""
            />
          </div>
        </>
      )}
    </MoveSurface>
  );
}
