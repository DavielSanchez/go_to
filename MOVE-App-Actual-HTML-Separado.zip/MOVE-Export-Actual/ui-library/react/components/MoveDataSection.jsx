import React, { useId } from 'react';
import { MoveSurface } from '../MoveSurface.jsx';

/** Patrón data-section usado en landing.js · landingView. */
export function MoveDataSection({
  theme = 'light',
  tenant = 'tp',
  reducedMotion = false,
  onAction,
  className = '',
  style,
  children,
}) {
  const uid = useId();
  return (
    <MoveSurface
      theme={theme}
      tenant={tenant}
      reducedMotion={reducedMotion}
      onAction={onAction}
      className={'' + ' ' + className}
      style={style}
    >
      {children ?? (
        <>
          <section className="data-section" id={uid + '-impact'}>
            <div className="lp-section">
              <div className="section-intro">
                <div>
                  <span className="lp-kicker">
                    {'04 / LA OPERACIÓN, A SIMPLE VISTA'}
                  </span>
                  <h2>
                    {'Lo que puedes ver'}
                    <br />
                    {'también puedes mejorar.'}
                  </h2>
                </div>
                <p>
                  {
                    'Así podría verse un resumen del servicio en una operación empresarial. Las cifras siguientes son ilustrativas.'
                  }
                </p>
              </div>
              <div className="demo-badge">
                <svg
                  className="icon"
                  viewBox="0 0 24 24"
                  aria-hidden="true"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    d="M12 11v6m0-10v.01M22 12a10 10 0 1 1-20 0 10 10 0 0 1 20 0"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  ></path>
                </svg>
                {
                  ' Escenario de demostración · No representa resultados de clientes'
                }
              </div>
              <div className="metrics-grid">
                <div>
                  <strong>{'1,200'}</strong>
                  <span>{'colaboradores en el escenario'}</span>
                </div>
                <div>
                  <strong>{'42'}</strong>
                  <span>{'vehículos coordinados'}</span>
                </div>
                <div>
                  <strong>
                    {'91'}
                    <span>{'%'}</span>
                  </strong>
                  <span>{'ocupación ilustrativa'}</span>
                </div>
                <div>
                  <strong>
                    {'18'}
                    <span>{'%'}</span>
                  </strong>
                  <span>{'reducción de costo hipotética'}</span>
                </div>
              </div>
              <div className="data-bottom">
                <div>
                  <h3>
                    {'Del “¿quién va hoy?”'}
                    <br />
                    {'a una operación visible.'}
                  </h3>
                  <p>
                    {
                      'Confirmaciones, asignaciones y abordajes permiten construir una vista compartida del servicio para tu equipo.'
                    }
                  </p>
                </div>
                <div className="mini-dashboard">
                  <div className="dashboard-title">
                    <b>{'Ocupación por salida'}</b>
                    <span>{'Datos mock'}</span>
                  </div>
                  <div className="bar-row">
                    <span>{'21:00'}</span>
                    <div>
                      <i style={{ width: '72%' }}></i>
                    </div>
                    <b>{'72%'}</b>
                  </div>
                  <div className="bar-row">
                    <span>{'22:00'}</span>
                    <div>
                      <i style={{ width: '91%' }}></i>
                    </div>
                    <b>{'91%'}</b>
                  </div>
                  <div className="bar-row">
                    <span>{'23:00'}</span>
                    <div>
                      <i style={{ width: '84%' }}></i>
                    </div>
                    <b>{'84%'}</b>
                  </div>
                  <div className="chart-foot">
                    {'Tres salidas · Ejemplo visual de seguimiento'}
                  </div>
                </div>
              </div>
            </div>
          </section>
        </>
      )}
    </MoveSurface>
  );
}
