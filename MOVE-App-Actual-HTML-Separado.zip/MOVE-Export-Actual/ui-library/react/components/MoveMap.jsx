import React, { useId } from 'react';
import { MoveSurface } from '../MoveSurface.jsx';

/** Patrón map usado en views.trip(). */
export function MoveMap({
  theme = 'light',
  tenant = 'tp',
  reducedMotion = false,
  onAction,
  className = '',
  style,
  children,
}) {
  const uid = useId();
  return (
    <MoveSurface
      theme={theme}
      tenant={tenant}
      reducedMotion={reducedMotion}
      onAction={onAction}
      className={'' + ' ' + className}
      style={style}
    >
      {children ?? (
        <>
          <div
            className="map"
            role="img"
            aria-label="Mapa esquemático de una ruta simulada de Churchill a Pantoja"
          >
            <div className="map-label">
              <svg
                className="icon"
                viewBox="0 0 24 24"
                aria-hidden="true"
                xmlns="http://www.w3.org/2000/svg"
              >
                <path
                  d="M20 10c0 6-8 12-8 12S4 16 4 10a8 8 0 1 1 16 0M15 10a3 3 0 1 1-6 0 3 3 0 0 1 6 0"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                ></path>
              </svg>
              {'Santo Domingo · Ruta 04'}
            </div>
            <svg
              viewBox="0 0 500 520"
              preserveAspectRatio="xMidYMid slice"
              xmlns="http://www.w3.org/2000/svg"
            >
              <rect width="500" height="520" fill="#f0f1f3"></rect>
              <g fill="#e3e7e4">
                <path d="M20 40h90v65H20zM335 55h115v90H335zM260 330h95v90h-95zM45 375h95v100H45z"></path>
              </g>
              <g stroke="white" strokeWidth="16" fill="none">
                <path d="M-20 120L530 200M-20 270L530 350M-20 420L530 500M80-20L20 540M220-20L160 540M360-20L300 540M500-20L440 540"></path>
              </g>
              <g stroke="#d8dce2" strokeWidth="2" fill="none">
                <path d="M-20 120L530 200M-20 270L530 350M-20 420L530 500M80-20L20 540M220-20L160 540M360-20L300 540M500-20L440 540"></path>
              </g>
              <path
                d="M420 424L315 409L331 320L193 299L214 153L91 136"
                stroke="var(--pink)"
                strokeWidth="8"
                strokeLinejoin="round"
                fill="none"
              ></path>
              <path
                d="M420 424L315 409L331 320"
                stroke="#23232c"
                strokeWidth="8"
                strokeLinejoin="round"
                fill="none"
              ></path>
              <circle
                cx="420"
                cy="424"
                r="10"
                fill="white"
                stroke="#23232c"
                strokeWidth="4"
              ></circle>
              <circle
                cx="91"
                cy="136"
                r="11"
                fill="var(--pink)"
                stroke="white"
                strokeWidth="5"
              ></circle>
              <g fontFamily="sans-serif" fill="#7a8188" fontSize="12">
                <text x="285" y="476">
                  {'CHURCHILL'}
                </text>
                <text x="28" y="104">
                  {'PANTOJA'}
                </text>
                <text x="54" y="246" transform="rotate(8 54 246)">
                  {'Autopista Duarte'}
                </text>
                <text x="230" y="57">
                  {'Los Ríos'}
                </text>
              </g>
              <circle
                cx="255"
                cy="308"
                r="29"
                fill="var(--pink)"
                opacity=".12"
              ></circle>
              <circle
                cx="255"
                cy="308"
                r="18"
                fill="var(--pink)"
                stroke="white"
                strokeWidth="4"
              ></circle>
              <path d="M249 312l6-13 6 13-6-3z" fill="white"></path>
            </svg>
            <span
              style={{
                position: 'absolute',
                bottom: '15px',
                right: '15px',
                fontSize: '11px',
                backgroundImage: 'none',
                backgroundPositionX: '0%',
                backgroundPositionY: '0%',
                backgroundPosition: '0% 0%',
                backgroundSize: 'auto',
                backgroundRepeat: 'repeat',
                backgroundOrigin: 'padding-box',
                backgroundClip: 'border-box',
                backgroundAttachment: 'scroll',
                backgroundColor: 'white',
                background: 'white',
                paddingTop: '6px',
                paddingRight: '10px',
                paddingBottom: '6px',
                paddingLeft: '10px',
                padding: '6px 10px',
                borderRadius: '8px',
              }}
            >
              {'Mapa esquemático · Sin GPS real'}
            </span>
          </div>
        </>
      )}
    </MoveSurface>
  );
}
