import React, { useId } from 'react';
import { MoveSurface } from '../MoveSurface.jsx';

/** Patrón ops-trip-top usado en opsOperationView(). */
export function MoveOpsTripTop({
  theme = 'light',
  tenant = 'tp',
  reducedMotion = false,
  onAction,
  className = '',
  style,
  children,
}) {
  const uid = useId();
  return (
    <MoveSurface
      theme={theme}
      tenant={tenant}
      reducedMotion={reducedMotion}
      onAction={onAction}
      className={'' + ' ' + className}
      style={style}
    >
      {children ?? (
        <>
          <div className="ops-trip-top">
            <small>{'TR-1040 · RUTA 07'}</small>
            <span className="ops-pill active">{'En viaje'}</span>
          </div>
        </>
      )}
    </MoveSurface>
  );
}
