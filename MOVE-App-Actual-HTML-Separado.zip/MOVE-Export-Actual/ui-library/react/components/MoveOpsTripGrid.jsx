import React, { useId } from 'react';
import { MoveSurface } from '../MoveSurface.jsx';

/** Patrón ops-trip-grid usado en opsOperationView(). */
export function MoveOpsTripGrid({
  theme = 'light',
  tenant = 'tp',
  reducedMotion = false,
  onAction,
  className = '',
  style,
  children,
}) {
  const uid = useId();
  return (
    <MoveSurface
      theme={theme}
      tenant={tenant}
      reducedMotion={reducedMotion}
      onAction={onAction}
      className={'' + ' ' + className}
      style={style}
    >
      {children ?? (
        <>
          <div className="ops-trip-grid">
            <article
              className="ops-trip-card"
              tabIndex="0"
              role="button"
              aria-label="Abrir TR-1040"
              data-move-click="openOpsTrip('TR-1040')"
              data-move-keydown="if(event.key==='Enter'||event.key===' '){event.preventDefault();openOpsTrip('TR-1040')}"
            >
              <div className="ops-trip-top">
                <small>{'TR-1040 · RUTA 07'}</small>
                <span className="ops-pill active">{'En viaje'}</span>
              </div>
              <h3>{'Los Girasoles'}</h3>
              <p className="ops-trip-site">
                {'TP · Churchill · Jornada anterior'}
              </p>
              <div className="ops-trip-stats">
                <div>
                  <small>{'Salida'}</small>
                  <b>{'00:30'}</b>
                </div>
                <div>
                  <small>{'A bordo'}</small>
                  <b>{'12 / 12'}</b>
                </div>
                <div>
                  <small>{'Unidad'}</small>
                  <b>{'12'}</b>
                </div>
              </div>
              <div className="ops-trip-driver">
                <svg
                  className="icon"
                  viewBox="0 0 24 24"
                  aria-hidden="true"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    d="M20 21v-2a6 6 0 0 0-6-6h-4a6 6 0 0 0-6 6v2M16 6a4 4 0 1 1-8 0 4 4 0 0 1 8 0"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  ></path>
                </svg>
                <b>{'Ángel Ramírez'}</b>
                <small>{'Asignación actual'}</small>
              </div>
              <div className="ops-trip-progress">
                <span>{'Progreso del recorrido'}</span>
                <span data-ops-progress-label="TR-1040">
                  {'43% · ETA 01:08'}
                </span>
              </div>
              <div className="ops-bar">
                <span
                  data-ops-progress="TR-1040"
                  style={{ width: '43%' }}
                ></span>
              </div>
            </article>
            <article
              className="ops-trip-card"
              tabIndex="0"
              role="button"
              aria-label="Abrir TR-1041"
              data-move-click="openOpsTrip('TR-1041')"
              data-move-keydown="if(event.key==='Enter'||event.key===' '){event.preventDefault();openOpsTrip('TR-1041')}"
            >
              <div className="ops-trip-top">
                <small>{'TR-1041 · RUTA 04'}</small>
                <span className="ops-pill boarding">{'Abordaje'}</span>
              </div>
              <h3>{'Pantoja'}</h3>
              <p className="ops-trip-site">{'TP · Churchill'}</p>
              <div className="ops-trip-stats">
                <div>
                  <small>{'Salida'}</small>
                  <b>{'00:30'}</b>
                </div>
                <div>
                  <small>{'A bordo'}</small>
                  <b>{'6 / 8'}</b>
                </div>
                <div>
                  <small>{'Unidad'}</small>
                  <b>{'13'}</b>
                </div>
              </div>
              <div className="ops-trip-driver">
                <svg
                  className="icon"
                  viewBox="0 0 24 24"
                  aria-hidden="true"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    d="M20 21v-2a6 6 0 0 0-6-6h-4a6 6 0 0 0-6 6v2M16 6a4 4 0 1 1-8 0 4 4 0 0 1 8 0"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  ></path>
                </svg>
                <b>{'Sin conductor'}</b>
                <small>{'Trip disponible'}</small>
              </div>
              <div className="ops-trip-progress">
                <span>{'Abordaje conservado'}</span>
                <span data-ops-progress-label="TR-1041">
                  {'0% · ETA 00:18'}
                </span>
              </div>
              <div className="ops-bar">
                <span
                  data-ops-progress="TR-1041"
                  style={{ width: '0%' }}
                ></span>
              </div>
            </article>
            <article
              className="ops-trip-card"
              tabIndex="0"
              role="button"
              aria-label="Abrir TR-1042"
              data-move-click="openOpsTrip('TR-1042')"
              data-move-keydown="if(event.key==='Enter'||event.key===' '){event.preventDefault();openOpsTrip('TR-1042')}"
            >
              <div className="ops-trip-top">
                <small>{'TR-1042 · RUTA 04'}</small>
                <span className="ops-pill completed">{'Finalizado'}</span>
              </div>
              <h3>{'Pantoja'}</h3>
              <p className="ops-trip-site">{'TP · Churchill'}</p>
              <div className="ops-trip-stats">
                <div>
                  <small>{'Salida'}</small>
                  <b>{'23:30'}</b>
                </div>
                <div>
                  <small>{'A bordo'}</small>
                  <b>{'12 / 12'}</b>
                </div>
                <div>
                  <small>{'Unidad'}</small>
                  <b>{'14'}</b>
                </div>
              </div>
              <div className="ops-trip-driver">
                <svg
                  className="icon"
                  viewBox="0 0 24 24"
                  aria-hidden="true"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    d="M20 21v-2a6 6 0 0 0-6-6h-4a6 6 0 0 0-6 6v2M16 6a4 4 0 1 1-8 0 4 4 0 0 1 8 0"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  ></path>
                </svg>
                <b>{'Pedro Castillo'}</b>
                <small>{'Asignación actual'}</small>
              </div>
              <div className="ops-trip-progress">
                <span>{'Progreso del recorrido'}</span>
                <span data-ops-progress-label="TR-1042">
                  {'100% · ETA 23:55'}
                </span>
              </div>
              <div className="ops-bar">
                <span
                  data-ops-progress="TR-1042"
                  style={{ width: '100%' }}
                ></span>
              </div>
            </article>
          </div>
        </>
      )}
    </MoveSurface>
  );
}
