import React, { useId } from 'react';
import { MoveSurface } from '../MoveSurface.jsx';

/** Campo inválido con error asociado accesible. */
export function MoveTextFieldError({
  theme = 'light',
  tenant = 'tp',
  reducedMotion = false,
  onAction,
  className = '',
  style,
  children,
}) {
  const uid = useId();
  return (
    <MoveSurface
      theme={theme}
      tenant={tenant}
      reducedMotion={reducedMotion}
      onAction={onAction}
      className={'' + ' ' + className}
      style={style}
    >
      {children ?? (
        <>
          <div>
            <label className="label" htmlFor={uid + '-email-error'}>
              {'Correo personal'}
            </label>
            <input
              id={uid + '-email-error'}
              type="email"
              defaultValue="correo@ejemplo.com"
              aria-invalid="true"
              aria-describedby={uid + '-email-error-message'}
            />
            <p
              id={uid + '-email-error-message'}
              className="form-error"
              role="alert"
            >
              {'Tu correo no está autorizado.'}
            </p>
          </div>
        </>
      )}
    </MoveSurface>
  );
}
