import React, { useId } from 'react';
import { MoveSurface } from '../MoveSurface.jsx';

/** Patrón settings-account usado en settingsView(). */
export function MoveSettingsAccount({
  theme = 'light',
  tenant = 'tp',
  reducedMotion = false,
  onAction,
  className = '',
  style,
  children,
}) {
  const uid = useId();
  return (
    <MoveSurface
      theme={theme}
      tenant={tenant}
      reducedMotion={reducedMotion}
      onAction={onAction}
      className={'' + ' ' + className}
      style={style}
    >
      {children ?? (
        <>
          <section className="card settings-account">
            <h2>{'Cuenta y privacidad'}</h2>
            <div className="info-grid">
              <div>
                <small>{'Empresa'}</small>
                <b>{'TP'}</b>
              </div>
              <div>
                <small>{'Perfil'}</small>
                <b>{'Colaborador'}</b>
              </div>
            </div>
            <p className="small-info">
              {'Tus preferencias se guardan en este navegador.'}
            </p>
            <button
              className="btn secondary"
              data-move-click="resetPreferences()"
            >
              {'Restablecer preferencias'}
            </button>
            <button className="text-btn" data-move-click="logoutMove()">
              {'Cerrar sesión'}
            </button>
          </section>
        </>
      )}
    </MoveSurface>
  );
}
