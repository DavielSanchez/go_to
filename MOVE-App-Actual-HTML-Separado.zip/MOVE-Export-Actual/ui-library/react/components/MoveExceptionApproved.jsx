import React, { useId } from 'react';
import { MoveSurface } from '../MoveSurface.jsx';

/** Bloque extraído del diseño actual de MOVE. Los eventos se exponen mediante onAction. */
export function MoveExceptionApproved({
  theme = 'light',
  tenant = 'tp',
  reducedMotion = false,
  onAction,
  className = '',
  style,
  children,
}) {
  const uid = useId();
  return (
    <MoveSurface
      theme={theme}
      tenant={tenant}
      reducedMotion={reducedMotion}
      onAction={onAction}
      className={'' + ' ' + className}
      style={style}
    >
      {children ?? (
        <>
          <div className="narrow">
            <div className="page-top">
              <div>
                <h1>{'Excepción de transporte'}</h1>
                <p className="sub">
                  {'Solicítala para hoy o para otra fecha.'}
                </p>
              </div>
            </div>
            <div className="card success">
              <span className="review-icon">
                <svg
                  className="icon"
                  viewBox="0 0 24 24"
                  aria-hidden="true"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    d="M5 12l4 4L19 6"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  ></path>
                </svg>
              </span>
              <span className="pill green">{'Aprobada'}</span>
              <h2>{'Tu transporte fue aprobado'}</h2>
              <div className="summary">
                <div>
                  <b>{'undefined'}</b>
                  <p>{'4 de octubre de 2026 · Salida undefined'}</p>
                </div>
              </div>
              <p className="small-info">
                {
                  'Presenta el ticket QR para abordar la unidad y salida asignadas.'
                }
              </p>
              <button
                className="btn"
                style={{ marginTop: '20px' }}
                data-move-click="navigate('ticket')"
              >
                {'Ver mi ticket QR'}
              </button>
              <button
                className="btn secondary"
                style={{ marginTop: '18px' }}
                data-move-click="newException()"
              >
                {'Solicitar para otra fecha'}
              </button>
            </div>
            <p className="demo-note">
              {'Vista de demostración · Datos de ejemplo'}
            </p>
          </div>
        </>
      )}
    </MoveSurface>
  );
}
