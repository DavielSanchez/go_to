import React, { useId } from 'react';
import { MoveSurface } from '../MoveSurface.jsx';

/** Patrón ops-integration usado en opsConfigurationView(). */
export function MoveOpsIntegration({
  theme = 'light',
  tenant = 'tp',
  reducedMotion = false,
  onAction,
  className = '',
  style,
  children,
}) {
  const uid = useId();
  return (
    <MoveSurface
      theme={theme}
      tenant={tenant}
      reducedMotion={reducedMotion}
      onAction={onAction}
      className={'' + ' ' + className}
      style={style}
    >
      {children ?? (
        <>
          <div className="ops-integration">
            <h3>{'IEX · SQL Server'}</h3>
            <p>
              <b>{'Lectura de horarios disponible'}</b>
            </p>
            <p>{'Última sincronización: 04/10/2026, 00:00:00'}</p>
            <p>{'Elegibilidad cada 2 horas · inicio 00:00'}</p>
            <p>
              {'116 empleados evaluados · 84 confirmaciones satisfactorias'}
            </p>
          </div>
        </>
      )}
    </MoveSurface>
  );
}
