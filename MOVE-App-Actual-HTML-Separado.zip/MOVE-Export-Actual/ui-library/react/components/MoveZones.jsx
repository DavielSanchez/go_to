import React, { useId } from 'react';
import { MoveSurface } from '../MoveSurface.jsx';

/** Bloque extraído del diseño actual de MOVE. Los eventos se exponen mediante onAction. */
export function MoveZones({
  theme = 'light',
  tenant = 'tp',
  reducedMotion = false,
  onAction,
  className = '',
  style,
  children,
}) {
  const uid = useId();
  return (
    <MoveSurface
      theme={theme}
      tenant={tenant}
      reducedMotion={reducedMotion}
      onAction={onAction}
      className={'' + ' ' + className}
      style={style}
    >
      {children ?? (
        <>
          <div className="management-controls">
            <button className="ops-button" data-move-click="newZone()">
              {'Nueva zona'}
            </button>
            <p className="ops-muted">
              {'Cada zona es una ruta; sus viajes se mantienen separados.'}
            </p>
          </div>
          <div className="zone-workspace">
            <section className="ops-card zone-list">
              <h2>{'Rutas de servicio'}</h2>
              <button
                className="zone-item "
                data-move-click="selectZone('tp-churchill-07')"
              >
                <b>{'Los Girasoles'}</b>
                <small>{'Ruta 07 · v1 · 4 puntos'}</small>
              </button>
              <button
                className="zone-item "
                data-move-click="selectZone('tp-churchill-04')"
              >
                <b>{'Pantoja'}</b>
                <small>{'Ruta 04 · v1 · 4 puntos'}</small>
              </button>
            </section>
            <section className="ops-card zone-editor">
              <div
                className="zone-tools"
                role="group"
                aria-label="Herramientas del mapa"
              >
                <button
                  className="ops-button secondary "
                  data-move-click="setZoneMode('pan')"
                >
                  {'Mover mapa'}
                </button>
                <button
                  className="ops-button secondary selected"
                  data-move-click="setZoneMode('points')"
                >
                  {'Por puntos'}
                </button>
                <button
                  className="ops-button secondary "
                  data-move-click="setZoneMode('freehand')"
                >
                  {'Trazo libre'}
                </button>
                <button
                  className="ops-button secondary"
                  data-move-click="undoZonePoint()"
                >
                  {'Deshacer'}
                </button>
                <button
                  className="ops-button secondary"
                  data-move-click="clearZone()"
                >
                  {'Limpiar'}
                </button>
              </div>
              <div
                id={uid + '-zoneMap'}
                className="zone-map"
                aria-label="Editor de zonas geográficas"
              ></div>
              <p id={uid + '-zonePointCount'} className="ops-muted">
                {'0 puntos · Arrastra los vértices para ajustar el límite.'}
              </p>
              <form data-move-submit="saveZone(event)" data-move-form="">
                <div className="ops-form-grid">
                  <label className="ops-label">
                    {'Nombre de la zona'}
                    <input
                      name="name"
                      defaultValue=""
                      required
                      data-move-input="zoneDraft.name=this.value"
                    />
                  </label>
                  <label className="ops-label">
                    {'Código de ruta'}
                    <input
                      name="route"
                      defaultValue=""
                      maxLength="12"
                      pattern="[A-Za-z0-9-]+"
                      required
                      data-move-input="zoneDraft.route=this.value"
                    />
                  </label>
                </div>
                <label className="ops-label">
                  {'Motivo'}
                  <input name="reason" minLength="8" maxLength="500" required />
                </label>
                <p className="ops-muted">
                  {
                    'La nueva versión se aplica a futuras planificaciones. Los viajes existentes conservan su ruta.'
                  }
                </p>
                <p
                  className="ops-form-error"
                  role="alert"
                  id={uid + '-managementError'}
                ></p>
                <button className="ops-button">{'Guardar zona'}</button>
              </form>
            </section>
          </div>
        </>
      )}
    </MoveSurface>
  );
}
