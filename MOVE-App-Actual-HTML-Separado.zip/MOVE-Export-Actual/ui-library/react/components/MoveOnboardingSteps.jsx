import React, { useId } from 'react';
import { MoveSurface } from '../MoveSurface.jsx';

/** Patrón onboarding-steps usado en onboardingView(). */
export function MoveOnboardingSteps({
  theme = 'light',
  tenant = 'tp',
  reducedMotion = false,
  onAction,
  className = '',
  style,
  children,
}) {
  const uid = useId();
  return (
    <MoveSurface
      theme={theme}
      tenant={tenant}
      reducedMotion={reducedMotion}
      onAction={onAction}
      className={'' + ' ' + className}
      style={style}
    >
      {children ?? (
        <>
          <div className="onboarding-steps">
            <span className="active">{'1. Identidad'}</span>
            <span className="">{'2. Vehículo'}</span>
            <span className="">{'3. Revisión'}</span>
          </div>
        </>
      )}
    </MoveSurface>
  );
}
