import React, { useId } from 'react';
import { MoveSurface } from '../MoveSurface.jsx';

/** Patrón stop-row usado en driverViews['driver-home'](). */
export function MoveStopRow({
  theme = 'light',
  tenant = 'tp',
  reducedMotion = false,
  onAction,
  className = '',
  style,
  children,
}) {
  const uid = useId();
  return (
    <MoveSurface
      theme={theme}
      tenant={tenant}
      reducedMotion={reducedMotion}
      onAction={onAction}
      className={'' + ' ' + className}
      style={style}
    >
      {children ?? (
        <>
          <div className="stop-row">
            <span className="stop-number">{'1'}</span>
            <div>
              <b>{'Los Girasoles'}</b>
              <p className="small-info">{'Ana Pérez · Carlos Mejía'}</p>
            </div>
          </div>
        </>
      )}
    </MoveSurface>
  );
}
