import React, { useId } from 'react';
import { MoveSurface } from '../MoveSurface.jsx';

/** Patrón ops-card usado en opsOverviewView(). */
export function MoveOpsCard({
  theme = 'light',
  tenant = 'tp',
  reducedMotion = false,
  onAction,
  className = '',
  style,
  children,
}) {
  const uid = useId();
  return (
    <MoveSurface
      theme={theme}
      tenant={tenant}
      reducedMotion={reducedMotion}
      onAction={onAction}
      className={'' + ' ' + className}
      style={style}
    >
      {children ?? (
        <>
          <section className="ops-card">
            <div className="ops-section-title">
              <div>
                <span className="ops-eyebrow">{'DESPACHO'}</span>
                <h2>{'Próximas ventanas'}</h2>
              </div>
              <a href="#ops-operation">{'Abrir operación'}</a>
            </div>
            <div className="ops-window-row">
              <div className="ops-window-time">{'21:30'}</div>
              <div>
                <b>{'0 trips · 0 abordados'}</b>
                <small>{'Ventana de la jornada seleccionada'}</small>
                <div className="ops-bar">
                  <span style={{ width: '0%' }}></span>
                </div>
              </div>
              <span className="ops-pill completed">{'Sin viajes'}</span>
            </div>
            <div className="ops-window-row">
              <div className="ops-window-time">{'22:30'}</div>
              <div>
                <b>{'0 trips · 0 abordados'}</b>
                <small>{'Ventana de la jornada seleccionada'}</small>
                <div className="ops-bar">
                  <span style={{ width: '0%' }}></span>
                </div>
              </div>
              <span className="ops-pill completed">{'Sin viajes'}</span>
            </div>
            <div className="ops-window-row">
              <div className="ops-window-time">{'23:30'}</div>
              <div>
                <b>{'1 trips · 12 abordados'}</b>
                <small>{'Ventana de la jornada seleccionada'}</small>
                <div className="ops-bar">
                  <span style={{ width: '75%' }}></span>
                </div>
              </div>
              <span className="ops-pill completed">{'Finalizado'}</span>
            </div>
            <div className="ops-window-row">
              <div className="ops-window-time">{'00:30'}</div>
              <div>
                <b>{'2 trips · 18 abordados'}</b>
                <small>{'Salida en el día calendario siguiente'}</small>
                <div className="ops-bar">
                  <span style={{ width: '56%' }}></span>
                </div>
              </div>
              <span className="ops-pill active">{'En viaje'}</span>
            </div>
          </section>
        </>
      )}
    </MoveSurface>
  );
}
