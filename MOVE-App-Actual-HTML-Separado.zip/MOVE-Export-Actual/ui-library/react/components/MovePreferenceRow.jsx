import React, { useId } from 'react';
import { MoveSurface } from '../MoveSurface.jsx';

/** Patrón preference-row usado en settingsView(). */
export function MovePreferenceRow({
  theme = 'light',
  tenant = 'tp',
  reducedMotion = false,
  onAction,
  className = '',
  style,
  children,
}) {
  const uid = useId();
  return (
    <MoveSurface
      theme={theme}
      tenant={tenant}
      reducedMotion={reducedMotion}
      onAction={onAction}
      className={'' + ' ' + className}
      style={style}
    >
      {children ?? (
        <>
          <label className="preference-row">
            <span>
              <b>{'Reducir movimiento'}</b>
              <small>
                {'Animaciones suaves o una experiencia más tranquila.'}
              </small>
            </span>
            <input
              type="checkbox"
              role="switch"
              aria-label="Reducir movimiento"
              data-move-change="setPreference('motion',this.checked)"
            />
            <span className="switch-track" aria-hidden="true"></span>
          </label>
        </>
      )}
    </MoveSurface>
  );
}
