import React, { useId } from 'react';
import { MoveSurface } from '../MoveSurface.jsx';

/** Patrón ops-comparison usado en opsStatisticsView(). */
export function MoveOpsComparison({
  theme = 'light',
  tenant = 'tp',
  reducedMotion = false,
  onAction,
  className = '',
  style,
  children,
}) {
  const uid = useId();
  return (
    <MoveSurface
      theme={theme}
      tenant={tenant}
      reducedMotion={reducedMotion}
      onAction={onAction}
      className={'' + ' ' + className}
      style={style}
    >
      {children ?? (
        <>
          <div className="ops-comparison">
            <div>
              <b>{'TP · Churchill'}</b>
              <span>{'88%'}</span>
            </div>
            <div className="ops-bar">
              <span style={{ width: '88%' }}></span>
            </div>
            <p className="ops-muted">{'84 confirmaciones · 116 elegibles'}</p>
          </div>
        </>
      )}
    </MoveSurface>
  );
}
