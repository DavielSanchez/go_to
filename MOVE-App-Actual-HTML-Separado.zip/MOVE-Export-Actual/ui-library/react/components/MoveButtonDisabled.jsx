import React, { useId } from 'react';
import { MoveSurface } from '../MoveSurface.jsx';

/** Estado deshabilitado. */
export function MoveButtonDisabled({
  theme = 'light',
  tenant = 'tp',
  reducedMotion = false,
  onAction,
  className = '',
  style,
  children,
}) {
  const uid = useId();
  return (
    <MoveSurface
      theme={theme}
      tenant={tenant}
      reducedMotion={reducedMotion}
      onAction={onAction}
      className={'' + ' ' + className}
      style={style}
    >
      {children ?? (
        <>
          <button className="btn" disabled>
            {'Confirmar transporte'}
          </button>
        </>
      )}
    </MoveSurface>
  );
}
