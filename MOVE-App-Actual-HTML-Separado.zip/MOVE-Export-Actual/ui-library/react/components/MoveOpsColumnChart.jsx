import React, { useId } from 'react';
import { MoveSurface } from '../MoveSurface.jsx';

/** Patrón ops-column-chart usado en opsStatisticsView(). */
export function MoveOpsColumnChart({
  theme = 'light',
  tenant = 'tp',
  reducedMotion = false,
  onAction,
  className = '',
  style,
  children,
}) {
  const uid = useId();
  return (
    <MoveSurface
      theme={theme}
      tenant={tenant}
      reducedMotion={reducedMotion}
      onAction={onAction}
      className={'' + ' ' + className}
      style={style}
    >
      {children ?? (
        <>
          <div
            className="ops-column-chart"
            aria-label="Ocupación de las últimas siete jornadas"
          >
            <div className="ops-column">
              <b>{'81%'}</b>
              <span style={{ height: '81%' }}></span>
              <small>{'D-6'}</small>
            </div>
            <div className="ops-column">
              <b>{'85%'}</b>
              <span style={{ height: '85%' }}></span>
              <small>{'D-5'}</small>
            </div>
            <div className="ops-column">
              <b>{'83%'}</b>
              <span style={{ height: '83%' }}></span>
              <small>{'D-4'}</small>
            </div>
            <div className="ops-column">
              <b>{'86%'}</b>
              <span style={{ height: '86%' }}></span>
              <small>{'D-3'}</small>
            </div>
            <div className="ops-column">
              <b>{'87%'}</b>
              <span style={{ height: '87%' }}></span>
              <small>{'D-2'}</small>
            </div>
            <div className="ops-column">
              <b>{'84%'}</b>
              <span style={{ height: '84%' }}></span>
              <small>{'D-1'}</small>
            </div>
            <div className="ops-column">
              <b>{'88%'}</b>
              <span style={{ height: '88%' }}></span>
              <small>{'Jornada'}</small>
            </div>
          </div>
        </>
      )}
    </MoveSurface>
  );
}
