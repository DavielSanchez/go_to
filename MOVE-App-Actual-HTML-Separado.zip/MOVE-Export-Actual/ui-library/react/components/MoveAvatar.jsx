import React, { useId } from 'react';
import { MoveSurface } from '../MoveSurface.jsx';

/** Avatar con iniciales. */
export function MoveAvatar({
  theme = 'light',
  tenant = 'tp',
  reducedMotion = false,
  onAction,
  className = '',
  style,
  children,
}) {
  const uid = useId();
  return (
    <MoveSurface
      theme={theme}
      tenant={tenant}
      reducedMotion={reducedMotion}
      onAction={onAction}
      className={'' + ' ' + className}
      style={style}
    >
      {children ?? (
        <>
          <span className="avatar" aria-label="Daviel Sánchez">
            {'DS'}
          </span>
        </>
      )}
    </MoveSurface>
  );
}
