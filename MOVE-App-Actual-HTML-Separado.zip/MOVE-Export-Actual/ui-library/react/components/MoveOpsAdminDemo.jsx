import React, { useId } from 'react';
import { MoveSurface } from '../MoveSurface.jsx';

/** Patrón ops-admin-demo usado en loginView(). */
export function MoveOpsAdminDemo({
  theme = 'light',
  tenant = 'tp',
  reducedMotion = false,
  onAction,
  className = '',
  style,
  children,
}) {
  const uid = useId();
  return (
    <MoveSurface
      theme={theme}
      tenant={tenant}
      reducedMotion={reducedMotion}
      onAction={onAction}
      className={'' + ' ' + className}
      style={style}
    >
      {children ?? (
        <>
          <section className="ops-admin-demo">
            <b>{'Portales de operación'}</b>
            <p>{'Accesos de demostración para revisar roles y alcances.'}</p>
            <div className="ops-admin-demo-buttons">
              <button
                type="button"
                data-move-click="fillOpsLogin('site-admin')"
              >
                {'Administrador'}
                <small>{'1 site de TP'}</small>
              </button>
              <button
                type="button"
                data-move-click="fillOpsLogin('coordinator')"
              >
                {'Coordinación de transporte'}
                <small>{'1 site de TP'}</small>
              </button>
              <button
                type="button"
                data-move-click="fillOpsLogin('company-admin')"
              >
                {'Country Admin'}
                <small>{'3 sites de TP'}</small>
              </button>
              <button type="button" data-move-click="fillOpsLogin('platform')">
                {'Administrador de MOVE'}
                <small>{'MOVE · todas las empresas'}</small>
              </button>
            </div>
          </section>
        </>
      )}
    </MoveSurface>
  );
}
