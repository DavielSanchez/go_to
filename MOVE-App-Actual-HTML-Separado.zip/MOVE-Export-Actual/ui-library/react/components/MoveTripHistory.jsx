import React, { useId } from 'react';
import { MoveSurface } from '../MoveSurface.jsx';

/** Bloque extraído del diseño actual de MOVE. Los eventos se exponen mediante onAction. */
export function MoveTripHistory({
  theme = 'light',
  tenant = 'tp',
  reducedMotion = false,
  onAction,
  className = '',
  style,
  children,
}) {
  const uid = useId();
  return (
    <MoveSurface
      theme={theme}
      tenant={tenant}
      reducedMotion={reducedMotion}
      onAction={onAction}
      className={'' + ' ' + className}
      style={style}
    >
      {children ?? (
        <>
          <section className="ops-card">
            <div className="ops-section-title">
              <h2>{'Todos los viajes'}</h2>
            </div>
            <div className="management-controls">
              <select
                aria-label="Filtrar historial"
                data-move-change="historyStatus=this.value;render()"
                defaultValue="all"
              >
                <option value="all">{'Todos los estados'}</option>
                <option value="active">{'En viaje'}</option>
                <option value="boarding">{'Abordaje'}</option>
                <option value="completed">{'Finalizado'}</option>
                <option value="paused">{'Pausado'}</option>
              </select>
            </div>
            <div className="ops-table-scroll">
              <table className="ops-table">
                <thead>
                  <tr>
                    <th>{'Viaje'}</th>
                    <th>{'Jornada / salida'}</th>
                    <th>{'Ruta'}</th>
                    <th>{'Pasajeros'}</th>
                    <th>{'Estado'}</th>
                    <th></th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td>
                      <b>{'TR-1040'}</b>
                      <small>{'Ángel Ramírez'}</small>
                    </td>
                    <td>
                      {'3 de octubre de 2026'}
                      <small>{'00:30'}</small>
                    </td>
                    <td>{'Los Girasoles'}</td>
                    <td>{'12 / 12'}</td>
                    <td>
                      <span className="ops-pill active">{'En viaje'}</span>
                    </td>
                    <td>
                      <button
                        className="ops-button secondary"
                        data-move-click="openOpsTrip('TR-1040')"
                      >
                        {'Ver viaje'}
                      </button>
                    </td>
                  </tr>
                  <tr>
                    <td>
                      <b>{'TR-1041'}</b>
                      <small>{'Sin conductor'}</small>
                    </td>
                    <td>
                      {'3 de octubre de 2026'}
                      <small>{'00:30'}</small>
                    </td>
                    <td>{'Pantoja'}</td>
                    <td>{'6 / 8'}</td>
                    <td>
                      <span className="ops-pill boarding">{'Abordaje'}</span>
                    </td>
                    <td>
                      <button
                        className="ops-button secondary"
                        data-move-click="openOpsTrip('TR-1041')"
                      >
                        {'Ver viaje'}
                      </button>
                    </td>
                  </tr>
                  <tr>
                    <td>
                      <b>{'TR-1042'}</b>
                      <small>{'Pedro Castillo'}</small>
                    </td>
                    <td>
                      {'3 de octubre de 2026'}
                      <small>{'23:30'}</small>
                    </td>
                    <td>{'Pantoja'}</td>
                    <td>{'12 / 12'}</td>
                    <td>
                      <span className="ops-pill completed">{'Finalizado'}</span>
                    </td>
                    <td>
                      <button
                        className="ops-button secondary"
                        data-move-click="openOpsTrip('TR-1042')"
                      >
                        {'Ver viaje'}
                      </button>
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
          </section>
        </>
      )}
    </MoveSurface>
  );
}
