import React, { useId } from 'react';
import { MoveSurface } from '../MoveSurface.jsx';

/** Patrón ops-audit-filters usado en opsAuditView(). */
export function MoveOpsAuditFilters({
  theme = 'light',
  tenant = 'tp',
  reducedMotion = false,
  onAction,
  className = '',
  style,
  children,
}) {
  const uid = useId();
  return (
    <MoveSurface
      theme={theme}
      tenant={tenant}
      reducedMotion={reducedMotion}
      onAction={onAction}
      className={'' + ' ' + className}
      style={style}
    >
      {children ?? (
        <>
          <div className="ops-audit-filters">
            <input
              type="search"
              id={uid + '-auditSearch'}
              placeholder="Buscar usuario, acción, trip o motivo…"
              defaultValue=""
              data-move-input="filterOpsAudit(this.value)"
            />
            <label>
              <input
                type="checkbox"
                data-move-change="setAuditImpersonated(this.checked)"
              />
              {'\n    Solo impersonación'}
            </label>
            <button
              className="ops-button secondary"
              data-move-click="exportOpsAudit()"
            >
              {'\n    Exportar registros visibles\n  '}
            </button>
          </div>
        </>
      )}
    </MoveSurface>
  );
}
