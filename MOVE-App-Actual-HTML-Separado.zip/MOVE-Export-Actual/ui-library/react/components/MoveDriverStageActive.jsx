import React, { useId } from 'react';
import { MoveSurface } from '../MoveSurface.jsx';

/** Bloque extraído del diseño actual de MOVE. Los eventos se exponen mediante onAction. */
export function MoveDriverStageActive({
  theme = 'light',
  tenant = 'tp',
  reducedMotion = false,
  onAction,
  className = '',
  style,
  children,
}) {
  const uid = useId();
  return (
    <MoveSurface
      theme={theme}
      tenant={tenant}
      reducedMotion={reducedMotion}
      onAction={onAction}
      className={'' + ' ' + className}
      style={style}
    >
      {children ?? (
        <>
          <div className="date">{'4 DE OCTUBRE DE 2026'}</div>
          <div className="page-top">
            <div>
              <h1>
                {'Hola, José '}
                <span className="accent">{'.'}</span>
              </h1>
              <p className="sub">{'Transporte externo · Proveedor asignado'}</p>
            </div>
          </div>
          <div className="home-grid">
            <section>
              <div className="card hero">
                <span className="pill">{'VIAJE EN CURSO'}</span>
                <h2>{'Los Girasoles'}</h2>
                <p>{'Tu próxima parada · 0 pasajeros abordaron.'}</p>
                <button
                  className="btn"
                  style={{ marginTop: '24px' }}
                  data-move-click="navigate('driver-route')"
                >
                  {'Ver navegación'}
                </button>
              </div>
            </section>
            <section>
              <div className="card">
                <h2>{'Vehículos de la misma zona'}</h2>
                <p className="small-info" style={{ marginTop: '10px' }}>
                  {
                    'Zona 04 · Los Alcarrizos. El orden de llegada reparte los pasajeros entre unidades; cada conductor escanea su grupo al mismo tiempo.'
                  }
                </p>
                <div className="zone-vehicle">
                  <div>
                    <b>{'Unidad 10'}</b>
                    <p className="small-info">
                      {'Llegada 1 · 6 pasajeros asignados'}
                    </p>
                  </div>
                  <span className="pill green">{'0/6 a bordo'}</span>
                </div>
                <div className="zone-vehicle">
                  <div>
                    <b>{'Unidad 11'}</b>
                    <p className="small-info">
                      {'Llegada 2 · 6 pasajeros asignados'}
                    </p>
                  </div>
                  <span className="pill green">{'0/6 a bordo'}</span>
                </div>
                <div className="zone-vehicle">
                  <div>
                    <b>{'Unidad 12 · Tú'}</b>
                    <p className="small-info">
                      {'Llegada 3 · 6 pasajeros asignados'}
                    </p>
                  </div>
                  <span className="pill green">{'0/6 a bordo'}</span>
                </div>
                <details style={{ marginTop: '18px' }}>
                  <summary>{'Probar abordaje simultáneo'}</summary>
                  <p
                    className="small-info"
                    style={{
                      marginTop: '12px',
                      marginRight: '0px',
                      marginBottom: '12px',
                      marginLeft: '0px',
                      margin: '12px 0px',
                    }}
                  >
                    {
                      'Simula escaneos en las otras unidades. Sus registros no cambian tus pasajeros ni bloquean tu escáner.'
                    }
                  </p>
                  <div className="form-actions">
                    <button
                      className="btn secondary"
                      data-move-click="scanOtherVehicle('10')"
                    >
                      {'Escanear en unidad 10'}
                    </button>
                    <button
                      className="btn secondary"
                      data-move-click="scanOtherVehicle('11')"
                    >
                      {'Escanear en unidad 11'}
                    </button>
                  </div>
                </details>
              </div>
              <div className="card">
                <h2>{'Tu jornada'}</h2>
                <div className="metric-row">
                  <div>
                    <strong>{'0'}</strong>
                    <small>{'Abordaron'}</small>
                  </div>
                  <div>
                    <strong>{'0'}</strong>
                    <small>{'Incidencias'}</small>
                  </div>
                  <div>
                    <strong>{'0'}</strong>
                    <small>{'Viajes completados'}</small>
                  </div>
                </div>
              </div>
              <a className="card help-card" href="#driver-incident">
                <span className="icon-box">
                  <svg
                    className="icon"
                    viewBox="0 0 24 24"
                    aria-hidden="true"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path
                      d="M12 11v6m0-10v.01M22 12a10 10 0 1 1-20 0 10 10 0 0 1 20 0"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    ></path>
                  </svg>
                </span>
                <div>
                  <h3>{'Reportar una incidencia'}</h3>
                  <p>{'Avería, retraso, seguridad u otro problema.'}</p>
                </div>
                <svg
                  className="icon"
                  viewBox="0 0 24 24"
                  aria-hidden="true"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    d="M9 5l7 7-7 7"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  ></path>
                </svg>
              </a>
              <div className="notice">
                <svg
                  className="icon"
                  viewBox="0 0 24 24"
                  aria-hidden="true"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    d="M12 11v6m0-10v.01M22 12a10 10 0 1 1-20 0 10 10 0 0 1 20 0"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  ></path>
                </svg>
                <span>
                  {
                    'Proveedor y asignaciones de ejemplo. El registro inicial no sustituye la revisión de documentos del proveedor.'
                  }
                </span>
              </div>
            </section>
          </div>
          <p className="demo-note">
            {'Vista de demostración · Datos de ejemplo'}
          </p>
        </>
      )}
    </MoveSurface>
  );
}
