import React, { useId } from 'react';
import { MoveSurface } from '../MoveSurface.jsx';

/** Patrón benefit-grid usado en landing.js · landingView. */
export function MoveBenefitGrid({
  theme = 'light',
  tenant = 'tp',
  reducedMotion = false,
  onAction,
  className = '',
  style,
  children,
}) {
  const uid = useId();
  return (
    <MoveSurface
      theme={theme}
      tenant={tenant}
      reducedMotion={reducedMotion}
      onAction={onAction}
      className={'' + ' ' + className}
      style={style}
    >
      {children ?? (
        <>
          <div className="benefit-grid">
            <article>
              <span className="benefit-number">{'01'}</span>
              <span className="benefit-icon">
                <svg
                  className="icon"
                  viewBox="0 0 24 24"
                  aria-hidden="true"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    d="M20 21v-2a6 6 0 0 0-6-6h-4a6 6 0 0 0-6 6v2M16 6a4 4 0 1 1-8 0 4 4 0 0 1 8 0"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  ></path>
                </svg>
              </span>
              <h3>{'Tu gente sabe qué esperar.'}</h3>
              <p>
                {
                  'Confirmación diaria, ticket de abordaje y seguimiento del viaje. Una experiencia clara desde el celular.'
                }
              </p>
              <span className="feature-label">
                {'EXPERIENCIA DEL COLABORADOR'}
              </span>
            </article>
            <article>
              <span className="benefit-number">{'02'}</span>
              <span className="benefit-icon">
                <svg
                  className="icon"
                  viewBox="0 0 24 24"
                  aria-hidden="true"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    d="M5 16V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2v11M5 11h14M8 3v8m8-8v8M5 16h14v3H5zM7 19v3m10-3v3M8 14h.01M16 14h.01"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  ></path>
                </svg>
              </span>
              <h3>{'Cada vehículo, con su grupo.'}</h3>
              <p>
                {
                  'Distribuye pasajeros entre unidades de la misma zona y permite el abordaje simultáneo, sin una cola de conductores.'
                }
              </p>
              <span className="feature-label">{'COORDINACIÓN OPERATIVA'}</span>
            </article>
            <article>
              <span className="benefit-number">{'03'}</span>
              <span className="benefit-icon">
                <svg
                  className="icon"
                  viewBox="0 0 24 24"
                  aria-hidden="true"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    d="M12 8v5l3 2M22 12a10 10 0 1 1-20 0 10 10 0 0 1 20 0"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  ></path>
                </svg>
              </span>
              <h3>{'Decisiones con contexto.'}</h3>
              <p>
                {
                  'Visualiza confirmaciones, ocupación e incidencias. Identifica oportunidades para usar mejor tu servicio de transporte.'
                }
              </p>
              <span className="feature-label">
                {'VISIBILIDAD DEL SERVICIO'}
              </span>
            </article>
          </div>
        </>
      )}
    </MoveSurface>
  );
}
