import React, { useId } from 'react';
import { MoveSurface } from '../MoveSurface.jsx';

/** Fecha y hora; se apilan en móvil. */
export function MoveDateTimeFields({
  theme = 'light',
  tenant = 'tp',
  reducedMotion = false,
  onAction,
  className = '',
  style,
  children,
}) {
  const uid = useId();
  return (
    <MoveSurface
      theme={theme}
      tenant={tenant}
      reducedMotion={reducedMotion}
      onAction={onAction}
      className={'' + ' ' + className}
      style={style}
    >
      {children ?? (
        <>
          <div className="two-fields">
            <div>
              <label className="label" htmlFor={uid + '-date-field'}>
                {'Fecha'}
              </label>
              <input
                id={uid + '-date-field'}
                type="date"
                defaultValue="2026-10-04"
              />
            </div>
            <div>
              <label className="label" htmlFor={uid + '-time-field'}>
                {'Hora'}
              </label>
              <input
                id={uid + '-time-field'}
                type="time"
                defaultValue="22:30"
              />
            </div>
          </div>
        </>
      )}
    </MoveSurface>
  );
}
