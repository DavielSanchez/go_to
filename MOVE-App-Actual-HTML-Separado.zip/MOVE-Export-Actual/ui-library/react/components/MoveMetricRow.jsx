import React, { useId } from 'react';
import { MoveSurface } from '../MoveSurface.jsx';

/** Patrón metric-row usado en driverViews['driver-home'](). */
export function MoveMetricRow({
  theme = 'light',
  tenant = 'tp',
  reducedMotion = false,
  onAction,
  className = '',
  style,
  children,
}) {
  const uid = useId();
  return (
    <MoveSurface
      theme={theme}
      tenant={tenant}
      reducedMotion={reducedMotion}
      onAction={onAction}
      className={'' + ' ' + className}
      style={style}
    >
      {children ?? (
        <>
          <div className="metric-row">
            <div>
              <strong>{'0'}</strong>
              <small>{'Abordaron'}</small>
            </div>
            <div>
              <strong>{'0'}</strong>
              <small>{'Incidencias'}</small>
            </div>
            <div>
              <strong>{'0'}</strong>
              <small>{'Viajes completados'}</small>
            </div>
          </div>
        </>
      )}
    </MoveSurface>
  );
}
