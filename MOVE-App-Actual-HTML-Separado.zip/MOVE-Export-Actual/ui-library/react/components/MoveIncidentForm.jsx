import React, { useId } from 'react';
import { MoveSurface } from '../MoveSurface.jsx';

/** Bloque extraído del diseño actual de MOVE. Los eventos se exponen mediante onAction. */
export function MoveIncidentForm({
  theme = 'light',
  tenant = 'tp',
  reducedMotion = false,
  onAction,
  className = '',
  style,
  children,
}) {
  const uid = useId();
  return (
    <MoveSurface
      theme={theme}
      tenant={tenant}
      reducedMotion={reducedMotion}
      onAction={onAction}
      className={'' + ' ' + className}
      style={style}
    >
      {children ?? (
        <>
          <form data-move-submit="saveIncident(event,'')" data-move-form="">
            <label className="ops-label">
              {'Viaje'}
              <select name="trip">
                <option value="TR-1040">{'TR-1040 · Los Girasoles'}</option>
                <option value="TR-1041">{'TR-1041 · Pantoja'}</option>
                <option value="TR-1042">{'TR-1042 · Pantoja'}</option>
              </select>
            </label>
            <label className="ops-label">
              {'Tipo'}
              <select name="type">
                <option>{'Tráfico'}</option>
                <option>{'Avería'}</option>
                <option>{'Seguridad'}</option>
                <option>{'Pasajero'}</option>
                <option>{'Otro'}</option>
              </select>
            </label>
            <label className="ops-label">
              {'Descripción'}
              <textarea
                name="detail"
                required
                maxLength="1000"
                defaultValue=""
              />
            </label>
            <label className="ops-label">
              {'Motivo'}
              <textarea
                name="reason"
                required
                minLength="8"
                maxLength="500"
                placeholder="Describe el motivo de este cambio."
                defaultValue=""
              />
            </label>
            <p
              className="ops-form-error"
              role="alert"
              id={uid + '-managementError'}
            ></p>
            <button className="ops-button">{'Guardar incidencia'}</button>
          </form>
        </>
      )}
    </MoveSurface>
  );
}
