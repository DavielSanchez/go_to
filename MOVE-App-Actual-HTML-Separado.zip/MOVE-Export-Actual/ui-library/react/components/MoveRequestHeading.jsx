import React, { useId } from 'react';
import { MoveSurface } from '../MoveSurface.jsx';

/** Patrón request-heading usado en approvalView(). */
export function MoveRequestHeading({
  theme = 'light',
  tenant = 'tp',
  reducedMotion = false,
  onAction,
  className = '',
  style,
  children,
}) {
  const uid = useId();
  return (
    <MoveSurface
      theme={theme}
      tenant={tenant}
      reducedMotion={reducedMotion}
      onAction={onAction}
      className={'' + ' ' + className}
      style={style}
    >
      {children ?? (
        <>
          <div className="request-heading">
            <div>
              <h2>{'Ana Pérez'}</h2>
              <p className="small-info">{'ID 104601 · EX-001'}</p>
            </div>
            <span className="pill amber">{'Pendiente'}</span>
          </div>
        </>
      )}
    </MoveSurface>
  );
}
