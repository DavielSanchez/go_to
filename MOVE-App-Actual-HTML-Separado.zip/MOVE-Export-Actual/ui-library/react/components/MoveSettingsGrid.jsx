import React, { useId } from 'react';
import { MoveSurface } from '../MoveSurface.jsx';

/** Patrón settings-grid usado en settingsView(). */
export function MoveSettingsGrid({
  theme = 'light',
  tenant = 'tp',
  reducedMotion = false,
  onAction,
  className = '',
  style,
  children,
}) {
  const uid = useId();
  return (
    <MoveSurface
      theme={theme}
      tenant={tenant}
      reducedMotion={reducedMotion}
      onAction={onAction}
      className={'' + ' ' + className}
      style={style}
    >
      {children ?? (
        <>
          <div className="settings-grid">
            <section className="card">
              <h2>{'Apariencia y accesibilidad'}</h2>
              <label className="label" htmlFor={uid + '-settingsTheme'}>
                {'Tema'}
              </label>
              <select
                id={uid + '-settingsTheme'}
                data-move-change="setAccountTheme(this.value)"
                defaultValue="light"
              >
                <option value="light">{'Claro'}</option>
                <option value="dark">{'Oscuro'}</option>
              </select>
              <label className="label" htmlFor={uid + '-settingsLanguage'}>
                {'Idioma'}
              </label>
              <select
                id={uid + '-settingsLanguage'}
                data-move-change="setInterfaceLanguage(this.value);render()"
                defaultValue="es"
              >
                <option value="es">{'🇩🇴 Español'}</option>
                <option value="en">{'🇺🇸 English'}</option>
              </select>
              <label className="preference-row">
                <span>
                  <b>{'Reducir movimiento'}</b>
                  <small>
                    {'Animaciones suaves o una experiencia más tranquila.'}
                  </small>
                </span>
                <input
                  type="checkbox"
                  role="switch"
                  aria-label="Reducir movimiento"
                  data-move-change="setPreference('motion',this.checked)"
                />
                <span className="switch-track" aria-hidden="true"></span>
              </label>
              <label className="preference-row">
                <span>
                  <b>{'Texto más grande'}</b>
                  <small>
                    {'Mejora la lectura de la información del viaje.'}
                  </small>
                </span>
                <input
                  type="checkbox"
                  role="switch"
                  aria-label="Texto más grande"
                  data-move-change="setPreference('largeText',this.checked)"
                />
                <span className="switch-track" aria-hidden="true"></span>
              </label>
              <label className="preference-row">
                <span>
                  <b>{'Vista compacta'}</b>
                  <small>
                    {'Reduce el espacio entre tarjetas en pantallas grandes.'}
                  </small>
                </span>
                <input
                  type="checkbox"
                  role="switch"
                  aria-label="Vista compacta"
                  data-move-change="setPreference('compact',this.checked)"
                />
                <span className="switch-track" aria-hidden="true"></span>
              </label>
            </section>
            <section>
              <div className="card">
                <h2>{'Preferencias de transporte'}</h2>
                <label className="label" htmlFor={uid + '-preferredWindow'}>
                  {'Ventana preferida'}
                </label>
                <select
                  id={uid + '-preferredWindow'}
                  data-move-change="setPreference('window',this.value)"
                  defaultValue="22:30"
                >
                  <option value="21:30">{'9:30 p. m.'}</option>
                  <option value="22:30">{'10:30 p. m.'}</option>
                  <option value="23:30">{'11:30 p. m.'}</option>
                  <option value="00:30">{'12:30 a. m. · Día siguiente'}</option>
                </select>
                <p className="small-info">
                  {
                    'Se propondrá al confirmar. Puedes elegir otra hora cada día.'
                  }
                </p>
              </div>
              <div className="card">
                <h2>{'Avisos dentro de la app'}</h2>
                <label className="preference-row">
                  <span>
                    <b>{'Confirmación diaria'}</b>
                    <small>{'Recordatorio para reservar tu transporte.'}</small>
                  </span>
                  <input
                    type="checkbox"
                    role="switch"
                    aria-label="Confirmación diaria"
                    defaultChecked
                    data-move-change="setPreference('reminders',this.checked)"
                  />
                  <span className="switch-track" aria-hidden="true"></span>
                </label>
                <label className="preference-row">
                  <span>
                    <b>{'Actualizaciones del viaje'}</b>
                    <small>{'Avisos del viaje y del abordaje.'}</small>
                  </span>
                  <input
                    type="checkbox"
                    role="switch"
                    aria-label="Actualizaciones del viaje"
                    defaultChecked
                    data-move-change="setPreference('tripAlerts',this.checked)"
                  />
                  <span className="switch-track" aria-hidden="true"></span>
                </label>
                <label className="preference-row">
                  <span>
                    <b>{'Estado de excepciones'}</b>
                    <small>{'Recordatorios de solicitudes pendientes.'}</small>
                  </span>
                  <input
                    type="checkbox"
                    role="switch"
                    aria-label="Estado de excepciones"
                    defaultChecked
                    data-move-change="setPreference('exceptionAlerts',this.checked)"
                  />
                  <span className="switch-track" aria-hidden="true"></span>
                </label>
                <label className="preference-row">
                  <span>
                    <b>{'Recordatorio de reseña'}</b>
                    <small>
                      {'Invitación a evaluar el viaje al finalizar.'}
                    </small>
                  </span>
                  <input
                    type="checkbox"
                    role="switch"
                    aria-label="Recordatorio de reseña"
                    defaultChecked
                    data-move-change="setPreference('reviewReminder',this.checked)"
                  />
                  <span className="switch-track" aria-hidden="true"></span>
                </label>
                <label className="preference-row">
                  <span>
                    <b>{'Respuesta háptica'}</b>
                    <small>
                      {'Vibración al reservar, si el dispositivo la permite.'}
                    </small>
                  </span>
                  <input
                    type="checkbox"
                    role="switch"
                    aria-label="Respuesta háptica"
                    data-move-change="setPreference('vibration',this.checked)"
                  />
                  <span className="switch-track" aria-hidden="true"></span>
                </label>
                <p className="small-info">
                  {
                    'Preferencias de demostración. No se envían notificaciones push ni correos.'
                  }
                </p>
              </div>
            </section>
            <section className="card settings-account">
              <h2>{'Cuenta y privacidad'}</h2>
              <div className="info-grid">
                <div>
                  <small>{'Empresa'}</small>
                  <b>{'TP'}</b>
                </div>
                <div>
                  <small>{'Perfil'}</small>
                  <b>{'Colaborador'}</b>
                </div>
              </div>
              <p className="small-info">
                {'Tus preferencias se guardan en este navegador.'}
              </p>
              <button
                className="btn secondary"
                data-move-click="resetPreferences()"
              >
                {'Restablecer preferencias'}
              </button>
              <button className="text-btn" data-move-click="logoutMove()">
                {'Cerrar sesión'}
              </button>
            </section>
          </div>
        </>
      )}
    </MoveSurface>
  );
}
