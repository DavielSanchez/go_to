import React, { useId } from 'react';
import { MoveSurface } from '../MoveSurface.jsx';
import asset0 from '../../assets/tp-logo.svg';
/** Animación original union-cross. Usa el control Reproducir para reiniciarla. Respeta la preferencia de movimiento reducido. */
export function MoveMotionUnionCross({
  theme = 'light',
  tenant = 'tp',
  reducedMotion = false,
  onAction,
  className = '',
  style,
  children,
}) {
  const uid = useId();
  return (
    <MoveSurface
      theme={theme}
      tenant={tenant}
      reducedMotion={reducedMotion}
      onAction={onAction}
      className={'' + ' ' + className}
      style={style}
    >
      {children ?? (
        <>
          <div className="brand-splash" style={{ minHeight: '300px' }}>
            <div className="brand-union">
              <img className="tenant-logo tp-logo" src={asset0} alt="TP" />
              <span className="collab-cross">{'×'}</span>
              <span className="brand">
                {'MOVE'}
                <span className="brand-dot"></span>
              </span>
            </div>
            <span className="loading-line"></span>
          </div>
        </>
      )}
    </MoveSurface>
  );
}
