import React, { useId } from 'react';
import { MoveSurface } from '../MoveSurface.jsx';
import asset0 from '../../assets/tp-logo.svg';
/** Patrón ops-company-row usado en opsPlatformView(). */
export function MoveOpsCompanyRow({
  theme = 'light',
  tenant = 'tp',
  reducedMotion = false,
  onAction,
  className = '',
  style,
  children,
}) {
  const uid = useId();
  return (
    <MoveSurface
      theme={theme}
      tenant={tenant}
      reducedMotion={reducedMotion}
      onAction={onAction}
      className={'' + ' ' + className}
      style={style}
    >
      {children ?? (
        <>
          <div className="ops-company-row">
            <img className="tp-logo" src={asset0} alt="TP" />
            <div>
              <b>{'TP'}</b>
              <small>{'4 tenants · DO / CO · Demostración'}</small>
            </div>
            <span className="ops-pill confirmed">{'Activo'}</span>
          </div>
        </>
      )}
    </MoveSurface>
  );
}
