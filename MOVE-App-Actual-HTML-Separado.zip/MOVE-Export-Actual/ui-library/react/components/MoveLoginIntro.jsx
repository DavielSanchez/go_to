import React, { useId } from 'react';
import { MoveSurface } from '../MoveSurface.jsx';

/** Patrón login-intro usado en loginView(). */
export function MoveLoginIntro({
  theme = 'light',
  tenant = 'tp',
  reducedMotion = false,
  onAction,
  className = '',
  style,
  children,
}) {
  const uid = useId();
  return (
    <MoveSurface
      theme={theme}
      tenant={tenant}
      reducedMotion={reducedMotion}
      onAction={onAction}
      className={'' + ' ' + className}
      style={style}
    >
      {children ?? (
        <>
          <div className="login-intro">
            <span className="pill">{'BIENVENIDO A MOVE'}</span>
            <h1>
              {'Tu jornada empieza aquí'}
              <span className="accent">{'.'}</span>
            </h1>
            <p className="sub">
              {
                'Accede como colaborador o conductor de un proveedor de transporte.'
              }
            </p>
          </div>
        </>
      )}
    </MoveSurface>
  );
}
