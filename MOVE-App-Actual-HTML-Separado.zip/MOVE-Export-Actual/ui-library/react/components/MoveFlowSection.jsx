import React, { useId } from 'react';
import { MoveSurface } from '../MoveSurface.jsx';

/** Patrón flow-section usado en landing.js · landingView. */
export function MoveFlowSection({
  theme = 'light',
  tenant = 'tp',
  reducedMotion = false,
  onAction,
  className = '',
  style,
  children,
}) {
  const uid = useId();
  return (
    <MoveSurface
      theme={theme}
      tenant={tenant}
      reducedMotion={reducedMotion}
      onAction={onAction}
      className={'' + ' ' + className}
      style={style}
    >
      {children ?? (
        <>
          <section className="lp-section flow-section">
            <div className="section-intro">
              <div>
                <span className="lp-kicker">{'03 / DE PUNTA A PUNTA'}</span>
                <h2>
                  {'Un regreso organizado.'}
                  <br />
                  {'En cuatro momentos.'}
                </h2>
              </div>
              <button
                className="lp-button ghost light"
                data-move-click="enterMove()"
              >
                {'Ver el flujo en la app'}
              </button>
            </div>
            <div className="flow-grid">
              <article>
                <span>{'01'}</span>
                <svg
                  className="icon"
                  viewBox="0 0 24 24"
                  aria-hidden="true"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    d="M20 21v-2a6 6 0 0 0-6-6h-4a6 6 0 0 0-6 6v2M16 6a4 4 0 1 1-8 0 4 4 0 0 1 8 0"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  ></path>
                </svg>
                <h3>{'Confirmar'}</h3>
                <p>
                  {
                    'El empleado indica si usará el transporte y recibe su ticket.'
                  }
                </p>
              </article>
              <article>
                <span>{'02'}</span>
                <svg
                  className="icon"
                  viewBox="0 0 24 24"
                  aria-hidden="true"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    d="M20 10c0 6-8 12-8 12S4 16 4 10a8 8 0 1 1 16 0M15 10a3 3 0 1 1-6 0 3 3 0 0 1 6 0"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  ></path>
                </svg>
                <h3>{'Coordinar'}</h3>
                <p>
                  {
                    'Los conductores registran su zona y reciben un grupo de pasajeros.'
                  }
                </p>
              </article>
              <article>
                <span>{'03'}</span>
                <svg
                  className="icon"
                  viewBox="0 0 24 24"
                  aria-hidden="true"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    d="M5 16V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2v11M5 11h14M8 3v8m8-8v8M5 16h14v3H5zM7 19v3m10-3v3M8 14h.01M16 14h.01"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  ></path>
                </svg>
                <h3>{'Abordar y viajar'}</h3>
                <p>
                  {
                    'Se validan los tickets y se inicia el recorrido con sus paradas.'
                  }
                </p>
              </article>
              <article>
                <span>{'04'}</span>
                <svg
                  className="icon"
                  viewBox="0 0 24 24"
                  aria-hidden="true"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    d="M12 3l3 6 7 1-5 5 1 7-6-3-6 3 1-7-5-5 7-1z"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  ></path>
                </svg>
                <h3>{'Escuchar y mejorar'}</h3>
                <p>
                  {'Reseñas, historial e incidencias completan la experiencia.'}
                </p>
              </article>
            </div>
          </section>
        </>
      )}
    </MoveSurface>
  );
}
