import React, { useId } from 'react';
import { MoveSurface } from '../MoveSurface.jsx';

/** Indicador adicional de carga. */
export function MoveSpinner({
  theme = 'light',
  tenant = 'tp',
  reducedMotion = false,
  onAction,
  className = '',
  style,
  children,
}) {
  const uid = useId();
  return (
    <MoveSurface
      theme={theme}
      tenant={tenant}
      reducedMotion={reducedMotion}
      onAction={onAction}
      className={'' + ' ' + className}
      style={style}
    >
      {children ?? (
        <>
          <span
            className="move-spinner"
            role="status"
            aria-label="Cargando"
          ></span>
        </>
      )}
    </MoveSurface>
  );
}
