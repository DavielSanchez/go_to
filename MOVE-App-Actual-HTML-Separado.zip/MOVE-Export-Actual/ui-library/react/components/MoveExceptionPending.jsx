import React, { useId } from 'react';
import { MoveSurface } from '../MoveSurface.jsx';

/** Bloque extraído del diseño actual de MOVE. Los eventos se exponen mediante onAction. */
export function MoveExceptionPending({
  theme = 'light',
  tenant = 'tp',
  reducedMotion = false,
  onAction,
  className = '',
  style,
  children,
}) {
  const uid = useId();
  return (
    <MoveSurface
      theme={theme}
      tenant={tenant}
      reducedMotion={reducedMotion}
      onAction={onAction}
      className={'' + ' ' + className}
      style={style}
    >
      {children ?? (
        <>
          <div className="narrow">
            <div className="page-top">
              <div>
                <h1>{'Excepción de transporte'}</h1>
                <p className="sub">
                  {'Solicítala para hoy o para otra fecha.'}
                </p>
              </div>
            </div>
            <div className="card success">
              <span className="review-icon">
                <svg
                  className="icon"
                  viewBox="0 0 24 24"
                  aria-hidden="true"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    d="M12 8v5l3 2M22 12a10 10 0 1 1-20 0 10 10 0 0 1 20 0"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  ></path>
                </svg>
              </span>
              <span className="pill amber">{'Pendiente de revisión'}</span>
              <h2>{'Solicitud enviada'}</h2>
              <div className="summary">
                <div>
                  <b>{'undefined'}</b>
                  <p>{'4 de octubre de 2026 · Salida undefined'}</p>
                </div>
              </div>
              <p className="small-info">
                {
                  'Espera la aprobación de transporte. Una solicitud pendiente no autoriza el abordaje.'
                }
              </p>
              <details className="demo-controls" style={{ marginTop: '20px' }}>
                <summary>{'Probar aprobación de demostración'}</summary>
                <button
                  className="btn secondary"
                  style={{ marginTop: '14px' }}
                  data-move-click="approveExceptionDemo()"
                >
                  {'Simular excepción aprobada'}
                </button>
              </details>
              <button
                className="btn secondary"
                style={{ marginTop: '18px' }}
                data-move-click="newException()"
              >
                {'Solicitar para otra fecha'}
              </button>
            </div>
            <p className="demo-note">
              {'Vista de demostración · Datos de ejemplo'}
            </p>
          </div>
        </>
      )}
    </MoveSurface>
  );
}
