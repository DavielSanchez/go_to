import React, { useId } from 'react';
import { MoveSurface } from '../MoveSurface.jsx';

/** SVG original de MOVE, vectorial y personalizable. */
export function MoveIconUser({
  theme = 'light',
  tenant = 'tp',
  reducedMotion = false,
  onAction,
  className = '',
  style,
  children,
}) {
  const uid = useId();
  return (
    <MoveSurface
      theme={theme}
      tenant={tenant}
      reducedMotion={reducedMotion}
      onAction={onAction}
      className={'' + ' ' + className}
      style={style}
    >
      {children ?? (
        <>
          <svg
            className="icon"
            viewBox="0 0 24 24"
            aria-hidden="true"
            xmlns="http://www.w3.org/2000/svg"
          >
            <path
              d="M20 21v-2a6 6 0 0 0-6-6h-4a6 6 0 0 0-6 6v2M16 6a4 4 0 1 1-8 0 4 4 0 0 1 8 0"
              strokeLinecap="round"
              strokeLinejoin="round"
            ></path>
          </svg>
        </>
      )}
    </MoveSurface>
  );
}
