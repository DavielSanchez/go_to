import React, { useId } from 'react';
import { MoveSurface } from '../MoveSurface.jsx';

/** Patrón route usado en views.home(). */
export function MoveRoute({
  theme = 'light',
  tenant = 'tp',
  reducedMotion = false,
  onAction,
  className = '',
  style,
  children,
}) {
  const uid = useId();
  return (
    <MoveSurface
      theme={theme}
      tenant={tenant}
      reducedMotion={reducedMotion}
      onAction={onAction}
      className={'' + ' ' + className}
      style={style}
    >
      {children ?? (
        <>
          <div className="route">
            <div className="route-item">
              <b>{'TP · Campus Churchill'}</b>
              <small>{'Salida por la puerta principal'}</small>
            </div>
            <div className="route-item">
              <b>{'Tu dirección de destino'}</b>
              <small>{'Entrada de Pantoja · Los Alcarrizos'}</small>
            </div>
          </div>
        </>
      )}
    </MoveSurface>
  );
}
