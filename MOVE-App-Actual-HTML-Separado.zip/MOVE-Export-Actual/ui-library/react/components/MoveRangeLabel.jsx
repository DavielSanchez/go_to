import React, { useId } from 'react';
import { MoveSurface } from '../MoveSurface.jsx';

/** Patrón range-label usado en landing.js · landingView. */
export function MoveRangeLabel({
  theme = 'light',
  tenant = 'tp',
  reducedMotion = false,
  onAction,
  className = '',
  style,
  children,
}) {
  const uid = useId();
  return (
    <MoveSurface
      theme={theme}
      tenant={tenant}
      reducedMotion={reducedMotion}
      onAction={onAction}
      className={'' + ' ' + className}
      style={style}
    >
      {children ?? (
        <>
          <div className="range-label">
            <label htmlFor={uid + '-calcOccupancy'}>
              {'Ocupación promedio'}
            </label>
            <b id={uid + '-occupancyValue'}>{'70%'}</b>
          </div>
        </>
      )}
    </MoveSurface>
  );
}
