import React, { useId } from 'react';
import { MoveSurface } from '../MoveSurface.jsx';

/** Patrón signup-progress usado en registrationView(). */
export function MoveSignupProgress({
  theme = 'light',
  tenant = 'tp',
  reducedMotion = false,
  onAction,
  className = '',
  style,
  children,
}) {
  const uid = useId();
  return (
    <MoveSurface
      theme={theme}
      tenant={tenant}
      reducedMotion={reducedMotion}
      onAction={onAction}
      className={'' + ' ' + className}
      style={style}
    >
      {children ?? (
        <>
          <div className="signup-progress">
            <span className="current">
              <i>{'1'}</i>
              {'Correo'}
            </span>
            <span className="">
              <i>{'2'}</i>
              {'Verificación'}
            </span>
            <span className="">
              <i>{'3'}</i>
              {'Contraseña'}
            </span>
          </div>
        </>
      )}
    </MoveSurface>
  );
}
