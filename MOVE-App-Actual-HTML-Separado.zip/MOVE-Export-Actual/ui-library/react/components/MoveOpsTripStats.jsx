import React, { useId } from 'react';
import { MoveSurface } from '../MoveSurface.jsx';

/** Patrón ops-trip-stats usado en opsOperationView(). */
export function MoveOpsTripStats({
  theme = 'light',
  tenant = 'tp',
  reducedMotion = false,
  onAction,
  className = '',
  style,
  children,
}) {
  const uid = useId();
  return (
    <MoveSurface
      theme={theme}
      tenant={tenant}
      reducedMotion={reducedMotion}
      onAction={onAction}
      className={'' + ' ' + className}
      style={style}
    >
      {children ?? (
        <>
          <div className="ops-trip-stats">
            <div>
              <small>{'Salida'}</small>
              <b>{'00:30'}</b>
            </div>
            <div>
              <small>{'A bordo'}</small>
              <b>{'12 / 12'}</b>
            </div>
            <div>
              <small>{'Unidad'}</small>
              <b>{'12'}</b>
            </div>
          </div>
        </>
      )}
    </MoveSurface>
  );
}
