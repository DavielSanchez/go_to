import React, { useId } from 'react';
import { MoveSurface } from '../MoveSurface.jsx';

/** Patrón ops-drawer-top usado en opsDrawerHTML(). */
export function MoveOpsDrawerTop({
  theme = 'light',
  tenant = 'tp',
  reducedMotion = false,
  onAction,
  className = '',
  style,
  children,
}) {
  const uid = useId();
  return (
    <MoveSurface
      theme={theme}
      tenant={tenant}
      reducedMotion={reducedMotion}
      onAction={onAction}
      className={'' + ' ' + className}
      style={style}
    >
      {children ?? (
        <>
          <div className="ops-drawer-top">
            <h2 id={uid + '-opsDrawerTitle'}>{'TR-1041 · Pantoja'}</h2>
            <button
              className="ops-icon-button"
              aria-label="Cerrar detalle"
              data-move-click="closeOpsDrawer()"
            >
              <svg
                className="icon"
                viewBox="0 0 24 24"
                aria-hidden="true"
                xmlns="http://www.w3.org/2000/svg"
              >
                <path
                  d="M15 5l-7 7 7 7"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                ></path>
              </svg>
            </button>
          </div>
        </>
      )}
    </MoveSurface>
  );
}
