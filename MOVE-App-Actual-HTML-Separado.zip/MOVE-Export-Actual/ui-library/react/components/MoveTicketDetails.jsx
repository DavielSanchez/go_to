import React, { useId } from 'react';
import { MoveSurface } from '../MoveSurface.jsx';

/** Patrón ticket-details usado en views.ticket(). */
export function MoveTicketDetails({
  theme = 'light',
  tenant = 'tp',
  reducedMotion = false,
  onAction,
  className = '',
  style,
  children,
}) {
  const uid = useId();
  return (
    <MoveSurface
      theme={theme}
      tenant={tenant}
      reducedMotion={reducedMotion}
      onAction={onAction}
      className={'' + ' ' + className}
      style={style}
    >
      {children ?? (
        <>
          <div className="ticket-details">
            <div>
              <small>{'Fecha del viaje'}</small>
              <b>{'4 de octubre de 2026'}</b>
            </div>
            <div>
              <small>{'Salida asignada'}</small>
              <b>{'22:30'}</b>
            </div>
            <div>
              <small>{'Vehículo'}</small>
              <b>{'Unidad 12'}</b>
            </div>
            <div>
              <small>{'Ruta'}</small>
              <b>{'04 · Churchill'}</b>
            </div>
          </div>
        </>
      )}
    </MoveSurface>
  );
}
