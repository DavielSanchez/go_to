import React, { useId } from 'react';
import { MoveSurface } from '../MoveSurface.jsx';

/** Patrón management-controls usado en opsPlansView(). */
export function MoveManagementControls({
  theme = 'light',
  tenant = 'tp',
  reducedMotion = false,
  onAction,
  className = '',
  style,
  children,
}) {
  const uid = useId();
  return (
    <MoveSurface
      theme={theme}
      tenant={tenant}
      reducedMotion={reducedMotion}
      onAction={onAction}
      className={'' + ' ' + className}
      style={style}
    >
      {children ?? (
        <>
          <div className="management-controls">
            <button
              className="ops-button"
              data-move-click="openManagementDrawer('plan-launch')"
            >
              {'Generar planificación'}
            </button>
            <button
              className="ops-button secondary"
              data-move-click="navigate('ops-qr');render()"
            >
              {'Abrir catálogo QR'}
            </button>
          </div>
        </>
      )}
    </MoveSurface>
  );
}
