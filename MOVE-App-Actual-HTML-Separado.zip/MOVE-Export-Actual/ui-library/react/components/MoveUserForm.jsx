import React, { useId } from 'react';
import { MoveSurface } from '../MoveSurface.jsx';

/** Bloque extraído del diseño actual de MOVE. Los eventos se exponen mediante onAction. */
export function MoveUserForm({
  theme = 'light',
  tenant = 'tp',
  reducedMotion = false,
  onAction,
  className = '',
  style,
  children,
}) {
  const uid = useId();
  return (
    <MoveSurface
      theme={theme}
      tenant={tenant}
      reducedMotion={reducedMotion}
      onAction={onAction}
      className={'' + ' ' + className}
      style={style}
    >
      {children ?? (
        <>
          <form
            data-move-submit="saveManagementUser(event,'')"
            data-move-form=""
          >
            <p className="ops-muted">{'TP · Churchill'}</p>
            <label className="ops-label">
              {'Nombre completo'}
              <input name="name" defaultValue="" required maxLength="100" />
            </label>
            <label className="ops-label">
              {'Correo personal'}
              <input type="email" name="email" defaultValue="" required />
            </label>
            <label className="ops-label">
              {'Rol'}
              <select name="role">
                <option value="agent">{'Empleado'}</option>
                <option value="supervisor">{'Supervisor'}</option>
                <option value="coordinator">{'Coordinador'}</option>
                <option value="tenant-admin">{'Administrador'}</option>
              </select>
            </label>
            <label className="ops-label">
              {'Motivo'}
              <textarea
                name="reason"
                required
                minLength="8"
                maxLength="500"
                placeholder="Describe el motivo de este cambio."
                defaultValue=""
              />
            </label>
            <p
              className="ops-form-error"
              role="alert"
              id={uid + '-managementError'}
            ></p>
            <button className="ops-button">{'Autorizar registro'}</button>
          </form>
        </>
      )}
    </MoveSurface>
  );
}
