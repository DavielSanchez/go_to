import React, { useId } from 'react';
import { MoveSurface } from '../MoveSurface.jsx';

/** Patrón ops-segmented usado en opsOperationView(). */
export function MoveOpsSegmented({
  theme = 'light',
  tenant = 'tp',
  reducedMotion = false,
  onAction,
  className = '',
  style,
  children,
}) {
  const uid = useId();
  return (
    <MoveSurface
      theme={theme}
      tenant={tenant}
      reducedMotion={reducedMotion}
      onAction={onAction}
      className={'' + ' ' + className}
      style={style}
    >
      {children ?? (
        <>
          <div className="ops-segmented" aria-label="Estado del viaje">
            <button
              className="active"
              data-move-click="setOpsTripFilter('all')"
            >
              {'Todos'}
            </button>
            <button className="" data-move-click="setOpsTripFilter('boarding')">
              {'Abordaje'}
            </button>
            <button className="" data-move-click="setOpsTripFilter('active')">
              {'En viaje'}
            </button>
            <button className="" data-move-click="setOpsTripFilter('paused')">
              {'Pausados'}
            </button>
            <button
              className=""
              data-move-click="setOpsTripFilter('completed')"
            >
              {'Finalizados'}
            </button>
          </div>
        </>
      )}
    </MoveSurface>
  );
}
