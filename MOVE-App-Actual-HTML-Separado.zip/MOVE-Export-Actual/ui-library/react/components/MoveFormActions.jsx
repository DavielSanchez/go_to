import React, { useId } from 'react';
import { MoveSurface } from '../MoveSurface.jsx';

/** Patrón form-actions usado en approvalView(). */
export function MoveFormActions({
  theme = 'light',
  tenant = 'tp',
  reducedMotion = false,
  onAction,
  className = '',
  style,
  children,
}) {
  const uid = useId();
  return (
    <MoveSurface
      theme={theme}
      tenant={tenant}
      reducedMotion={reducedMotion}
      onAction={onAction}
      className={'' + ' ' + className}
      style={style}
    >
      {children ?? (
        <>
          <div className="form-actions">
            <button
              className="btn outline"
              data-move-click="decideException('EX-001','rejected')"
            >
              {'Rechazar'}
            </button>
            <button
              className="btn"
              data-move-click="decideException('EX-001','approved')"
            >
              {'Aprobar excepción'}
            </button>
          </div>
        </>
      )}
    </MoveSurface>
  );
}
