import React, { useId } from 'react';
import { MoveSurface } from '../MoveSurface.jsx';

/** Patrón ops-plan-summary usado en opsPlansView(). */
export function MoveOpsPlanSummary({
  theme = 'light',
  tenant = 'tp',
  reducedMotion = false,
  onAction,
  className = '',
  style,
  children,
}) {
  const uid = useId();
  return (
    <MoveSurface
      theme={theme}
      tenant={tenant}
      reducedMotion={reducedMotion}
      onAction={onAction}
      className={'' + ' ' + className}
      style={style}
    >
      {children ?? (
        <>
          <div className="ops-plan-summary">
            <div>
              <strong>{'20'}</strong>
              <small>{'Pasajeros incluidos'}</small>
            </div>
            <div>
              <strong>{'2'}</strong>
              <small>{'Viajes calculados'}</small>
            </div>
            <div>
              <strong>{'6'}</strong>
              <small>{'Sin confirmar'}</small>
            </div>
          </div>
        </>
      )}
    </MoveSurface>
  );
}
