import React, { useId } from 'react';
import { MoveSurface } from '../MoveSurface.jsx';

/** Switch de preferencias, con interacción nativa. */
export function MoveSwitch({
  theme = 'light',
  tenant = 'tp',
  reducedMotion = false,
  onAction,
  className = '',
  style,
  children,
}) {
  const uid = useId();
  return (
    <MoveSurface
      theme={theme}
      tenant={tenant}
      reducedMotion={reducedMotion}
      onAction={onAction}
      className={'' + ' ' + className}
      style={style}
    >
      {children ?? (
        <>
          <label className="preference-row">
            <span>
              <b>{'Confirmación diaria'}</b>
              <small>{'Recordatorio para reservar tu transporte.'}</small>
            </span>
            <input
              type="checkbox"
              role="switch"
              aria-label="Confirmación diaria"
              defaultChecked
              data-move-change="setPreference('reminders',this.checked)"
            />
            <span className="switch-track" aria-hidden="true"></span>
          </label>
        </>
      )}
    </MoveSurface>
  );
}
