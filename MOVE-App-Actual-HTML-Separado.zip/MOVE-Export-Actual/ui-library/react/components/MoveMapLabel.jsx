import React, { useId } from 'react';
import { MoveSurface } from '../MoveSurface.jsx';

/** Patrón map-label usado en views.trip(). */
export function MoveMapLabel({
  theme = 'light',
  tenant = 'tp',
  reducedMotion = false,
  onAction,
  className = '',
  style,
  children,
}) {
  const uid = useId();
  return (
    <MoveSurface
      theme={theme}
      tenant={tenant}
      reducedMotion={reducedMotion}
      onAction={onAction}
      className={'' + ' ' + className}
      style={style}
    >
      {children ?? (
        <>
          <div className="map-label">
            <svg
              className="icon"
              viewBox="0 0 24 24"
              aria-hidden="true"
              xmlns="http://www.w3.org/2000/svg"
            >
              <path
                d="M20 10c0 6-8 12-8 12S4 16 4 10a8 8 0 1 1 16 0M15 10a3 3 0 1 1-6 0 3 3 0 0 1 6 0"
                strokeLinecap="round"
                strokeLinejoin="round"
              ></path>
            </svg>
            {'Santo Domingo · Ruta 04'}
          </div>
        </>
      )}
    </MoveSurface>
  );
}
