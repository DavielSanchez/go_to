import React, { useId } from 'react';
import { MoveSurface } from '../MoveSurface.jsx';

/** Patrón address-card usado en views.home(). */
export function MoveAddressCard({
  theme = 'light',
  tenant = 'tp',
  reducedMotion = false,
  onAction,
  className = '',
  style,
  children,
}) {
  const uid = useId();
  return (
    <MoveSurface
      theme={theme}
      tenant={tenant}
      reducedMotion={reducedMotion}
      onAction={onAction}
      className={'' + ' ' + className}
      style={style}
    >
      {children ?? (
        <>
          <div className="card address-card">
            <div className="section-heading" style={{ marginTop: '0px' }}>
              <h2>{'Mi dirección'}</h2>
              <span className="icon-box">
                <svg
                  className="icon"
                  viewBox="0 0 24 24"
                  aria-hidden="true"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    d="M20 10c0 6-8 12-8 12S4 16 4 10a8 8 0 1 1 16 0M15 10a3 3 0 1 1-6 0 3 3 0 0 1 6 0"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  ></path>
                </svg>
              </span>
            </div>
            <p className="address-value">
              {'Entrada de Pantoja · Los Alcarrizos'}
            </p>
            <p className="small-info">{'Ubicación: 18.53000, -70.01000'}</p>
            <p className="small-info" style={{ marginTop: '12px' }}>
              {
                '0 de 3 cambios automáticos utilizados. Desde el cuarto, transporte debe aprobar el cambio.'
              }
            </p>
            <button
              className="btn secondary"
              style={{ marginTop: '18px' }}
              data-move-click="navigate('address')"
            >
              {'Cambiar dirección'}
            </button>
          </div>
        </>
      )}
    </MoveSurface>
  );
}
