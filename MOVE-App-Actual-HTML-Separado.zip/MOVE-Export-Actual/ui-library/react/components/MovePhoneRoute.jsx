import React, { useId } from 'react';
import { MoveSurface } from '../MoveSurface.jsx';

/** Patrón phone-route usado en landing.js · landingView. */
export function MovePhoneRoute({
  theme = 'light',
  tenant = 'tp',
  reducedMotion = false,
  onAction,
  className = '',
  style,
  children,
}) {
  const uid = useId();
  return (
    <MoveSurface
      theme={theme}
      tenant={tenant}
      reducedMotion={reducedMotion}
      onAction={onAction}
      className={'' + ' ' + className}
      style={style}
    >
      {children ?? (
        <>
          <div className="phone-route">
            <b>{'TP · Campus Churchill'}</b>
            <span>{'↓'}</span>
            <b>{'Los Alcarrizos'}</b>
            <small>{'Unidad 12 · Ruta 04'}</small>
          </div>
        </>
      )}
    </MoveSurface>
  );
}
