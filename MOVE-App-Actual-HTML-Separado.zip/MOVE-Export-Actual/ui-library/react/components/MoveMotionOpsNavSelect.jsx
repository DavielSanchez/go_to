import React, { useId } from 'react';
import { MoveSurface } from '../MoveSurface.jsx';

/** Animación original ops-nav-select. Usa el control Reproducir para reiniciarla. Respeta la preferencia de movimiento reducido. */
export function MoveMotionOpsNavSelect({
  theme = 'light',
  tenant = 'tp',
  reducedMotion = false,
  onAction,
  className = '',
  style,
  children,
}) {
  const uid = useId();
  return (
    <MoveSurface
      theme={theme}
      tenant={tenant}
      reducedMotion={reducedMotion}
      onAction={onAction}
      className={'' + ' ' + className}
      style={style}
    >
      {children ?? (
        <>
          <section
            className="card"
            style={{ animation: 'ops-nav-select .7s ease both' }}
          >
            <h2>{'Tu regreso a casa'}</h2>
            <p className="sub">{'ops-nav-select'}</p>
          </section>
        </>
      )}
    </MoveSurface>
  );
}
