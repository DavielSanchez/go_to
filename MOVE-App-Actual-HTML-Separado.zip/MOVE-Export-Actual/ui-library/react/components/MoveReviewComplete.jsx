import React, { useId } from 'react';
import { MoveSurface } from '../MoveSurface.jsx';

/** Bloque extraído del diseño actual de MOVE. Los eventos se exponen mediante onAction. */
export function MoveReviewComplete({
  theme = 'light',
  tenant = 'tp',
  reducedMotion = false,
  onAction,
  className = '',
  style,
  children,
}) {
  const uid = useId();
  return (
    <MoveSurface
      theme={theme}
      tenant={tenant}
      reducedMotion={reducedMotion}
      onAction={onAction}
      className={'' + ' ' + className}
      style={style}
    >
      {children ?? (
        <>
          <div className="review">
            <button className="back" data-move-click="navigate('trip')">
              <svg
                className="icon"
                viewBox="0 0 24 24"
                aria-hidden="true"
                xmlns="http://www.w3.org/2000/svg"
              >
                <path
                  d="M15 5l-7 7 7 7"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                ></path>
              </svg>
              {'Mi viaje'}
            </button>
            <div className="card success">
              <div className="review-icon">
                <svg
                  className="icon"
                  viewBox="0 0 24 24"
                  aria-hidden="true"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    d="M5 12l4 4L19 6"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  ></path>
                </svg>
              </div>
              <h1>{'¡Gracias, Daviel!'}</h1>
              <p style={{ marginTop: '15px' }}>
                {'Tu opinión nos ayuda a mejorar'}
                <br />
                {'el transporte de todos.'}
              </p>
              <div className="stars" aria-label="5 de 5 estrellas">
                {'★★★★★'}
              </div>
              <button
                className="btn"
                style={{ marginTop: '25px' }}
                data-move-click="navigate('home')"
              >
                {'Volver al inicio'}
              </button>
            </div>
            <p className="demo-note">
              {'Vista de demostración · Datos de ejemplo'}
            </p>
          </div>
        </>
      )}
    </MoveSurface>
  );
}
