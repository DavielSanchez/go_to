import React, { useId } from 'react';
import { MoveSurface } from '../MoveSurface.jsx';

/** Bloque extraído del diseño actual de MOVE. Los eventos se exponen mediante onAction. */
export function MoveDriverRegistration({
  theme = 'light',
  tenant = 'tp',
  reducedMotion = false,
  onAction,
  className = '',
  style,
  children,
}) {
  const uid = useId();
  return (
    <MoveSurface
      theme={theme}
      tenant={tenant}
      reducedMotion={reducedMotion}
      onAction={onAction}
      className={'' + ' ' + className}
      style={style}
    >
      {children ?? (
        <>
          <div className="signup-wrap">
            <button
              className="back"
              data-move-click="navigate('login');render()"
            >
              <svg
                className="icon"
                viewBox="0 0 24 24"
                aria-hidden="true"
                xmlns="http://www.w3.org/2000/svg"
              >
                <path
                  d="M15 5l-7 7 7 7"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                ></path>
              </svg>
              {'Volver al login'}
            </button>
            <div className="signup-title">
              <span className="pill">{'TU ACCESO A MOVE'}</span>
              <h1>{'Cada viaje empieza aquí.'}</h1>
              <p className="sub">
                {'Regístrate como conductor con tu correo personal.'}
              </p>
            </div>
            <div className="signup-progress">
              <span className="current">
                <i>{'1'}</i>
                {'Correo'}
              </span>
              <span className="">
                <i>{'2'}</i>
                {'Verificación'}
              </span>
              <span className="">
                <i>{'3'}</i>
                {'Contraseña'}
              </span>
            </div>
            <form
              className="card signup-card"
              id={uid + '-registrationForm'}
              data-move-form=""
            >
              <div
                className="access-tabs"
                role="group"
                aria-label="Tipo de registro"
              >
                <button
                  type="button"
                  className=""
                  data-move-click="setRegistrationRole('corporate')"
                >
                  <svg
                    className="icon"
                    viewBox="0 0 24 24"
                    aria-hidden="true"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path
                      d="M20 21v-2a6 6 0 0 0-6-6h-4a6 6 0 0 0-6 6v2M16 6a4 4 0 1 1-8 0 4 4 0 0 1 8 0"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    ></path>
                  </svg>
                  {'Corporativo'}
                </button>
                <button
                  type="button"
                  className="selected"
                  data-move-click="setRegistrationRole('driver')"
                >
                  <svg
                    className="icon"
                    viewBox="0 0 24 24"
                    aria-hidden="true"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path
                      d="M5 16V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2v11M5 11h14M8 3v8m8-8v8M5 16h14v3H5zM7 19v3m10-3v3M8 14h.01M16 14h.01"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    ></path>
                  </svg>
                  {'Conductores'}
                </button>
              </div>
              <h2>{'Tu próximo recorrido empieza aquí.'}</h2>
              <p className="small-info">
                {
                  'Puedes crear tu cuenta con cualquier correo personal válido. Después completarás tus datos y los del vehículo.'
                }
              </p>
              <label className="label" htmlFor={uid + '-signupEmail'}>
                {'Correo personal'}
              </label>
              <input
                id={uid + '-signupEmail'}
                name="email"
                type="email"
                autoComplete="email"
                placeholder="nombre@correo.com"
                required
                defaultValue="ana.perez@gmail.com"
              />
              <div
                id={uid + '-registrationError'}
                className="form-error"
                role="alert"
              ></div>
              <button className="btn" type="submit">
                {'Continuar'}
              </button>
            </form>
            <p className="demo-note">
              {'Vista de demostración · Datos de ejemplo'}
            </p>
          </div>
        </>
      )}
    </MoveSurface>
  );
}
