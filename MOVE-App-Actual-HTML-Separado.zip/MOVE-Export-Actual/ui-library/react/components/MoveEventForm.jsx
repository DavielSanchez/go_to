import React, { useId } from 'react';
import { MoveSurface } from '../MoveSurface.jsx';

/** Bloque extraído del diseño actual de MOVE. Los eventos se exponen mediante onAction. */
export function MoveEventForm({
  theme = 'light',
  tenant = 'tp',
  reducedMotion = false,
  onAction,
  className = '',
  style,
  children,
}) {
  const uid = useId();
  return (
    <MoveSurface
      theme={theme}
      tenant={tenant}
      reducedMotion={reducedMotion}
      onAction={onAction}
      className={'' + ' ' + className}
      style={style}
    >
      {children ?? (
        <>
          <form data-move-submit="saveEvent(event)" data-move-form="">
            <p className="ops-muted">{'TP · Churchill'}</p>
            <label className="ops-label">
              {'Nombre del evento'}
              <input
                name="name"
                defaultValue=""
                required
                data-move-input="eventDraft.name=this.value"
              />
            </label>
            <div className="ops-form-grid">
              <label className="ops-label">
                {'Fecha'}
                <input
                  type="date"
                  name="date"
                  defaultValue="2026-10-04"
                  required
                  data-move-input="eventDraft.date=this.value"
                />
              </label>
              <label className="ops-label">
                {'Hora'}
                <input
                  type="time"
                  name="time"
                  defaultValue="10:00"
                  required
                  data-move-input="eventDraft.time=this.value"
                />
              </label>
            </div>
            <label className="ops-label">
              {'Trayecto'}
              <select
                name="mode"
                data-move-change="eventDraft.mode=this.value;render()"
                defaultValue="common"
              >
                <option value="common">{'Origen y destino comunes'}</option>
                <option value="from-home">
                  {'Desde los domicilios a un destino'}
                </option>
                <option value="to-home">
                  {'Desde un origen a los domicilios'}
                </option>
              </select>
            </label>
            <div className="ops-form-grid">
              <label className="ops-label">
                {'Origen'}
                <input
                  name="originName"
                  defaultValue="TP · Churchill"
                  required
                  data-move-input="eventDraft.originName=this.value"
                />
              </label>
              <label className="ops-label">
                {'Destino'}
                <input
                  name="destinationName"
                  defaultValue=""
                  required
                  data-move-input="eventDraft.destinationName=this.value"
                />
              </label>
            </div>
            <div className="zone-tools">
              <button
                type="button"
                className="ops-button secondary"
                data-move-click="eventMapTarget='origin';toast('Selecciona el origen en el mapa')"
              >
                {'Marcar origen'}
              </button>
              <button
                type="button"
                className="ops-button secondary"
                data-move-click="eventMapTarget='destination';toast('Selecciona el destino en el mapa')"
              >
                {'Marcar destino'}
              </button>
            </div>
            <div id={uid + '-eventMap'} className="event-map"></div>
            <p className="ops-muted">
              {
                'Arrastra los marcadores o selecciona un punto. Los domicilios usan la dirección registrada del empleado.'
              }
            </p>
            <label className="ops-label">{'Empleados'}</label>
            <div className="event-user-list">
              <label className="management-check">
                <input
                  type="checkbox"
                  name="users"
                  defaultValue="tp-churchill-U0"
                  data-move-change="toggleEventUser(this.value,this.checked)"
                />
                <span>{'Ana Pérez 1'}</span>
              </label>
              <label className="management-check">
                <input
                  type="checkbox"
                  name="users"
                  defaultValue="tp-churchill-U1"
                  data-move-change="toggleEventUser(this.value,this.checked)"
                />
                <span>{'Carlos Mejía 2'}</span>
              </label>
              <label className="management-check">
                <input
                  type="checkbox"
                  name="users"
                  defaultValue="tp-churchill-U2"
                  data-move-change="toggleEventUser(this.value,this.checked)"
                />
                <span>{'Laura Díaz 3'}</span>
              </label>
              <label className="management-check">
                <input
                  type="checkbox"
                  name="users"
                  defaultValue="tp-churchill-U3"
                  data-move-change="toggleEventUser(this.value,this.checked)"
                />
                <span>{'Miguel Santos 4'}</span>
              </label>
              <label className="management-check">
                <input
                  type="checkbox"
                  name="users"
                  defaultValue="tp-churchill-U4"
                  data-move-change="toggleEventUser(this.value,this.checked)"
                />
                <span>{'Sofía Rodríguez 5'}</span>
              </label>
              <label className="management-check">
                <input
                  type="checkbox"
                  name="users"
                  defaultValue="tp-churchill-U5"
                  data-move-change="toggleEventUser(this.value,this.checked)"
                />
                <span>{'Juan Reyes 6'}</span>
              </label>
              <label className="management-check">
                <input
                  type="checkbox"
                  name="users"
                  defaultValue="tp-churchill-U6"
                  data-move-change="toggleEventUser(this.value,this.checked)"
                />
                <span>{'Ana Pérez 7'}</span>
              </label>
              <label className="management-check">
                <input
                  type="checkbox"
                  name="users"
                  defaultValue="tp-churchill-U7"
                  data-move-change="toggleEventUser(this.value,this.checked)"
                />
                <span>{'Carlos Mejía 8'}</span>
              </label>
              <label className="management-check">
                <input
                  type="checkbox"
                  name="users"
                  defaultValue="tp-churchill-U8"
                  data-move-change="toggleEventUser(this.value,this.checked)"
                />
                <span>{'Laura Díaz 9'}</span>
              </label>
              <label className="management-check">
                <input
                  type="checkbox"
                  name="users"
                  defaultValue="tp-churchill-U9"
                  data-move-change="toggleEventUser(this.value,this.checked)"
                />
                <span>{'Miguel Santos 10'}</span>
              </label>
              <label className="management-check">
                <input
                  type="checkbox"
                  name="users"
                  defaultValue="tp-churchill-U10"
                  data-move-change="toggleEventUser(this.value,this.checked)"
                />
                <span>{'Sofía Rodríguez 11'}</span>
              </label>
              <label className="management-check">
                <input
                  type="checkbox"
                  name="users"
                  defaultValue="tp-churchill-U11"
                  data-move-change="toggleEventUser(this.value,this.checked)"
                />
                <span>{'Juan Reyes 12'}</span>
              </label>
              <label className="management-check">
                <input
                  type="checkbox"
                  name="users"
                  defaultValue="tp-churchill-U12"
                  data-move-change="toggleEventUser(this.value,this.checked)"
                />
                <span>{'Ana Pérez 13'}</span>
              </label>
              <label className="management-check">
                <input
                  type="checkbox"
                  name="users"
                  defaultValue="tp-churchill-U13"
                  data-move-change="toggleEventUser(this.value,this.checked)"
                />
                <span>{'Carlos Mejía 14'}</span>
              </label>
              <label className="management-check">
                <input
                  type="checkbox"
                  name="users"
                  defaultValue="tp-churchill-U14"
                  data-move-change="toggleEventUser(this.value,this.checked)"
                />
                <span>{'Laura Díaz 15'}</span>
              </label>
              <label className="management-check">
                <input
                  type="checkbox"
                  name="users"
                  defaultValue="tp-churchill-U15"
                  data-move-change="toggleEventUser(this.value,this.checked)"
                />
                <span>{'Miguel Santos 16'}</span>
              </label>
              <label className="management-check">
                <input
                  type="checkbox"
                  name="users"
                  defaultValue="tp-churchill-U16"
                  data-move-change="toggleEventUser(this.value,this.checked)"
                />
                <span>{'Sofía Rodríguez 17'}</span>
              </label>
              <label className="management-check">
                <input
                  type="checkbox"
                  name="users"
                  defaultValue="tp-churchill-U17"
                  data-move-change="toggleEventUser(this.value,this.checked)"
                />
                <span>{'Juan Reyes 18'}</span>
              </label>
              <label className="management-check">
                <input
                  type="checkbox"
                  name="users"
                  defaultValue="tp-churchill-U18"
                  data-move-change="toggleEventUser(this.value,this.checked)"
                />
                <span>{'Ana Pérez 19'}</span>
              </label>
              <label className="management-check">
                <input
                  type="checkbox"
                  name="users"
                  defaultValue="tp-churchill-U19"
                  data-move-change="toggleEventUser(this.value,this.checked)"
                />
                <span>{'Carlos Mejía 20'}</span>
              </label>
              <label className="management-check">
                <input
                  type="checkbox"
                  name="users"
                  defaultValue="tp-churchill-U20"
                  data-move-change="toggleEventUser(this.value,this.checked)"
                />
                <span>{'Laura Díaz 21'}</span>
              </label>
              <label className="management-check">
                <input
                  type="checkbox"
                  name="users"
                  defaultValue="tp-churchill-U21"
                  data-move-change="toggleEventUser(this.value,this.checked)"
                />
                <span>{'Miguel Santos 22'}</span>
              </label>
              <label className="management-check">
                <input
                  type="checkbox"
                  name="users"
                  defaultValue="tp-churchill-U22"
                  data-move-change="toggleEventUser(this.value,this.checked)"
                />
                <span>{'Sofía Rodríguez 23'}</span>
              </label>
              <label className="management-check">
                <input
                  type="checkbox"
                  name="users"
                  defaultValue="tp-churchill-U23"
                  data-move-change="toggleEventUser(this.value,this.checked)"
                />
                <span>{'Juan Reyes 24'}</span>
              </label>
              <label className="management-check">
                <input
                  type="checkbox"
                  name="users"
                  defaultValue="tp-churchill-U24"
                  data-move-change="toggleEventUser(this.value,this.checked)"
                />
                <span>{'Ana Pérez 25'}</span>
              </label>
              <label className="management-check">
                <input
                  type="checkbox"
                  name="users"
                  defaultValue="tp-churchill-U25"
                  data-move-change="toggleEventUser(this.value,this.checked)"
                />
                <span>{'Carlos Mejía 26'}</span>
              </label>
              <label className="management-check">
                <input
                  type="checkbox"
                  name="users"
                  defaultValue="tp-churchill-U26"
                  data-move-change="toggleEventUser(this.value,this.checked)"
                />
                <span>{'Laura Díaz 27'}</span>
              </label>
              <label className="management-check">
                <input
                  type="checkbox"
                  name="users"
                  defaultValue="tp-churchill-U27"
                  data-move-change="toggleEventUser(this.value,this.checked)"
                />
                <span>{'Miguel Santos 28'}</span>
              </label>
              <label className="management-check">
                <input
                  type="checkbox"
                  name="users"
                  defaultValue="tp-churchill-U28"
                  data-move-change="toggleEventUser(this.value,this.checked)"
                />
                <span>{'Sofía Rodríguez 29'}</span>
              </label>
              <label className="management-check">
                <input
                  type="checkbox"
                  name="users"
                  defaultValue="tp-churchill-U29"
                  data-move-change="toggleEventUser(this.value,this.checked)"
                />
                <span>{'Juan Reyes 30'}</span>
              </label>
              <label className="management-check">
                <input
                  type="checkbox"
                  name="users"
                  defaultValue="tp-churchill-U30"
                  data-move-change="toggleEventUser(this.value,this.checked)"
                />
                <span>{'Ana Pérez 31'}</span>
              </label>
              <label className="management-check">
                <input
                  type="checkbox"
                  name="users"
                  defaultValue="tp-churchill-U31"
                  data-move-change="toggleEventUser(this.value,this.checked)"
                />
                <span>{'Carlos Mejía 32'}</span>
              </label>
              <label className="management-check">
                <input
                  type="checkbox"
                  name="users"
                  defaultValue="tp-churchill-U32"
                  data-move-change="toggleEventUser(this.value,this.checked)"
                />
                <span>{'Laura Díaz 33'}</span>
              </label>
              <label className="management-check">
                <input
                  type="checkbox"
                  name="users"
                  defaultValue="tp-churchill-U33"
                  data-move-change="toggleEventUser(this.value,this.checked)"
                />
                <span>{'Miguel Santos 34'}</span>
              </label>
              <label className="management-check">
                <input
                  type="checkbox"
                  name="users"
                  defaultValue="tp-churchill-U34"
                  data-move-change="toggleEventUser(this.value,this.checked)"
                />
                <span>{'Sofía Rodríguez 35'}</span>
              </label>
            </div>
            <h3>{'Invitados'}</h3>
            <p className="ops-muted">
              {
                'Para trayectos domiciliarios registra un pin y una ruta de servicio.'
              }
            </p>
            <div id={uid + '-eventGuests'}></div>
            <button
              type="button"
              className="ops-button secondary"
              data-move-click="addEventGuest()"
            >
              {'Agregar invitado'}
            </button>
            <div className="ops-form-grid">
              <label className="ops-label">
                {'Costo estimado'}
                <input
                  name="estimated"
                  type="number"
                  step="0.01"
                  min="0"
                  defaultValue="0"
                  required
                  data-move-input="eventDraft.estimated=Number(this.value)"
                />
              </label>
              <label className="ops-label">
                {'Moneda'}
                <select
                  name="currency"
                  data-move-change="eventDraft.currency=this.value"
                  defaultValue="DOP"
                >
                  <option>{'DOP'}</option>
                  <option>{'USD'}</option>
                  <option>{'COP'}</option>
                  <option>{'EUR'}</option>
                </select>
              </label>
            </div>
            <label className="ops-label">
              {'Motivo'}
              <textarea
                name="reason"
                required
                minLength="8"
                maxLength="500"
                placeholder="Describe el motivo de este cambio."
                defaultValue=""
              />
            </label>
            <p
              className="ops-form-error"
              role="alert"
              id={uid + '-managementError'}
            ></p>
            <button className="ops-button">
              {'Guardar propuesta de evento'}
            </button>
          </form>
        </>
      )}
    </MoveSurface>
  );
}
