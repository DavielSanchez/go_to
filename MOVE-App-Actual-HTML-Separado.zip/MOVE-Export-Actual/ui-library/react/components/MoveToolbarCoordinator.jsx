import React, { useId } from 'react';
import { MoveSurface } from '../MoveSurface.jsx';

/** Navegación del rol Coordinator. */
export function MoveToolbarCoordinator({
  theme = 'light',
  tenant = 'tp',
  reducedMotion = false,
  onAction,
  className = '',
  style,
  children,
}) {
  const uid = useId();
  return (
    <MoveSurface
      theme={theme}
      tenant={tenant}
      reducedMotion={reducedMotion}
      onAction={onAction}
      className={'' + ' ' + className}
      style={style}
    >
      {children ?? (
        <>
          <div className="ops-toolbar">
            <label className="ops-date-label">
              {'Jornada operativa'}
              <input
                type="date"
                id={uid + '-opsDate'}
                defaultValue="2026-10-03"
                data-move-change="setOpsDate(this.value)"
              />
            </label>
            <div className="ops-clock">
              <b>{'00:42'}</b>
              <small>{'Reloj de demostración · RD'}</small>
            </div>
          </div>
        </>
      )}
    </MoveSurface>
  );
}
