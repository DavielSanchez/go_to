import React, { useId } from 'react';
import { MoveSurface } from '../MoveSurface.jsx';

/** Patrón rating usado en views.trip(). */
export function MoveRating({
  theme = 'light',
  tenant = 'tp',
  reducedMotion = false,
  onAction,
  className = '',
  style,
  children,
}) {
  const uid = useId();
  return (
    <MoveSurface
      theme={theme}
      tenant={tenant}
      reducedMotion={reducedMotion}
      onAction={onAction}
      className={'' + ' ' + className}
      style={style}
    >
      {children ?? (
        <>
          <span className="rating">
            <span className="star">{'★'}</span>
            {' 4.9'}
          </span>
        </>
      )}
    </MoveSurface>
  );
}
