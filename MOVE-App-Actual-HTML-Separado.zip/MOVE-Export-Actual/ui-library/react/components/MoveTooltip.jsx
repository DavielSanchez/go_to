import React, { useId } from 'react';
import { MoveSurface } from '../MoveSurface.jsx';

/** Tooltip nativo accesible. */
export function MoveTooltip({
  theme = 'light',
  tenant = 'tp',
  reducedMotion = false,
  onAction,
  className = '',
  style,
  children,
}) {
  const uid = useId();
  return (
    <MoveSurface
      theme={theme}
      tenant={tenant}
      reducedMotion={reducedMotion}
      onAction={onAction}
      className={'' + ' ' + className}
      style={style}
    >
      {children ?? (
        <>
          <button
            className="btn outline"
            title="Este plan incluye pasajeros confirmados antes del cutoff."
          >
            {'Información del plan'}
          </button>
        </>
      )}
    </MoveSurface>
  );
}
