import React, { useId } from 'react';
import { MoveSurface } from '../MoveSurface.jsx';

/** Patrón review usado en views.review(). */
export function MoveReview({
  theme = 'light',
  tenant = 'tp',
  reducedMotion = false,
  onAction,
  className = '',
  style,
  children,
}) {
  const uid = useId();
  return (
    <MoveSurface
      theme={theme}
      tenant={tenant}
      reducedMotion={reducedMotion}
      onAction={onAction}
      className={'' + ' ' + className}
      style={style}
    >
      {children ?? (
        <>
          <div className="review">
            <button className="back" data-move-click="navigate('trip')">
              <svg
                className="icon"
                viewBox="0 0 24 24"
                aria-hidden="true"
                xmlns="http://www.w3.org/2000/svg"
              >
                <path
                  d="M15 5l-7 7 7 7"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                ></path>
              </svg>
              {'Mi viaje'}
            </button>
            <div className="review-icon">
              <svg
                className="icon"
                viewBox="0 0 24 24"
                aria-hidden="true"
                xmlns="http://www.w3.org/2000/svg"
              >
                <path
                  d="M12 3l8 3v6c0 5-8 9-8 9s-8-4-8-9V6zM8 12l3 3 5-6"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                ></path>
              </svg>
            </div>
            <h1>{'¿Cómo estuvo tu viaje?'}</h1>
            <p className="sub">
              {'Llegaste a casa. Ahora cuéntanos tu experiencia.'}
            </p>
            <div className="summary">
              <svg
                className="icon"
                viewBox="0 0 24 24"
                aria-hidden="true"
                xmlns="http://www.w3.org/2000/svg"
              >
                <path
                  d="M5 16V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2v11M5 11h14M8 3v8m8-8v8M5 16h14v3H5zM7 19v3m10-3v3M8 14h.01M16 14h.01"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                ></path>
              </svg>
              <div>
                <b>{'Churchill → Los Alcarrizos'}</b>
                <p>{'Hoy, 10:30 p. m. · José Ramírez'}</p>
              </div>
            </div>
            <div className="stars" aria-label="Calificación del viaje">
              <button
                type="button"
                aria-label="1 estrella"
                aria-pressed="false"
                className=""
                data-move-click="setRating(1)"
              >
                {'★'}
              </button>
              <button
                type="button"
                aria-label="2 estrellas"
                aria-pressed="false"
                className=""
                data-move-click="setRating(2)"
              >
                {'★'}
              </button>
              <button
                type="button"
                aria-label="3 estrellas"
                aria-pressed="false"
                className=""
                data-move-click="setRating(3)"
              >
                {'★'}
              </button>
              <button
                type="button"
                aria-label="4 estrellas"
                aria-pressed="false"
                className=""
                data-move-click="setRating(4)"
              >
                {'★'}
              </button>
              <button
                type="button"
                aria-label="5 estrellas"
                aria-pressed="false"
                className=""
                data-move-click="setRating(5)"
              >
                {'★'}
              </button>
            </div>
            <p className="small-info" id={uid + '-ratingLabel'}>
              {'Selecciona una calificación'}
            </p>
            <label className="label">{'¿Qué destacarías?'}</label>
            <div className="tags">
              <button
                className="tag "
                aria-pressed="false"
                data-move-click="toggleTag('Puntualidad')"
              >
                {'Puntualidad'}
              </button>
              <button
                className="tag "
                aria-pressed="false"
                data-move-click="toggleTag('Buen trato')"
              >
                {'Buen trato'}
              </button>
              <button
                className="tag "
                aria-pressed="false"
                data-move-click="toggleTag('Comodidad')"
              >
                {'Comodidad'}
              </button>
              <button
                className="tag "
                aria-pressed="false"
                data-move-click="toggleTag('Conducción segura')"
              >
                {'Conducción segura'}
              </button>
            </div>
            <label
              className="label"
              htmlFor={uid + '-comment'}
              style={{ textAlign: 'left' }}
            >
              {'Un comentario más '}
              <span style={{ fontWeight: '400', color: 'var(--muted)' }}>
                {'(opcional)'}
              </span>
            </label>
            <textarea
              id={uid + '-comment'}
              placeholder="¿Qué podemos mejorar?"
              maxLength="500"
              defaultValue=""
            />
            <button
              className="btn"
              style={{ marginTop: '24px' }}
              disabled
              data-move-click="submitReview()"
            >
              {'Enviar reseña'}
            </button>
            <button className="cancel" data-move-click="navigate('home')">
              {'Lo haré después'}
            </button>
            <p className="demo-note">
              {'Vista de demostración · Datos de ejemplo'}
            </p>
          </div>
        </>
      )}
    </MoveSurface>
  );
}
