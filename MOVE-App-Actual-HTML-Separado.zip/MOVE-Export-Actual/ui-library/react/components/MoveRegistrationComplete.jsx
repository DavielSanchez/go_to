import React, { useId } from 'react';
import { MoveSurface } from '../MoveSurface.jsx';

/** Bloque extraído del diseño actual de MOVE. Los eventos se exponen mediante onAction. */
export function MoveRegistrationComplete({
  theme = 'light',
  tenant = 'tp',
  reducedMotion = false,
  onAction,
  className = '',
  style,
  children,
}) {
  const uid = useId();
  return (
    <MoveSurface
      theme={theme}
      tenant={tenant}
      reducedMotion={reducedMotion}
      onAction={onAction}
      className={'' + ' ' + className}
      style={style}
    >
      {children ?? (
        <>
          <div className="signup-wrap">
            <button
              className="back"
              data-move-click="navigate('login');render()"
            >
              <svg
                className="icon"
                viewBox="0 0 24 24"
                aria-hidden="true"
                xmlns="http://www.w3.org/2000/svg"
              >
                <path
                  d="M15 5l-7 7 7 7"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                ></path>
              </svg>
              {'Volver al login'}
            </button>
            <div className="signup-title">
              <span className="pill">{'TU ACCESO A MOVE'}</span>
              <h1>{'Tu cuenta está lista.'}</h1>
              <p className="sub">
                {'Acceso corporativo con tu correo personal autorizado.'}
              </p>
            </div>
            <div className="card signup-success">
              <div className="review-icon">
                <svg
                  className="icon"
                  viewBox="0 0 24 24"
                  aria-hidden="true"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    d="M5 12l4 4L19 6"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  ></path>
                </svg>
              </div>
              <h2>{'¡Bienvenido a MOVE!'}</h2>
              <p className="sub">{'Tu cuenta de demostración fue creada.'}</p>
              <b data-user-content="">{'ana.perez@gmail.com'}</b>
              <button className="btn" data-move-click="goToRegisteredLogin()">
                {'Iniciar sesión con mi cuenta'}
              </button>
              <p className="small-info">
                {
                  'Podrás usar el correo y la contraseña que acabas de crear en este dispositivo.'
                }
              </p>
            </div>
            <p className="demo-note">
              {'Vista de demostración · Datos de ejemplo'}
            </p>
          </div>
        </>
      )}
    </MoveSurface>
  );
}
