import React, { useId } from 'react';
import { MoveSurface } from '../MoveSurface.jsx';

/** Bloque extraído del diseño actual de MOVE. Los eventos se exponen mediante onAction. */
export function MoveIncidents({
  theme = 'light',
  tenant = 'tp',
  reducedMotion = false,
  onAction,
  className = '',
  style,
  children,
}) {
  const uid = useId();
  return (
    <MoveSurface
      theme={theme}
      tenant={tenant}
      reducedMotion={reducedMotion}
      onAction={onAction}
      className={'' + ' ' + className}
      style={style}
    >
      {children ?? (
        <>
          <div className="ops-metrics">
            <article className="ops-metric">
              <small>{'Casos abiertos'}</small>
              <strong>{'1'}</strong>
              <p>{'Pendientes de seguimiento'}</p>
              <span>
                <svg
                  className="icon"
                  viewBox="0 0 24 24"
                  aria-hidden="true"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    d="M12 11v6m0-10v.01M22 12a10 10 0 1 1-20 0 10 10 0 0 1 20 0"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  ></path>
                </svg>
              </span>
            </article>
            <article className="ops-metric">
              <small>{'En seguimiento'}</small>
              <strong>{'0'}</strong>
              <p>{'Con responsable operativo'}</p>
              <span>
                <svg
                  className="icon"
                  viewBox="0 0 24 24"
                  aria-hidden="true"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    d="M12 8v5l3 2M22 12a10 10 0 1 1-20 0 10 10 0 0 1 20 0"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  ></path>
                </svg>
              </span>
            </article>
            <article className="ops-metric">
              <small>{'Resueltos'}</small>
              <strong>{'0'}</strong>
              <p>{'Historial conservado'}</p>
              <span>
                <svg
                  className="icon"
                  viewBox="0 0 24 24"
                  aria-hidden="true"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    d="M5 12l4 4L19 6"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  ></path>
                </svg>
              </span>
            </article>
          </div>
          <section className="ops-card">
            <div className="ops-section-title">
              <h2>{'Casos de la operación'}</h2>
            </div>
            <button
              className="ops-button"
              data-move-click="openManagementDrawer('incident-create')"
            >
              {'Registrar incidencia'}
            </button>
            <div className="ops-table-scroll">
              <table className="ops-table">
                <thead>
                  <tr>
                    <th>{'Caso'}</th>
                    <th>{'Viaje'}</th>
                    <th>{'Tipo'}</th>
                    <th>{'Estado'}</th>
                    <th></th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td>
                      <b>{'INC-501'}</b>
                      <small>{'04/10/2026, 15:26:14'}</small>
                    </td>
                    <td>{'TR-1040'}</td>
                    <td>{'Tráfico'}</td>
                    <td>{'Abierta'}</td>
                    <td>
                      <button
                        className="ops-button secondary"
                        data-move-click="openManagementDrawer('incident-edit','INC-501')"
                      >
                        {'Gestionar'}
                      </button>
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
          </section>
        </>
      )}
    </MoveSurface>
  );
}
