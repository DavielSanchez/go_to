import React, { useId } from 'react';
import { MoveSurface } from '../MoveSurface.jsx';

/** Bloque extraído del diseño actual de MOVE. Los eventos se exponen mediante onAction. */
export function MoveEvents({
  theme = 'light',
  tenant = 'tp',
  reducedMotion = false,
  onAction,
  className = '',
  style,
  children,
}) {
  const uid = useId();
  return (
    <MoveSurface
      theme={theme}
      tenant={tenant}
      reducedMotion={reducedMotion}
      onAction={onAction}
      className={'' + ' ' + className}
      style={style}
    >
      {children ?? (
        <>
          <div className="management-controls">
            <button
              className="ops-button"
              data-move-click="eventDraft=newEventDraft();openManagementDrawer('event-create')"
            >
              {'Crear evento'}
            </button>
          </div>
          <div className="ops-plan-grid">
            <section className="ops-card">
              <div className="ops-section-title">
                <h2>{'Viajes a medida'}</h2>
              </div>
              <p className="ops-muted">
                {
                  'Crea un traslado de trabajo o un evento especial. Cada salida tendrá sus viajes y QR de ruta.'
                }
              </p>
            </section>
          </div>
        </>
      )}
    </MoveSurface>
  );
}
