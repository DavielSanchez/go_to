import React, { useId } from 'react';
import { MoveSurface } from '../MoveSurface.jsx';

/** Patrón request-summary usado en approvalView(). */
export function MoveRequestSummary({
  theme = 'light',
  tenant = 'tp',
  reducedMotion = false,
  onAction,
  className = '',
  style,
  children,
}) {
  const uid = useId();
  return (
    <MoveSurface
      theme={theme}
      tenant={tenant}
      reducedMotion={reducedMotion}
      onAction={onAction}
      className={'' + ' ' + className}
      style={style}
    >
      {children ?? (
        <>
          <div className="request-summary">
            <div>
              <small>{'Motivo'}</small>
              <b>{'Horas extra'}</b>
            </div>
            <div>
              <small>{'Salida solicitada'}</small>
              <b>{'4 de octubre de 2026 · 23:00'}</b>
            </div>
          </div>
        </>
      )}
    </MoveSurface>
  );
}
