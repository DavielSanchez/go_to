import React, { useId } from 'react';
import { MoveSurface } from '../MoveSurface.jsx';

/** Bloque extraído del diseño actual de MOVE. Los eventos se exponen mediante onAction. */
export function MoveOpsConfiguration({
  theme = 'light',
  tenant = 'tp',
  reducedMotion = false,
  onAction,
  className = '',
  style,
  children,
}) {
  const uid = useId();
  return (
    <MoveSurface
      theme={theme}
      tenant={tenant}
      reducedMotion={reducedMotion}
      onAction={onAction}
      className={'' + ' ' + className}
      style={style}
    >
      {children ?? (
        <>
          <div className="ops-callout">
            {
              '\n  Los cambios se aplican al tenant elegido. Los trips ya confirmados conservan\n  su fecha y ventana. Todo cambio queda en auditoría.\n'
            }
          </div>
          <div className="ops-config-grid">
            <section className="ops-card">
              <h2>{'Tenant que vas a configurar'}</h2>
              <label className="ops-label" htmlFor={uid + '-configTenant'}>
                {'Site / tenant'}
              </label>
              <select
                id={uid + '-configTenant'}
                data-move-change="setConfigTenant(this.value)"
                defaultValue="tp-churchill"
              >
                <option value="tp-churchill">{'TP · Churchill'}</option>
              </select>
              <div className="ops-integration">
                <h3>{'IEX · SQL Server'}</h3>
                <p>
                  <b>{'Lectura de horarios disponible'}</b>
                </p>
                <p>{'Última sincronización: 04/10/2026, 00:00:00'}</p>
                <p>{'Elegibilidad cada 2 horas · inicio 00:00'}</p>
                <p>
                  {'116 empleados evaluados · 84 confirmaciones satisfactorias'}
                </p>
              </div>
              <div className="ops-config-summary">
                {'País: DO'}
                <br />
                {'Ciudad: Santo Domingo'}
                <br />
                {'Tenant: tp-churchill'}
                <br />
                {'Las integraciones mostradas son de demostración.'}
              </div>
            </section>
            <form
              className="ops-card"
              id={uid + '-opsConfigForm'}
              data-move-submit="saveOpsConfig(event)"
              data-move-form=""
            >
              <h2>{'Reglas de transporte'}</h2>
              <p className="ops-muted">
                {
                  '\n      Afectan la elegibilidad y los próximos planes de esta operación.\n    '
                }
              </p>
              <div className="ops-form-grid">
                <label>
                  {'Salida elegible desde'}
                  <input
                    type="time"
                    name="eligible"
                    defaultValue="21:00"
                    required
                  />
                </label>
                <label>
                  {'Cutoff del plan'}
                  <input
                    type="time"
                    name="cutoff"
                    defaultValue="20:00"
                    required
                  />
                </label>
                <label>
                  {'Asientos libres por vehículo'}
                  <input
                    type="number"
                    name="gap"
                    min="0"
                    max="10"
                    defaultValue="2"
                    required
                  />
                </label>
                <label>
                  {'Tiempo de gracia · minutos'}
                  <input
                    type="number"
                    name="grace"
                    min="0"
                    max="60"
                    defaultValue="10"
                    required
                  />
                </label>
              </div>
              <fieldset className="ops-window-fields">
                <legend>{'Ventanas disponibles'}</legend>
                <div>
                  <label>
                    <input
                      type="checkbox"
                      name="windows"
                      defaultValue="21:30"
                      defaultChecked
                    />
                    {'21:30'}
                  </label>
                  <label>
                    <input
                      type="checkbox"
                      name="windows"
                      defaultValue="22:30"
                      defaultChecked
                    />
                    {'22:30'}
                  </label>
                  <label>
                    <input
                      type="checkbox"
                      name="windows"
                      defaultValue="23:30"
                      defaultChecked
                    />
                    {'23:30'}
                  </label>
                  <label>
                    <input
                      type="checkbox"
                      name="windows"
                      defaultValue="00:30"
                      defaultChecked
                    />
                    {'00:30'}
                  </label>
                </div>
              </fieldset>
              <label className="ops-label" htmlFor={uid + '-opsOrigin'}>
                {'Nombre del punto de origen'}
              </label>
              <input
                id={uid + '-opsOrigin'}
                name="origin"
                defaultValue="TP · Churchill"
                maxLength="120"
                required
              />
              <label className="ops-label" htmlFor={uid + '-configReason'}>
                {'Motivo del cambio'}
              </label>
              <textarea
                id={uid + '-configReason'}
                name="reason"
                maxLength="500"
                required
                placeholder="Explica por qué cambia la configuración."
                defaultValue=""
              />
              <button className="ops-button" type="submit">
                {'Guardar configuración'}
              </button>
              <p
                className="ops-form-error"
                id={uid + '-opsConfigError'}
                role="alert"
              ></p>
            </form>
          </div>
        </>
      )}
    </MoveSurface>
  );
}
