import React, { useId } from 'react';
import { MoveSurface } from '../MoveSurface.jsx';

/** Patrón two-fields usado en views.exception(). */
export function MoveTwoFields({
  theme = 'light',
  tenant = 'tp',
  reducedMotion = false,
  onAction,
  className = '',
  style,
  children,
}) {
  const uid = useId();
  return (
    <MoveSurface
      theme={theme}
      tenant={tenant}
      reducedMotion={reducedMotion}
      onAction={onAction}
      className={'' + ' ' + className}
      style={style}
    >
      {children ?? (
        <>
          <div className="two-fields">
            <div>
              <label className="label" htmlFor={uid + '-requestDate'}>
                {'Fecha del transporte'}
              </label>
              <input
                id={uid + '-requestDate'}
                name="date"
                type="date"
                defaultValue="2026-10-04"
                min="2026-10-04"
                required
              />
            </div>
            <div>
              <label className="label" htmlFor={uid + '-requestTime'}>
                {'Hora de salida'}
              </label>
              <input
                id={uid + '-requestTime'}
                name="time"
                type="time"
                defaultValue="22:00"
                required
              />
            </div>
          </div>
        </>
      )}
    </MoveSurface>
  );
}
