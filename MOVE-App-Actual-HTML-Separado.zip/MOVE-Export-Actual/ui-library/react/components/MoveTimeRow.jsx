import React, { useId } from 'react';
import { MoveSurface } from '../MoveSurface.jsx';

/** Patrón time-row usado en views.home(). */
export function MoveTimeRow({
  theme = 'light',
  tenant = 'tp',
  reducedMotion = false,
  onAction,
  className = '',
  style,
  children,
}) {
  const uid = useId();
  return (
    <MoveSurface
      theme={theme}
      tenant={tenant}
      reducedMotion={reducedMotion}
      onAction={onAction}
      className={'' + ' ' + className}
      style={style}
    >
      {children ?? (
        <>
          <div className="time-row">
            <div>
              <small>{'Salida de tu turno'}</small>
              <strong>
                {'10:00 '}
                <span style={{ fontSize: '14px' }}>{'p. m.'}</span>
              </strong>
            </div>
            <div>
              <small>{'Salida del transporte'}</small>
              <strong>
                {'10:30 '}
                <span style={{ fontSize: '14px' }}>{'p. m.'}</span>
              </strong>
            </div>
          </div>
        </>
      )}
    </MoveSurface>
  );
}
