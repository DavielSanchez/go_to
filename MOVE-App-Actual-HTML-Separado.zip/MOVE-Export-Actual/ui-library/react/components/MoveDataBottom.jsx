import React, { useId } from 'react';
import { MoveSurface } from '../MoveSurface.jsx';

/** Patrón data-bottom usado en landing.js · landingView. */
export function MoveDataBottom({
  theme = 'light',
  tenant = 'tp',
  reducedMotion = false,
  onAction,
  className = '',
  style,
  children,
}) {
  const uid = useId();
  return (
    <MoveSurface
      theme={theme}
      tenant={tenant}
      reducedMotion={reducedMotion}
      onAction={onAction}
      className={'' + ' ' + className}
      style={style}
    >
      {children ?? (
        <>
          <div className="data-bottom">
            <div>
              <h3>
                {'Del “¿quién va hoy?”'}
                <br />
                {'a una operación visible.'}
              </h3>
              <p>
                {
                  'Confirmaciones, asignaciones y abordajes permiten construir una vista compartida del servicio para tu equipo.'
                }
              </p>
            </div>
            <div className="mini-dashboard">
              <div className="dashboard-title">
                <b>{'Ocupación por salida'}</b>
                <span>{'Datos mock'}</span>
              </div>
              <div className="bar-row">
                <span>{'21:00'}</span>
                <div>
                  <i style={{ width: '72%' }}></i>
                </div>
                <b>{'72%'}</b>
              </div>
              <div className="bar-row">
                <span>{'22:00'}</span>
                <div>
                  <i style={{ width: '91%' }}></i>
                </div>
                <b>{'91%'}</b>
              </div>
              <div className="bar-row">
                <span>{'23:00'}</span>
                <div>
                  <i style={{ width: '84%' }}></i>
                </div>
                <b>{'84%'}</b>
              </div>
              <div className="chart-foot">
                {'Tres salidas · Ejemplo visual de seguimiento'}
              </div>
            </div>
          </div>
        </>
      )}
    </MoveSurface>
  );
}
