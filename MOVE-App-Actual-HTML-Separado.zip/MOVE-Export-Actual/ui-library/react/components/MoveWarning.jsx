import React, { useId } from 'react';
import { MoveSurface } from '../MoveSurface.jsx';

/** Patrón warning usado en launchPlanForm(). */
export function MoveWarning({
  theme = 'light',
  tenant = 'tp',
  reducedMotion = false,
  onAction,
  className = '',
  style,
  children,
}) {
  const uid = useId();
  return (
    <MoveSurface
      theme={theme}
      tenant={tenant}
      reducedMotion={reducedMotion}
      onAction={onAction}
      className={'' + ' ' + className}
      style={style}
    >
      {children ?? (
        <>
          <div className="ops-callout warning">
            <b>{'El cutoff está configurado a las 20:00.'}</b>
            <p>
              {
                'Generar antes del cierre puede dejar empleados pendientes. Revisa su listado al confirmar; las incorporaciones posteriores requieren aprobación.'
              }
            </p>
          </div>
        </>
      )}
    </MoveSurface>
  );
}
