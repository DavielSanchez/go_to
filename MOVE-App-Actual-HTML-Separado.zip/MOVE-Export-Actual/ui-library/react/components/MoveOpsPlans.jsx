import React, { useId } from 'react';
import { MoveSurface } from '../MoveSurface.jsx';

/** Bloque extraído del diseño actual de MOVE. Los eventos se exponen mediante onAction. */
export function MoveOpsPlans({
  theme = 'light',
  tenant = 'tp',
  reducedMotion = false,
  onAction,
  className = '',
  style,
  children,
}) {
  const uid = useId();
  return (
    <MoveSurface
      theme={theme}
      tenant={tenant}
      reducedMotion={reducedMotion}
      onAction={onAction}
      className={'' + ' ' + className}
      style={style}
    >
      {children ?? (
        <>
          <div className="management-controls">
            <button
              className="ops-button"
              data-move-click="openManagementDrawer('plan-launch')"
            >
              {'Generar planificación'}
            </button>
            <button
              className="ops-button secondary"
              data-move-click="navigate('ops-qr');render()"
            >
              {'Abrir catálogo QR'}
            </button>
          </div>
          <div className="ops-plan-grid">
            <article className="ops-card ops-plan-card">
              <div className="ops-plan-meta">
                <span className="ops-eyebrow">{'TP · Churchill'}</span>
                <span className="ops-pill confirmed">{'Confirmado'}</span>
              </div>
              <h3>{'Salida 00:30'}</h3>
              <p className="ops-muted">
                {'PLAN-100 · 3 de octubre de 2026 · Versión 1'}
              </p>
              <div className="ops-plan-summary">
                <div>
                  <strong>{'20'}</strong>
                  <small>{'Pasajeros incluidos'}</small>
                </div>
                <div>
                  <strong>{'2'}</strong>
                  <small>{'Viajes calculados'}</small>
                </div>
                <div>
                  <strong>{'6'}</strong>
                  <small>{'Sin confirmar'}</small>
                </div>
              </div>
              <div className="ops-plan-route">
                <b>{'Los Girasoles'}</b>
                <span>{'12 pasajeros'}</span>
                <button
                  className="ops-icon-button"
                  aria-label="Ver QR de ruta"
                  data-move-click="openOpsRoute('PLAN-100','07')"
                >
                  <svg
                    className="icon"
                    viewBox="0 0 24 24"
                    aria-hidden="true"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path
                      d="M3 7h18v4a2 2 0 0 0 0 4v4H3v-4a2 2 0 0 0 0-4zM15 7v2m0 3v2m0 3v2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    ></path>
                  </svg>
                </button>
              </div>
              <div className="ops-plan-route">
                <b>{'Pantoja'}</b>
                <span>{'8 pasajeros'}</span>
                <button
                  className="ops-icon-button"
                  aria-label="Ver QR de ruta"
                  data-move-click="openOpsRoute('PLAN-100','04')"
                >
                  <svg
                    className="icon"
                    viewBox="0 0 24 24"
                    aria-hidden="true"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path
                      d="M3 7h18v4a2 2 0 0 0 0 4v4H3v-4a2 2 0 0 0 0-4zM15 7v2m0 3v2m0 3v2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    ></path>
                  </svg>
                </button>
              </div>
              <details>
                <summary>{'Empleados pendientes (6)'}</summary>
                <p className="ops-muted">{'Ana Pérez 25'}</p>
                <p className="ops-muted">{'Carlos Mejía 26'}</p>
                <p className="ops-muted">{'Laura Díaz 27'}</p>
                <p className="ops-muted">{'Miguel Santos 28'}</p>
                <p className="ops-muted">{'Sofía Rodríguez 29'}</p>
                <p className="ops-muted">{'Juan Reyes 30'}</p>
              </details>
              <p className="ops-muted">
                {'Cutoff 20:00 · Confirmaciones cerradas'}
              </p>
              <button
                className="ops-button secondary"
                data-move-click="openManagementDrawer('plan-update','PLAN-100')"
              >
                {'4 por incorporar · Revisar actualización'}
              </button>
            </article>
          </div>
          <details className="ops-card">
            <summary>{'Simular nuevas respuestas'}</summary>
            <p className="ops-muted">
              {
                'Solo se reciben antes del cutoff. Para probar, selecciona la jornada de hoy y genera un plan.'
              }
            </p>
            <button
              className="ops-button secondary"
              data-move-click="simulatePendingConfirmations('PLAN-100')"
            >
              {'Recibir respuestas · 00:30'}
            </button>
          </details>
        </>
      )}
    </MoveSurface>
  );
}
