import React, { useId } from 'react';
import { MoveSurface } from '../MoveSurface.jsx';

/** Patrón signup-success usado en registrationView(). */
export function MoveSignupSuccess({
  theme = 'light',
  tenant = 'tp',
  reducedMotion = false,
  onAction,
  className = '',
  style,
  children,
}) {
  const uid = useId();
  return (
    <MoveSurface
      theme={theme}
      tenant={tenant}
      reducedMotion={reducedMotion}
      onAction={onAction}
      className={'' + ' ' + className}
      style={style}
    >
      {children ?? (
        <>
          <div className="card signup-success">
            <div className="review-icon">
              <svg
                className="icon"
                viewBox="0 0 24 24"
                aria-hidden="true"
                xmlns="http://www.w3.org/2000/svg"
              >
                <path
                  d="M5 12l4 4L19 6"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                ></path>
              </svg>
            </div>
            <h2>{'¡Bienvenido a MOVE!'}</h2>
            <p className="sub">{'Tu cuenta de demostración fue creada.'}</p>
            <b data-user-content="">{'ana.perez@gmail.com'}</b>
            <button className="btn" data-move-click="goToRegisteredLogin()">
              {'Iniciar sesión con mi cuenta'}
            </button>
            <p className="small-info">
              {
                'Podrás usar el correo y la contraseña que acabas de crear en este dispositivo.'
              }
            </p>
          </div>
        </>
      )}
    </MoveSurface>
  );
}
