import React, { useId } from 'react';
import { MoveSurface } from '../MoveSurface.jsx';

/** Patrón info-grid usado en views.home(). */
export function MoveInfoGrid({
  theme = 'light',
  tenant = 'tp',
  reducedMotion = false,
  onAction,
  className = '',
  style,
  children,
}) {
  const uid = useId();
  return (
    <MoveSurface
      theme={theme}
      tenant={tenant}
      reducedMotion={reducedMotion}
      onAction={onAction}
      className={'' + ' ' + className}
      style={style}
    >
      {children ?? (
        <>
          <div className="info-grid">
            <div>
              <small>{'Punto de encuentro'}</small>
              <b>{'Parqueo B · Zona 2'}</b>
            </div>
            <div>
              <small>{'Tiempo estimado'}</small>
              <b>{'35–45 minutos'}</b>
            </div>
          </div>
        </>
      )}
    </MoveSurface>
  );
}
