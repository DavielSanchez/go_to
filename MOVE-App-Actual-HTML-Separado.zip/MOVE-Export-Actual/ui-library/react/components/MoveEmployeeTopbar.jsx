import React, { useId } from 'react';
import { MoveSurface } from '../MoveSurface.jsx';
import asset0 from '../../assets/tp-logo.svg';
/** Navegación compartida con agentes y conductores. */
export function MoveEmployeeTopbar({
  theme = 'light',
  tenant = 'tp',
  reducedMotion = false,
  onAction,
  className = '',
  style,
  children,
}) {
  const uid = useId();
  return (
    <MoveSurface
      theme={theme}
      tenant={tenant}
      reducedMotion={reducedMotion}
      onAction={onAction}
      className={'' + ' ' + className}
      style={style}
    >
      {children ?? (
        <>
          <header>
            <a
              className="brand-collab"
              href="#ops-platform"
              aria-label="TP × MOVE"
            >
              <img className="tenant-logo tp-logo" src={asset0} alt="TP" />
              <span className="collab-cross" aria-hidden="true">
                {'×'}
              </span>
              <span className="brand">
                {'MOVE'}
                <span className="brand-dot"></span>
              </span>
            </a>
            <div className="header-right">
              <button
                className="avatar"
                aria-label="Opciones de cuenta"
                aria-expanded="false"
                aria-haspopup="dialog"
                data-move-click="navigate('profile')"
              >
                {'DS'}
              </button>
            </div>
          </header>
        </>
      )}
    </MoveSurface>
  );
}
