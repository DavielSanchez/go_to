import React, { useId } from 'react';
import { MoveSurface } from '../MoveSurface.jsx';

/** Animación original ops-drawer-enter. Usa el control Reproducir para reiniciarla. Respeta la preferencia de movimiento reducido. */
export function MoveMotionOpsDrawerEnter({
  theme = 'light',
  tenant = 'tp',
  reducedMotion = false,
  onAction,
  className = '',
  style,
  children,
}) {
  const uid = useId();
  return (
    <MoveSurface
      theme={theme}
      tenant={tenant}
      reducedMotion={reducedMotion}
      onAction={onAction}
      className={'' + ' ' + className}
      style={style}
    >
      {children ?? (
        <>
          <section
            className="card"
            style={{ animation: 'ops-drawer-enter .25s ease both' }}
          >
            <h2>{'Detalle del viaje'}</h2>
            <p className="sub">{'Entrada suave del panel de operación.'}</p>
          </section>
        </>
      )}
    </MoveSurface>
  );
}
