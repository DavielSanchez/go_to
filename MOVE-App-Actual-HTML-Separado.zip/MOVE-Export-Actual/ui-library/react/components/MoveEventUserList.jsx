import React, { useId } from 'react';
import { MoveSurface } from '../MoveSurface.jsx';

/** Patrón event-user-list usado en eventForm(). */
export function MoveEventUserList({
  theme = 'light',
  tenant = 'tp',
  reducedMotion = false,
  onAction,
  className = '',
  style,
  children,
}) {
  const uid = useId();
  return (
    <MoveSurface
      theme={theme}
      tenant={tenant}
      reducedMotion={reducedMotion}
      onAction={onAction}
      className={'' + ' ' + className}
      style={style}
    >
      {children ?? (
        <>
          <div className="event-user-list">
            <label className="management-check">
              <input
                type="checkbox"
                name="users"
                defaultValue="tp-churchill-U0"
                data-move-change="toggleEventUser(this.value,this.checked)"
              />
              <span>{'Ana Pérez 1'}</span>
            </label>
            <label className="management-check">
              <input
                type="checkbox"
                name="users"
                defaultValue="tp-churchill-U1"
                data-move-change="toggleEventUser(this.value,this.checked)"
              />
              <span>{'Carlos Mejía 2'}</span>
            </label>
            <label className="management-check">
              <input
                type="checkbox"
                name="users"
                defaultValue="tp-churchill-U2"
                data-move-change="toggleEventUser(this.value,this.checked)"
              />
              <span>{'Laura Díaz 3'}</span>
            </label>
            <label className="management-check">
              <input
                type="checkbox"
                name="users"
                defaultValue="tp-churchill-U3"
                data-move-change="toggleEventUser(this.value,this.checked)"
              />
              <span>{'Miguel Santos 4'}</span>
            </label>
            <label className="management-check">
              <input
                type="checkbox"
                name="users"
                defaultValue="tp-churchill-U4"
                data-move-change="toggleEventUser(this.value,this.checked)"
              />
              <span>{'Sofía Rodríguez 5'}</span>
            </label>
            <label className="management-check">
              <input
                type="checkbox"
                name="users"
                defaultValue="tp-churchill-U5"
                data-move-change="toggleEventUser(this.value,this.checked)"
              />
              <span>{'Juan Reyes 6'}</span>
            </label>
            <label className="management-check">
              <input
                type="checkbox"
                name="users"
                defaultValue="tp-churchill-U6"
                data-move-change="toggleEventUser(this.value,this.checked)"
              />
              <span>{'Ana Pérez 7'}</span>
            </label>
            <label className="management-check">
              <input
                type="checkbox"
                name="users"
                defaultValue="tp-churchill-U7"
                data-move-change="toggleEventUser(this.value,this.checked)"
              />
              <span>{'Carlos Mejía 8'}</span>
            </label>
            <label className="management-check">
              <input
                type="checkbox"
                name="users"
                defaultValue="tp-churchill-U8"
                data-move-change="toggleEventUser(this.value,this.checked)"
              />
              <span>{'Laura Díaz 9'}</span>
            </label>
            <label className="management-check">
              <input
                type="checkbox"
                name="users"
                defaultValue="tp-churchill-U9"
                data-move-change="toggleEventUser(this.value,this.checked)"
              />
              <span>{'Miguel Santos 10'}</span>
            </label>
            <label className="management-check">
              <input
                type="checkbox"
                name="users"
                defaultValue="tp-churchill-U10"
                data-move-change="toggleEventUser(this.value,this.checked)"
              />
              <span>{'Sofía Rodríguez 11'}</span>
            </label>
            <label className="management-check">
              <input
                type="checkbox"
                name="users"
                defaultValue="tp-churchill-U11"
                data-move-change="toggleEventUser(this.value,this.checked)"
              />
              <span>{'Juan Reyes 12'}</span>
            </label>
            <label className="management-check">
              <input
                type="checkbox"
                name="users"
                defaultValue="tp-churchill-U12"
                data-move-change="toggleEventUser(this.value,this.checked)"
              />
              <span>{'Ana Pérez 13'}</span>
            </label>
            <label className="management-check">
              <input
                type="checkbox"
                name="users"
                defaultValue="tp-churchill-U13"
                data-move-change="toggleEventUser(this.value,this.checked)"
              />
              <span>{'Carlos Mejía 14'}</span>
            </label>
            <label className="management-check">
              <input
                type="checkbox"
                name="users"
                defaultValue="tp-churchill-U14"
                data-move-change="toggleEventUser(this.value,this.checked)"
              />
              <span>{'Laura Díaz 15'}</span>
            </label>
            <label className="management-check">
              <input
                type="checkbox"
                name="users"
                defaultValue="tp-churchill-U15"
                data-move-change="toggleEventUser(this.value,this.checked)"
              />
              <span>{'Miguel Santos 16'}</span>
            </label>
            <label className="management-check">
              <input
                type="checkbox"
                name="users"
                defaultValue="tp-churchill-U16"
                data-move-change="toggleEventUser(this.value,this.checked)"
              />
              <span>{'Sofía Rodríguez 17'}</span>
            </label>
            <label className="management-check">
              <input
                type="checkbox"
                name="users"
                defaultValue="tp-churchill-U17"
                data-move-change="toggleEventUser(this.value,this.checked)"
              />
              <span>{'Juan Reyes 18'}</span>
            </label>
            <label className="management-check">
              <input
                type="checkbox"
                name="users"
                defaultValue="tp-churchill-U18"
                data-move-change="toggleEventUser(this.value,this.checked)"
              />
              <span>{'Ana Pérez 19'}</span>
            </label>
            <label className="management-check">
              <input
                type="checkbox"
                name="users"
                defaultValue="tp-churchill-U19"
                data-move-change="toggleEventUser(this.value,this.checked)"
              />
              <span>{'Carlos Mejía 20'}</span>
            </label>
            <label className="management-check">
              <input
                type="checkbox"
                name="users"
                defaultValue="tp-churchill-U20"
                data-move-change="toggleEventUser(this.value,this.checked)"
              />
              <span>{'Laura Díaz 21'}</span>
            </label>
            <label className="management-check">
              <input
                type="checkbox"
                name="users"
                defaultValue="tp-churchill-U21"
                data-move-change="toggleEventUser(this.value,this.checked)"
              />
              <span>{'Miguel Santos 22'}</span>
            </label>
            <label className="management-check">
              <input
                type="checkbox"
                name="users"
                defaultValue="tp-churchill-U22"
                data-move-change="toggleEventUser(this.value,this.checked)"
              />
              <span>{'Sofía Rodríguez 23'}</span>
            </label>
            <label className="management-check">
              <input
                type="checkbox"
                name="users"
                defaultValue="tp-churchill-U23"
                data-move-change="toggleEventUser(this.value,this.checked)"
              />
              <span>{'Juan Reyes 24'}</span>
            </label>
            <label className="management-check">
              <input
                type="checkbox"
                name="users"
                defaultValue="tp-churchill-U24"
                data-move-change="toggleEventUser(this.value,this.checked)"
              />
              <span>{'Ana Pérez 25'}</span>
            </label>
            <label className="management-check">
              <input
                type="checkbox"
                name="users"
                defaultValue="tp-churchill-U25"
                data-move-change="toggleEventUser(this.value,this.checked)"
              />
              <span>{'Carlos Mejía 26'}</span>
            </label>
            <label className="management-check">
              <input
                type="checkbox"
                name="users"
                defaultValue="tp-churchill-U26"
                data-move-change="toggleEventUser(this.value,this.checked)"
              />
              <span>{'Laura Díaz 27'}</span>
            </label>
            <label className="management-check">
              <input
                type="checkbox"
                name="users"
                defaultValue="tp-churchill-U27"
                data-move-change="toggleEventUser(this.value,this.checked)"
              />
              <span>{'Miguel Santos 28'}</span>
            </label>
            <label className="management-check">
              <input
                type="checkbox"
                name="users"
                defaultValue="tp-churchill-U28"
                data-move-change="toggleEventUser(this.value,this.checked)"
              />
              <span>{'Sofía Rodríguez 29'}</span>
            </label>
            <label className="management-check">
              <input
                type="checkbox"
                name="users"
                defaultValue="tp-churchill-U29"
                data-move-change="toggleEventUser(this.value,this.checked)"
              />
              <span>{'Juan Reyes 30'}</span>
            </label>
            <label className="management-check">
              <input
                type="checkbox"
                name="users"
                defaultValue="tp-churchill-U30"
                data-move-change="toggleEventUser(this.value,this.checked)"
              />
              <span>{'Ana Pérez 31'}</span>
            </label>
            <label className="management-check">
              <input
                type="checkbox"
                name="users"
                defaultValue="tp-churchill-U31"
                data-move-change="toggleEventUser(this.value,this.checked)"
              />
              <span>{'Carlos Mejía 32'}</span>
            </label>
            <label className="management-check">
              <input
                type="checkbox"
                name="users"
                defaultValue="tp-churchill-U32"
                data-move-change="toggleEventUser(this.value,this.checked)"
              />
              <span>{'Laura Díaz 33'}</span>
            </label>
            <label className="management-check">
              <input
                type="checkbox"
                name="users"
                defaultValue="tp-churchill-U33"
                data-move-change="toggleEventUser(this.value,this.checked)"
              />
              <span>{'Miguel Santos 34'}</span>
            </label>
            <label className="management-check">
              <input
                type="checkbox"
                name="users"
                defaultValue="tp-churchill-U34"
                data-move-change="toggleEventUser(this.value,this.checked)"
              />
              <span>{'Sofía Rodríguez 35'}</span>
            </label>
          </div>
        </>
      )}
    </MoveSurface>
  );
}
