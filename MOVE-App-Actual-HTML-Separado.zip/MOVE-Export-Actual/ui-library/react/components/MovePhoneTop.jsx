import React, { useId } from 'react';
import { MoveSurface } from '../MoveSurface.jsx';

/** Patrón phone-top usado en landing.js · landingView. */
export function MovePhoneTop({
  theme = 'light',
  tenant = 'tp',
  reducedMotion = false,
  onAction,
  className = '',
  style,
  children,
}) {
  const uid = useId();
  return (
    <MoveSurface
      theme={theme}
      tenant={tenant}
      reducedMotion={reducedMotion}
      onAction={onAction}
      className={'' + ' ' + className}
      style={style}
    >
      {children ?? (
        <>
          <div className="phone-top">
            <span className="brand">
              {'MOVE'}
              <span className="brand-dot"></span>
            </span>
            <span className="phone-avatar">{'DS'}</span>
          </div>
        </>
      )}
    </MoveSurface>
  );
}
