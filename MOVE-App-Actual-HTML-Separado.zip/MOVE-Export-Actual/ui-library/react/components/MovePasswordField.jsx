import React, { useId } from 'react';
import { MoveSurface } from '../MoveSurface.jsx';

/** Campo de contraseña. */
export function MovePasswordField({
  theme = 'light',
  tenant = 'tp',
  reducedMotion = false,
  onAction,
  className = '',
  style,
  children,
}) {
  const uid = useId();
  return (
    <MoveSurface
      theme={theme}
      tenant={tenant}
      reducedMotion={reducedMotion}
      onAction={onAction}
      className={'' + ' ' + className}
      style={style}
    >
      {children ?? (
        <>
          <div>
            <label className="label" htmlFor={uid + '-password-field'}>
              {'Contraseña'}
            </label>
            <input
              id={uid + '-password-field'}
              type="password"
              autoComplete="current-password"
              placeholder="Tu contraseña"
            />
          </div>
        </>
      )}
    </MoveSurface>
  );
}
