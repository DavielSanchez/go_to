import React, { useId } from 'react';
import { MoveSurface } from '../MoveSurface.jsx';

/** Patrón product-story usado en landing.js · landingView. */
export function MoveProductStory({
  theme = 'light',
  tenant = 'tp',
  reducedMotion = false,
  onAction,
  className = '',
  style,
  children,
}) {
  const uid = useId();
  return (
    <MoveSurface
      theme={theme}
      tenant={tenant}
      reducedMotion={reducedMotion}
      onAction={onAction}
      className={'' + ' ' + className}
      style={style}
    >
      {children ?? (
        <>
          <div className="product-story">
            <div
              className="lp-tabs"
              role="tablist"
              aria-label="Experiencias MOVE"
            >
              <button
                id={uid + '-employeeTab'}
                role="tab"
                aria-selected="true"
                className="active"
                data-move-click="selectLandingRole('employee')"
              >
                {'Colaborador'}
              </button>
              <button
                id={uid + '-driverTab'}
                role="tab"
                aria-selected="false"
                className=""
                data-move-click="selectLandingRole('driver')"
              >
                {'Conductor'}
              </button>
            </div>
            <div id={uid + '-roleStory'}>
              <span className="lp-kicker">
                {'MENOS DUDAS AL FINAL DEL TURNO'}
              </span>
              <h3>{'Tu regreso, en tus manos.'}</h3>
              <p>
                {
                  'Confirma tu transporte en segundos y consulta la información que necesitas para abordar.'
                }
              </p>
              <ul>
                <li>
                  <svg
                    className="icon"
                    viewBox="0 0 24 24"
                    aria-hidden="true"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path
                      d="M5 12l4 4L19 6"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    ></path>
                  </svg>
                  {'Confirmación diaria y ticket QR'}
                </li>
                <li>
                  <svg
                    className="icon"
                    viewBox="0 0 24 24"
                    aria-hidden="true"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path
                      d="M5 12l4 4L19 6"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    ></path>
                  </svg>
                  {'Excepciones cuando cambia la jornada'}
                </li>
                <li>
                  <svg
                    className="icon"
                    viewBox="0 0 24 24"
                    aria-hidden="true"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path
                      d="M5 12l4 4L19 6"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    ></path>
                  </svg>
                  {'Seguimiento del viaje y reseña final'}
                </li>
              </ul>
            </div>
            <button className="lp-button dark" data-move-click="enterMove()">
              {'Probar la demo completa '}
              <svg
                className="icon"
                viewBox="0 0 24 24"
                aria-hidden="true"
                xmlns="http://www.w3.org/2000/svg"
              >
                <path
                  d="M5 3h4l2 5-3 2c2 3 3 4 6 6l2-3 5 2v4c-8 5-22-9-16-16"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                ></path>
              </svg>
            </button>
            <p className="product-footnote">
              {'Prototipo navegable con datos de demostración.'}
            </p>
          </div>
        </>
      )}
    </MoveSurface>
  );
}
