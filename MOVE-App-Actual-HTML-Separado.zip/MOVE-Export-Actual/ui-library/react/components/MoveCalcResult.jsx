import React, { useId } from 'react';
import { MoveSurface } from '../MoveSurface.jsx';

/** Patrón calc-result usado en landing.js · landingView. */
export function MoveCalcResult({
  theme = 'light',
  tenant = 'tp',
  reducedMotion = false,
  onAction,
  className = '',
  style,
  children,
}) {
  const uid = useId();
  return (
    <MoveSurface
      theme={theme}
      tenant={tenant}
      reducedMotion={reducedMotion}
      onAction={onAction}
      className={'' + ' ' + className}
      style={style}
    >
      {children ?? (
        <>
          <div className="calc-result" aria-live="polite">
            <span>{'Costo mensual asociado a asientos vacíos'}</span>
            <strong id={uid + '-emptyCost'}>{'RD$277,200'}</strong>
            <small id={uid + '-emptySeats'}>
              {'72 asientos vacíos por día · Estimación en RD$'}
            </small>
          </div>
        </>
      )}
    </MoveSurface>
  );
}
