import React, { useId } from 'react';
import { MoveSurface } from '../MoveSurface.jsx';

/** Patrón ops-passenger usado en opsDrawerHTML(). */
export function MoveOpsPassenger({
  theme = 'light',
  tenant = 'tp',
  reducedMotion = false,
  onAction,
  className = '',
  style,
  children,
}) {
  const uid = useId();
  return (
    <MoveSurface
      theme={theme}
      tenant={tenant}
      reducedMotion={reducedMotion}
      onAction={onAction}
      className={'' + ' ' + className}
      style={style}
    >
      {children ?? (
        <>
          <div className="ops-passenger">
            <span>{'Ana Pérez'}</span>
            <span className="ops-pill confirmed">{'Abordado'}</span>
          </div>
        </>
      )}
    </MoveSurface>
  );
}
