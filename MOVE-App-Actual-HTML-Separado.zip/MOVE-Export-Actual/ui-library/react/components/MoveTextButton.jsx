import React, { useId } from 'react';
import { MoveSurface } from '../MoveSurface.jsx';

/** Botón de texto. */
export function MoveTextButton({
  theme = 'light',
  tenant = 'tp',
  reducedMotion = false,
  onAction,
  className = '',
  style,
  children,
}) {
  const uid = useId();
  return (
    <MoveSurface
      theme={theme}
      tenant={tenant}
      reducedMotion={reducedMotion}
      onAction={onAction}
      className={'' + ' ' + className}
      style={style}
    >
      {children ?? (
        <>
          <button className="text-btn">{'Cambiar dirección'}</button>
        </>
      )}
    </MoveSurface>
  );
}
