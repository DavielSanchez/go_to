import React, { useId } from 'react';
import { MoveSurface } from '../MoveSurface.jsx';

/** Patrón zone-item usado en zonesView(). */
export function MoveZoneItem({
  theme = 'light',
  tenant = 'tp',
  reducedMotion = false,
  onAction,
  className = '',
  style,
  children,
}) {
  const uid = useId();
  return (
    <MoveSurface
      theme={theme}
      tenant={tenant}
      reducedMotion={reducedMotion}
      onAction={onAction}
      className={'' + ' ' + className}
      style={style}
    >
      {children ?? (
        <>
          <button
            className="zone-item "
            data-move-click="selectZone('tp-churchill-07')"
          >
            <b>{'Los Girasoles'}</b>
            <small>{'Ruta 07 · v1 · 4 puntos'}</small>
          </button>
        </>
      )}
    </MoveSurface>
  );
}
