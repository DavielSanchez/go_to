import React, { useId } from 'react';
import { MoveSurface } from '../MoveSurface.jsx';

/** Badges y estados operativos. */
export function MoveStatusBadges({
  theme = 'light',
  tenant = 'tp',
  reducedMotion = false,
  onAction,
  className = '',
  style,
  children,
}) {
  const uid = useId();
  return (
    <MoveSurface
      theme={theme}
      tenant={tenant}
      reducedMotion={reducedMotion}
      onAction={onAction}
      className={'' + ' ' + className}
      style={style}
    >
      {children ?? (
        <>
          <div style={{ display: 'flex', flexWrap: 'wrap', gap: '10px' }}>
            <span className="pill">{'Confirmado'}</span>
            <span className="pill green">{'Finalizado'}</span>
            <span className="pill amber">{'Pendiente'}</span>
            <span className="ops-badge danger">{'Incidencia'}</span>
          </div>
        </>
      )}
    </MoveSurface>
  );
}
