import React, { useId } from 'react';
import { MoveSurface } from '../MoveSurface.jsx';

/** Navegación del rol Platform. */
export function MoveSiteScopePlatform({
  theme = 'light',
  tenant = 'tp',
  reducedMotion = false,
  onAction,
  className = '',
  style,
  children,
}) {
  const uid = useId();
  return (
    <MoveSurface
      theme={theme}
      tenant={tenant}
      reducedMotion={reducedMotion}
      onAction={onAction}
      className={'' + ' ' + className}
      style={style}
    >
      {children ?? (
        <>
          <details className="ops-scope">
            <summary>
              <svg
                className="icon"
                viewBox="0 0 24 24"
                aria-hidden="true"
                xmlns="http://www.w3.org/2000/svg"
              >
                <path
                  d="M20 10c0 6-8 12-8 12S4 16 4 10a8 8 0 1 1 16 0M15 10a3 3 0 1 1-6 0 3 3 0 0 1 6 0"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                ></path>
              </svg>
              <div>
                {'7 tenants seleccionados'}
                <small>{'Alcance autorizado · selección múltiple'}</small>
              </div>
              <svg
                className="icon"
                viewBox="0 0 24 24"
                aria-hidden="true"
                xmlns="http://www.w3.org/2000/svg"
              >
                <path
                  d="M9 5l7 7-7 7"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                ></path>
              </svg>
            </summary>
            <div className="ops-scope-list">
              <button
                className="ops-scope-all"
                data-move-click="selectAllOpsTenants()"
              >
                {'Seleccionar todos los autorizados'}
              </button>
              <label>
                <input
                  type="checkbox"
                  defaultValue="tp-churchill"
                  defaultChecked
                  data-move-change="toggleOpsTenant(this.value,this.checked)"
                />
                <span>
                  {'TP · Churchill'}
                  <small>{'DO · Santo Domingo'}</small>
                </span>
              </label>
              <label>
                <input
                  type="checkbox"
                  defaultValue="tp-sambil"
                  defaultChecked
                  data-move-change="toggleOpsTenant(this.value,this.checked)"
                />
                <span>
                  {'TP · Sambil'}
                  <small>{'DO · Santo Domingo'}</small>
                </span>
              </label>
              <label>
                <input
                  type="checkbox"
                  defaultValue="tp-santiago"
                  defaultChecked
                  data-move-change="toggleOpsTenant(this.value,this.checked)"
                />
                <span>
                  {'TP · Santiago'}
                  <small>{'DO · Santiago'}</small>
                </span>
              </label>
              <label>
                <input
                  type="checkbox"
                  defaultValue="tp-bogota"
                  defaultChecked
                  data-move-change="toggleOpsTenant(this.value,this.checked)"
                />
                <span>
                  {'TP · Bogotá'}
                  <small>{'CO · Bogotá'}</small>
                </span>
              </label>
              <label>
                <input
                  type="checkbox"
                  defaultValue="alorica-sd"
                  defaultChecked
                  data-move-change="toggleOpsTenant(this.value,this.checked)"
                />
                <span>
                  {'Alorica · Santo Domingo'}
                  <small>{'DO · Santo Domingo'}</small>
                </span>
              </label>
              <label>
                <input
                  type="checkbox"
                  defaultValue="concentrix-sd"
                  defaultChecked
                  data-move-change="toggleOpsTenant(this.value,this.checked)"
                />
                <span>
                  {'Concentrix · Santo Domingo'}
                  <small>{'DO · Santo Domingo'}</small>
                </span>
              </label>
              <label>
                <input
                  type="checkbox"
                  defaultValue="trueshore-sd"
                  defaultChecked
                  data-move-change="toggleOpsTenant(this.value,this.checked)"
                />
                <span>
                  {'TrueShore · Santo Domingo'}
                  <small>{'DO · Santo Domingo'}</small>
                </span>
              </label>
            </div>
          </details>
        </>
      )}
    </MoveSurface>
  );
}
