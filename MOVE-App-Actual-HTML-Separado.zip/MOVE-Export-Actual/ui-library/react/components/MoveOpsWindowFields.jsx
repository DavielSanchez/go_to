import React, { useId } from 'react';
import { MoveSurface } from '../MoveSurface.jsx';

/** Patrón ops-window-fields usado en opsConfigurationView(). */
export function MoveOpsWindowFields({
  theme = 'light',
  tenant = 'tp',
  reducedMotion = false,
  onAction,
  className = '',
  style,
  children,
}) {
  const uid = useId();
  return (
    <MoveSurface
      theme={theme}
      tenant={tenant}
      reducedMotion={reducedMotion}
      onAction={onAction}
      className={'' + ' ' + className}
      style={style}
    >
      {children ?? (
        <>
          <fieldset className="ops-window-fields">
            <legend>{'Ventanas disponibles'}</legend>
            <div>
              <label>
                <input
                  type="checkbox"
                  name="windows"
                  defaultValue="21:30"
                  defaultChecked
                />
                {'21:30'}
              </label>
              <label>
                <input
                  type="checkbox"
                  name="windows"
                  defaultValue="22:30"
                  defaultChecked
                />
                {'22:30'}
              </label>
              <label>
                <input
                  type="checkbox"
                  name="windows"
                  defaultValue="23:30"
                  defaultChecked
                />
                {'23:30'}
              </label>
              <label>
                <input
                  type="checkbox"
                  name="windows"
                  defaultValue="00:30"
                  defaultChecked
                />
                {'00:30'}
              </label>
            </div>
          </fieldset>
        </>
      )}
    </MoveSurface>
  );
}
