import React, { useId } from 'react';
import { MoveSurface } from '../MoveSurface.jsx';

/** Patrón zone-tools usado en zonesView(). */
export function MoveZoneTools({
  theme = 'light',
  tenant = 'tp',
  reducedMotion = false,
  onAction,
  className = '',
  style,
  children,
}) {
  const uid = useId();
  return (
    <MoveSurface
      theme={theme}
      tenant={tenant}
      reducedMotion={reducedMotion}
      onAction={onAction}
      className={'' + ' ' + className}
      style={style}
    >
      {children ?? (
        <>
          <div
            className="zone-tools"
            role="group"
            aria-label="Herramientas del mapa"
          >
            <button
              className="ops-button secondary "
              data-move-click="setZoneMode('pan')"
            >
              {'Mover mapa'}
            </button>
            <button
              className="ops-button secondary selected"
              data-move-click="setZoneMode('points')"
            >
              {'Por puntos'}
            </button>
            <button
              className="ops-button secondary "
              data-move-click="setZoneMode('freehand')"
            >
              {'Trazo libre'}
            </button>
            <button
              className="ops-button secondary"
              data-move-click="undoZonePoint()"
            >
              {'Deshacer'}
            </button>
            <button
              className="ops-button secondary"
              data-move-click="clearZone()"
            >
              {'Limpiar'}
            </button>
          </div>
        </>
      )}
    </MoveSurface>
  );
}
