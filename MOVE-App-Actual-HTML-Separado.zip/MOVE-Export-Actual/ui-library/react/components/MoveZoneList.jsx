import React, { useId } from 'react';
import { MoveSurface } from '../MoveSurface.jsx';

/** Patrón zone-list usado en zonesView(). */
export function MoveZoneList({
  theme = 'light',
  tenant = 'tp',
  reducedMotion = false,
  onAction,
  className = '',
  style,
  children,
}) {
  const uid = useId();
  return (
    <MoveSurface
      theme={theme}
      tenant={tenant}
      reducedMotion={reducedMotion}
      onAction={onAction}
      className={'' + ' ' + className}
      style={style}
    >
      {children ?? (
        <>
          <section className="ops-card zone-list">
            <h2>{'Rutas de servicio'}</h2>
            <button
              className="zone-item "
              data-move-click="selectZone('tp-churchill-07')"
            >
              <b>{'Los Girasoles'}</b>
              <small>{'Ruta 07 · v1 · 4 puntos'}</small>
            </button>
            <button
              className="zone-item "
              data-move-click="selectZone('tp-churchill-04')"
            >
              <b>{'Pantoja'}</b>
              <small>{'Ruta 04 · v1 · 4 puntos'}</small>
            </button>
          </section>
        </>
      )}
    </MoveSurface>
  );
}
