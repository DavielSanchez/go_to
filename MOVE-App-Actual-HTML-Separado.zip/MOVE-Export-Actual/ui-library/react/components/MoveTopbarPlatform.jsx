import React, { useId } from 'react';
import { MoveSurface } from '../MoveSurface.jsx';

/** Navegación del rol Platform. */
export function MoveTopbarPlatform({
  theme = 'light',
  tenant = 'tp',
  reducedMotion = false,
  onAction,
  className = '',
  style,
  children,
}) {
  const uid = useId();
  return (
    <MoveSurface
      theme={theme}
      tenant={tenant}
      reducedMotion={reducedMotion}
      onAction={onAction}
      className={'' + ' ' + className}
      style={style}
    >
      {children ?? (
        <>
          <header className="ops-topbar">
            <div className="ops-breadcrumb">
              {'\n        MOVE / Plataforma'}
              <span className="ops-live">
                <i></i>
                {'En vivo · Demo'}
              </span>
            </div>
            <div className="ops-top-actions">
              <button
                className="ops-icon-button"
                aria-label="Cambiar tema"
                data-move-click="\n            toggleTheme();\n            render();\n          "
              >
                <svg
                  className="icon"
                  viewBox="0 0 24 24"
                  aria-hidden="true"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    d="M21 13A9 9 0 1 1 11 3a7 7 0 0 0 10 10"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  ></path>
                </svg>
              </button>
              <select
                aria-label="Idioma"
                data-move-change="\n            setInterfaceLanguage(this.value);\n            render();\n          "
                defaultValue="es"
              >
                <option value="es">{'🇩🇴 ES'}</option>
                <option value="en">{'🇺🇸 EN'}</option>
              </select>
              <button
                className="ops-icon-button"
                aria-label="Ver auditoría"
                data-move-click="\n            navigate('ops-audit');\n            render();\n          "
              >
                <svg
                  className="icon"
                  viewBox="0 0 24 24"
                  aria-hidden="true"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    d="M12 3l8 3v6c0 5-8 9-8 9s-8-4-8-9V6zM8 12l3 3 5-6"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  ></path>
                </svg>
              </button>
            </div>
          </header>
        </>
      )}
    </MoveSurface>
  );
}
