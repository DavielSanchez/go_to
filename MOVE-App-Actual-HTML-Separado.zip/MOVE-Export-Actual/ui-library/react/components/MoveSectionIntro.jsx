import React, { useId } from 'react';
import { MoveSurface } from '../MoveSurface.jsx';

/** Patrón section-intro usado en landing.js · landingView. */
export function MoveSectionIntro({
  theme = 'light',
  tenant = 'tp',
  reducedMotion = false,
  onAction,
  className = '',
  style,
  children,
}) {
  const uid = useId();
  return (
    <MoveSurface
      theme={theme}
      tenant={tenant}
      reducedMotion={reducedMotion}
      onAction={onAction}
      className={'' + ' ' + className}
      style={style}
    >
      {children ?? (
        <>
          <div className="section-intro">
            <div>
              <span className="lp-kicker">
                {'01 / UNA MEJOR FORMA DE MOVERSE'}
              </span>
              <h2>
                {'Tu transporte puede'}
                <br />
                {'trabajar mejor.'}
              </h2>
            </div>
            <p>
              {
                'Las listas dispersas, los asientos vacíos y las llamadas de última hora no deberían definir el final de una jornada.'
              }
            </p>
          </div>
        </>
      )}
    </MoveSurface>
  );
}
