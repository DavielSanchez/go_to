import React, { useId } from 'react';
import { MoveSurface } from '../MoveSurface.jsx';

/** Patrón visual-caption usado en landing.js · landingView. */
export function MoveVisualCaption({
  theme = 'light',
  tenant = 'tp',
  reducedMotion = false,
  onAction,
  className = '',
  style,
  children,
}) {
  const uid = useId();
  return (
    <MoveSurface
      theme={theme}
      tenant={tenant}
      reducedMotion={reducedMotion}
      onAction={onAction}
      className={'' + ' ' + className}
      style={style}
    >
      {children ?? (
        <>
          <div className="visual-caption">
            <span className="lp-kicker">{'MENOS INCERTIDUMBRE'}</span>
            <p>
              {'Más tranquilidad.'}
              <br />
              {'Dentro y fuera del trabajo.'}
            </p>
          </div>
        </>
      )}
    </MoveSurface>
  );
}
