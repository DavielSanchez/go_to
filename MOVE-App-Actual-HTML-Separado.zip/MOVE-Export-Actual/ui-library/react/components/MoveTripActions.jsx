import React, { useId } from 'react';
import { MoveSurface } from '../MoveSurface.jsx';

/** Patrón trip-actions usado en views.trip(). */
export function MoveTripActions({
  theme = 'light',
  tenant = 'tp',
  reducedMotion = false,
  onAction,
  className = '',
  style,
  children,
}) {
  const uid = useId();
  return (
    <MoveSurface
      theme={theme}
      tenant={tenant}
      reducedMotion={reducedMotion}
      onAction={onAction}
      className={'' + ' ' + className}
      style={style}
    >
      {children ?? (
        <>
          <div className="trip-actions">
            <button
              className="btn secondary"
              data-move-click="toast('Demo: aquí podrás contactar al conductor.')"
            >
              <svg
                className="icon"
                viewBox="0 0 24 24"
                aria-hidden="true"
                xmlns="http://www.w3.org/2000/svg"
              >
                <path
                  d="M5 3h4l2 5-3 2c2 3 3 4 6 6l2-3 5 2v4c-8 5-22-9-16-16"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                ></path>
              </svg>
              {'Conductor'}
            </button>
            <button
              className="btn secondary"
              data-move-click="toast('Demo: aquí podrás contactar al equipo de transporte.')"
            >
              <svg
                className="icon"
                viewBox="0 0 24 24"
                aria-hidden="true"
                xmlns="http://www.w3.org/2000/svg"
              >
                <path
                  d="M21 11a9 9 0 0 1-9 9H4l-3 2 2-6a9 9 0 1 1 18-5M7 11h10"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                ></path>
              </svg>
              {'Soporte'}
            </button>
          </div>
        </>
      )}
    </MoveSurface>
  );
}
