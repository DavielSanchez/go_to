import React, { useId } from 'react';
import { MoveSurface } from '../MoveSurface.jsx';

/** Bloque extraído del diseño actual de MOVE. Los eventos se exponen mediante onAction. */
export function MoveAccountMenu({
  theme = 'light',
  tenant = 'tp',
  reducedMotion = false,
  onAction,
  className = '',
  style,
  children,
}) {
  const uid = useId();
  return (
    <MoveSurface
      theme={theme}
      tenant={tenant}
      reducedMotion={reducedMotion}
      onAction={onAction}
      className={'' + ' ' + className}
      style={style}
    >
      {children ?? (
        <>
          <div
            id={uid + '-accountMenu'}
            className="account-menu"
            role="dialog"
            aria-label="Opciones de cuenta"
          >
            <div className="account-menu-title">
              <b>{'Daviel Sánchez'}</b>
              <small>{'Colaborador'}</small>
            </div>
            <button data-move-click="accountOpen=false;navigate(access.role==='driver'?'driver-profile':'profile');render()">
              <svg
                className="icon"
                viewBox="0 0 24 24"
                aria-hidden="true"
                xmlns="http://www.w3.org/2000/svg"
              >
                <path
                  d="M20 21v-2a6 6 0 0 0-6-6h-4a6 6 0 0 0-6 6v2M16 6a4 4 0 1 1-8 0 4 4 0 0 1 8 0"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                ></path>
              </svg>
              {'Mi perfil'}
            </button>
            <button data-move-click="accountOpen=false;navigate('settings');render()">
              <svg
                className="icon"
                viewBox="0 0 24 24"
                aria-hidden="true"
                xmlns="http://www.w3.org/2000/svg"
              >
                <path
                  d="M12 3l8 3v6c0 5-8 9-8 9s-8-4-8-9V6zM8 12l3 3 5-6"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                ></path>
              </svg>
              {'Configuración'}
            </button>
            <div className="account-setting">
              <span>{'Tema'}</span>
              <div>
                <button
                  aria-pressed="true"
                  data-move-click="setAccountTheme('light')"
                >
                  {'Claro'}
                </button>
                <button
                  aria-pressed="false"
                  data-move-click="setAccountTheme('dark')"
                >
                  {'Oscuro'}
                </button>
              </div>
            </div>
            <div className="account-setting">
              <span>{'Idioma'}</span>
              <div>
                <button
                  aria-pressed="true"
                  data-move-click="setInterfaceLanguage('es')"
                >
                  {'🇩🇴 Español'}
                </button>
                <button
                  aria-pressed="false"
                  data-move-click="setInterfaceLanguage('en')"
                >
                  {'🇺🇸 English'}
                </button>
              </div>
            </div>
            <button
              className="logout-action"
              data-move-click="accountOpen=false;logoutMove()"
            >
              <svg
                className="icon"
                viewBox="0 0 24 24"
                aria-hidden="true"
                xmlns="http://www.w3.org/2000/svg"
              >
                <path
                  d="M15 5l-7 7 7 7"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                ></path>
              </svg>
              {'Cerrar sesión'}
            </button>
          </div>
        </>
      )}
    </MoveSurface>
  );
}
