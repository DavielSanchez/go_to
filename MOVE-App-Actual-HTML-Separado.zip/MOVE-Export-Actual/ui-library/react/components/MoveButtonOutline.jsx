import React, { useId } from 'react';
import { MoveSurface } from '../MoveSurface.jsx';

/** Acción con borde. */
export function MoveButtonOutline({
  theme = 'light',
  tenant = 'tp',
  reducedMotion = false,
  onAction,
  className = '',
  style,
  children,
}) {
  const uid = useId();
  return (
    <MoveSurface
      theme={theme}
      tenant={tenant}
      reducedMotion={reducedMotion}
      onAction={onAction}
      className={'' + ' ' + className}
      style={style}
    >
      {children ?? (
        <>
          <button className="btn outline">{'Ver detalles'}</button>
        </>
      )}
    </MoveSurface>
  );
}
