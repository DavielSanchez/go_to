import React, { useId } from 'react';
import { MoveSurface } from '../MoveSurface.jsx';

/** Bloque extraído del diseño actual de MOVE. Los eventos se exponen mediante onAction. */
export function MoveUsers({
  theme = 'light',
  tenant = 'tp',
  reducedMotion = false,
  onAction,
  className = '',
  style,
  children,
}) {
  const uid = useId();
  return (
    <MoveSurface
      theme={theme}
      tenant={tenant}
      reducedMotion={reducedMotion}
      onAction={onAction}
      className={'' + ' ' + className}
      style={style}
    >
      {children ?? (
        <>
          <section className="ops-card">
            <div className="ops-section-title">
              <h2>{'Cuentas y acceso'}</h2>
            </div>
            <div className="management-controls">
              <input
                aria-label="Buscar usuarios"
                placeholder="Buscar nombre o correo…"
                defaultValue=""
                data-move-input="managementSearch=this.value;updateUsersList()"
              />
              <button
                className="ops-button"
                data-move-click="openManagementDrawer('user-create')"
              >
                {'Preregistrar empleado'}
              </button>
              <button
                className="ops-button secondary"
                data-move-click="openManagementDrawer('user-import')"
              >
                {'Importar Excel / CSV'}
              </button>
            </div>
            <p className="ops-muted">
              {
                'El correo personal autorizado habilita el registro con OTP. 48 cuentas en esta vista.'
              }
            </p>
            <div id={uid + '-usersList'}>
              <div className="ops-table-scroll">
                <table className="ops-table">
                  <thead>
                    <tr>
                      <th>{'Persona'}</th>
                      <th>{'Correo'}</th>
                      <th>{'Rol'}</th>
                      <th>{'Estado'}</th>
                      <th></th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td>
                        <b>{'Ana Pérez 1'}</b>
                      </td>
                      <td>{'empleado1.tp-churchill@example.com'}</td>
                      <td>{'Supervisor'}</td>
                      <td>
                        <span className="ops-pill confirmed">{'Activa'}</span>
                      </td>
                      <td>
                        <button
                          className="ops-button secondary"
                          data-move-click="openManagementDrawer('user-edit','tp-churchill-U0')"
                        >
                          {'Editar'}
                        </button>
                      </td>
                    </tr>
                    <tr>
                      <td>
                        <b>{'Carlos Mejía 2'}</b>
                      </td>
                      <td>{'empleado2.tp-churchill@example.com'}</td>
                      <td>{'Coordinador'}</td>
                      <td>
                        <span className="ops-pill confirmed">{'Activa'}</span>
                      </td>
                      <td>
                        <button
                          className="ops-button secondary"
                          data-move-click="openManagementDrawer('user-edit','tp-churchill-U1')"
                        >
                          {'Editar'}
                        </button>
                      </td>
                    </tr>
                    <tr>
                      <td>
                        <b>{'Laura Díaz 3'}</b>
                      </td>
                      <td>{'empleado3.tp-churchill@example.com'}</td>
                      <td>{'Administrador'}</td>
                      <td>
                        <span className="ops-pill confirmed">{'Activa'}</span>
                      </td>
                      <td>
                        <button
                          className="ops-button secondary"
                          data-move-click="openManagementDrawer('user-edit','tp-churchill-U2')"
                        >
                          {'Editar'}
                        </button>
                      </td>
                    </tr>
                    <tr>
                      <td>
                        <b>{'Miguel Santos 4'}</b>
                      </td>
                      <td>{'empleado4.tp-churchill@example.com'}</td>
                      <td>{'Empleado'}</td>
                      <td>
                        <span className="ops-pill confirmed">{'Activa'}</span>
                      </td>
                      <td>
                        <button
                          className="ops-button secondary"
                          data-move-click="openManagementDrawer('user-edit','tp-churchill-U3')"
                        >
                          {'Editar'}
                        </button>
                      </td>
                    </tr>
                    <tr>
                      <td>
                        <b>{'Sofía Rodríguez 5'}</b>
                      </td>
                      <td>{'empleado5.tp-churchill@example.com'}</td>
                      <td>{'Empleado'}</td>
                      <td>
                        <span className="ops-pill confirmed">{'Activa'}</span>
                      </td>
                      <td>
                        <button
                          className="ops-button secondary"
                          data-move-click="openManagementDrawer('user-edit','tp-churchill-U4')"
                        >
                          {'Editar'}
                        </button>
                      </td>
                    </tr>
                    <tr>
                      <td>
                        <b>{'Juan Reyes 6'}</b>
                      </td>
                      <td>{'empleado6.tp-churchill@example.com'}</td>
                      <td>{'Empleado'}</td>
                      <td>
                        <span className="ops-pill confirmed">{'Activa'}</span>
                      </td>
                      <td>
                        <button
                          className="ops-button secondary"
                          data-move-click="openManagementDrawer('user-edit','tp-churchill-U5')"
                        >
                          {'Editar'}
                        </button>
                      </td>
                    </tr>
                    <tr>
                      <td>
                        <b>{'Ana Pérez 7'}</b>
                      </td>
                      <td>{'empleado7.tp-churchill@example.com'}</td>
                      <td>{'Empleado'}</td>
                      <td>
                        <span className="ops-pill confirmed">{'Activa'}</span>
                      </td>
                      <td>
                        <button
                          className="ops-button secondary"
                          data-move-click="openManagementDrawer('user-edit','tp-churchill-U6')"
                        >
                          {'Editar'}
                        </button>
                      </td>
                    </tr>
                    <tr>
                      <td>
                        <b>{'Carlos Mejía 8'}</b>
                      </td>
                      <td>{'empleado8.tp-churchill@example.com'}</td>
                      <td>{'Empleado'}</td>
                      <td>
                        <span className="ops-pill confirmed">{'Activa'}</span>
                      </td>
                      <td>
                        <button
                          className="ops-button secondary"
                          data-move-click="openManagementDrawer('user-edit','tp-churchill-U7')"
                        >
                          {'Editar'}
                        </button>
                      </td>
                    </tr>
                    <tr>
                      <td>
                        <b>{'Laura Díaz 9'}</b>
                      </td>
                      <td>{'empleado9.tp-churchill@example.com'}</td>
                      <td>{'Empleado'}</td>
                      <td>
                        <span className="ops-pill confirmed">{'Activa'}</span>
                      </td>
                      <td>
                        <button
                          className="ops-button secondary"
                          data-move-click="openManagementDrawer('user-edit','tp-churchill-U8')"
                        >
                          {'Editar'}
                        </button>
                      </td>
                    </tr>
                    <tr>
                      <td>
                        <b>{'Miguel Santos 10'}</b>
                      </td>
                      <td>{'empleado10.tp-churchill@example.com'}</td>
                      <td>{'Empleado'}</td>
                      <td>
                        <span className="ops-pill confirmed">{'Activa'}</span>
                      </td>
                      <td>
                        <button
                          className="ops-button secondary"
                          data-move-click="openManagementDrawer('user-edit','tp-churchill-U9')"
                        >
                          {'Editar'}
                        </button>
                      </td>
                    </tr>
                    <tr>
                      <td>
                        <b>{'Sofía Rodríguez 11'}</b>
                      </td>
                      <td>{'empleado11.tp-churchill@example.com'}</td>
                      <td>{'Empleado'}</td>
                      <td>
                        <span className="ops-pill confirmed">{'Activa'}</span>
                      </td>
                      <td>
                        <button
                          className="ops-button secondary"
                          data-move-click="openManagementDrawer('user-edit','tp-churchill-U10')"
                        >
                          {'Editar'}
                        </button>
                      </td>
                    </tr>
                    <tr>
                      <td>
                        <b>{'Juan Reyes 12'}</b>
                      </td>
                      <td>{'empleado12.tp-churchill@example.com'}</td>
                      <td>{'Empleado'}</td>
                      <td>
                        <span className="ops-pill confirmed">{'Activa'}</span>
                      </td>
                      <td>
                        <button
                          className="ops-button secondary"
                          data-move-click="openManagementDrawer('user-edit','tp-churchill-U11')"
                        >
                          {'Editar'}
                        </button>
                      </td>
                    </tr>
                    <tr>
                      <td>
                        <b>{'Ana Pérez 13'}</b>
                      </td>
                      <td>{'empleado13.tp-churchill@example.com'}</td>
                      <td>{'Empleado'}</td>
                      <td>
                        <span className="ops-pill confirmed">{'Activa'}</span>
                      </td>
                      <td>
                        <button
                          className="ops-button secondary"
                          data-move-click="openManagementDrawer('user-edit','tp-churchill-U12')"
                        >
                          {'Editar'}
                        </button>
                      </td>
                    </tr>
                    <tr>
                      <td>
                        <b>{'Carlos Mejía 14'}</b>
                      </td>
                      <td>{'empleado14.tp-churchill@example.com'}</td>
                      <td>{'Empleado'}</td>
                      <td>
                        <span className="ops-pill confirmed">{'Activa'}</span>
                      </td>
                      <td>
                        <button
                          className="ops-button secondary"
                          data-move-click="openManagementDrawer('user-edit','tp-churchill-U13')"
                        >
                          {'Editar'}
                        </button>
                      </td>
                    </tr>
                    <tr>
                      <td>
                        <b>{'Laura Díaz 15'}</b>
                      </td>
                      <td>{'empleado15.tp-churchill@example.com'}</td>
                      <td>{'Empleado'}</td>
                      <td>
                        <span className="ops-pill confirmed">{'Activa'}</span>
                      </td>
                      <td>
                        <button
                          className="ops-button secondary"
                          data-move-click="openManagementDrawer('user-edit','tp-churchill-U14')"
                        >
                          {'Editar'}
                        </button>
                      </td>
                    </tr>
                    <tr>
                      <td>
                        <b>{'Miguel Santos 16'}</b>
                      </td>
                      <td>{'empleado16.tp-churchill@example.com'}</td>
                      <td>{'Empleado'}</td>
                      <td>
                        <span className="ops-pill confirmed">{'Activa'}</span>
                      </td>
                      <td>
                        <button
                          className="ops-button secondary"
                          data-move-click="openManagementDrawer('user-edit','tp-churchill-U15')"
                        >
                          {'Editar'}
                        </button>
                      </td>
                    </tr>
                    <tr>
                      <td>
                        <b>{'Sofía Rodríguez 17'}</b>
                      </td>
                      <td>{'empleado17.tp-churchill@example.com'}</td>
                      <td>{'Empleado'}</td>
                      <td>
                        <span className="ops-pill confirmed">{'Activa'}</span>
                      </td>
                      <td>
                        <button
                          className="ops-button secondary"
                          data-move-click="openManagementDrawer('user-edit','tp-churchill-U16')"
                        >
                          {'Editar'}
                        </button>
                      </td>
                    </tr>
                    <tr>
                      <td>
                        <b>{'Juan Reyes 18'}</b>
                      </td>
                      <td>{'empleado18.tp-churchill@example.com'}</td>
                      <td>{'Empleado'}</td>
                      <td>
                        <span className="ops-pill confirmed">{'Activa'}</span>
                      </td>
                      <td>
                        <button
                          className="ops-button secondary"
                          data-move-click="openManagementDrawer('user-edit','tp-churchill-U17')"
                        >
                          {'Editar'}
                        </button>
                      </td>
                    </tr>
                    <tr>
                      <td>
                        <b>{'Ana Pérez 19'}</b>
                      </td>
                      <td>{'empleado19.tp-churchill@example.com'}</td>
                      <td>{'Empleado'}</td>
                      <td>
                        <span className="ops-pill confirmed">{'Activa'}</span>
                      </td>
                      <td>
                        <button
                          className="ops-button secondary"
                          data-move-click="openManagementDrawer('user-edit','tp-churchill-U18')"
                        >
                          {'Editar'}
                        </button>
                      </td>
                    </tr>
                    <tr>
                      <td>
                        <b>{'Carlos Mejía 20'}</b>
                      </td>
                      <td>{'empleado20.tp-churchill@example.com'}</td>
                      <td>{'Empleado'}</td>
                      <td>
                        <span className="ops-pill confirmed">{'Activa'}</span>
                      </td>
                      <td>
                        <button
                          className="ops-button secondary"
                          data-move-click="openManagementDrawer('user-edit','tp-churchill-U19')"
                        >
                          {'Editar'}
                        </button>
                      </td>
                    </tr>
                    <tr>
                      <td>
                        <b>{'Laura Díaz 21'}</b>
                      </td>
                      <td>{'empleado21.tp-churchill@example.com'}</td>
                      <td>{'Empleado'}</td>
                      <td>
                        <span className="ops-pill confirmed">{'Activa'}</span>
                      </td>
                      <td>
                        <button
                          className="ops-button secondary"
                          data-move-click="openManagementDrawer('user-edit','tp-churchill-U20')"
                        >
                          {'Editar'}
                        </button>
                      </td>
                    </tr>
                    <tr>
                      <td>
                        <b>{'Miguel Santos 22'}</b>
                      </td>
                      <td>{'empleado22.tp-churchill@example.com'}</td>
                      <td>{'Empleado'}</td>
                      <td>
                        <span className="ops-pill confirmed">{'Activa'}</span>
                      </td>
                      <td>
                        <button
                          className="ops-button secondary"
                          data-move-click="openManagementDrawer('user-edit','tp-churchill-U21')"
                        >
                          {'Editar'}
                        </button>
                      </td>
                    </tr>
                    <tr>
                      <td>
                        <b>{'Sofía Rodríguez 23'}</b>
                      </td>
                      <td>{'empleado23.tp-churchill@example.com'}</td>
                      <td>{'Empleado'}</td>
                      <td>
                        <span className="ops-pill confirmed">{'Activa'}</span>
                      </td>
                      <td>
                        <button
                          className="ops-button secondary"
                          data-move-click="openManagementDrawer('user-edit','tp-churchill-U22')"
                        >
                          {'Editar'}
                        </button>
                      </td>
                    </tr>
                    <tr>
                      <td>
                        <b>{'Juan Reyes 24'}</b>
                      </td>
                      <td>{'empleado24.tp-churchill@example.com'}</td>
                      <td>{'Empleado'}</td>
                      <td>
                        <span className="ops-pill confirmed">{'Activa'}</span>
                      </td>
                      <td>
                        <button
                          className="ops-button secondary"
                          data-move-click="openManagementDrawer('user-edit','tp-churchill-U23')"
                        >
                          {'Editar'}
                        </button>
                      </td>
                    </tr>
                    <tr>
                      <td>
                        <b>{'Ana Pérez 25'}</b>
                      </td>
                      <td>{'empleado25.tp-churchill@example.com'}</td>
                      <td>{'Empleado'}</td>
                      <td>
                        <span className="ops-pill confirmed">{'Activa'}</span>
                      </td>
                      <td>
                        <button
                          className="ops-button secondary"
                          data-move-click="openManagementDrawer('user-edit','tp-churchill-U24')"
                        >
                          {'Editar'}
                        </button>
                      </td>
                    </tr>
                    <tr>
                      <td>
                        <b>{'Carlos Mejía 26'}</b>
                      </td>
                      <td>{'empleado26.tp-churchill@example.com'}</td>
                      <td>{'Empleado'}</td>
                      <td>
                        <span className="ops-pill confirmed">{'Activa'}</span>
                      </td>
                      <td>
                        <button
                          className="ops-button secondary"
                          data-move-click="openManagementDrawer('user-edit','tp-churchill-U25')"
                        >
                          {'Editar'}
                        </button>
                      </td>
                    </tr>
                    <tr>
                      <td>
                        <b>{'Laura Díaz 27'}</b>
                      </td>
                      <td>{'empleado27.tp-churchill@example.com'}</td>
                      <td>{'Empleado'}</td>
                      <td>
                        <span className="ops-pill confirmed">{'Activa'}</span>
                      </td>
                      <td>
                        <button
                          className="ops-button secondary"
                          data-move-click="openManagementDrawer('user-edit','tp-churchill-U26')"
                        >
                          {'Editar'}
                        </button>
                      </td>
                    </tr>
                    <tr>
                      <td>
                        <b>{'Miguel Santos 28'}</b>
                      </td>
                      <td>{'empleado28.tp-churchill@example.com'}</td>
                      <td>{'Empleado'}</td>
                      <td>
                        <span className="ops-pill confirmed">{'Activa'}</span>
                      </td>
                      <td>
                        <button
                          className="ops-button secondary"
                          data-move-click="openManagementDrawer('user-edit','tp-churchill-U27')"
                        >
                          {'Editar'}
                        </button>
                      </td>
                    </tr>
                    <tr>
                      <td>
                        <b>{'Sofía Rodríguez 29'}</b>
                      </td>
                      <td>{'empleado29.tp-churchill@example.com'}</td>
                      <td>{'Empleado'}</td>
                      <td>
                        <span className="ops-pill confirmed">{'Activa'}</span>
                      </td>
                      <td>
                        <button
                          className="ops-button secondary"
                          data-move-click="openManagementDrawer('user-edit','tp-churchill-U28')"
                        >
                          {'Editar'}
                        </button>
                      </td>
                    </tr>
                    <tr>
                      <td>
                        <b>{'Juan Reyes 30'}</b>
                      </td>
                      <td>{'empleado30.tp-churchill@example.com'}</td>
                      <td>{'Empleado'}</td>
                      <td>
                        <span className="ops-pill confirmed">{'Activa'}</span>
                      </td>
                      <td>
                        <button
                          className="ops-button secondary"
                          data-move-click="openManagementDrawer('user-edit','tp-churchill-U29')"
                        >
                          {'Editar'}
                        </button>
                      </td>
                    </tr>
                    <tr>
                      <td>
                        <b>{'Ana Pérez 31'}</b>
                      </td>
                      <td>{'empleado31.tp-churchill@example.com'}</td>
                      <td>{'Empleado'}</td>
                      <td>
                        <span className="ops-pill confirmed">{'Activa'}</span>
                      </td>
                      <td>
                        <button
                          className="ops-button secondary"
                          data-move-click="openManagementDrawer('user-edit','tp-churchill-U30')"
                        >
                          {'Editar'}
                        </button>
                      </td>
                    </tr>
                    <tr>
                      <td>
                        <b>{'Carlos Mejía 32'}</b>
                      </td>
                      <td>{'empleado32.tp-churchill@example.com'}</td>
                      <td>{'Empleado'}</td>
                      <td>
                        <span className="ops-pill confirmed">{'Activa'}</span>
                      </td>
                      <td>
                        <button
                          className="ops-button secondary"
                          data-move-click="openManagementDrawer('user-edit','tp-churchill-U31')"
                        >
                          {'Editar'}
                        </button>
                      </td>
                    </tr>
                    <tr>
                      <td>
                        <b>{'Laura Díaz 33'}</b>
                      </td>
                      <td>{'empleado33.tp-churchill@example.com'}</td>
                      <td>{'Empleado'}</td>
                      <td>
                        <span className="ops-pill confirmed">{'Activa'}</span>
                      </td>
                      <td>
                        <button
                          className="ops-button secondary"
                          data-move-click="openManagementDrawer('user-edit','tp-churchill-U32')"
                        >
                          {'Editar'}
                        </button>
                      </td>
                    </tr>
                    <tr>
                      <td>
                        <b>{'Miguel Santos 34'}</b>
                      </td>
                      <td>{'empleado34.tp-churchill@example.com'}</td>
                      <td>{'Empleado'}</td>
                      <td>
                        <span className="ops-pill confirmed">{'Activa'}</span>
                      </td>
                      <td>
                        <button
                          className="ops-button secondary"
                          data-move-click="openManagementDrawer('user-edit','tp-churchill-U33')"
                        >
                          {'Editar'}
                        </button>
                      </td>
                    </tr>
                    <tr>
                      <td>
                        <b>{'Sofía Rodríguez 35'}</b>
                      </td>
                      <td>{'empleado35.tp-churchill@example.com'}</td>
                      <td>{'Empleado'}</td>
                      <td>
                        <span className="ops-pill confirmed">{'Activa'}</span>
                      </td>
                      <td>
                        <button
                          className="ops-button secondary"
                          data-move-click="openManagementDrawer('user-edit','tp-churchill-U34')"
                        >
                          {'Editar'}
                        </button>
                      </td>
                    </tr>
                    <tr>
                      <td>
                        <b>{'Juan Reyes 36'}</b>
                      </td>
                      <td>{'empleado36.tp-churchill@example.com'}</td>
                      <td>{'Empleado'}</td>
                      <td>
                        <span className="ops-pill draft">
                          {'Preregistrada'}
                        </span>
                      </td>
                      <td>
                        <button
                          className="ops-button secondary"
                          data-move-click="openManagementDrawer('user-edit','tp-churchill-U35')"
                        >
                          {'Editar'}
                        </button>
                      </td>
                    </tr>
                    <tr>
                      <td>
                        <b>{'Ana Pérez 37'}</b>
                      </td>
                      <td>{'empleado37.tp-churchill@example.com'}</td>
                      <td>{'Empleado'}</td>
                      <td>
                        <span className="ops-pill draft">
                          {'Preregistrada'}
                        </span>
                      </td>
                      <td>
                        <button
                          className="ops-button secondary"
                          data-move-click="openManagementDrawer('user-edit','tp-churchill-U36')"
                        >
                          {'Editar'}
                        </button>
                      </td>
                    </tr>
                    <tr>
                      <td>
                        <b>{'Carlos Mejía 38'}</b>
                      </td>
                      <td>{'empleado38.tp-churchill@example.com'}</td>
                      <td>{'Empleado'}</td>
                      <td>
                        <span className="ops-pill draft">
                          {'Preregistrada'}
                        </span>
                      </td>
                      <td>
                        <button
                          className="ops-button secondary"
                          data-move-click="openManagementDrawer('user-edit','tp-churchill-U37')"
                        >
                          {'Editar'}
                        </button>
                      </td>
                    </tr>
                    <tr>
                      <td>
                        <b>{'Laura Díaz 39'}</b>
                      </td>
                      <td>{'empleado39.tp-churchill@example.com'}</td>
                      <td>{'Empleado'}</td>
                      <td>
                        <span className="ops-pill draft">
                          {'Preregistrada'}
                        </span>
                      </td>
                      <td>
                        <button
                          className="ops-button secondary"
                          data-move-click="openManagementDrawer('user-edit','tp-churchill-U38')"
                        >
                          {'Editar'}
                        </button>
                      </td>
                    </tr>
                    <tr>
                      <td>
                        <b>{'Miguel Santos 40'}</b>
                      </td>
                      <td>{'empleado40.tp-churchill@example.com'}</td>
                      <td>{'Empleado'}</td>
                      <td>
                        <span className="ops-pill draft">
                          {'Preregistrada'}
                        </span>
                      </td>
                      <td>
                        <button
                          className="ops-button secondary"
                          data-move-click="openManagementDrawer('user-edit','tp-churchill-U39')"
                        >
                          {'Editar'}
                        </button>
                      </td>
                    </tr>
                    <tr>
                      <td>
                        <b>{'Sofía Rodríguez 41'}</b>
                      </td>
                      <td>{'empleado41.tp-churchill@example.com'}</td>
                      <td>{'Empleado'}</td>
                      <td>
                        <span className="ops-pill draft">
                          {'Preregistrada'}
                        </span>
                      </td>
                      <td>
                        <button
                          className="ops-button secondary"
                          data-move-click="openManagementDrawer('user-edit','tp-churchill-U40')"
                        >
                          {'Editar'}
                        </button>
                      </td>
                    </tr>
                    <tr>
                      <td>
                        <b>{'Juan Reyes 42'}</b>
                      </td>
                      <td>{'empleado42.tp-churchill@example.com'}</td>
                      <td>{'Empleado'}</td>
                      <td>
                        <span className="ops-pill draft">
                          {'Preregistrada'}
                        </span>
                      </td>
                      <td>
                        <button
                          className="ops-button secondary"
                          data-move-click="openManagementDrawer('user-edit','tp-churchill-U41')"
                        >
                          {'Editar'}
                        </button>
                      </td>
                    </tr>
                    <tr>
                      <td>
                        <b>{'Ana Pérez 43'}</b>
                      </td>
                      <td>{'empleado43.tp-churchill@example.com'}</td>
                      <td>{'Empleado'}</td>
                      <td>
                        <span className="ops-pill draft">
                          {'Preregistrada'}
                        </span>
                      </td>
                      <td>
                        <button
                          className="ops-button secondary"
                          data-move-click="openManagementDrawer('user-edit','tp-churchill-U42')"
                        >
                          {'Editar'}
                        </button>
                      </td>
                    </tr>
                    <tr>
                      <td>
                        <b>{'Carlos Mejía 44'}</b>
                      </td>
                      <td>{'empleado44.tp-churchill@example.com'}</td>
                      <td>{'Empleado'}</td>
                      <td>
                        <span className="ops-pill draft">
                          {'Preregistrada'}
                        </span>
                      </td>
                      <td>
                        <button
                          className="ops-button secondary"
                          data-move-click="openManagementDrawer('user-edit','tp-churchill-U43')"
                        >
                          {'Editar'}
                        </button>
                      </td>
                    </tr>
                    <tr>
                      <td>
                        <b>{'Laura Díaz 45'}</b>
                      </td>
                      <td>{'empleado45.tp-churchill@example.com'}</td>
                      <td>{'Empleado'}</td>
                      <td>
                        <span className="ops-pill draft">
                          {'Preregistrada'}
                        </span>
                      </td>
                      <td>
                        <button
                          className="ops-button secondary"
                          data-move-click="openManagementDrawer('user-edit','tp-churchill-U44')"
                        >
                          {'Editar'}
                        </button>
                      </td>
                    </tr>
                    <tr>
                      <td>
                        <b>{'Miguel Santos 46'}</b>
                      </td>
                      <td>{'empleado46.tp-churchill@example.com'}</td>
                      <td>{'Empleado'}</td>
                      <td>
                        <span className="ops-pill draft">
                          {'Preregistrada'}
                        </span>
                      </td>
                      <td>
                        <button
                          className="ops-button secondary"
                          data-move-click="openManagementDrawer('user-edit','tp-churchill-U45')"
                        >
                          {'Editar'}
                        </button>
                      </td>
                    </tr>
                    <tr>
                      <td>
                        <b>{'Sofía Rodríguez 47'}</b>
                      </td>
                      <td>{'empleado47.tp-churchill@example.com'}</td>
                      <td>{'Empleado'}</td>
                      <td>
                        <span className="ops-pill draft">
                          {'Preregistrada'}
                        </span>
                      </td>
                      <td>
                        <button
                          className="ops-button secondary"
                          data-move-click="openManagementDrawer('user-edit','tp-churchill-U46')"
                        >
                          {'Editar'}
                        </button>
                      </td>
                    </tr>
                    <tr>
                      <td>
                        <b>{'Juan Reyes 48'}</b>
                      </td>
                      <td>{'empleado48.tp-churchill@example.com'}</td>
                      <td>{'Empleado'}</td>
                      <td>
                        <span className="ops-pill draft">
                          {'Preregistrada'}
                        </span>
                      </td>
                      <td>
                        <button
                          className="ops-button secondary"
                          data-move-click="openManagementDrawer('user-edit','tp-churchill-U47')"
                        >
                          {'Editar'}
                        </button>
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </section>
        </>
      )}
    </MoveSurface>
  );
}
