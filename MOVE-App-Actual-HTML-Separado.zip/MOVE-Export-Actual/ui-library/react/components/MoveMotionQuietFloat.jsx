import React, { useId } from 'react';
import { MoveSurface } from '../MoveSurface.jsx';

/** Animación original quiet-float. Usa el control Reproducir para reiniciarla. Respeta la preferencia de movimiento reducido. */
export function MoveMotionQuietFloat({
  theme = 'light',
  tenant = 'tp',
  reducedMotion = false,
  onAction,
  className = '',
  style,
  children,
}) {
  const uid = useId();
  return (
    <MoveSurface
      theme={theme}
      tenant={tenant}
      reducedMotion={reducedMotion}
      onAction={onAction}
      className={'' + ' ' + className}
      style={style}
    >
      {children ?? (
        <>
          <section
            className="card"
            style={{ animation: 'quiet-float 4s ease-in-out infinite' }}
          >
            <h2>{'Tu regreso a casa'}</h2>
            <p className="sub">{'quiet-float'}</p>
          </section>
        </>
      )}
    </MoveSurface>
  );
}
