import React, { useId } from 'react';
import { MoveSurface } from '../MoveSurface.jsx';

/** Patrón lp-product usado en landing.js · landingView. */
export function MoveLpProduct({
  theme = 'light',
  tenant = 'tp',
  reducedMotion = false,
  onAction,
  className = '',
  style,
  children,
}) {
  const uid = useId();
  return (
    <MoveSurface
      theme={theme}
      tenant={tenant}
      reducedMotion={reducedMotion}
      onAction={onAction}
      className={'' + ' ' + className}
      style={style}
    >
      {children ?? (
        <>
          <section className="lp-product" id={uid + '-product'}>
            <div className="lp-section">
              <div className="section-intro">
                <div>
                  <span className="lp-kicker">
                    {'02 / UN SERVICIO. TODOS CONECTADOS.'}
                  </span>
                  <h2>
                    {'Una experiencia para cada'}
                    <br />
                    {'parte del recorrido.'}
                  </h2>
                </div>
                <p>
                  {
                    'Explora cómo MOVE acompaña a quienes viajan y a quienes los llevan a casa.'
                  }
                </p>
              </div>
              <div className="product-layout">
                <div className="product-story">
                  <div
                    className="lp-tabs"
                    role="tablist"
                    aria-label="Experiencias MOVE"
                  >
                    <button
                      id={uid + '-employeeTab'}
                      role="tab"
                      aria-selected="true"
                      className="active"
                      data-move-click="selectLandingRole('employee')"
                    >
                      {'Colaborador'}
                    </button>
                    <button
                      id={uid + '-driverTab'}
                      role="tab"
                      aria-selected="false"
                      className=""
                      data-move-click="selectLandingRole('driver')"
                    >
                      {'Conductor'}
                    </button>
                  </div>
                  <div id={uid + '-roleStory'}>
                    <span className="lp-kicker">
                      {'MENOS DUDAS AL FINAL DEL TURNO'}
                    </span>
                    <h3>{'Tu regreso, en tus manos.'}</h3>
                    <p>
                      {
                        'Confirma tu transporte en segundos y consulta la información que necesitas para abordar.'
                      }
                    </p>
                    <ul>
                      <li>
                        <svg
                          className="icon"
                          viewBox="0 0 24 24"
                          aria-hidden="true"
                          xmlns="http://www.w3.org/2000/svg"
                        >
                          <path
                            d="M5 12l4 4L19 6"
                            strokeLinecap="round"
                            strokeLinejoin="round"
                          ></path>
                        </svg>
                        {'Confirmación diaria y ticket QR'}
                      </li>
                      <li>
                        <svg
                          className="icon"
                          viewBox="0 0 24 24"
                          aria-hidden="true"
                          xmlns="http://www.w3.org/2000/svg"
                        >
                          <path
                            d="M5 12l4 4L19 6"
                            strokeLinecap="round"
                            strokeLinejoin="round"
                          ></path>
                        </svg>
                        {'Excepciones cuando cambia la jornada'}
                      </li>
                      <li>
                        <svg
                          className="icon"
                          viewBox="0 0 24 24"
                          aria-hidden="true"
                          xmlns="http://www.w3.org/2000/svg"
                        >
                          <path
                            d="M5 12l4 4L19 6"
                            strokeLinecap="round"
                            strokeLinejoin="round"
                          ></path>
                        </svg>
                        {'Seguimiento del viaje y reseña final'}
                      </li>
                    </ul>
                  </div>
                  <button
                    className="lp-button dark"
                    data-move-click="enterMove()"
                  >
                    {'Probar la demo completa '}
                    <svg
                      className="icon"
                      viewBox="0 0 24 24"
                      aria-hidden="true"
                      xmlns="http://www.w3.org/2000/svg"
                    >
                      <path
                        d="M5 3h4l2 5-3 2c2 3 3 4 6 6l2-3 5 2v4c-8 5-22-9-16-16"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                      ></path>
                    </svg>
                  </button>
                  <p className="product-footnote">
                    {'Prototipo navegable con datos de demostración.'}
                  </p>
                </div>
                <div className="phone-stage">
                  <div className="orbit-label">
                    {'MOVE / UNA JORNADA MÁS SIMPLE'}
                  </div>
                  <div className="product-phone">
                    <div className="phone-camera"></div>
                    <div className="phone-top">
                      <span className="brand">
                        {'MOVE'}
                        <span className="brand-dot"></span>
                      </span>
                      <span className="phone-avatar">{'DS'}</span>
                    </div>
                    <div id={uid + '-phonePreview'}>
                      <div className="phone-content">
                        <small>{'VIERNES, 2 DE OCTUBRE'}</small>
                        <h3>
                          {'Hola, Daviel'}
                          <span>{'.'}</span>
                        </h3>
                        <p>{'Tu regreso a casa, organizado.'}</p>
                        <div className="phone-hero">
                          <span>{'✓ RESERVA CONFIRMADA'}</span>
                          <h4>
                            {'Todo listo para'}
                            <br />
                            {'tu regreso.'}
                          </h4>
                          <div>
                            <small>{'Salida del transporte'}</small>
                            <b>{'10:15 p. m.'}</b>
                          </div>
                          <button data-move-click="enterMove()">
                            {'Ver mi viaje'}
                          </button>
                        </div>
                        <h4>{'Tu ruta asignada'}</h4>
                        <div className="phone-route">
                          <b>{'TP · Campus Churchill'}</b>
                          <span>{'↓'}</span>
                          <b>{'Los Alcarrizos'}</b>
                          <small>{'Unidad 12 · Ruta 04'}</small>
                        </div>
                      </div>
                    </div>
                    <div className="phone-nav">
                      <svg
                        className="icon"
                        viewBox="0 0 24 24"
                        aria-hidden="true"
                        xmlns="http://www.w3.org/2000/svg"
                      >
                        <path
                          d="M3 10l9-7 9 7v10a1 1 0 0 1-1 1h-5v-7H9v7H4a1 1 0 0 1-1-1z"
                          strokeLinecap="round"
                          strokeLinejoin="round"
                        ></path>
                      </svg>
                      <svg
                        className="icon"
                        viewBox="0 0 24 24"
                        aria-hidden="true"
                        xmlns="http://www.w3.org/2000/svg"
                      >
                        <path
                          d="M5 16V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2v11M5 11h14M8 3v8m8-8v8M5 16h14v3H5zM7 19v3m10-3v3M8 14h.01M16 14h.01"
                          strokeLinecap="round"
                          strokeLinejoin="round"
                        ></path>
                      </svg>
                      <svg
                        className="icon"
                        viewBox="0 0 24 24"
                        aria-hidden="true"
                        xmlns="http://www.w3.org/2000/svg"
                      >
                        <path
                          d="M3 7h18v4a2 2 0 0 0 0 4v4H3v-4a2 2 0 0 0 0-4zM15 7v2m0 3v2m0 3v2"
                          strokeLinecap="round"
                          strokeLinejoin="round"
                        ></path>
                      </svg>
                      <svg
                        className="icon"
                        viewBox="0 0 24 24"
                        aria-hidden="true"
                        xmlns="http://www.w3.org/2000/svg"
                      >
                        <path
                          d="M20 21v-2a6 6 0 0 0-6-6h-4a6 6 0 0 0-6 6v2M16 6a4 4 0 1 1-8 0 4 4 0 0 1 8 0"
                          strokeLinecap="round"
                          strokeLinejoin="round"
                        ></path>
                      </svg>
                    </div>
                  </div>
                  <div className="product-floating">
                    <span>
                      <svg
                        className="icon"
                        viewBox="0 0 24 24"
                        aria-hidden="true"
                        xmlns="http://www.w3.org/2000/svg"
                      >
                        <path
                          d="M5 12l4 4L19 6"
                          strokeLinecap="round"
                          strokeLinejoin="round"
                        ></path>
                      </svg>
                    </span>
                    <div>
                      <b>{'Confirmación recibida'}</b>
                      <small>{'Un asiento. Una preocupación menos.'}</small>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </section>
        </>
      )}
    </MoveSurface>
  );
}
