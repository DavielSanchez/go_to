import React, { useId } from 'react';
import { MoveSurface } from '../MoveSurface.jsx';

/** Bloque extraído del diseño actual de MOVE. Los eventos se exponen mediante onAction. */
export function MoveOpsOverview({
  theme = 'light',
  tenant = 'tp',
  reducedMotion = false,
  onAction,
  className = '',
  style,
  children,
}) {
  const uid = useId();
  return (
    <MoveSurface
      theme={theme}
      tenant={tenant}
      reducedMotion={reducedMotion}
      onAction={onAction}
      className={'' + ' ' + className}
      style={style}
    >
      {children ?? (
        <>
          <div className="ops-metrics">
            <article className="ops-metric">
              <small>{'Demanda confirmada'}</small>
              <strong>{'84'}</strong>
              <p>{'1 tenants seleccionados'}</p>
              <span>
                <svg
                  className="icon"
                  viewBox="0 0 24 24"
                  aria-hidden="true"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    d="M20 21v-2a6 6 0 0 0-6-6h-4a6 6 0 0 0-6 6v2M16 6a4 4 0 1 1-8 0 4 4 0 0 1 8 0"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  ></path>
                </svg>
              </span>
            </article>
            <article className="ops-metric">
              <small>{'Pasajeros abordados'}</small>
              <strong>{'30'}</strong>
              <p>{'Asignados al trip, no al conductor'}</p>
              <span>
                <svg
                  className="icon"
                  viewBox="0 0 24 24"
                  aria-hidden="true"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    d="M3 7h18v4a2 2 0 0 0 0 4v4H3v-4a2 2 0 0 0 0-4zM15 7v2m0 3v2m0 3v2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  ></path>
                </svg>
              </span>
            </article>
            <article className="ops-metric">
              <small>{'Viajes en curso'}</small>
              <strong>{'1'}</strong>
              <p>{'Incluye jornadas anteriores activas'}</p>
              <span>
                <svg
                  className="icon"
                  viewBox="0 0 24 24"
                  aria-hidden="true"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    d="M5 16V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2v11M5 11h14M8 3v8m8-8v8M5 16h14v3H5zM7 19v3m10-3v3M8 14h.01M16 14h.01"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  ></path>
                </svg>
              </span>
            </article>
            <article className="ops-metric">
              <small>{'Planes por confirmar'}</small>
              <strong>{'0'}</strong>
              <p>{'Necesitan atención'}</p>
              <span>
                <svg
                  className="icon"
                  viewBox="0 0 24 24"
                  aria-hidden="true"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    d="M12 11v6m0-10v.01M22 12a10 10 0 1 1-20 0 10 10 0 0 1 20 0"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  ></path>
                </svg>
              </span>
            </article>
          </div>
          <div className="ops-overview-grid">
            <section className="ops-card">
              <div className="ops-section-title">
                <div>
                  <span className="ops-eyebrow">{'DESPACHO'}</span>
                  <h2>{'Próximas ventanas'}</h2>
                </div>
                <a href="#ops-operation">{'Abrir operación'}</a>
              </div>
              <div className="ops-window-row">
                <div className="ops-window-time">{'21:30'}</div>
                <div>
                  <b>{'0 trips · 0 abordados'}</b>
                  <small>{'Ventana de la jornada seleccionada'}</small>
                  <div className="ops-bar">
                    <span style={{ width: '0%' }}></span>
                  </div>
                </div>
                <span className="ops-pill completed">{'Sin viajes'}</span>
              </div>
              <div className="ops-window-row">
                <div className="ops-window-time">{'22:30'}</div>
                <div>
                  <b>{'0 trips · 0 abordados'}</b>
                  <small>{'Ventana de la jornada seleccionada'}</small>
                  <div className="ops-bar">
                    <span style={{ width: '0%' }}></span>
                  </div>
                </div>
                <span className="ops-pill completed">{'Sin viajes'}</span>
              </div>
              <div className="ops-window-row">
                <div className="ops-window-time">{'23:30'}</div>
                <div>
                  <b>{'1 trips · 12 abordados'}</b>
                  <small>{'Ventana de la jornada seleccionada'}</small>
                  <div className="ops-bar">
                    <span style={{ width: '75%' }}></span>
                  </div>
                </div>
                <span className="ops-pill completed">{'Finalizado'}</span>
              </div>
              <div className="ops-window-row">
                <div className="ops-window-time">{'00:30'}</div>
                <div>
                  <b>{'2 trips · 18 abordados'}</b>
                  <small>{'Salida en el día calendario siguiente'}</small>
                  <div className="ops-bar">
                    <span style={{ width: '56%' }}></span>
                  </div>
                </div>
                <span className="ops-pill active">{'En viaje'}</span>
              </div>
            </section>
            <section className="ops-card">
              <div className="ops-section-title">
                <div>
                  <span className="ops-eyebrow">{'PRIORIDADES'}</span>
                  <h2>{'Necesita atención'}</h2>
                </div>
                <span className="ops-count">{'1'}</span>
              </div>
              <div className="ops-attention">
                <span>
                  <svg
                    className="icon"
                    viewBox="0 0 24 24"
                    aria-hidden="true"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path
                      d="M5 16V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2v11M5 11h14M8 3v8m8-8v8M5 16h14v3H5zM7 19v3m10-3v3M8 14h.01M16 14h.01"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    ></path>
                  </svg>
                </span>
                <div>
                  <b>{'TR-1041 necesita conductor'}</b>
                  <p>{'TP · Churchill · 6 pasajeros conservan su abordaje.'}</p>
                  <button data-move-click="openOpsTrip('TR-1041')">
                    {'Revisar trip'}
                  </button>
                </div>
              </div>
            </section>
          </div>
          <section className="ops-card">
            <div className="ops-section-title">
              <div>
                <span className="ops-eyebrow">{'ALCANCE OPERATIVO'}</span>
                <h2>{'Tus tenants, en una vista'}</h2>
              </div>
              <span className="ops-muted">{'1 seleccionados'}</span>
            </div>
            <div className="ops-table-scroll">
              <table className="ops-table">
                <thead>
                  <tr>
                    <th>{'Tenant'}</th>
                    <th>{'Demanda'}</th>
                    <th>{'Abordados'}</th>
                    <th>{'Viajes activos'}</th>
                    <th>{'Plan'}</th>
                    <th>{'Operación'}</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td>
                      <b>{'TP · Churchill'}</b>
                      <small>{'DO · Santo Domingo'}</small>
                    </td>
                    <td>{'84'}</td>
                    <td>{'30'}</td>
                    <td>{'1'}</td>
                    <td>
                      <span className="ops-pill confirmed">{'Confirmado'}</span>
                    </td>
                    <td>
                      <button
                        className="ops-button secondary"
                        data-move-click="focusOpsTenant('tp-churchill')"
                      >
                        {'Ver tenant'}
                      </button>
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
          </section>
        </>
      )}
    </MoveSurface>
  );
}
