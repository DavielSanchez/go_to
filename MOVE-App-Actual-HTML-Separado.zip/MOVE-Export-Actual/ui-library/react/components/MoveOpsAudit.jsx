import React, { useId } from 'react';
import { MoveSurface } from '../MoveSurface.jsx';

/** Bloque extraído del diseño actual de MOVE. Los eventos se exponen mediante onAction. */
export function MoveOpsAudit({
  theme = 'light',
  tenant = 'tp',
  reducedMotion = false,
  onAction,
  className = '',
  style,
  children,
}) {
  const uid = useId();
  return (
    <MoveSurface
      theme={theme}
      tenant={tenant}
      reducedMotion={reducedMotion}
      onAction={onAction}
      className={'' + ' ' + className}
      style={style}
    >
      {children ?? (
        <>
          <div className="ops-callout">
            {
              '\n  Cada registro identifica al actor real, al usuario efectivo y al tenant. La\n  demo guarda el historial en este navegador; la auditoría de producción deberá\n  persistirse en el servidor.\n'
            }
          </div>
          <div className="ops-audit-filters">
            <input
              type="search"
              id={uid + '-auditSearch'}
              placeholder="Buscar usuario, acción, trip o motivo…"
              defaultValue=""
              data-move-input="filterOpsAudit(this.value)"
            />
            <label>
              <input
                type="checkbox"
                data-move-change="setAuditImpersonated(this.checked)"
              />
              {'\n    Solo impersonación'}
            </label>
            <button
              className="ops-button secondary"
              data-move-click="exportOpsAudit()"
            >
              {'\n    Exportar registros visibles\n  '}
            </button>
          </div>
          <section className="ops-card">
            <div className="ops-section-title">
              <h2>{'Historial de acciones'}</h2>
              <span id={uid + '-auditCount'} className="ops-muted">
                {'1 registros'}
              </span>
            </div>
            <div className="ops-table-scroll">
              <table className="ops-table">
                <thead>
                  <tr>
                    <th>{'Fecha y hora · RD'}</th>
                    <th>{'Actor real'}</th>
                    <th>{'Usuario efectivo'}</th>
                    <th>{'Acción / objeto'}</th>
                    <th>{'Alcance'}</th>
                    <th></th>
                  </tr>
                </thead>
                <tbody id={uid + '-auditRows'}>
                  <tr>
                    <td>
                      {'03/10/2026, 20:07:31'}
                      <small>{'Sesión impersonada'}</small>
                    </td>
                    <td>
                      <b>{'Daviel Sánchez'}</b>
                      <small>{'move.admin.demo@gmail.com'}</small>
                    </td>
                    <td>
                      <b>{'María Rodríguez'}</b>
                      <small>{'Administrador'}</small>
                    </td>
                    <td>
                      <b>{'configuration.updated'}</b>
                      <small>{'tp-churchill'}</small>
                    </td>
                    <td>{'TP · Churchill'}</td>
                    <td>
                      <button
                        className="ops-button secondary"
                        data-move-click="openOpsAudit('AUD-DEMO-001')"
                      >
                        {'Detalles'}
                      </button>
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
          </section>
        </>
      )}
    </MoveSurface>
  );
}
