import React, { useId } from 'react';
import { MoveSurface } from '../MoveSurface.jsx';

/** Patrón ops-form-grid usado en opsConfigurationView(). */
export function MoveOpsFormGrid({
  theme = 'light',
  tenant = 'tp',
  reducedMotion = false,
  onAction,
  className = '',
  style,
  children,
}) {
  const uid = useId();
  return (
    <MoveSurface
      theme={theme}
      tenant={tenant}
      reducedMotion={reducedMotion}
      onAction={onAction}
      className={'' + ' ' + className}
      style={style}
    >
      {children ?? (
        <>
          <div className="ops-form-grid">
            <label>
              {'Salida elegible desde'}
              <input
                type="time"
                name="eligible"
                defaultValue="21:00"
                required
              />
            </label>
            <label>
              {'Cutoff del plan'}
              <input type="time" name="cutoff" defaultValue="20:00" required />
            </label>
            <label>
              {'Asientos libres por vehículo'}
              <input
                type="number"
                name="gap"
                min="0"
                max="10"
                defaultValue="2"
                required
              />
            </label>
            <label>
              {'Tiempo de gracia · minutos'}
              <input
                type="number"
                name="grace"
                min="0"
                max="60"
                defaultValue="10"
                required
              />
            </label>
          </div>
        </>
      )}
    </MoveSurface>
  );
}
