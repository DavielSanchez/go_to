import React, { useId } from 'react';
import { MoveSurface } from '../MoveSurface.jsx';

/** Estado vacío. */
export function MoveEmptyState({
  theme = 'light',
  tenant = 'tp',
  reducedMotion = false,
  onAction,
  className = '',
  style,
  children,
}) {
  const uid = useId();
  return (
    <MoveSurface
      theme={theme}
      tenant={tenant}
      reducedMotion={reducedMotion}
      onAction={onAction}
      className={'' + ' ' + className}
      style={style}
    >
      {children ?? (
        <>
          <div className="card empty-state">
            <span className="review-icon">
              <svg
                className="icon"
                viewBox="0 0 24 24"
                aria-hidden="true"
                xmlns="http://www.w3.org/2000/svg"
              >
                <path
                  d="M5 12l4 4L19 6"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                ></path>
              </svg>
            </span>
            <h2>{'No hay solicitudes pendientes'}</h2>
            <p className="sub">{'Las nuevas solicitudes aparecerán aquí.'}</p>
          </div>
        </>
      )}
    </MoveSurface>
  );
}
