import React, { useId } from 'react';
import { MoveSurface } from '../MoveSurface.jsx';

/** Bloque extraído del diseño actual de MOVE. Los eventos se exponen mediante onAction. */
export function MoveExceptionForm({
  theme = 'light',
  tenant = 'tp',
  reducedMotion = false,
  onAction,
  className = '',
  style,
  children,
}) {
  const uid = useId();
  return (
    <MoveSurface
      theme={theme}
      tenant={tenant}
      reducedMotion={reducedMotion}
      onAction={onAction}
      className={'' + ' ' + className}
      style={style}
    >
      {children ?? (
        <>
          <div className="narrow">
            <div className="page-top">
              <div>
                <h1>{'Excepción de transporte'}</h1>
                <p className="sub">
                  {'Solicítala para hoy o para otra fecha.'}
                </p>
              </div>
            </div>
            <form
              id={uid + '-datedExceptionForm'}
              className="card"
              data-move-form=""
            >
              <span className="step-label">{'NUEVA SOLICITUD'}</span>
              <div className="two-fields">
                <div>
                  <label className="label" htmlFor={uid + '-requestDate'}>
                    {'Fecha del transporte'}
                  </label>
                  <input
                    id={uid + '-requestDate'}
                    name="date"
                    type="date"
                    defaultValue="2026-10-04"
                    min="2026-10-04"
                    required
                  />
                </div>
                <div>
                  <label className="label" htmlFor={uid + '-requestTime'}>
                    {'Hora de salida'}
                  </label>
                  <input
                    id={uid + '-requestTime'}
                    name="time"
                    type="time"
                    defaultValue="22:00"
                    required
                  />
                </div>
              </div>
              <h2
                style={{
                  marginTop: '24px',
                  marginRight: '0px',
                  marginBottom: '16px',
                  marginLeft: '0px',
                  margin: '24px 0px 16px',
                }}
              >
                {'¿Por qué necesitas transporte?'}
              </h2>
              <label className="choice">
                <input
                  type="radio"
                  name="reason"
                  defaultValue="Horas extra"
                  required
                />
                <b>{'Horas extra'}</b>
              </label>
              <label className="choice">
                <input
                  type="radio"
                  name="reason"
                  defaultValue="Cambio de turno"
                  required
                />
                <b>{'Cambio de turno'}</b>
              </label>
              <label className="choice">
                <input
                  type="radio"
                  name="reason"
                  defaultValue="Capacitación"
                  required
                />
                <b>{'Capacitación'}</b>
              </label>
              <label className="choice">
                <input
                  type="radio"
                  name="reason"
                  defaultValue="Apoyo operativo"
                  required
                />
                <b>{'Apoyo operativo'}</b>
              </label>
              <label className="choice">
                <input
                  type="radio"
                  name="reason"
                  defaultValue="Otro motivo"
                  required
                />
                <b>{'Otro motivo'}</b>
              </label>
              <label className="label" htmlFor={uid + '-detail'}>
                {'Detalles de la solicitud'}
              </label>
              <textarea
                id={uid + '-detail'}
                name="detail"
                required
                maxLength="500"
                placeholder="Cuéntanos por qué necesitas la excepción…"
                defaultValue=""
              />
              <div className="notice">
                <svg
                  className="icon"
                  viewBox="0 0 24 24"
                  aria-hidden="true"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    d="M12 11v6m0-10v.01M22 12a10 10 0 1 1-20 0 10 10 0 0 1 20 0"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  ></path>
                </svg>
                <span>
                  {
                    'La solicitud requiere aprobación y está sujeta a disponibilidad. Al aprobarse, recibirás el ticket del viaje asignado.'
                  }
                </span>
              </div>
              <button className="btn" type="submit">
                {'Enviar solicitud'}
              </button>
            </form>
            <p className="demo-note">
              {'Vista de demostración · Datos de ejemplo'}
            </p>
          </div>
        </>
      )}
    </MoveSurface>
  );
}
