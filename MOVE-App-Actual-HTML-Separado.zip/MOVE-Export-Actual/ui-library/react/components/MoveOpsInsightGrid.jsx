import React, { useId } from 'react';
import { MoveSurface } from '../MoveSurface.jsx';

/** Patrón ops-insight-grid usado en opsStatisticsView(). */
export function MoveOpsInsightGrid({
  theme = 'light',
  tenant = 'tp',
  reducedMotion = false,
  onAction,
  className = '',
  style,
  children,
}) {
  const uid = useId();
  return (
    <MoveSurface
      theme={theme}
      tenant={tenant}
      reducedMotion={reducedMotion}
      onAction={onAction}
      className={'' + ' ' + className}
      style={style}
    >
      {children ?? (
        <>
          <div className="ops-insight-grid">
            <div>
              <b>{'1'}</b>
              <p>
                {
                  'Tenants incluidos en la comparativa. El alcance cambia todos los indicadores.'
                }
              </p>
            </div>
            <div>
              <b>{'3'}</b>
              <p>
                {
                  'Excepciones aprobadas incluidas en los planes de esta jornada.'
                }
              </p>
            </div>
            <div>
              <b>{'1'}</b>
              <p>{'Trips abiertos que aún necesitan un conductor.'}</p>
            </div>
          </div>
        </>
      )}
    </MoveSurface>
  );
}
