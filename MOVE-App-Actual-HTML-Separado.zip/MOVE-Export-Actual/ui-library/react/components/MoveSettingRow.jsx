import React, { useId } from 'react';
import { MoveSurface } from '../MoveSurface.jsx';

/** Patrón setting-row usado en views.profile(). */
export function MoveSettingRow({
  theme = 'light',
  tenant = 'tp',
  reducedMotion = false,
  onAction,
  className = '',
  style,
  children,
}) {
  const uid = useId();
  return (
    <MoveSurface
      theme={theme}
      tenant={tenant}
      reducedMotion={reducedMotion}
      onAction={onAction}
      className={'' + ' ' + className}
      style={style}
    >
      {children ?? (
        <>
          <div className="setting-row">
            <div>
              <h3>{'Modo oscuro'}</h3>
              <p className="small-info">
                {'Tu preferencia se guarda en este dispositivo.'}
              </p>
            </div>
            <button
              className="btn secondary compact"
              aria-pressed="false"
              data-move-click="toggleTheme();render()"
            >
              {'Desactivado'}
            </button>
          </div>
        </>
      )}
    </MoveSurface>
  );
}
