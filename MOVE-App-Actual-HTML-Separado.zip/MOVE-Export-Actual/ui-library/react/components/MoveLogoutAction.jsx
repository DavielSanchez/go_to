import React, { useId } from 'react';
import { MoveSurface } from '../MoveSurface.jsx';

/** Patrón logout-action usado en accountMenuHTML(). */
export function MoveLogoutAction({
  theme = 'light',
  tenant = 'tp',
  reducedMotion = false,
  onAction,
  className = '',
  style,
  children,
}) {
  const uid = useId();
  return (
    <MoveSurface
      theme={theme}
      tenant={tenant}
      reducedMotion={reducedMotion}
      onAction={onAction}
      className={'' + ' ' + className}
      style={style}
    >
      {children ?? (
        <>
          <button
            className="logout-action"
            data-move-click="accountOpen=false;logoutMove()"
          >
            <svg
              className="icon"
              viewBox="0 0 24 24"
              aria-hidden="true"
              xmlns="http://www.w3.org/2000/svg"
            >
              <path
                d="M15 5l-7 7 7 7"
                strokeLinecap="round"
                strokeLinejoin="round"
              ></path>
            </svg>
            {'Cerrar sesión'}
          </button>
        </>
      )}
    </MoveSurface>
  );
}
