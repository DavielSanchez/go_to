import React, { useId } from 'react';
import { MoveSurface } from '../MoveSurface.jsx';

/** Aviso con ícono. */
export function MoveNotice({
  theme = 'light',
  tenant = 'tp',
  reducedMotion = false,
  onAction,
  className = '',
  style,
  children,
}) {
  const uid = useId();
  return (
    <MoveSurface
      theme={theme}
      tenant={tenant}
      reducedMotion={reducedMotion}
      onAction={onAction}
      className={'' + ' ' + className}
      style={style}
    >
      {children ?? (
        <>
          <div className="notice">
            <svg
              className="icon"
              viewBox="0 0 24 24"
              aria-hidden="true"
              xmlns="http://www.w3.org/2000/svg"
            >
              <path
                d="M12 11v6m0-10v.01M22 12a10 10 0 1 1-20 0 10 10 0 0 1 20 0"
                strokeLinecap="round"
                strokeLinejoin="round"
              ></path>
            </svg>
            <span>
              {'Confirma antes de las 8:00 p. m. para reservar tu asiento.'}
            </span>
          </div>
        </>
      )}
    </MoveSurface>
  );
}
