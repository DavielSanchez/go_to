import React, { useId } from 'react';
import { MoveSurface } from '../MoveSurface.jsx';

/** Patrón ops-trip-progress usado en opsOperationView(). */
export function MoveOpsTripProgress({
  theme = 'light',
  tenant = 'tp',
  reducedMotion = false,
  onAction,
  className = '',
  style,
  children,
}) {
  const uid = useId();
  return (
    <MoveSurface
      theme={theme}
      tenant={tenant}
      reducedMotion={reducedMotion}
      onAction={onAction}
      className={'' + ' ' + className}
      style={style}
    >
      {children ?? (
        <>
          <div className="ops-trip-progress">
            <span>{'Progreso del recorrido'}</span>
            <span data-ops-progress-label="TR-1040">{'43% · ETA 01:08'}</span>
          </div>
        </>
      )}
    </MoveSurface>
  );
}
