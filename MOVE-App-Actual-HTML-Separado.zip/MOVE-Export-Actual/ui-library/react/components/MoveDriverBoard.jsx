import React, { useId } from 'react';
import { MoveSurface } from '../MoveSurface.jsx';

/** Bloque extraído del diseño actual de MOVE. Los eventos se exponen mediante onAction. */
export function MoveDriverBoard({
  theme = 'light',
  tenant = 'tp',
  reducedMotion = false,
  onAction,
  className = '',
  style,
  children,
}) {
  const uid = useId();
  return (
    <MoveSurface
      theme={theme}
      tenant={tenant}
      reducedMotion={reducedMotion}
      onAction={onAction}
      className={'' + ' ' + className}
      style={style}
    >
      {children ?? (
        <>
          <div className="page-top">
            <div>
              <h1>{'Abordaje'}</h1>
              <p className="sub">
                {'Valida el ticket de cada empleado antes de darle entrada.'}
              </p>
            </div>
          </div>
          <div className="card empty-state">
            <span className="review-icon">
              <svg
                className="icon"
                viewBox="0 0 24 24"
                aria-hidden="true"
                xmlns="http://www.w3.org/2000/svg"
              >
                <path
                  d="M5 16V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2v11M5 11h14M8 3v8m8-8v8M5 16h14v3H5zM7 19v3m10-3v3M8 14h.01M16 14h.01"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                ></path>
              </svg>
            </span>
            <h2>{'El abordaje aún no está abierto'}</h2>
            <p className="sub">
              {
                'Escanea el QR de tu ruta para recibir los pasajeros de esa salida.'
              }
            </p>
            <button
              className="btn secondary"
              style={{ marginTop: '20px' }}
              data-move-click="navigate('driver-home')"
            >
              {'Ir al inicio'}
            </button>
          </div>
          <p className="demo-note">
            {'Vista de demostración · Datos de ejemplo'}
          </p>
        </>
      )}
    </MoveSurface>
  );
}
