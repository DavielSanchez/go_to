import React, { useId } from 'react';
import { MoveSurface } from '../MoveSurface.jsx';

/** Patrón account-menu-title usado en accountMenuHTML(). */
export function MoveAccountMenuTitle({
  theme = 'light',
  tenant = 'tp',
  reducedMotion = false,
  onAction,
  className = '',
  style,
  children,
}) {
  const uid = useId();
  return (
    <MoveSurface
      theme={theme}
      tenant={tenant}
      reducedMotion={reducedMotion}
      onAction={onAction}
      className={'' + ' ' + className}
      style={style}
    >
      {children ?? (
        <>
          <div className="account-menu-title">
            <b>{'Daviel Sánchez'}</b>
            <small>{'Colaborador'}</small>
          </div>
        </>
      )}
    </MoveSurface>
  );
}
