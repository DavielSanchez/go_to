import React, { useId } from 'react';
import { MoveSurface } from '../MoveSurface.jsx';

/** Patrón page-top usado en views.home(). */
export function MovePageTop({
  theme = 'light',
  tenant = 'tp',
  reducedMotion = false,
  onAction,
  className = '',
  style,
  children,
}) {
  const uid = useId();
  return (
    <MoveSurface
      theme={theme}
      tenant={tenant}
      reducedMotion={reducedMotion}
      onAction={onAction}
      className={'' + ' ' + className}
      style={style}
    >
      {children ?? (
        <>
          <div className="page-top">
            <div>
              <h1>
                {'Hola, Daviel '}
                <span className="accent">{'.'}</span>
              </h1>
              <p className="sub">{'Tu regreso a casa, organizado.'}</p>
            </div>
            <span className="desktop-date mobile-hide">
              {'Santo Domingo, RD'}
            </span>
          </div>
        </>
      )}
    </MoveSurface>
  );
}
