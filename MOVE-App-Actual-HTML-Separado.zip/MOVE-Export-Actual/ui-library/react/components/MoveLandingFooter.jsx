import React, { useId } from 'react';
import { MoveSurface } from '../MoveSurface.jsx';
import asset0 from '../../assets/tp-logo.svg';
/** Patrón landing-footer usado en landing.js · landingView. */
export function MoveLandingFooter({
  theme = 'light',
  tenant = 'tp',
  reducedMotion = false,
  onAction,
  className = '',
  style,
  children,
}) {
  const uid = useId();
  return (
    <MoveSurface
      theme={theme}
      tenant={tenant}
      reducedMotion={reducedMotion}
      onAction={onAction}
      className={'' + ' ' + className}
      style={style}
    >
      {children ?? (
        <>
          <footer className="landing-footer">
            <a
              className="brand-collab footer-collab"
              href="#landing"
              aria-label="TP × MOVE"
            >
              <img className="tp-logo" src={asset0} alt="TP" />
              <span className="collab-cross" aria-hidden="true">
                {'×'}
              </span>
              <span className="brand">
                {'MOVE'}
                <span className="brand-dot"></span>
              </span>
            </a>
            <div className="footer-about">
              <p>{'Una app de TP.'}</p>
              <small>{'Transporte empresarial, conectado.'}</small>
            </div>
            <span>{'© 2026 MOVE · Demostración del producto'}</span>
            <button data-move-click="scrollLanding('benefits')">
              {'Volver a explorar'}
            </button>
          </footer>
        </>
      )}
    </MoveSurface>
  );
}
