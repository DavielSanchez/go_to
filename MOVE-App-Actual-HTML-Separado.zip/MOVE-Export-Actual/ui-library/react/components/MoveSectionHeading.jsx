import React, { useId } from 'react';
import { MoveSurface } from '../MoveSurface.jsx';

/** Patrón section-heading usado en views.home(). */
export function MoveSectionHeading({
  theme = 'light',
  tenant = 'tp',
  reducedMotion = false,
  onAction,
  className = '',
  style,
  children,
}) {
  const uid = useId();
  return (
    <MoveSurface
      theme={theme}
      tenant={tenant}
      reducedMotion={reducedMotion}
      onAction={onAction}
      className={'' + ' ' + className}
      style={style}
    >
      {children ?? (
        <>
          <div className="section-heading" style={{ marginTop: '0px' }}>
            <h2>{'Tu ruta asignada'}</h2>
            <span className="pill">{'Ruta 04'}</span>
          </div>
        </>
      )}
    </MoveSurface>
  );
}
