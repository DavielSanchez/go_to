import React, { useId } from 'react';
import { MoveSurface } from '../MoveSurface.jsx';

/** Patrón ops-stop usado en opsDrawerHTML(). */
export function MoveOpsStop({
  theme = 'light',
  tenant = 'tp',
  reducedMotion = false,
  onAction,
  className = '',
  style,
  children,
}) {
  const uid = useId();
  return (
    <MoveSurface
      theme={theme}
      tenant={tenant}
      reducedMotion={reducedMotion}
      onAction={onAction}
      className={'' + ' ' + className}
      style={style}
    >
      {children ?? (
        <>
          <div
            data-ops-stop="TR-1041"
            data-stop-index="0"
            className="ops-stop done"
          >
            <span>{'1'}</span>
            <b>{'TP · Churchill'}</b>
            <small>{'00:30'}</small>
          </div>
        </>
      )}
    </MoveSurface>
  );
}
