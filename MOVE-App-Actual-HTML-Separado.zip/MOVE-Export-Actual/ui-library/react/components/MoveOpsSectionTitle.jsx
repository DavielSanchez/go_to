import React, { useId } from 'react';
import { MoveSurface } from '../MoveSurface.jsx';

/** Patrón ops-section-title usado en opsOverviewView(). */
export function MoveOpsSectionTitle({
  theme = 'light',
  tenant = 'tp',
  reducedMotion = false,
  onAction,
  className = '',
  style,
  children,
}) {
  const uid = useId();
  return (
    <MoveSurface
      theme={theme}
      tenant={tenant}
      reducedMotion={reducedMotion}
      onAction={onAction}
      className={'' + ' ' + className}
      style={style}
    >
      {children ?? (
        <>
          <div className="ops-section-title">
            <div>
              <span className="ops-eyebrow">{'DESPACHO'}</span>
              <h2>{'Próximas ventanas'}</h2>
            </div>
            <a href="#ops-operation">{'Abrir operación'}</a>
          </div>
        </>
      )}
    </MoveSurface>
  );
}
