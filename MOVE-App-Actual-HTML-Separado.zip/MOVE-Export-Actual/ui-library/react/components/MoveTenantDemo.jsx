import React, { useId } from 'react';
import { MoveSurface } from '../MoveSurface.jsx';
import asset0 from '../../assets/alorica-logo.png';
import asset1 from '../../assets/trueshore-logo.svg';
import asset2 from '../../assets/concentrix-logo.webp';
/** Patrón tenant-demo usado en loginView(). */
export function MoveTenantDemo({
  theme = 'light',
  tenant = 'tp',
  reducedMotion = false,
  onAction,
  className = '',
  style,
  children,
}) {
  const uid = useId();
  return (
    <MoveSurface
      theme={theme}
      tenant={tenant}
      reducedMotion={reducedMotion}
      onAction={onAction}
      className={'' + ' ' + className}
      style={style}
    >
      {children ?? (
        <>
          <div className="tenant-demo">
            <b>{'Prueba otra empresa'}</b>
            <span>{'Personalización de demostración'}</span>
            <div className="tenant-demo-grid">
              <button
                type="button"
                data-move-click="fillTenantLogin('alorica')"
              >
                <img className="alorica-logo" src={asset0} alt="Alorica" />
                <span>{'Alorica'}</span>
              </button>
              <button
                type="button"
                data-move-click="fillTenantLogin('trueshore')"
              >
                <img className="trueshore-logo" src={asset1} alt="TrueShore" />
                <span>{'TrueShore'}</span>
              </button>
              <button
                type="button"
                data-move-click="fillTenantLogin('concentrix')"
              >
                <img
                  className="concentrix-logo"
                  src={asset2}
                  alt="Concentrix"
                />
                <span>{'Concentrix'}</span>
              </button>
            </div>
          </div>
        </>
      )}
    </MoveSurface>
  );
}
