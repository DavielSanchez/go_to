import React, { useId } from 'react';
import { MoveSurface } from '../MoveSurface.jsx';

/** Patrón ops-column usado en opsStatisticsView(). */
export function MoveOpsColumn({
  theme = 'light',
  tenant = 'tp',
  reducedMotion = false,
  onAction,
  className = '',
  style,
  children,
}) {
  const uid = useId();
  return (
    <MoveSurface
      theme={theme}
      tenant={tenant}
      reducedMotion={reducedMotion}
      onAction={onAction}
      className={'' + ' ' + className}
      style={style}
    >
      {children ?? (
        <>
          <div className="ops-column">
            <b>{'81%'}</b>
            <span style={{ height: '81%' }}></span>
            <small>{'D-6'}</small>
          </div>
        </>
      )}
    </MoveSurface>
  );
}
