import React, { useId } from 'react';
import { MoveSurface } from '../MoveSurface.jsx';

/** Patrón route-locked usado en driverViews['driver-home'](). */
export function MoveRouteLocked({
  theme = 'light',
  tenant = 'tp',
  reducedMotion = false,
  onAction,
  className = '',
  style,
  children,
}) {
  const uid = useId();
  return (
    <MoveSurface
      theme={theme}
      tenant={tenant}
      reducedMotion={reducedMotion}
      onAction={onAction}
      className={'' + ' ' + className}
      style={style}
    >
      {children ?? (
        <>
          <p className="route-locked">
            <svg
              className="icon"
              viewBox="0 0 24 24"
              aria-hidden="true"
              xmlns="http://www.w3.org/2000/svg"
            >
              <path
                d="M12 3l8 3v6c0 5-8 9-8 9s-8-4-8-9V6zM8 12l3 3 5-6"
                strokeLinecap="round"
                strokeLinejoin="round"
              ></path>
            </svg>
            {'La hora de esta ruta está fijada por su QR.'}
          </p>
        </>
      )}
    </MoveSurface>
  );
}
