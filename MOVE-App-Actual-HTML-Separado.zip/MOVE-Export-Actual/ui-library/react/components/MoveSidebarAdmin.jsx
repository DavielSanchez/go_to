import React, { useId } from 'react';
import { MoveSurface } from '../MoveSurface.jsx';
import asset0 from '../../assets/tp-logo.svg';
/** Navegación del rol Admin. */
export function MoveSidebarAdmin({
  theme = 'light',
  tenant = 'tp',
  reducedMotion = false,
  onAction,
  className = '',
  style,
  children,
}) {
  const uid = useId();
  return (
    <MoveSurface
      theme={theme}
      tenant={tenant}
      reducedMotion={reducedMotion}
      onAction={onAction}
      className={'' + ' ' + className}
      style={style}
    >
      {children ?? (
        <>
          <aside className="ops-sidebar">
            <a
              className="brand-collab ops-collaboration"
              href="#ops-overview"
              aria-label="TP × MOVE"
            >
              <img className="tenant-logo tp-logo" src={asset0} alt="TP" />
              <span className="collab-cross" aria-hidden="true">
                {'×'}
              </span>
              <span className="brand">
                {'MOVE'}
                <span className="brand-dot"></span>
              </span>
            </a>
            <small className="ops-brand-caption">{'OPERATIONS'}</small>
            <div className="ops-company">
              <b>{'TP · Churchill'}</b>
            </div>
            <div className="ops-role">{'Administrador'}</div>
            <nav aria-label="Navegación del portal">
              <a href="#ops-overview" className="active" aria-current="page">
                <svg
                  className="icon"
                  viewBox="0 0 24 24"
                  aria-hidden="true"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    d="M3 10l9-7 9 7v10a1 1 0 0 1-1 1h-5v-7H9v7H4a1 1 0 0 1-1-1z"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  ></path>
                </svg>
                {'Resumen'}
              </a>
              <a href="#ops-operation" className="">
                <svg
                  className="icon"
                  viewBox="0 0 24 24"
                  aria-hidden="true"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    d="M5 16V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2v11M5 11h14M8 3v8m8-8v8M5 16h14v3H5zM7 19v3m10-3v3M8 14h.01M16 14h.01"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  ></path>
                </svg>
                {'Operación en vivo'}
              </a>
              <a href="#ops-plans" className="">
                <svg
                  className="icon"
                  viewBox="0 0 24 24"
                  aria-hidden="true"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    d="M3 7h18v4a2 2 0 0 0 0 4v4H3v-4a2 2 0 0 0 0-4zM15 7v2m0 3v2m0 3v2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  ></path>
                </svg>
                {'Planificación'}
              </a>
              <a href="#ops-qr" className="">
                <svg
                  className="icon"
                  viewBox="0 0 24 24"
                  aria-hidden="true"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    d="M3 7h18v4a2 2 0 0 0 0 4v4H3v-4a2 2 0 0 0 0-4zM15 7v2m0 3v2m0 3v2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  ></path>
                </svg>
                {'Catálogo QR'}
              </a>
              <a href="#ops-zones" className="">
                <svg
                  className="icon"
                  viewBox="0 0 24 24"
                  aria-hidden="true"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    d="M20 10c0 6-8 12-8 12S4 16 4 10a8 8 0 1 1 16 0M15 10a3 3 0 1 1-6 0 3 3 0 0 1 6 0"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  ></path>
                </svg>
                {'Zonas y rutas'}
              </a>
              <a href="#ops-users" className="">
                <svg
                  className="icon"
                  viewBox="0 0 24 24"
                  aria-hidden="true"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    d="M20 21v-2a6 6 0 0 0-6-6h-4a6 6 0 0 0-6 6v2M16 6a4 4 0 1 1-8 0 4 4 0 0 1 8 0"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  ></path>
                </svg>
                {'Usuarios'}
              </a>
              <a href="#ops-fleet" className="">
                <svg
                  className="icon"
                  viewBox="0 0 24 24"
                  aria-hidden="true"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    d="M5 16V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2v11M5 11h14M8 3v8m8-8v8M5 16h14v3H5zM7 19v3m10-3v3M8 14h.01M16 14h.01"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  ></path>
                </svg>
                {'Flotilla'}
              </a>
              <a href="#ops-events" className="">
                <svg
                  className="icon"
                  viewBox="0 0 24 24"
                  aria-hidden="true"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    d="M12 8v5l3 2M22 12a10 10 0 1 1-20 0 10 10 0 0 1 20 0"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  ></path>
                </svg>
                {'Eventos'}
              </a>
              <a href="#ops-history" className="">
                <svg
                  className="icon"
                  viewBox="0 0 24 24"
                  aria-hidden="true"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    d="M12 8v5l3 2M22 12a10 10 0 1 1-20 0 10 10 0 0 1 20 0"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  ></path>
                </svg>
                {'Historial'}
              </a>
              <a href="#ops-incidents" className="">
                <svg
                  className="icon"
                  viewBox="0 0 24 24"
                  aria-hidden="true"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    d="M12 11v6m0-10v.01M22 12a10 10 0 1 1-20 0 10 10 0 0 1 20 0"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  ></path>
                </svg>
                {'Incidencias'}
              </a>
              <a href="#ops-reviews" className="">
                <svg
                  className="icon"
                  viewBox="0 0 24 24"
                  aria-hidden="true"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    d="M12 3l3 6 7 1-5 5 1 7-6-3-6 3 1-7-5-5 7-1z"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  ></path>
                </svg>
                {'Reseñas'}
              </a>
              <a href="#ops-statistics" className="">
                <svg
                  className="icon"
                  viewBox="0 0 24 24"
                  aria-hidden="true"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    d="M12 8v5l3 2M22 12a10 10 0 1 1-20 0 10 10 0 0 1 20 0"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  ></path>
                </svg>
                {'Estadísticas'}
              </a>
              <a href="#ops-configuration" className="">
                <svg
                  className="icon"
                  viewBox="0 0 24 24"
                  aria-hidden="true"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    d="M12 3l8 3v6c0 5-8 9-8 9s-8-4-8-9V6zM8 12l3 3 5-6"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  ></path>
                </svg>
                {'Configuración'}
              </a>
              <a href="#ops-audit" className="">
                <svg
                  className="icon"
                  viewBox="0 0 24 24"
                  aria-hidden="true"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    d="M12 3l8 3v6c0 5-8 9-8 9s-8-4-8-9V6zM8 12l3 3 5-6"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  ></path>
                </svg>
                {'Auditoría'}
              </a>
              <a href="#ops-account" className="">
                <svg
                  className="icon"
                  viewBox="0 0 24 24"
                  aria-hidden="true"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    d="M20 21v-2a6 6 0 0 0-6-6h-4a6 6 0 0 0-6 6v2M16 6a4 4 0 1 1-8 0 4 4 0 0 1 8 0"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  ></path>
                </svg>
                {'Mi perfil'}
              </a>
            </nav>
            <div className="ops-sidebar-foot">
              <span className="ops-avatar">{'MR'}</span>
              <div>
                <b>{'María Rodríguez'}</b>
                <small>{'admin.tp.demo@gmail.com'}</small>
              </div>
            </div>
            <button className="ops-signout" data-move-click="logoutMove()">
              {'Cerrar sesión'}
            </button>
          </aside>
        </>
      )}
    </MoveSurface>
  );
}
