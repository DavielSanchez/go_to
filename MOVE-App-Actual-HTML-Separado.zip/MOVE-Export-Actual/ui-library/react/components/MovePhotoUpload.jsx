import React, { useId } from 'react';
import { MoveSurface } from '../MoveSurface.jsx';

/** Input cámara/galería y preview; requiere permiso de cámara en móvil. */
export function MovePhotoUpload({
  theme = 'light',
  tenant = 'tp',
  reducedMotion = false,
  onAction,
  className = '',
  style,
  children,
}) {
  const uid = useId();
  return (
    <MoveSurface
      theme={theme}
      tenant={tenant}
      reducedMotion={reducedMotion}
      onAction={onAction}
      className={'' + ' ' + className}
      style={style}
    >
      {children ?? (
        <>
          <div className="photo-field">
            <b>{'Foto de licencia'}</b>
            <div id={uid + '-preview-license'} className="photo-preview">
              <span>
                <svg
                  className="icon"
                  viewBox="0 0 24 24"
                  aria-hidden="true"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    d="M5 3h4l2 5-3 2c2 3 3 4 6 6l2-3 5 2v4c-8 5-22-9-16-16"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  ></path>
                </svg>
                {'Sin foto'}
              </span>
            </div>
            <div className="photo-actions">
              <label className="btn secondary">
                {'Tomar foto'}
                <input
                  type="file"
                  accept="image/*"
                  capture="environment"
                  data-photo="license"
                  hidden
                />
              </label>
              <label className="btn secondary">
                {'Galería'}
                <input
                  type="file"
                  accept="image/*"
                  data-photo="license"
                  hidden
                />
              </label>
            </div>
          </div>
        </>
      )}
    </MoveSurface>
  );
}
