import React, { useId } from 'react';
import { MoveSurface } from '../MoveSurface.jsx';

/** Patrón approval-metrics usado en approvalView(). */
export function MoveApprovalMetrics({
  theme = 'light',
  tenant = 'tp',
  reducedMotion = false,
  onAction,
  className = '',
  style,
  children,
}) {
  const uid = useId();
  return (
    <MoveSurface
      theme={theme}
      tenant={tenant}
      reducedMotion={reducedMotion}
      onAction={onAction}
      className={'' + ' ' + className}
      style={style}
    >
      {children ?? (
        <>
          <div className="approval-metrics">
            <div className="card">
              <strong>{'2'}</strong>
              <span>{'Pendientes'}</span>
            </div>
            <div className="card">
              <strong>{'1'}</strong>
              <span>{'Aprobadas'}</span>
            </div>
            <div className="card">
              <strong>{'0'}</strong>
              <span>{'Rechazadas'}</span>
            </div>
          </div>
        </>
      )}
    </MoveSurface>
  );
}
