import React, { useId } from 'react';
import { MoveSurface } from '../MoveSurface.jsx';

/** SVG original de MOVE, vectorial y personalizable. */
export function MoveIconCheck({
  theme = 'light',
  tenant = 'tp',
  reducedMotion = false,
  onAction,
  className = '',
  style,
  children,
}) {
  const uid = useId();
  return (
    <MoveSurface
      theme={theme}
      tenant={tenant}
      reducedMotion={reducedMotion}
      onAction={onAction}
      className={'' + ' ' + className}
      style={style}
    >
      {children ?? (
        <>
          <svg
            className="icon"
            viewBox="0 0 24 24"
            aria-hidden="true"
            xmlns="http://www.w3.org/2000/svg"
          >
            <path
              d="M5 12l4 4L19 6"
              strokeLinecap="round"
              strokeLinejoin="round"
            ></path>
          </svg>
        </>
      )}
    </MoveSurface>
  );
}
