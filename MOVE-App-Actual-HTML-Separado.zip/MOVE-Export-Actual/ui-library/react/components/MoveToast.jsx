import React, { useId } from 'react';
import { MoveSurface } from '../MoveSurface.jsx';

/** Toast con entrada y salida. */
export function MoveToast({
  theme = 'light',
  tenant = 'tp',
  reducedMotion = false,
  onAction,
  className = '',
  style,
  children,
}) {
  const uid = useId();
  return (
    <MoveSurface
      theme={theme}
      tenant={tenant}
      reducedMotion={reducedMotion}
      onAction={onAction}
      className={'' + ' ' + className}
      style={style}
    >
      {children ?? (
        <>
          <div className="move-library-toast" role="status">
            {'Configuración guardada.'}
          </div>
        </>
      )}
    </MoveSurface>
  );
}
