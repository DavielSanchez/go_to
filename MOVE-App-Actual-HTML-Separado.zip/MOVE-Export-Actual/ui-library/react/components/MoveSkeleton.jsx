import React, { useId } from 'react';
import { MoveSurface } from '../MoveSurface.jsx';

/** Skeleton adicional para integrar estados de carga, con movimiento reducido. */
export function MoveSkeleton({
  theme = 'light',
  tenant = 'tp',
  reducedMotion = false,
  onAction,
  className = '',
  style,
  children,
}) {
  const uid = useId();
  return (
    <MoveSurface
      theme={theme}
      tenant={tenant}
      reducedMotion={reducedMotion}
      onAction={onAction}
      className={'' + ' ' + className}
      style={style}
    >
      {children ?? (
        <>
          <div className="card">
            <div
              className="move-skeleton"
              style={{ width: '45%', height: '24px' }}
            ></div>
            <div
              className="move-skeleton"
              style={{ height: '14px', marginTop: '18px' }}
            ></div>
            <div
              className="move-skeleton"
              style={{ width: '70%', height: '14px', marginTop: '12px' }}
            ></div>
          </div>
        </>
      )}
    </MoveSurface>
  );
}
