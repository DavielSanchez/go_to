import React, { useId } from 'react';
import { MoveSurface } from '../MoveSurface.jsx';

/** Bloque extraído del diseño actual de MOVE. Los eventos se exponen mediante onAction. */
export function MoveReviews({
  theme = 'light',
  tenant = 'tp',
  reducedMotion = false,
  onAction,
  className = '',
  style,
  children,
}) {
  const uid = useId();
  return (
    <MoveSurface
      theme={theme}
      tenant={tenant}
      reducedMotion={reducedMotion}
      onAction={onAction}
      className={'' + ' ' + className}
      style={style}
    >
      {children ?? (
        <>
          <div className="ops-metrics">
            <article className="ops-metric">
              <small>{'Calificación promedio'}</small>
              <strong>{'4.3 / 5'}</strong>
              <p>{'Opiniones de los pasajeros'}</p>
              <span>
                <svg
                  className="icon"
                  viewBox="0 0 24 24"
                  aria-hidden="true"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    d="M12 3l3 6 7 1-5 5 1 7-6-3-6 3 1-7-5-5 7-1z"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  ></path>
                </svg>
              </span>
            </article>
            <article className="ops-metric">
              <small>{'Reseñas recibidas'}</small>
              <strong>{'4'}</strong>
              <p>{'Viajes dentro de tu alcance'}</p>
              <span>
                <svg
                  className="icon"
                  viewBox="0 0 24 24"
                  aria-hidden="true"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    d="M21 11a9 9 0 0 1-9 9H4l-3 2 2-6a9 9 0 1 1 18-5M7 11h10"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  ></path>
                </svg>
              </span>
            </article>
            <article className="ops-metric">
              <small>{'Valoraciones de 4–5'}</small>
              <strong>{'3'}</strong>
              <p>{'Experiencias favorables'}</p>
              <span>
                <svg
                  className="icon"
                  viewBox="0 0 24 24"
                  aria-hidden="true"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    d="M5 12l4 4L19 6"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  ></path>
                </svg>
              </span>
            </article>
          </div>
          <div className="management-review-grid">
            <section className="ops-card">
              <div className="ops-section-title">
                <h2>{'Ana Pérez'}</h2>
              </div>
              <div className="review-rating" aria-label="5 de 5">
                <span className="filled">
                  <svg
                    className="icon"
                    viewBox="0 0 24 24"
                    aria-hidden="true"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path
                      d="M12 3l3 6 7 1-5 5 1 7-6-3-6 3 1-7-5-5 7-1z"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    ></path>
                  </svg>
                </span>
                <span className="filled">
                  <svg
                    className="icon"
                    viewBox="0 0 24 24"
                    aria-hidden="true"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path
                      d="M12 3l3 6 7 1-5 5 1 7-6-3-6 3 1-7-5-5 7-1z"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    ></path>
                  </svg>
                </span>
                <span className="filled">
                  <svg
                    className="icon"
                    viewBox="0 0 24 24"
                    aria-hidden="true"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path
                      d="M12 3l3 6 7 1-5 5 1 7-6-3-6 3 1-7-5-5 7-1z"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    ></path>
                  </svg>
                </span>
                <span className="filled">
                  <svg
                    className="icon"
                    viewBox="0 0 24 24"
                    aria-hidden="true"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path
                      d="M12 3l3 6 7 1-5 5 1 7-6-3-6 3 1-7-5-5 7-1z"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    ></path>
                  </svg>
                </span>
                <span className="filled">
                  <svg
                    className="icon"
                    viewBox="0 0 24 24"
                    aria-hidden="true"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path
                      d="M12 3l3 6 7 1-5 5 1 7-6-3-6 3 1-7-5-5 7-1z"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    ></path>
                  </svg>
                </span>
              </div>
              <p>{'Buen trato y viaje cómodo.'}</p>
              <p className="ops-muted">{'TR-1042 · 04/10/2026, 15:26:14'}</p>
              <button
                className="ops-button secondary"
                data-move-click="openOpsTrip('TR-1042')"
              >
                {'Ver viaje'}
              </button>
            </section>
            <section className="ops-card">
              <div className="ops-section-title">
                <h2>{'Carlos Mejía'}</h2>
              </div>
              <div className="review-rating" aria-label="4 de 5">
                <span className="filled">
                  <svg
                    className="icon"
                    viewBox="0 0 24 24"
                    aria-hidden="true"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path
                      d="M12 3l3 6 7 1-5 5 1 7-6-3-6 3 1-7-5-5 7-1z"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    ></path>
                  </svg>
                </span>
                <span className="filled">
                  <svg
                    className="icon"
                    viewBox="0 0 24 24"
                    aria-hidden="true"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path
                      d="M12 3l3 6 7 1-5 5 1 7-6-3-6 3 1-7-5-5 7-1z"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    ></path>
                  </svg>
                </span>
                <span className="filled">
                  <svg
                    className="icon"
                    viewBox="0 0 24 24"
                    aria-hidden="true"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path
                      d="M12 3l3 6 7 1-5 5 1 7-6-3-6 3 1-7-5-5 7-1z"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    ></path>
                  </svg>
                </span>
                <span className="filled">
                  <svg
                    className="icon"
                    viewBox="0 0 24 24"
                    aria-hidden="true"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path
                      d="M12 3l3 6 7 1-5 5 1 7-6-3-6 3 1-7-5-5 7-1z"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    ></path>
                  </svg>
                </span>
                <span className="">
                  <svg
                    className="icon"
                    viewBox="0 0 24 24"
                    aria-hidden="true"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path
                      d="M12 3l3 6 7 1-5 5 1 7-6-3-6 3 1-7-5-5 7-1z"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    ></path>
                  </svg>
                </span>
              </div>
              <p>{'El conductor fue muy amable.'}</p>
              <p className="ops-muted">{'TR-1042 · 04/10/2026, 15:26:14'}</p>
              <button
                className="ops-button secondary"
                data-move-click="openOpsTrip('TR-1042')"
              >
                {'Ver viaje'}
              </button>
            </section>
            <section className="ops-card">
              <div className="ops-section-title">
                <h2>{'Laura Díaz'}</h2>
              </div>
              <div className="review-rating" aria-label="5 de 5">
                <span className="filled">
                  <svg
                    className="icon"
                    viewBox="0 0 24 24"
                    aria-hidden="true"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path
                      d="M12 3l3 6 7 1-5 5 1 7-6-3-6 3 1-7-5-5 7-1z"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    ></path>
                  </svg>
                </span>
                <span className="filled">
                  <svg
                    className="icon"
                    viewBox="0 0 24 24"
                    aria-hidden="true"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path
                      d="M12 3l3 6 7 1-5 5 1 7-6-3-6 3 1-7-5-5 7-1z"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    ></path>
                  </svg>
                </span>
                <span className="filled">
                  <svg
                    className="icon"
                    viewBox="0 0 24 24"
                    aria-hidden="true"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path
                      d="M12 3l3 6 7 1-5 5 1 7-6-3-6 3 1-7-5-5 7-1z"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    ></path>
                  </svg>
                </span>
                <span className="filled">
                  <svg
                    className="icon"
                    viewBox="0 0 24 24"
                    aria-hidden="true"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path
                      d="M12 3l3 6 7 1-5 5 1 7-6-3-6 3 1-7-5-5 7-1z"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    ></path>
                  </svg>
                </span>
                <span className="filled">
                  <svg
                    className="icon"
                    viewBox="0 0 24 24"
                    aria-hidden="true"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path
                      d="M12 3l3 6 7 1-5 5 1 7-6-3-6 3 1-7-5-5 7-1z"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    ></path>
                  </svg>
                </span>
              </div>
              <p>{'Llegamos a tiempo.'}</p>
              <p className="ops-muted">{'TR-1042 · 04/10/2026, 15:26:14'}</p>
              <button
                className="ops-button secondary"
                data-move-click="openOpsTrip('TR-1042')"
              >
                {'Ver viaje'}
              </button>
            </section>
            <section className="ops-card">
              <div className="ops-section-title">
                <h2>{'Miguel Santos'}</h2>
              </div>
              <div className="review-rating" aria-label="3 de 5">
                <span className="filled">
                  <svg
                    className="icon"
                    viewBox="0 0 24 24"
                    aria-hidden="true"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path
                      d="M12 3l3 6 7 1-5 5 1 7-6-3-6 3 1-7-5-5 7-1z"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    ></path>
                  </svg>
                </span>
                <span className="filled">
                  <svg
                    className="icon"
                    viewBox="0 0 24 24"
                    aria-hidden="true"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path
                      d="M12 3l3 6 7 1-5 5 1 7-6-3-6 3 1-7-5-5 7-1z"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    ></path>
                  </svg>
                </span>
                <span className="filled">
                  <svg
                    className="icon"
                    viewBox="0 0 24 24"
                    aria-hidden="true"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path
                      d="M12 3l3 6 7 1-5 5 1 7-6-3-6 3 1-7-5-5 7-1z"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    ></path>
                  </svg>
                </span>
                <span className="">
                  <svg
                    className="icon"
                    viewBox="0 0 24 24"
                    aria-hidden="true"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path
                      d="M12 3l3 6 7 1-5 5 1 7-6-3-6 3 1-7-5-5 7-1z"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    ></path>
                  </svg>
                </span>
                <span className="">
                  <svg
                    className="icon"
                    viewBox="0 0 24 24"
                    aria-hidden="true"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path
                      d="M12 3l3 6 7 1-5 5 1 7-6-3-6 3 1-7-5-5 7-1z"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    ></path>
                  </svg>
                </span>
              </div>
              <p>{'Podemos mejorar la puntualidad.'}</p>
              <p className="ops-muted">{'TR-1042 · 04/10/2026, 15:26:14'}</p>
              <button
                className="ops-button secondary"
                data-move-click="openOpsTrip('TR-1042')"
              >
                {'Ver viaje'}
              </button>
            </section>
          </div>
        </>
      )}
    </MoveSurface>
  );
}
