import React, { useId } from 'react';
import { MoveSurface } from '../MoveSurface.jsx';

/** Campo con label, helper text y foco visible. */
export function MoveTextField({
  theme = 'light',
  tenant = 'tp',
  reducedMotion = false,
  onAction,
  className = '',
  style,
  children,
}) {
  const uid = useId();
  return (
    <MoveSurface
      theme={theme}
      tenant={tenant}
      reducedMotion={reducedMotion}
      onAction={onAction}
      className={'' + ' ' + className}
      style={style}
    >
      {children ?? (
        <>
          <div>
            <label className="label" htmlFor={uid + '-email-field'}>
              {'Correo personal'}
            </label>
            <input
              id={uid + '-email-field'}
              type="email"
              placeholder="nombre@correo.com"
              autoComplete="email"
            />
            <p className="small-info">
              {'Usa el correo autorizado por tu empresa.'}
            </p>
          </div>
        </>
      )}
    </MoveSurface>
  );
}
