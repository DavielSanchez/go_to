import React, { useId } from 'react';
import { MoveSurface } from '../MoveSurface.jsx';
import asset0 from '../../assets/tp-logo.svg';
/** Colaboración de empresa y MOVE. */
export function MoveBrandTp({
  theme = 'light',
  tenant = 'tp',
  reducedMotion = false,
  onAction,
  className = '',
  style,
  children,
}) {
  const uid = useId();
  return (
    <MoveSurface
      theme={theme}
      tenant={tenant}
      reducedMotion={reducedMotion}
      onAction={onAction}
      className={'' + ' ' + className}
      style={style}
    >
      {children ?? (
        <>
          <div className="brand-collab">
            <img className="tenant-logo tp-logo" src={asset0} alt="TP" />
            <span className="collab-cross" aria-hidden="true">
              {'×'}
            </span>
            <span className="brand">
              {'MOVE'}
              <span className="brand-dot"></span>
            </span>
          </div>
        </>
      )}
    </MoveSurface>
  );
}
