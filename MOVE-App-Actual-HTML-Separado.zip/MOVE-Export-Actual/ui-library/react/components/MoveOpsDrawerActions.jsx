import React, { useId } from 'react';
import { MoveSurface } from '../MoveSurface.jsx';

/** Patrón ops-drawer-actions usado en opsDrawerHTML(). */
export function MoveOpsDrawerActions({
  theme = 'light',
  tenant = 'tp',
  reducedMotion = false,
  onAction,
  className = '',
  style,
  children,
}) {
  const uid = useId();
  return (
    <MoveSurface
      theme={theme}
      tenant={tenant}
      reducedMotion={reducedMotion}
      onAction={onAction}
      className={'' + ' ' + className}
      style={style}
    >
      {children ?? (
        <>
          <div className="ops-drawer-actions">
            <button
              className="ops-button"
              data-move-click="performOpsTripAction('TR-1041','assign')"
            >
              {'Asignar conductor'}
            </button>
          </div>
        </>
      )}
    </MoveSurface>
  );
}
