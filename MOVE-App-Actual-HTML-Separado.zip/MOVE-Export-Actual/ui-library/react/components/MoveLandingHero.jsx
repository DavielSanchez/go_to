import React, { useId } from 'react';
import { MoveSurface } from '../MoveSurface.jsx';
import asset0 from '../../assets/transport.webp';
/** Patrón landing-hero usado en landing.js · landingView. */
export function MoveLandingHero({
  theme = 'light',
  tenant = 'tp',
  reducedMotion = false,
  onAction,
  className = '',
  style,
  children,
}) {
  const uid = useId();
  return (
    <MoveSurface
      theme={theme}
      tenant={tenant}
      reducedMotion={reducedMotion}
      onAction={onAction}
      className={'' + ' ' + className}
      style={style}
    >
      {children ?? (
        <>
          <section className="landing-hero">
            <div className="hero-copy">
              <div className="lp-kicker">
                <span></span>
                {'TRANSPORTE EMPRESARIAL, CONECTADO'}
              </div>
              <h1>
                {'El buen trabajo'}
                <br />
                {'merece un '}
                <em>{'buen regreso.'}</em>
              </h1>
              <p>
                {
                  'De la salida del turno a la última parada. MOVE conecta a tu gente, tus conductores y tu operación en una sola experiencia.'
                }
              </p>
              <div className="lp-actions">
                <button
                  className="lp-button pink"
                  data-move-click="enterMove()"
                >
                  {'Explorar la solución '}
                  <svg
                    className="icon"
                    viewBox="0 0 24 24"
                    aria-hidden="true"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path
                      d="M5 16V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2v11M5 11h14M8 3v8m8-8v8M5 16h14v3H5zM7 19v3m10-3v3M8 14h.01M16 14h.01"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    ></path>
                  </svg>
                </button>
                <button
                  className="lp-button ghost"
                  data-move-click="scrollLanding('product')"
                >
                  {'Conoce cómo funciona'}
                </button>
              </div>
              <div className="hero-detail">
                <span>
                  <svg
                    className="icon"
                    viewBox="0 0 24 24"
                    aria-hidden="true"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path
                      d="M12 3l8 3v6c0 5-8 9-8 9s-8-4-8-9V6zM8 12l3 3 5-6"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    ></path>
                  </svg>
                  {' Para empresas con transporte de personal'}
                </span>
                <span>
                  <svg
                    className="icon"
                    viewBox="0 0 24 24"
                    aria-hidden="true"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path
                      d="M5 3h4l2 5-3 2c2 3 3 4 6 6l2-3 5 2v4c-8 5-22-9-16-16"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    ></path>
                  </svg>
                  {' Web app · Mobile first'}
                </span>
              </div>
            </div>
            <div className="hero-visual">
              <img
                src={asset0}
                alt="Colaboradores abordando un transporte empresarial al salir de una oficina"
                width="1536"
                height="1024"
              />
              <div className="visual-shade"></div>
              <div className="floating-route">
                <span className="float-icon">
                  <svg
                    className="icon"
                    viewBox="0 0 24 24"
                    aria-hidden="true"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path
                      d="M5 16V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2v11M5 11h14M8 3v8m8-8v8M5 16h14v3H5zM7 19v3m10-3v3M8 14h.01M16 14h.01"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    ></path>
                  </svg>
                </span>
                <div>
                  <small>{'TU TRANSPORTE ESTÁ LISTO'}</small>
                  <b>{'Tu turno termina. Tu regreso empieza.'}</b>
                  <span>{'Ruta 04 · 22:15 · Asiento confirmado'}</span>
                </div>
                <span className="float-check">
                  <svg
                    className="icon"
                    viewBox="0 0 24 24"
                    aria-hidden="true"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path
                      d="M5 12l4 4L19 6"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    ></path>
                  </svg>
                </span>
              </div>
              <div className="visual-caption">
                <span className="lp-kicker">{'MENOS INCERTIDUMBRE'}</span>
                <p>
                  {'Más tranquilidad.'}
                  <br />
                  {'Dentro y fuera del trabajo.'}
                </p>
              </div>
            </div>
          </section>
        </>
      )}
    </MoveSurface>
  );
}
