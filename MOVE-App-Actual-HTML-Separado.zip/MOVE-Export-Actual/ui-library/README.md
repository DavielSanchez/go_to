# MOVE UI Library

Biblioteca visual extraída del código actual de **MOVE · Transporte TP**, sin modificar la aplicación publicada.

## Explorar

Abre **index.html** directamente en tu navegador. Este catálogo es autocontenido: incluye datos, assets de preview, estilos y código para copiar. Las fuentes DM Sans y Manrope se cargan de Google Fonts si tienes conexión; sin conexión se usa la fuente del sistema.

Funciones del catálogo:

- 344 entradas: controles, patrones, bloques compuestos, SVG, identidad y movimiento.
- Comparación de modos claro y oscuro.
- Vista previa a 390, 1024 y 1440 px. Cuando falta espacio, el preview se escala conservando su viewport real.
- Buscar por nombre, categoría y descripción; Ctrl/Cmd K enfoca la búsqueda.
- Empresas TP, Alorica, TrueShore y Concentrix.
- Copiar HTML, React y React + Tailwind, con fallback para archivos locales.
- Reiniciar animaciones y reducir movimiento.
- Interacciones visuales de switches, radio/checkbox, selectores, chips, estrellas, navegación y formularios. Las operaciones del negocio se emiten como eventos.

## Contenido

| Archivo o carpeta | Contenido |
| --- | --- |
| `index.html` | Catálogo interactivo autocontenido |
| `html/` | 344 ejemplos HTML formateados |
| `react/components/` | 344 bloques JSX formateados |
| `react-tailwind/components/` | 344 bloques JSX con utilidades Tailwind y base compartida |
| `react/Core.jsx` | Controles con props: botón, input, switch, tabs, rating, navegación, dialog y toast |
| `react/MoveSurface.jsx` | Contenedor de tema, empresa y eventos |
| `move.css` | Estilos originales con selectores delimitados por `[data-move-root]` |
| `move-source.css` | CSS del producto original, sin delimitación; referencia, no importar junto a move.css |
| `library-additions.css` | Skeleton, spinner, toast y ajustes de integración |
| `runtime.js` | Interacciones visuales y callbacks; no ejecuta acciones del producto |
| `tailwind.css` | Entrada para Tailwind CSS v4 |
| `assets/` | Logos originales y asset de la landing |
| `tokens.json` | Colores, temas, marcas, fuentes y referencias de tamaño |
| `inventory.json` | Procedencia, clases, pantallas/estados y animaciones |

La biblioteca contiene 66 ejemplos compuestos de vistas y estados. Las 368 clases CSS indexadas se conservan en la base, incluidas reglas que solo aplican a estados anidados. Los bloques se extrajeron como ejemplos con datos demo: no son un paquete npm publicado ni una implementación del backend.

## HTML

Para ejecutar los HTML individuales y sus módulos:

```bash
cd MOVE-UI-Library
python -m http.server 8080
```

En Windows también puedes utilizar `py -m http.server 8080`.

Abre `http://localhost:8080` para ver el catálogo, o `http://localhost:8080/html/MoveButtonPrimary.html` para un ejemplo.

```html
<link rel="stylesheet" href="move.css" />
<link rel="stylesheet" href="library-additions.css" />
<div data-move-root data-theme="dark" data-tenant="tp">
  <button class="btn">Confirmar transporte</button>
</div>
<script type="module">
  import { mountMoveUI } from './runtime.js';
  mountMoveUI(document.querySelector('[data-move-root]'), action => {
    console.log(action);
  });
</script>
```

Puedes mover los ejemplos a otro proyecto conservando los imports y assets o ajustando sus rutas. Los HTML individuales vienen en claro: cambia `data-theme` en el contenedor a `dark` para el modo oscuro.

## React

Copia la carpeta de la biblioteca dentro de tu código fuente. Requiere React y React DOM de tu proyecto y un bundler que admita JSX y imports de assets. No se incluye node_modules.

```jsx
import './move-ui/move.css';
import './move-ui/library-additions.css';
import { MoveSurface, MoveButton, MoveInput } from './move-ui/react/index.js';

export default function Example() {
  return (
    <MoveSurface theme="dark" tenant="tp">
      <MoveInput label="Correo personal" type="email" />
      <MoveButton onClick={() => console.log('Confirmar')}>
        Confirmar transporte
      </MoveButton>
    </MoveSurface>
  );
}
```

### Controles con props

| Control | Props principales |
| --- | --- |
| `MoveButton` | `variant` primary/secondary/outline, `size`, `disabled`, `onClick`, props nativas |
| `MoveInput` | `label`, `helperText`, `error`, `value`/`defaultValue`, `onChange`, props nativas |
| `MoveSwitchControl` | `label`, `description`, `checked`/`defaultChecked`, `onChange`, `disabled` |
| `MoveTabs` | `items: [{value,label}]`, `value`, `onChange`, `label` |
| `MoveRating` | `value`, `onChange`, `readOnly` |
| `MoveNavigation` | `items: [{value,label,icon}]`, `value`, `onChange`, `orientation` bottom/side |
| `MoveDialog` | `open`, `title`, `children`, `actions`, `onClose` |
| `MoveToastMessage` | `message`, `duration`, `onDismiss` |
| `MoveSurface` | `theme`, `tenant`, `reducedMotion`, `onAction`, `className`, `style`, `children` |

`MoveDialog` utiliza `<dialog>` nativo con showModal, Escape, backdrop y restauración de foco del navegador. Mantén el estado `open` en tu aplicación y ciérralo en `onClose`.

### Bloques compuestos

```jsx
import { MoveEmployeeHome } from './move-ui/react/index.js';

<MoveEmployeeHome
  theme="dark"
  tenant="tp"
  reducedMotion={false}
  onAction={action => console.log(action)}
/>
```

Estos bloques conservan datos demo y estructura del producto, y aceptan `children` para sustituir su contenido. Para poblarlos con datos reales, adapta el JSX explícito del archivo: está separado y formateado para hacerlo fácilmente. Los IDs de campos React se generan con useId para permitir varias instancias.

`onAction` recibe `type` (click/change/submit), `original`, `label`, `fields`, `name`, `value` y `target` según el evento. **No evalúes la cadena original**: úsala únicamente para identificar la intención y llamar tus funciones. No se conserva ningún handler inline que dependa de globals de la app.

## React con Tailwind

Usa la configuración Tailwind CSS v4 de tu proyecto e importa `tailwind.css`:

```jsx
import './move-ui/tailwind.css';
import { MoveEmployeeHome } from './move-ui/react-tailwind/index.js';
```

```css
@import 'tailwindcss';
@import './move.css' layer(components);
@import './library-additions.css' layer(components);
@source './react-tailwind';
@custom-variant dark (&:where([data-theme='dark'], [data-theme='dark'] *));
```

La variante Tailwind es **híbrida**: tiene utilidades literales para los patrones comunes y conserva selectores complejos, pseudo-elementos, media queries y animaciones originales en la capa `components`. No es una versión independiente sin CSS compartido. Esto conserva la identidad del producto y evita una conversión aproximada de sus estados.

## Temas y marcas

Usa `theme="light"` o `theme="dark"`. En HTML el atributo equivalente es `data-theme`.

`tenant` admite `tp`, `alorica`, `trueshore`, `concentrix`. El contenedor React define automáticamente sus variables de marca. En HTML, ajusta `--pink`, `--tint`, `--tenant-soft` y `--tenant-hero` si necesitas una marca específica. Los SVG originales permanecen vectoriales.

## Animaciones

Incluye las 10 animaciones nombradas del producto: indicador de navegación, entrada de ícono, aparición, flotación sutil, unión de logos, cruz, barra de carga, drawer y selección del menú operativo. Todas las transiciones originales están en `move.css`.

Skeleton y spinner son dos primitivas de carga añadidas para la biblioteca. No representan pantallas nuevas de la aplicación.

Respeta `prefers-reduced-motion`; también puedes activar `reducedMotion` en React o `reduce-motion` en el contenedor HTML.

## Integración que corresponde a tu aplicación

La biblioteca no trae los servicios funcionales que el equipo está construyendo:

- Autenticación real, whitelist y envío de OTP.
- Motor de elegibilidad, cutoff y planificación.
- Mapas Leaflet, tiles, cálculo de rutas y GPS real.
- Cámara, decodificación y validación de QR.
- Generación dinámica del QR: los SVG del catálogo son ejemplos visuales.
- Persistencia de viajes, incidencias, costos, reseñas y auditoría.
- Importación de Excel/CSV y carga de archivos en servidor.

El editor de zonas y las pantallas de mapas contienen la superficie y controles del diseño; integra tu motor de mapa y eventos. El responsive de los bloques se conserva mediante las reglas originales; los layouts completos de una aplicación requieren su shell.

## Procedencia

Fuente: checkout de MOVE UI v17, commit `0ea7bd7e1dcdf6cf082b495e3ec37cde32c8db37`.

Los logos de TP, Alorica, TrueShore y Concentrix son assets de la demostración existente; sus marcas pertenecen a sus titulares. No se añadieron dependencias externas al proyecto original ni se cambió la app publicada.
