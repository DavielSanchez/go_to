# Validación de la exportación

Build: 361 plantillas HTML compiladas.

66 expresiones de vistas/bloques comparadas entre la UI original y la exportada: misma estructura y atributos, normalizando espacios de formato y fijando las fechas de los datos demo.

Pruebas incluidas:

- tests/smoke.mjs: landing, login por empresa, colaboración, ventanas y medianoche, ticket QR, preferencias, OTP del conductor, ruta fija por QR, supervisor e idioma.
- tests/management.mjs: permisos y scope, coordinación, plan anticipado, confirmación, actualización aprobada, cutoff, preregistro, CSV/XLSX, zonas, eventos, QR externos, vinculación/desvinculación y pasajero conservado, impersonación trazable y registro con rol administrativo.

Las pruebas usan JSDOM. La revisión visual en navegador y las pruebas de dispositivos (cámara/GPS) requieren el entorno de destino. No se sustituyeron las imágenes, estilos, librerías ni la lógica demo. El único cambio funcional de empaquetado es el nombre aislado del cache del service worker.
