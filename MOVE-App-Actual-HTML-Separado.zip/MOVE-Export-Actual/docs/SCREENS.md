# Pantallas y plantillas

Las 361 plantillas incluyen pantallas, estados y fragmentos reutilizados. El prefijo de cada ruta identifica el área y el módulo de origen.

## administration

| HTML editable en src/templates/ | JavaScript de origen |
| --- | --- |
| `administration/admin-dashboard/ops-pill.html` | `src/js/admin/dashboard.js` |
| `administration/admin-dashboard/ops-metric.html` | `src/js/admin/dashboard.js` |
| `administration/admin-dashboard/ops-scope-control.html` | `src/js/admin/dashboard.js` |
| `administration/admin-dashboard/ops-scope-control-02.html` | `src/js/admin/dashboard.js` |
| `administration/admin-dashboard/ops-windows.html` | `src/js/admin/dashboard.js` |
| `administration/admin-dashboard/ops-overview-view.html` | `src/js/admin/dashboard.js` |
| `administration/admin-dashboard/ops-overview-view-02.html` | `src/js/admin/dashboard.js` |
| `administration/admin-dashboard/tenants.html` | `src/js/admin/dashboard.js` |
| `administration/admin-dashboard/attention.html` | `src/js/admin/dashboard.js` |
| `administration/admin-dashboard/ops-trip-card.html` | `src/js/admin/dashboard.js` |
| `administration/admin-dashboard/filters.html` | `src/js/admin/dashboard.js` |
| `administration/admin-dashboard/empty.html` | `src/js/admin/dashboard.js` |
| `administration/admin-dashboard/cards.html` | `src/js/admin/dashboard.js` |
| `administration/admin-dashboard/cards-02.html` | `src/js/admin/dashboard.js` |
| `administration/admin-dashboard/cards-03.html` | `src/js/admin/dashboard.js` |
| `administration/admin-dashboard/cards-04.html` | `src/js/admin/dashboard.js` |
| `administration/admin-dashboard/cards-05.html` | `src/js/admin/dashboard.js` |
| `administration/admin-dashboard/cards-06.html` | `src/js/admin/dashboard.js` |
| `administration/admin-dashboard/plans.html` | `src/js/admin/dashboard.js` |
| `administration/admin-dashboard/chart.html` | `src/js/admin/dashboard.js` |
| `administration/admin-dashboard/comparison.html` | `src/js/admin/dashboard.js` |
| `administration/admin-dashboard/insights.html` | `src/js/admin/dashboard.js` |
| `administration/admin-dashboard/tenant-options.html` | `src/js/admin/dashboard.js` |
| `administration/admin-dashboard/integration.html` | `src/js/admin/dashboard.js` |
| `administration/admin-dashboard/window-inputs.html` | `src/js/admin/dashboard.js` |
| `administration/admin-dashboard/window-inputs-02.html` | `src/js/admin/dashboard.js` |
| `administration/admin-dashboard/summary.html` | `src/js/admin/dashboard.js` |
| `administration/admin-dashboard/ops-audit-rows.html` | `src/js/admin/dashboard.js` |
| `administration/admin-dashboard/ops-audit-rows-02.html` | `src/js/admin/dashboard.js` |
| `administration/admin-dashboard/ops-audit-rows-03.html` | `src/js/admin/dashboard.js` |
| `administration/admin-dashboard/companies.html` | `src/js/admin/dashboard.js` |
| `administration/admin-dashboard/targets.html` | `src/js/admin/dashboard.js` |
| `administration/admin-dashboard/users.html` | `src/js/admin/dashboard.js` |
| `administration/admin-dashboard/users-02.html` | `src/js/admin/dashboard.js` |
| `administration/admin-dashboard/ops-action-form.html` | `src/js/admin/dashboard.js` |
| `administration/admin-dashboard/buttons.html` | `src/js/admin/dashboard.js` |
| `administration/admin-dashboard/buttons-02.html` | `src/js/admin/dashboard.js` |
| `administration/admin-dashboard/buttons-03.html` | `src/js/admin/dashboard.js` |
| `administration/admin-dashboard/buttons-04.html` | `src/js/admin/dashboard.js` |
| `administration/admin-dashboard/ops-action-form-02.html` | `src/js/admin/dashboard.js` |
| `administration/admin-dashboard/ops-action-form-03.html` | `src/js/admin/dashboard.js` |
| `administration/admin-dashboard/ops-action-form-04.html` | `src/js/admin/dashboard.js` |
| `administration/admin-dashboard/content.html` | `src/js/admin/dashboard.js` |
| `administration/admin-dashboard/content-02.html` | `src/js/admin/dashboard.js` |
| `administration/admin-dashboard/content-03.html` | `src/js/admin/dashboard.js` |
| `administration/admin-dashboard/content-04.html` | `src/js/admin/dashboard.js` |
| `administration/admin-dashboard/content-05.html` | `src/js/admin/dashboard.js` |
| `administration/admin-dashboard/content-06.html` | `src/js/admin/dashboard.js` |
| `administration/admin-dashboard/content-07.html` | `src/js/admin/dashboard.js` |
| `administration/admin-dashboard/content-08.html` | `src/js/admin/dashboard.js` |
| `administration/admin-dashboard/content-09.html` | `src/js/admin/dashboard.js` |
| `administration/admin-dashboard/ops-drawer-html.html` | `src/js/admin/dashboard.js` |
| `administration/admin-dashboard/ops-mobile-warning.html` | `src/js/admin/dashboard.js` |
| `administration/admin-dashboard/render-ops-portal.html` | `src/js/admin/dashboard.js` |
| `administration/admin-dashboard/render-ops-portal-02.html` | `src/js/admin/dashboard.js` |
| `administration/admin-dashboard/render-ops-portal-03.html` | `src/js/admin/dashboard.js` |
| `administration/admin-dashboard/impersonation.html` | `src/js/admin/dashboard.js` |
| `administration/admin-dashboard/notice.html` | `src/js/admin/dashboard.js` |
| `administration/admin-dashboard/company.html` | `src/js/admin/dashboard.js` |
| `administration/admin-dashboard/company-02.html` | `src/js/admin/dashboard.js` |
| `administration/admin-dashboard/navigation.html` | `src/js/admin/dashboard.js` |
| `administration/admin-dashboard/languages.html` | `src/js/admin/dashboard.js` |
| `administration/admin-dashboard/actions.html` | `src/js/admin/dashboard.js` |
| `administration/admin-dashboard/actions-02.html` | `src/js/admin/dashboard.js` |
| `administration/admin-dashboard/login-view.html` | `src/js/admin/dashboard.js` |
| `administration/admin-dashboard/login-view-02.html` | `src/js/admin/dashboard.js` |
| `administration/admin-modules-administration/selected-site-control.html` | `src/js/admin/modules/administration.js` |
| `administration/admin-modules-administration/selected-site-control-02.html` | `src/js/admin/modules/administration.js` |
| `administration/admin-modules-administration/management-table.html` | `src/js/admin/modules/administration.js` |
| `administration/admin-modules-administration/management-table-02.html` | `src/js/admin/modules/administration.js` |
| `administration/admin-modules-administration/management-table-03.html` | `src/js/admin/modules/administration.js` |
| `administration/admin-modules-administration/module-card.html` | `src/js/admin/modules/administration.js` |
| `administration/admin-modules-administration/site-cell.html` | `src/js/admin/modules/administration.js` |
| `administration/admin-modules-administration/drawer-frame.html` | `src/js/admin/modules/administration.js` |
| `administration/admin-modules-administration/reason-input.html` | `src/js/admin/modules/administration.js` |
| `administration/admin-modules-administration/toolbar.html` | `src/js/admin/modules/administration.js` |
| `administration/admin-modules-administration/users-view.html` | `src/js/admin/modules/administration.js` |
| `administration/admin-modules-administration/users-table.html` | `src/js/admin/modules/administration.js` |
| `administration/admin-modules-administration/user-form.html` | `src/js/admin/modules/administration.js` |
| `administration/admin-modules-administration/user-form-02.html` | `src/js/admin/modules/administration.js` |
| `administration/admin-modules-administration/user-form-03.html` | `src/js/admin/modules/administration.js` |
| `administration/admin-modules-administration/user-form-04.html` | `src/js/admin/modules/administration.js` |
| `administration/admin-modules-administration/import-form.html` | `src/js/admin/modules/administration.js` |
| `administration/admin-modules-administration/read-user-import.html` | `src/js/admin/modules/administration.js` |
| `administration/admin-modules-administration/read-user-import-02.html` | `src/js/admin/modules/administration.js` |
| `administration/admin-modules-administration/read-user-import-03.html` | `src/js/admin/modules/administration.js` |
| `administration/admin-modules-administration/fleet-view.html` | `src/js/admin/modules/administration.js` |
| `administration/admin-modules-administration/fleet-view-02.html` | `src/js/admin/modules/administration.js` |
| `administration/admin-modules-administration/fleet-form.html` | `src/js/admin/modules/administration.js` |
| `administration/admin-modules-administration/history-view.html` | `src/js/admin/modules/administration.js` |
| `administration/admin-modules-administration/history-view-02.html` | `src/js/admin/modules/administration.js` |
| `administration/admin-modules-administration/history-view-03.html` | `src/js/admin/modules/administration.js` |
| `administration/admin-modules-administration/incidents-view.html` | `src/js/admin/modules/administration.js` |
| `administration/admin-modules-administration/incidents-view-02.html` | `src/js/admin/modules/administration.js` |
| `administration/admin-modules-administration/incidents-view-03.html` | `src/js/admin/modules/administration.js` |
| `administration/admin-modules-administration/incident-form.html` | `src/js/admin/modules/administration.js` |
| `administration/admin-modules-administration/incident-form-02.html` | `src/js/admin/modules/administration.js` |
| `administration/admin-modules-administration/incident-form-03.html` | `src/js/admin/modules/administration.js` |
| `administration/admin-modules-administration/incident-form-04.html` | `src/js/admin/modules/administration.js` |
| `administration/admin-modules-administration/incident-form-05.html` | `src/js/admin/modules/administration.js` |
| `administration/admin-modules-administration/incident-form-06.html` | `src/js/admin/modules/administration.js` |
| `administration/admin-modules-administration/reviews-view.html` | `src/js/admin/modules/administration.js` |
| `administration/admin-modules-administration/reviews-view-02.html` | `src/js/admin/modules/administration.js` |
| `administration/admin-modules-administration/reviews-view-03.html` | `src/js/admin/modules/administration.js` |
| `administration/admin-modules-administration/management-mobile-navigation.html` | `src/js/admin/modules/administration.js` |
| `administration/admin-modules-administration/management-mobile-navigation-02.html` | `src/js/admin/modules/administration.js` |
| `administration/admin-modules-administration/humanize-administration.html` | `src/js/admin/modules/administration.js` |
| `administration/admin-modules-administration/trip-history-details.html` | `src/js/admin/modules/administration.js` |
| `administration/admin-modules-administration/trip-history-details-02.html` | `src/js/admin/modules/administration.js` |
| `administration/admin-modules-administration/trip-history-details-03.html` | `src/js/admin/modules/administration.js` |
| `administration/admin-modules-administration/trip-history-details-04.html` | `src/js/admin/modules/administration.js` |
| `administration/admin-modules-administration/trip-history-details-05.html` | `src/js/admin/modules/administration.js` |
| `administration/admin-modules-administration/trip-history-details-06.html` | `src/js/admin/modules/administration.js` |
| `administration/admin-modules-administration/trip-history-details-07.html` | `src/js/admin/modules/administration.js` |
| `administration/admin-modules-administration/more.html` | `src/js/admin/modules/administration.js` |
| `administration/admin-modules-administration/more-02.html` | `src/js/admin/modules/administration.js` |
| `administration/admin-modules-administration/trip-history-details-08.html` | `src/js/admin/modules/administration.js` |
| `administration/admin-modules-administration/account-menu-html.html` | `src/js/admin/modules/administration.js` |
| `administration/admin-modules-administration/account-menu-html-02.html` | `src/js/admin/modules/administration.js` |
| `administration/admin-modules-administration/fragment.html` | `src/js/admin/modules/administration.js` |
| `administration/admin-modules-administration/fragment-02.html` | `src/js/admin/modules/administration.js` |
| `administration/admin-modules-events/events-view.html` | `src/js/admin/modules/events.js` |
| `administration/admin-modules-events/events-view-02.html` | `src/js/admin/modules/events.js` |
| `administration/admin-modules-events/events-view-03.html` | `src/js/admin/modules/events.js` |
| `administration/admin-modules-events/event-form.html` | `src/js/admin/modules/events.js` |
| `administration/admin-modules-events/event-form-02.html` | `src/js/admin/modules/events.js` |
| `administration/admin-modules-events/event-form-03.html` | `src/js/admin/modules/events.js` |
| `administration/admin-modules-events/event-form-04.html` | `src/js/admin/modules/events.js` |
| `administration/admin-modules-events/guest-fields.html` | `src/js/admin/modules/events.js` |
| `administration/admin-modules-events/guest-fields-02.html` | `src/js/admin/modules/events.js` |
| `administration/admin-modules-events/guest-fields-03.html` | `src/js/admin/modules/events.js` |
| `administration/admin-modules-events/event-details.html` | `src/js/admin/modules/events.js` |
| `administration/admin-modules-events/event-details-02.html` | `src/js/admin/modules/events.js` |
| `administration/admin-modules-events/event-details-03.html` | `src/js/admin/modules/events.js` |
| `administration/admin-modules-events/event-details-04.html` | `src/js/admin/modules/events.js` |
| `administration/admin-modules-events/event-details-05.html` | `src/js/admin/modules/events.js` |
| `administration/admin-modules-events/event-details-06.html` | `src/js/admin/modules/events.js` |
| `administration/admin-modules-planning/intro.html` | `src/js/admin/modules/planning.js` |
| `administration/admin-modules-planning/intro-02.html` | `src/js/admin/modules/planning.js` |
| `administration/admin-modules-planning/ops-plans-view.html` | `src/js/admin/modules/planning.js` |
| `administration/admin-modules-planning/ops-plans-view-02.html` | `src/js/admin/modules/planning.js` |
| `administration/admin-modules-planning/ops-plans-view-03.html` | `src/js/admin/modules/planning.js` |
| `administration/admin-modules-planning/ops-plans-view-04.html` | `src/js/admin/modules/planning.js` |
| `administration/admin-modules-planning/ops-plans-view-05.html` | `src/js/admin/modules/planning.js` |
| `administration/admin-modules-planning/ops-plans-view-06.html` | `src/js/admin/modules/planning.js` |
| `administration/admin-modules-planning/ops-plans-view-07.html` | `src/js/admin/modules/planning.js` |
| `administration/admin-modules-planning/ops-plans-view-08.html` | `src/js/admin/modules/planning.js` |
| `administration/admin-modules-planning/ops-plans-view-09.html` | `src/js/admin/modules/planning.js` |
| `administration/admin-modules-planning/launch-plan-form.html` | `src/js/admin/modules/planning.js` |
| `administration/admin-modules-planning/launch-plan-form-02.html` | `src/js/admin/modules/planning.js` |
| `administration/admin-modules-planning/plan-update-form.html` | `src/js/admin/modules/planning.js` |
| `administration/admin-modules-planning/plan-update-form-02.html` | `src/js/admin/modules/planning.js` |
| `administration/admin-modules-planning/html.html` | `src/js/admin/modules/planning.js` |
| `administration/admin-modules-planning/html-02.html` | `src/js/admin/modules/planning.js` |
| `administration/admin-modules-planning/html-03.html` | `src/js/admin/modules/planning.js` |
| `administration/admin-modules-planning/ops-plans-view-10.html` | `src/js/admin/modules/planning.js` |
| `administration/admin-modules-planning/ops-plans-view-11.html` | `src/js/admin/modules/planning.js` |
| `administration/admin-modules-qr-link/catalog-cards.html` | `src/js/admin/modules/qr-link.js` |
| `administration/admin-modules-qr-link/catalog-view.html` | `src/js/admin/modules/qr-link.js` |
| `administration/admin-modules-qr-link/catalog-view-02.html` | `src/js/admin/modules/qr-link.js` |
| `administration/admin-modules-qr-link/export-catalog.html` | `src/js/admin/modules/qr-link.js` |
| `administration/admin-modules-qr-link/ops-drawer-html.html` | `src/js/admin/modules/qr-link.js` |
| `administration/admin-modules-qr-link/ops-drawer-html-02.html` | `src/js/admin/modules/qr-link.js` |
| `administration/admin-modules-qr-link/linked-driver-view.html` | `src/js/admin/modules/qr-link.js` |
| `administration/admin-modules-qr-link/linked-driver-view-02.html` | `src/js/admin/modules/qr-link.js` |
| `administration/admin-modules-qr-link/linked-driver-view-03.html` | `src/js/admin/modules/qr-link.js` |
| `administration/admin-modules-qr-link/linked-driver-view-04.html` | `src/js/admin/modules/qr-link.js` |
| `administration/admin-modules-qr-link/linked-driver-view-05.html` | `src/js/admin/modules/qr-link.js` |
| `administration/admin-modules-qr-link/linked-driver-view-06.html` | `src/js/admin/modules/qr-link.js` |
| `administration/admin-modules-qr-link/linked-driver-view-07.html` | `src/js/admin/modules/qr-link.js` |
| `administration/admin-modules-qr-link/notice.html` | `src/js/admin/modules/qr-link.js` |
| `administration/admin-modules-qr-link/notice-02.html` | `src/js/admin/modules/qr-link.js` |
| `administration/admin-modules-zones/zones-view.html` | `src/js/admin/modules/zones.js` |
| `administration/admin-modules-zones/zones-view-02.html` | `src/js/admin/modules/zones.js` |
| `administration/admin-modules-zones/zones-view-03.html` | `src/js/admin/modules/zones.js` |
| `administration/admin-modules-zones/html.html` | `src/js/admin/modules/zones.js` |

## employee

| HTML editable en src/templates/ | JavaScript de origen |
| --- | --- |
| `employee/app/icon.html` | `src/js/app.js` |
| `employee/app/page-heading.html` | `src/js/app.js` |
| `employee/app/page-heading-02.html` | `src/js/app.js` |
| `employee/app/route.html` | `src/js/app.js` |
| `employee/app/demo.html` | `src/js/app.js` |
| `employee/app/nav.html` | `src/js/app.js` |
| `employee/app/home.html` | `src/js/app.js` |
| `employee/app/home-02.html` | `src/js/app.js` |
| `employee/app/home-03.html` | `src/js/app.js` |
| `employee/app/home-04.html` | `src/js/app.js` |
| `employee/app/home-05.html` | `src/js/app.js` |
| `employee/app/home-06.html` | `src/js/app.js` |
| `employee/app/home-07.html` | `src/js/app.js` |
| `employee/app/exception.html` | `src/js/app.js` |
| `employee/app/exception-02.html` | `src/js/app.js` |
| `employee/app/exception-03.html` | `src/js/app.js` |
| `employee/app/exception-04.html` | `src/js/app.js` |
| `employee/app/trip.html` | `src/js/app.js` |
| `employee/app/trip-02.html` | `src/js/app.js` |
| `employee/app/trip-03.html` | `src/js/app.js` |
| `employee/app/review.html` | `src/js/app.js` |
| `employee/app/review-02.html` | `src/js/app.js` |
| `employee/app/review-03.html` | `src/js/app.js` |
| `employee/app/review-04.html` | `src/js/app.js` |
| `employee/app/review-05.html` | `src/js/app.js` |
| `employee/app/history.html` | `src/js/app.js` |
| `employee/app/profile.html` | `src/js/app.js` |
| `employee/app/history-row.html` | `src/js/app.js` |
| `employee/app/history-row-02.html` | `src/js/app.js` |
| `employee/app/address-summary.html` | `src/js/app.js` |
| `employee/app/address-summary-02.html` | `src/js/app.js` |
| `employee/app/fragment.html` | `src/js/app.js` |
| `employee/app/fragment-02.html` | `src/js/app.js` |
| `employee/app/fragment-03.html` | `src/js/app.js` |
| `employee/app/fragment-04.html` | `src/js/app.js` |
| `employee/app/fragment-05.html` | `src/js/app.js` |
| `employee/app/fragment-06.html` | `src/js/app.js` |
| `employee/app/fragment-07.html` | `src/js/app.js` |
| `employee/app/fragment-08.html` | `src/js/app.js` |
| `employee/app/fragment-09.html` | `src/js/app.js` |
| `employee/app/fragment-10.html` | `src/js/app.js` |
| `employee/app/fragment-11.html` | `src/js/app.js` |
| `employee/app/address-summary-03.html` | `src/js/app.js` |
| `employee/app/address-summary-04.html` | `src/js/app.js` |
| `employee/app/address-summary-05.html` | `src/js/app.js` |
| `employee/app/fragment-12.html` | `src/js/app.js` |
| `employee/app/fragment-13.html` | `src/js/app.js` |
| `employee/app/fragment-14.html` | `src/js/app.js` |
| `employee/app/attribution.html` | `src/js/app.js` |
| `employee/app/qr-markup.html` | `src/js/app.js` |
| `employee/app/ticket-card.html` | `src/js/app.js` |
| `employee/app/fragment-15.html` | `src/js/app.js` |
| `employee/app/fragment-16.html` | `src/js/app.js` |
| `employee/app/fragment-17.html` | `src/js/app.js` |
| `employee/app/simulate-scan.html` | `src/js/app.js` |
| `employee/app/fragment-18.html` | `src/js/app.js` |
| `employee/app/fragment-19.html` | `src/js/app.js` |
| `employee/app/fragment-20.html` | `src/js/app.js` |
| `employee/app/fragment-21.html` | `src/js/app.js` |
| `employee/app/fragment-22.html` | `src/js/app.js` |
| `employee/app/fragment-23.html` | `src/js/app.js` |
| `employee/app/fragment-24.html` | `src/js/app.js` |
| `employee/app/fragment-25.html` | `src/js/app.js` |
| `employee/app/fragment-26.html` | `src/js/app.js` |

## driver

| HTML editable en src/templates/ | JavaScript de origen |
| --- | --- |
| `driver/driver/set-navigation.html` | `src/js/driver.js` |
| `driver/driver/sync-header.html` | `src/js/driver.js` |
| `driver/driver/render.html` | `src/js/driver.js` |
| `driver/driver/render-02.html` | `src/js/driver.js` |
| `driver/driver/links.html` | `src/js/driver.js` |
| `driver/driver/login-view.html` | `src/js/driver.js` |
| `driver/driver/field.html` | `src/js/driver.js` |
| `driver/driver/photo-field.html` | `src/js/driver.js` |
| `driver/driver/photo-field-02.html` | `src/js/driver.js` |
| `driver/driver/photo-field-03.html` | `src/js/driver.js` |
| `driver/driver/photo-field-04.html` | `src/js/driver.js` |
| `driver/driver/onboarding-view.html` | `src/js/driver.js` |
| `driver/driver/onboarding-view-02.html` | `src/js/driver.js` |
| `driver/driver/onboarding-view-03.html` | `src/js/driver.js` |
| `driver/driver/onboarding-view-04.html` | `src/js/driver.js` |
| `driver/driver/onboarding-view-05.html` | `src/js/driver.js` |
| `driver/driver/onboarding-view-06.html` | `src/js/driver.js` |
| `driver/driver/onboarding-view-07.html` | `src/js/driver.js` |
| `driver/driver/set-photo.html` | `src/js/driver.js` |
| `driver/driver/driver-banner.html` | `src/js/driver.js` |
| `driver/driver/driver-banner-02.html` | `src/js/driver.js` |
| `driver/driver/zone-card.html` | `src/js/driver.js` |
| `driver/driver/zone-card-02.html` | `src/js/driver.js` |
| `driver/driver/route-stops.html` | `src/js/driver.js` |
| `driver/driver/route-stops-02.html` | `src/js/driver.js` |
| `driver/driver/assignment-card.html` | `src/js/driver.js` |
| `driver/driver/driver-home.html` | `src/js/driver.js` |
| `driver/driver/driver-home-02.html` | `src/js/driver.js` |
| `driver/driver/driver-board.html` | `src/js/driver.js` |
| `driver/driver/driver-board-02.html` | `src/js/driver.js` |
| `driver/driver/driver-board-03.html` | `src/js/driver.js` |
| `driver/driver/driver-route.html` | `src/js/driver.js` |
| `driver/driver/driver-route-02.html` | `src/js/driver.js` |
| `driver/driver/driver-route-03.html` | `src/js/driver.js` |
| `driver/driver/driver-incident.html` | `src/js/driver.js` |
| `driver/driver/driver-incident-02.html` | `src/js/driver.js` |
| `driver/driver/driver-incident-03.html` | `src/js/driver.js` |
| `driver/driver/driver-incident-04.html` | `src/js/driver.js` |
| `driver/driver/driver-history.html` | `src/js/driver.js` |
| `driver/driver/driver-history-02.html` | `src/js/driver.js` |
| `driver/driver/driver-profile.html` | `src/js/driver.js` |
| `driver/driver/driver-profile-02.html` | `src/js/driver.js` |
| `driver/driver/empty-driver.html` | `src/js/driver.js` |
| `driver/driver/zone-distribution-card.html` | `src/js/driver.js` |
| `driver/driver/zone-distribution-card-02.html` | `src/js/driver.js` |
| `driver/driver/zone-distribution-card-03.html` | `src/js/driver.js` |
| `driver/driver/scan-result-html.html` | `src/js/driver.js` |
| `driver/driver/html.html` | `src/js/driver.js` |
| `driver/driver/load-driver-map.html` | `src/js/driver.js` |
| `driver/driver/load-driver-map-02.html` | `src/js/driver.js` |
| `driver/driver/load-driver-map-03.html` | `src/js/driver.js` |
| `driver/driver/open-scanner.html` | `src/js/driver.js` |
| `driver/driver/vehicle-input.html` | `src/js/driver.js` |
| `driver/driver/fragment.html` | `src/js/driver.js` |
| `driver/driver/fragment-02.html` | `src/js/driver.js` |
| `driver/driver/fragment-03.html` | `src/js/driver.js` |
| `driver/driver/fragment-04.html` | `src/js/driver.js` |
| `driver/driver/bind-driver.html` | `src/js/driver.js` |

## supervisor

| HTML editable en src/templates/ | JavaScript de origen |
| --- | --- |
| `supervisor/experience/html.html` | `src/js/experience.js` |
| `supervisor/experience/html-02.html` | `src/js/experience.js` |
| `supervisor/experience/approval-view.html` | `src/js/experience.js` |
| `supervisor/experience/approval-view-02.html` | `src/js/experience.js` |
| `supervisor/experience/approval-view-03.html` | `src/js/experience.js` |
| `supervisor/experience/approval-view-04.html` | `src/js/experience.js` |
| `supervisor/experience/approval-view-05.html` | `src/js/experience.js` |
| `supervisor/experience/approval-view-06.html` | `src/js/experience.js` |
| `supervisor/experience/approval-view-07.html` | `src/js/experience.js` |
| `supervisor/experience/approval-view-08.html` | `src/js/experience.js` |
| `supervisor/experience/approval-view-09.html` | `src/js/experience.js` |
| `supervisor/experience/account-menu-html.html` | `src/js/experience.js` |
| `supervisor/experience/update-account-controls.html` | `src/js/experience.js` |
| `supervisor/experience/render.html` | `src/js/experience.js` |
| `supervisor/experience/links.html` | `src/js/experience.js` |
| `supervisor/experience/render-02.html` | `src/js/experience.js` |

## landing

| HTML editable en src/templates/ | JavaScript de origen |
| --- | --- |
| `landing/landing/landing-view.html` | `src/js/landing.js` |
| `landing/landing/landing-view-02.html` | `src/js/landing.js` |
| `landing/landing/landing-view-03.html` | `src/js/landing.js` |
| `landing/landing/landing-view-04.html` | `src/js/landing.js` |
| `landing/landing/landing-view-05.html` | `src/js/landing.js` |
| `landing/landing/role-story.html` | `src/js/landing.js` |
| `landing/landing/role-story-02.html` | `src/js/landing.js` |
| `landing/landing/phone-preview.html` | `src/js/landing.js` |
| `landing/landing/phone-preview-02.html` | `src/js/landing.js` |
| `landing/landing/render.html` | `src/js/landing.js` |

## personalization

| HTML editable en src/templates/ | JavaScript de origen |
| --- | --- |
| `personalization/personalization/tenant-brand.html` | `src/js/personalization.js` |
| `personalization/personalization/move-brand.html` | `src/js/personalization.js` |
| `personalization/personalization/apply-tenant-brand.html` | `src/js/personalization.js` |
| `personalization/personalization/login-view.html` | `src/js/personalization.js` |
| `personalization/personalization/login-view-02.html` | `src/js/personalization.js` |
| `personalization/personalization/show-tenant-splash.html` | `src/js/personalization.js` |
| `personalization/personalization/preference-switch.html` | `src/js/personalization.js` |
| `personalization/personalization/window-options.html` | `src/js/personalization.js` |
| `personalization/personalization/settings-view.html` | `src/js/personalization.js` |
| `personalization/personalization/account-menu-html.html` | `src/js/personalization.js` |
| `personalization/personalization/account-menu-html-02.html` | `src/js/personalization.js` |
| `personalization/personalization/departure-view.html` | `src/js/personalization.js` |
| `personalization/personalization/departure-view-02.html` | `src/js/personalization.js` |
| `personalization/personalization/render.html` | `src/js/personalization.js` |
| `personalization/personalization/render-02.html` | `src/js/personalization.js` |
| `personalization/personalization/render-03.html` | `src/js/personalization.js` |
| `personalization/personalization/render-04.html` | `src/js/personalization.js` |
| `personalization/personalization/render-05.html` | `src/js/personalization.js` |
| `personalization/personalization/render-06.html` | `src/js/personalization.js` |
| `personalization/personalization/render-07.html` | `src/js/personalization.js` |
| `personalization/personalization/render-08.html` | `src/js/personalization.js` |
| `personalization/personalization/render-09.html` | `src/js/personalization.js` |
| `personalization/personalization/render-10.html` | `src/js/personalization.js` |
| `personalization/personalization/render-11.html` | `src/js/personalization.js` |

## polish

| HTML editable en src/templates/ | JavaScript de origen |
| --- | --- |
| `polish/polish/decorate-landing.html` | `src/js/polish.js` |

## registration

| HTML editable en src/templates/ | JavaScript de origen |
| --- | --- |
| `registration/registration/login-view.html` | `src/js/registration.js` |
| `registration/registration/signup-steps.html` | `src/js/registration.js` |
| `registration/registration/signup-steps-02.html` | `src/js/registration.js` |
| `registration/registration/registration-view.html` | `src/js/registration.js` |
| `registration/registration/registration-view-02.html` | `src/js/registration.js` |
| `registration/registration/registration-view-03.html` | `src/js/registration.js` |
| `registration/registration/registration-view-04.html` | `src/js/registration.js` |
| `registration/registration/registration-view-05.html` | `src/js/registration.js` |
| `registration/registration/registration-view-06.html` | `src/js/registration.js` |
| `registration/registration/registration-view-07.html` | `src/js/registration.js` |
| `registration/registration/registration-view-08.html` | `src/js/registration.js` |
| `registration/registration/registration-view-09.html` | `src/js/registration.js` |

## Plantillas nativas del portal

`public/admin/`: shell, overview, operation, plans, statistics, configuration, audit y platform.

## Rutas principales

Landing/login/register; home/departure/exception/ticket/address/trip/review/history/profile/settings; approvals; driver-home/driver-onboarding/driver-board/driver-route/driver-incident/driver-history/driver-profile/driver-vehicle; ops-overview/ops-operation/ops-plans/ops-qr/ops-zones/ops-users/ops-fleet/ops-events/ops-history/ops-incidents/ops-reviews/ops-statistics/ops-configuration/ops-audit/ops-account/ops-platform.
