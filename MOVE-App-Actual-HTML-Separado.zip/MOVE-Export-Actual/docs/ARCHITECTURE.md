# Arquitectura de la UI exportada

MOVE sigue siendo una SPA estática con navegación por hash, scripts clásicos y datos demo. El orden de carga de `src/index.html` es parte del funcionamiento: los módulos posteriores amplían funciones y vistas definidas antes.

## Módulos

| Módulo en src/js | Responsabilidad |
| --- | --- |
| `app.js` | Vistas y estado del empleado, confirmaciones, direcciones, tickets y reseñas |
| `driver.js` | Login compartido, conductor, onboarding, cámara, abordaje y recorrido |
| `landing.js` | Landing del producto |
| `i18n.js` | Diccionario y traducción de la interfaz |
| `experience.js` | Avatar, menús, supervisor y mejoras de experiencia |
| `registration.js` | Registro corporativo/conductor, OTP y cuentas demo |
| `polish.js` | Navegación animada y animaciones de landing |
| `personalization.js` | Empresas, temas, unión de logos, ventanas y preferencias |
| `admin/dashboard.js` | Roles, scope, dashboard, datos demo, auditoría e impersonación |
| `admin/modules/administration.js` | Usuarios, flotilla, historial, incidencias, reseñas y navegación administrativa |
| `admin/modules/planning.js` | Generación y confirmación de planes, revisiones y cutoff |
| `admin/modules/zones.js` | Editor de zonas con polígonos |
| `admin/modules/events.js` | Eventos, invitados, origen/destino, trips y costos |
| `admin/modules/import-xlsx.js` | Lectura y validación de Excel/CSV demo |
| `admin/modules/qr-link.js` | Catálogo QR, enlaces de rutas, sesión pendiente y unión del conductor |

## Plantillas

`src/templates/` agrupa los fragmentos por área y módulo. Las plantillas nativas de administración permanecen en `public/admin/` porque el producto ya las carga con fetch. Todas las rutas se preservan en el build.

El compilador expande las macros de forma recursiva, valida que las rutas permanezcan dentro de la carpeta de plantillas y mantiene el ámbito de cada expresión. No se añadieron dependencias al navegador ni un backend de plantillas.

## Estado

El código conserva los modelos actuales `state`, `access`, `driver`, `registration` y `opsModel`. Se persisten datos demo en sessionStorage/localStorage según el módulo. Los permisos implementados en JavaScript sirven para demostrar la UI; la autorización real debe validarse en tu servidor.

## PWA

`src/sw.js` conserva el inventario de cache del producto. El nombre del cache cambia a `move-export-v17-readable` para aislar esta copia de versiones locales anteriores. El resto del código funcional y las rutas del producto se conservan.
