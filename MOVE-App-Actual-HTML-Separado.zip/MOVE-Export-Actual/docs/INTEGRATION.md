# Puntos para conectar tu backend

El backend funcional lo mantiene tu aplicación. Estos son los puntos que hoy producen o consumen datos demo; sirven como mapa para integrar la UI.

| Área | Archivo / puntos principales | Conectar con |
| --- | --- | --- |
| Login y sesión | `driver.js`: bindLogin / loginDemo; ampliaciones en registration, personalization y dashboard | Tu autenticación, usuario, rol y scope autorizados |
| Registro y OTP | `registration.js`: submitRegistrationEmail, issueRegistrationOTP, verifyRegistrationOTP, finishRegistration | Whitelist, emisión/validación de OTP y credenciales |
| Marcas | `personalization.js`: currentTenant, tenantBrand, applyTenantPalette | Configuración de empresa/site de la sesión |
| Confirmación y horarios | `app.js` y `personalization.js`: confirmRide, departureView, completeDeparture | Confirmations elegibles, cutoff y ventanas autorizadas |
| Dirección | `app.js`: setPin y formulario pinAddressForm | Dirección, cobertura de zona y reglas de aprobación |
| Excepciones | `app.js`, `experience.js`: formulario y decisiones del supervisor | Solicitudes, supervisados autorizados y aprobación |
| Planes | `admin/modules/planning.js`: launchPlan, confirmOpsPlan, applyPlanUpdate | Motor de planificación, versiones, pendientes y autorización |
| Zonas | `admin/modules/zones.js`: saveZone | Polígonos, cobertura y versionado |
| Usuarios | `admin/modules/administration.js`: saveManagementUser, commitUserImport | Preregistro, roles y altas masivas |
| Flotilla | `admin/modules/administration.js`: saveFleetType | Tipos, capacidad, gap y estado por site |
| Trips y coordinación | `admin/dashboard.js`: changeOpsTrip y vistas operativas | Trips reales, acciones permitidas y eventos en vivo |
| Conductor y QR | `admin/modules/qr-link.js`: parseRouteLink, claimRoute y funciones linkedDriver | Resolución del QR, trip libre y asignación atómica |
| Abordaje | `driver.js` y funciones de trip vinculado | Escaneo/asignación del pasajero al trip, independiente del conductor |
| Recorrido | `driver.js`: loadDriverMap y vistas de ruta; vistas del empleado | GPS, paradas, ETA y estado del viaje |
| Eventos | `admin/modules/events.js`: saveEvent, confirmEventById | Participantes/invitados, trips especiales y costos |
| Incidencias y reseñas | Módulo administration, vistas del conductor y empleado | Casos, seguimiento, reviews y estadísticas |
| Auditoría/impersonación | `admin/dashboard.js`: recordOps, beginOpsImpersonation, endOpsImpersonation | Actor real, usuario efectivo, motivo, scope, hora, before/after y sesión |

Mantén en servidor los límites de rol, scope, cutoff, capacidad, transiciones de estado y exclusividad de asignación. Las reglas de UI no sustituyen esas validaciones.

La asignación pertenece al trip, no al driver. Una desvinculación no debe eliminar pasajeros abordados. Las confirmaciones posteriores a un plan confirmado requieren revisión aprobada por el administrador, sin alterar viajes ya iniciados. La jornada operativa y la fecha del viaje deben seguir separadas para ventanas que cruzan medianoche.

El enlace QR conserva el destino pendiente durante el login. Usa ese mecanismo al reemplazar la sesión demo para que el conductor no tenga que escanear otra vez.

La biblioteca `ui-library/` ofrece JSX para portar bloques a React, pero la SPA exportada sigue usando su lógica y scripts actuales. Migra los modelos a tu estado y sustituye los callbacks demo por llamadas a tus servicios.
