# MOVE — Transporte empresarial

Código del prototipo publicado el 3 de octubre de 2026.
Incluye landing comercial, login simulado, portal corporativo y portal del conductor.

## Ejecutar localmente

No necesita instalar dependencias ni compilar: HTML, CSS y JavaScript nativo.

```bash
cd MOVE
python -m http.server 8080 --directory dist
```

Abre http://localhost:8080 en el navegador. En Windows también puedes usar `py -m http.server 8080 --directory dist`.
Puedes usar un servidor estático de tu editor, apuntando a `dist`.
No abras index.html directamente con file://: la PWA y otras funciones requieren un servidor.

## Recorridos

- `/` o `/#landing`: presentación del producto.
- `/#login`: selector Corporativo / Conductores y acceso simulado.
- Acceso demo: botón «Entrar como corporativo demo» o «Entrar como conductor demo».
- Iniciar sesión simulada como conductor nuevo conserva el onboarding con fotos.
- Perfil → Cerrar sesión para cambiar de acceso.

## Estructura

- dist/index.html: entrada y barra superior TP × MOVE.
- dist/style.css: interfaz de empleados y conductores, estilos responsive y tema oscuro.
- dist/app.js: flujo corporativo, dirección, confirmación, excepciones, ticket y reseñas.
- dist/driver.js: login, onboarding, asignación por zona, validación, ruta, incidencias y edición del vehículo.
- dist/landing.js y dist/landing.css: landing, vista por rol y calculadora.
- dist/sw.js y dist/manifest.webmanifest: service worker y configuración PWA.
- dist/vendor/: Leaflet, QRCode y jsQR distribuidos con el prototipo.
- dist/transport.webp: imagen ilustrativa generada para la landing.

## Alcance de la demostración

No hay backend, autenticación real ni sincronización multiusuario. Los datos de sesión se guardan con sessionStorage. Las fotos se previsualizan localmente y sus metadatos se conservan durante la sesión; no hay almacenamiento de documentos en un servidor. La distribución y el abordaje de otras unidades se simulan en el mismo dispositivo.

Los mapas utilizan OpenStreetMap/Leaflet, las indicaciones OSRM y la navegación externa Google Maps. Estas funciones y las fuentes de Google necesitan conexión a Internet. Cámara y PWA requieren HTTPS o localhost y dependen de las capacidades del navegador.

Las métricas de la landing son mock. La calculadora es una estimación, no un resultado real ni una promesa de ahorro.

## Publicar

Publica el contenido de `dist` en cualquier hosting estático con HTTPS.
Al editar el prototipo, incrementa la versión de caché de `sw.js` y las versiones de los recursos en `index.html`/`sw.js` para distribuir los cambios a dispositivos con caché.

## Crear tu repositorio

```bash
git init
git add .
git commit -m "Initial MOVE prototype"
```

Luego conecta tu repositorio remoto habitual. Este paquete no contiene credenciales, configuración privada del hosting ni el historial Git del servicio.

Las marcas TP y MOVE se conservan como aparecen en el prototipo. Las bibliotecas de terceros mantienen sus avisos de licencia incluidos.
