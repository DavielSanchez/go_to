import assert from "node:assert/strict";
import fs from "node:fs/promises";
import path from "node:path";
import vm from "node:vm";
import { webcrypto } from "node:crypto";
import { JSDOM } from "jsdom";

const root = path.resolve(import.meta.dirname, "..");
export async function openDemo(directory = path.join(root, "dist")) {
  const dom = new JSDOM(await fs.readFile(path.join(directory, "index.html"), "utf8"), {
    url: "http://localhost:5173/",
    runScripts: "outside-only",
    pretendToBeVisual: true,
  });
  dom.window.scrollTo = () => {};
  dom.window.matchMedia = () => ({
    matches: false,
    addEventListener() {},
    removeEventListener() {},
  });
  Object.defineProperty(dom.window, "crypto", { value: webcrypto });
  const context = dom.getInternalVMContext();
  for (const file of [
    "vendor/qrcode.js",
    "app.js",
    "driver.js",
    "landing.js",
    "i18n.js",
    "experience.js",
    "registration.js",
    "polish.js",
    "personalization.js",
  ]) {
    vm.runInContext(await fs.readFile(path.join(directory, file), "utf8"), context, {
      filename: file,
    });
  }
  const run = (source) => vm.runInContext(source, context);
  const flushLogin = () =>
    run("splashActive=false;document.body.classList.remove('brand-loading');render()");
  return { dom, run, flushLogin };
}

if (import.meta.url === new URL(process.argv[1], "file:").href) {
  const { dom, run, flushLogin } = await openDemo();
  try {
    assert(dom.window.document.querySelector(".marketing"));
    run("navigate('login');render()");
    assert(dom.window.document.querySelector("#sharedLogin"));
    assert(!dom.window.document.querySelector("header .brand-collab img"));
    for (const tenant of ["alorica", "trueshore", "concentrix"]) {
      run(`logoutMove();fillTenantLogin('${tenant}')`);
      dom.window.document
        .querySelector("#sharedLogin")
        .dispatchEvent(new dom.window.Event("submit", { bubbles: true, cancelable: true }));
      assert.equal(run("currentTenant()"), tenant);
      assert(dom.window.document.querySelector(".brand-splash"));
      flushLogin();
      assert(dom.window.document.querySelector("header .brand-collab img"));
    }
    run(
      "state.addressPoint={lat:18.5,lng:-70};state.eligible=true;state.confirmed=false;confirmRide();render()",
    );
    assert.equal(dom.window.document.querySelectorAll(".departure-option").length, 4);
    run("chooseDeparture('00:30');completeDeparture();render()");
    assert.equal(run("state.ticket.time"), "00:30");
    assert.notEqual(run("state.ticket.date"), run("today()"));
    assert(dom.window.document.querySelector(".ticket-qr svg"));
    run("navigate('settings');render()");
    assert(dom.window.document.querySelector("#settingsLanguage"));
    run("setPreference('motion',true);setPreference('window','23:30')");
    assert.equal(run("preferences().window"), "23:30");
    run("startRegistration('driver');submitRegistrationEmail('demo.driver@example.net')");
    assert.equal(run("registration.step"), "otp");
    assert(run("verifyRegistrationOTP(registration.code)"));
    assert(
      await run(
        "finishRegistration({name:'Demo Driver',password:'DemoPass123',confirm:'DemoPass123'})",
      ),
    );
    run("logoutMove();switchRole('driver');loginDemo()");
    flushLogin();
    assert(!dom.window.document.querySelector("#driverWindow"));
    run("driver.stage='arrival';render()");
    assert.equal(dom.window.document.querySelectorAll(".route-qr-card").length, 4);
    run("simulateRouteScan(demoRouteCatalog()[1].routeId)");
    assert.equal(run("driver.departureTime"), "22:30");
    assert(!run("joinZone(demoRouteCatalog()[0].routeId)"));
    assert.equal(run("driver.departureTime"), "22:30");
    run("logoutMove();access.role='corporate';access.corporateRole='supervisor';loginDemo()");
    flushLogin();
    run("navigate('approvals');render()");
    assert(dom.window.document.querySelector(".approval-list"));
    run("setInterfaceLanguage('en')");
    assert.equal(run("t('Configuración')"), "Settings");
    console.log(
      "PASS: landing, tenant logins, brand animation, windows, QR, settings, driver OTP, fixed route assignment, supervisor and language.",
    );
  } finally {
    dom.window.close();
  }
}
