# Pantallas HTML

La estructura común está en `src/index.html`. Estas plantillas contienen el contenido de cada pantalla o estado. Para modificar una sección incluida con `htmlTemplate(...)`, abre el archivo indicado en esa llamada.

| Pantalla / estado                 | Archivo HTML                                                  | Lógica JavaScript en `src/js/`                                  |
| --------------------------------- | ------------------------------------------------------------- | --------------------------------------------------------------- |
| Login                             | `src/templates/screens/auth/login.html`                       | `driver.js, experience.js, registration.js, personalization.js` |
| Registro y OTP                    | `src/templates/screens/auth/register.html`                    | `registration.js`                                               |
| Abordaje del conductor            | `src/templates/screens/driver/board.html`                     | `driver.js`                                                     |
| Historial del conductor           | `src/templates/screens/driver/history.html`                   | `driver.js`                                                     |
| Inicio del conductor              | `src/templates/screens/driver/home.html`                      | `driver.js`                                                     |
| Incidencias                       | `src/templates/screens/driver/incident.html`                  | `driver.js`                                                     |
| Onboarding del conductor          | `src/templates/screens/driver/onboarding.html`                | `driver.js`                                                     |
| Perfil del conductor              | `src/templates/screens/driver/profile.html`                   | `driver.js`                                                     |
| Ruta del conductor                | `src/templates/screens/driver/route.html`                     | `driver.js`                                                     |
| Editar vehículo                   | `src/templates/screens/driver/vehicle.html`                   | `driver.js`                                                     |
| Dirección y pin del mapa          | `src/templates/screens/employee/address.html`                 | `app.js, personalization.js`                                    |
| Elegir hora y confirmar           | `src/templates/screens/employee/departure.html`               | `app.js, personalization.js`                                    |
| Solicitar excepción               | `src/templates/screens/employee/exception.html`               | `app.js, personalization.js`                                    |
| Historial del empleado            | `src/templates/screens/employee/history.html`                 | `app.js, personalization.js`                                    |
| Inicio con excepción aprobada     | `src/templates/screens/employee/home-approved-exception.html` | `app.js, personalization.js`                                    |
| Inicio sin dirección o transporte | `src/templates/screens/employee/home-unavailable.html`        | `app.js, personalization.js`                                    |
| Inicio del empleado               | `src/templates/screens/employee/home.html`                    | `app.js, personalization.js`                                    |
| Perfil del empleado               | `src/templates/screens/employee/profile.html`                 | `app.js, personalization.js`                                    |
| Reseña del viaje                  | `src/templates/screens/employee/review.html`                  | `app.js, personalization.js`                                    |
| Ticket QR                         | `src/templates/screens/employee/ticket.html`                  | `app.js, personalization.js`                                    |
| Viaje programado                  | `src/templates/screens/employee/trip-scheduled.html`          | `app.js, personalization.js`                                    |
| Viaje no disponible               | `src/templates/screens/employee/trip-unavailable.html`        | `app.js, personalization.js`                                    |
| Viaje del empleado                | `src/templates/screens/employee/trip.html`                    | `app.js, personalization.js`                                    |
| Landing del producto              | `src/templates/screens/landing/index.html`                    | `landing.js`                                                    |
| Menú del avatar                   | `src/templates/screens/shared/account-menu.html`              | `experience.js, personalization.js`                             |
| Configuración                     | `src/templates/screens/shared/settings.html`                  | `personalization.js`                                            |
| Excepciones del equipo            | `src/templates/screens/supervisor/team.html`                  | `experience.js`                                                 |

Los componentes menores están agrupados por rol en `src/templates/components/`. `templates-index.json` permite buscar cualquiera de las 183 plantillas y su módulo de origen.
