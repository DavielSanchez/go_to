# MOVE · Código fuente legible

Copia editable del prototipo MOVE. Pantallas y componentes en archivos HTML separados; lógica JavaScript y estilos CSS con sangría, saltos de línea y formato consistente.

## Ejecutar en Windows, macOS o Linux

Necesitas Node.js 22 o superior. Abre la carpeta del proyecto en VS Code y ejecuta:

```bash
npm ci
npm run dev
```

Abre **http://localhost:5173**. Al guardar cambios en `src/` o `public/`, se recompila automáticamente; actualiza la pestaña para verlos.

Para ejecutar una compilación sin observar cambios:

```bash
npm start
```

## Dónde editar

| Carpeta                     | Contenido                                                                                  |
| --------------------------- | ------------------------------------------------------------------------------------------ |
| `src/templates/screens/`    | Pantallas HTML: empleado, conductor, supervisor, login, registro, landing y configuración. |
| `src/templates/components/` | Tarjetas, estados condicionales, formularios, navegación, logos y otros fragmentos HTML.   |
| `src/js/`                   | Estado, reglas del prototipo, eventos, QR, registro, traducciones y tenants.               |
| `src/css/`                  | Estilos de la app, landing, responsive, temas y personalización.                           |
| `src/index.html`            | Estructura común: topbar, sidebar, contenido, navegación inferior y orden de scripts.      |
| `public/`                   | Logos, imágenes, manifiesto PWA y bibliotecas locales.                                     |
| `tools/`                    | Compilación, formateo y servidor local.                                                    |
| `tests/`                    | Comprobaciones funcionales con DOM simulado.                                               |

El archivo **SCREENS.md** indica el HTML y el JavaScript de cada pantalla. **templates-index.json** contiene el índice completo de las plantillas y su módulo de origen.

## Cómo funcionan los HTML separados

Son plantillas HTML dinámicas que se montan dentro de `src/index.html`. No se abren por separado con doble clic: utiliza el servidor y las rutas de la aplicación.

Ejemplo de una plantilla:

```html
<h2>Tu transporte</h2>
<p><%= state.confirmed ? "Reserva confirmada" : "Pendiente de confirmar" %></p>
<%= htmlTemplate("components/employee/address-summary.html") %>
```

- `<%= expresión %>` inserta el resultado de una expresión JavaScript.
- `htmlTemplate("archivo.html")` inserta otro fragmento desde `src/templates/`.
- Las expresiones también pueden contener condiciones y `.map()` para listas.
- La compilación conserva el alcance de las variables de la función que usa la plantilla.
- No necesitas instalar EJS: el compilador local implementa estas dos operaciones. No incluye el resto de las etiquetas de EJS.
- Algunas piezas son fragmentos de apertura o cierre utilizados por funciones existentes; su etiqueta complementaria está en la pantalla o componente que las incluye.

Edita `src/` y `public/`. `dist/` se genera al compilar y no está incluido en este ZIP, para que la entrega contenga únicamente fuentes editables y recursos.

## Comandos

```bash
npm run build   # Genera dist/ para servir o publicar
npm run format  # Formatea HTML, JS, CSS, JSON y documentación
npm test        # Compila y prueba los flujos principales
```

Conserva dos espacios de sangría en las plantillas. El formateador de HTML del proyecto respeta las expresiones y los fragmentos parciales; utiliza `npm run format` para esas plantillas.

Para publicar en un hosting estático, sube el contenido generado de `dist/`. La cámara, ubicación y service worker requieren HTTPS o localhost.

## Cuentas demo

| Empresa / perfil | Correo o identificador      | Contraseña    |
| ---------------- | --------------------------- | ------------- |
| TP · empleado    | `empleado.demo`             | `move-demo`   |
| TP · conductor   | `conductor.demo`            | `move-demo`   |
| Alorica          | `alorica.demo@gmail.com`    | `MoveDemo123` |
| TrueShore        | `trueshore.demo@gmail.com`  | `MoveDemo123` |
| Concentrix       | `concentrix.demo@gmail.com` | `MoveDemo123` |

Para TP supervisor: elige **Corporativo → Supervisor** en el login. El botón de conductor demo completa sus datos de ejemplo; el login normal permite probar el onboarding.

El registro corporativo usa la whitelist definida en `registration.js` y las cuentas adicionales de `personalization.js`. El registro de conductor acepta correos válidos y exige OTP. Los códigos se muestran en pantalla; no se envían correos reales.

## Alcance del prototipo

El login, los OTP, las aprobaciones y las asignaciones son demostraciones locales. `localStorage` conserva cuentas de prueba y preferencias; `sessionStorage` conserva sesión y operación. No hay backend de autenticación ni sincronización entre dispositivos.

Los QR de ruta identifican empresa, ruta, zona, fecha y ventana. La hora del conductor se fija al escanear; no hay selector de ventana. Los tickets de empleados se comprueban contra fecha, unidad y hora.

Los mapas y las direcciones usan servicios externos de OpenStreetMap, OSRM y Google Maps cuando están disponibles. Las fuentes tipográficas utilizan Google Fonts.

La base JavaScript conserva las funciones y extensiones del prototipo para mantener su comportamiento. Esta entrega reorganiza las vistas en HTML y formatea el código; no es una migración a React ni una implementación de producción.
