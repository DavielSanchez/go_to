# Organización del código

## Módulos JavaScript

| Archivo              | Responsabilidad                                                                               |
| -------------------- | --------------------------------------------------------------------------------------------- |
| `app.js`             | Estado del empleado, navegación, confirmación, excepciones, dirección, ticket y reseña.       |
| `driver.js`          | Acceso compartido, onboarding, vehículo, catálogo de rutas QR, abordaje, viaje e incidencias. |
| `landing.js`         | Presentación pública del producto y calculadora de ocupación.                                 |
| `i18n.js`            | Traducciones y actualización de los textos de la interfaz.                                    |
| `experience.js`      | Rol supervisor, aprobación de excepciones y menú de la cuenta.                                |
| `registration.js`    | Whitelist, OTP, creación local de cuentas y validación de contraseñas de prueba.              |
| `polish.js`          | Indicador animado de navegación, idiomas y animaciones de la landing.                         |
| `personalization.js` | Empresas demo, branding después del login, preferencias y selección de salida del empleado.   |

Los scripts se cargan en el orden de `src/index.html`. Comparten variables y funciones globales; algunos módulos extienden funciones anteriores. Mantén ese orden al editar.

## Estilos

| Archivo               | Responsabilidad                                              |
| --------------------- | ------------------------------------------------------------ |
| `style.css`           | Componentes y estructura general del prototipo.              |
| `landing.css`         | Landing pública.                                             |
| `experience.css`      | Menú del avatar y vistas de supervisores.                    |
| `polish.css`          | Navegación animada, registro y animaciones discretas.        |
| `personalization.css` | Tenants, configuración, ventanas y responsive móvil/sidebar. |

El orden de los estilos también importa: las últimas hojas amplían las anteriores.

## Ejemplo: cambiar la confirmación del empleado

1. Edita el contenido de `src/templates/screens/employee/departure.html`.
2. Cambia las ventanas o la regla de fecha en `src/js/personalization.js`.
3. Ajusta su apariencia en `src/css/personalization.css`.
4. Ejecuta `npm test`; con `npm run dev`, el HTML se recompila al guardar.

## Ejemplo: cambiar una empresa

Edita `tenants`, `tenantDemoUsers` y `applyTenantPalette()` en `src/js/personalization.js`. Sus imágenes están en `public/` y las clases de los logos en `src/css/personalization.css`.

## Ejemplo: cambiar una ruta de conductor

El catálogo y sus validaciones están en `demoRouteCatalog()`, `resolveDemoRoute()`, `joinZone()` y `checkBoarding()`, dentro de `src/js/driver.js`. La interfaz de escaneo se encuentra en los componentes de ese módulo; las pantallas completas están en `src/templates/screens/driver/`.

## Bibliotecas y activos

Las bibliotecas de Leaflet, QR y lector QR están en `public/vendor/`, formateadas y con sus avisos originales. Los logos y la fotografía del prototipo están incluidos. Las imágenes no requieren claves de API para mostrarse.
