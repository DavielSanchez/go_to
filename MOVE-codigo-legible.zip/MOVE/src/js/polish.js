Object.assign(enTranslations, {
  "10:15 p. m.": "10:15 p.m.",
  "01 / UNA MEJOR FORMA DE MOVERSE": "01 / A BETTER WAY TO MOVE",
  "Las listas dispersas, los asientos vacíos y las llamadas de última hora no deberían definir el final de una jornada.":
    "Scattered lists, empty seats and last-minute calls should not define the end of a workday.",
  "Confirmación diaria, ticket de abordaje y seguimiento del viaje. Una experiencia clara desde el celular.":
    "Daily confirmation, boarding tickets and trip tracking. A clear experience on your phone.",
  "EXPERIENCIA DEL COLABORADOR": "EMPLOYEE EXPERIENCE",
  "Distribuye pasajeros entre unidades de la misma zona y permite el abordaje simultáneo, sin una cola de conductores.":
    "Distribute passengers across vehicles serving the same zone and enable simultaneous boarding without a driver queue.",
  "COORDINACIÓN OPERATIVA": "OPERATIONAL COORDINATION",
  "Visualiza confirmaciones, ocupación e incidencias. Identifica oportunidades para usar mejor tu servicio de transporte.":
    "See confirmations, occupancy and incidents. Identify opportunities to make better use of your transport service.",
  "VISIBILIDAD DEL SERVICIO": "SERVICE VISIBILITY",
  "02 / UN SERVICIO. TODOS CONECTADOS.": "02 / ONE SERVICE. EVERYONE CONNECTED.",
  "Explora cómo MOVE acompaña a quienes viajan y a quienes los llevan a casa.":
    "Explore how MOVE supports passengers and the drivers who take them home.",
  "MOVE / UNA JORNADA MÁS SIMPLE": "MOVE / A SIMPLER WORKDAY",
  "VIERNES, 2 DE OCTUBRE": "FRIDAY, OCTOBER 2",
  "✓ RESERVA CONFIRMADA": "✓ RESERVATION CONFIRMED",
  "Todo listo para": "Everything is ready for",
  "tu regreso.": "your ride home.",
  "Confirmación recibida": "Confirmation received",
  "Un asiento. Una preocupación menos.": "One seat. One less worry.",
  "03 / DE PUNTA A PUNTA": "03 / FROM START TO FINISH",
  "Ver el flujo en la app": "View the flow in the app",
  "El empleado indica si usará el transporte y recibe su ticket.":
    "The employee confirms their transport needs and receives a ticket.",
  "Los conductores registran su zona y reciben un grupo de pasajeros.":
    "Drivers check into their zone and receive a group of passengers.",
  "Se validan los tickets y se inicia el recorrido con sus paradas.":
    "Tickets are validated and the trip begins with its assigned stops.",
  "Reseñas, historial e incidencias completan la experiencia.":
    "Reviews, history and incidents complete the experience.",
  "04 / LA OPERACIÓN, A SIMPLE VISTA": "04 / OPERATIONS AT A GLANCE",
  "Lo que puedes ver": "What you can see,",
  "también puedes mejorar.": "you can improve.",
  "Así podría verse un resumen del servicio en una operación empresarial. Las cifras siguientes son ilustrativas.":
    "This is what a business transport service summary could look like. The figures below are illustrative.",
  "Escenario de demostración · No representa resultados de clientes":
    "Demo scenario · Not actual customer results",
  "colaboradores en el escenario": "employees in this scenario",
  "vehículos coordinados": "coordinated vehicles",
  "ocupación ilustrativa": "illustrative occupancy",
  "reducción de costo hipotética": "hypothetical cost reduction",
  "Del “¿quién va hoy?”": "From “who is traveling today?”",
  "a una operación visible.": "to visible operations.",
  "Confirmaciones, asignaciones y abordajes permiten construir una vista compartida del servicio para tu equipo.":
    "Confirmations, assignments and boarding records create a shared service view for your team.",
  "Ocupación por salida": "Occupancy by departure",
  "Datos mock": "Mock data",
  "Tres salidas · Ejemplo visual de seguimiento": "Three departures · Visual tracking example",
  "05 / ENCUENTRA TU PUNTO DE PARTIDA": "05 / FIND YOUR STARTING POINT",
  "Haz una estimación con los datos de tu operación. El resultado pone en perspectiva el costo del espacio contratado que no se utiliza.":
    "Estimate using your operational data. The result highlights the cost of contracted capacity that goes unused.",
  "Estimación orientativa: supone un costo uniforme por asiento y todas las salidas con la misma capacidad. No es una promesa de ahorro.":
    "Indicative estimate: assumes a uniform cost per seat and equal capacity for all departures. This is not a savings guarantee.",
  "Completa valores válidos en todos los campos.": "Enter valid values in every field.",
  "06 / EL SERVICIO, CON MÁS CONTROL": "06 / MORE CONTROL OVER YOUR SERVICE",
  "Los detalles importan.": "The details matter.",
  "MOVE los conecta.": "MOVE connects them.",
  "Excepciones sin perder el contexto": "Exceptions with context",
  "Solicitudes por horas extra, capacitaciones y cambios de turno, con estado de aprobación.":
    "Requests for overtime, training and shift changes, with approval status.",
  "Destinos y zonas organizados": "Organized destinations and zones",
  "Ubicación de destino, paradas y asignación de vehículos para cada recorrido.":
    "Destination locations, stops and vehicle assignments for each trip.",
  "Validación antes de abordar": "Validation before boarding",
  "Tickets por fecha, horario y unidad. Cada conductor valida a sus pasajeros asignados.":
    "Tickets by date, departure time and vehicle. Each driver validates their assigned passengers.",
  "Pensado para el celular": "Designed for mobile",
  "Una PWA para empleados y conductores, con una interfaz que se adapta a su jornada.":
    "A PWA for employees and drivers, with an interface that fits their workday.",
  "Incidencias documentadas": "Documented incidents",
  "Un lugar para registrar retrasos, averías u otros problemas durante el servicio.":
    "A place to record delays, breakdowns and other service issues.",
  "La voz de quienes viajan": "A voice for passengers",
  "Calificaciones y comentarios al terminar el recorrido para conocer la experiencia.":
    "End-of-trip ratings and comments to understand the passenger experience.",
  "¿MOVE es una empresa de transporte?": "Is MOVE a transport company?",
  "MOVE es la solución digital que organiza el servicio. Tu empresa y sus proveedores conservan la operación de los vehículos y conductores.":
    "MOVE is the digital solution that organizes the service. Your company and its providers continue to operate the vehicles and drivers.",
  "¿Puede usarse en otras empresas además de TP?": "Can other companies besides TP use it?",
  "Sí. La propuesta está pensada para empresas que ofrecen transporte de personal. El prototipo usa un contexto de TP para mostrar los recorridos y experiencias.":
    "Yes. The solution is designed for companies offering employee transport. The prototype uses a TP context to demonstrate trips and experiences.",
  "¿Qué puedo probar ahora?": "What can I try now?",
  "Puedes explorar el login simulado, confirmar transporte, solicitar excepciones y recorrer el flujo del conductor: registro, zona, abordaje, viaje y perfil.":
    "Explore simulated sign-in, confirm transport, request exceptions and try the driver flow: registration, zone, boarding, trip and profile.",
  "¿Los datos y resultados son reales?": "Are the data and results real?",
  "No. Esta presentación y el prototipo utilizan datos mock. Las métricas son ilustrativas y no corresponden a resultados comprobados de un cliente.":
    "No. This presentation and prototype use mock data. The metrics are illustrative and do not represent verified customer results.",
  "¿Ya incluye autenticación e integraciones empresariales?":
    "Does it include authentication and enterprise integrations?",
  "El prototipo muestra la experiencia del producto. La autenticación real, las integraciones y la operación sincronizada entre dispositivos se definirán para la implementación.":
    "The prototype demonstrates the product experience. Real authentication, integrations and synchronized operations across devices will be defined during implementation.",
  "LA PRÓXIMA PARADA ES UNA MEJOR OPERACIÓN": "NEXT STOP: BETTER OPERATIONS",
  "Descubre una forma más clara de coordinar": "Discover a clearer way to coordinate",
  "el transporte que acompaña a tu equipo.": "the transport that supports your team.",
  "Una app de TP.": "An app by TP.",
  "Registra tu llegada, recibe tus pasajeros y organiza el abordaje junto a las otras unidades de tu zona.":
    "Check in, receive your passengers and organize boarding alongside the other vehicles in your zone.",
  "TRANSPORTE EXTERNO": "EXTERNAL TRANSPORT",
  "Tu ruta está lista.": "Your route is ready.",
  "6 pasajeros.": "6 passengers.",
  "Un buen regreso.": "A good ride home.",
  "Abordaje simultáneo": "Simultaneous boarding",
  "Cada unidad registra a su grupo.": "Each vehicle checks in its own group.",
  "¿Primera vez en MOVE?": "First time on MOVE?",
  "Crear mi cuenta": "Create my account",
  "Volver al login": "Back to sign in",
  "TU ACCESO A MOVE": "YOUR ACCESS TO MOVE",
  "Cada viaje empieza aquí.": "Every journey starts here.",
  "Tu cuenta está lista.": "Your account is ready.",
  "Acceso corporativo con tu correo personal autorizado.":
    "Corporate access with your authorized personal email.",
  "Regístrate como conductor con tu correo personal.":
    "Register as a driver with your personal email.",
  Correo: "Email",
  Verificación: "Verification",
  "Tu cuenta": "Your account",
  "Tipo de registro": "Registration type",
  "Primero, tu correo.": "First, your email.",
  "Tu próximo recorrido empieza aquí.": "Your next journey starts here.",
  "Usa el correo personal que tu empresa autorizó. Si está en la lista, podrás verificarlo y crear tu contraseña.":
    "Use the personal email authorized by your company. If it is on the list, you can verify it and create your password.",
  "Puedes crear tu cuenta con cualquier correo personal válido. Después completarás tus datos y los del vehículo.":
    "Create your account with any valid personal email. You will then complete your personal and vehicle details.",
  "Correo personal": "Personal email",
  "Verificar mi correo": "Verify my email",
  "Correos autorizados para probar": "Authorized emails to try",
  "Whitelist de demostración: estos correos son ejemplos y no reciben mensajes.":
    "Demo whitelist: these emails are examples and do not receive messages.",
  "Verifica tu correo.": "Verify your email.",
  "Introduce el código de 6 dígitos para continuar.": "Enter the 6-digit code to continue.",
  "Código de verificación": "Verification code",
  "OTP de demostración": "Demo OTP",
  "No se envió un correo real. Este código vence en 5 minutos.":
    "No real email was sent. This code expires in 5 minutes.",
  "Validar código": "Verify code",
  "Reenviar código": "Resend code",
  "Cambiar correo": "Change email",
  "Correo verificado.": "Email verified.",
  "Crea tu cuenta de conductor.": "Create your driver account.",
  "Elige una contraseña para entrar a MOVE.": "Choose a password to sign in to MOVE.",
  "Tu nombre y apellido": "Your first and last name",
  "Nueva contraseña": "New password",
  "Al menos 8 caracteres": "At least 8 characters",
  "Una letra y un número": "A letter and a number",
  "Confirmar contraseña": "Confirm password",
  "Crear cuenta": "Create account",
  "Registro de demostración. Tus datos se guardan únicamente en este navegador.":
    "Demo registration. Your data is stored only in this browser.",
  "¡Bienvenido a MOVE!": "Welcome to MOVE!",
  "Tu cuenta de demostración fue creada.": "Your demo account has been created.",
  "Iniciar sesión con mi cuenta": "Sign in with my account",
  "Podrás usar el correo y la contraseña que acabas de crear en este dispositivo.":
    "You can use the email and password you just created on this device.",
  "Introduce un correo válido.": "Enter a valid email.",
  "Este correo ya tiene una cuenta en este navegador. Inicia sesión.":
    "This email already has an account in this browser. Sign in.",
  "Tu correo no está autorizado. Contacta a tu empresa para que lo agregue a la lista.":
    "Your email is not authorized. Contact your company to add it to the list.",
  "El código venció. Solicita uno nuevo.": "The code expired. Request a new one.",
  "Se agotaron los intentos. Solicita un nuevo código.":
    "No attempts remaining. Request a new code.",
  "Código incorrecto. Revisa los 6 dígitos.": "Incorrect code. Check all 6 digits.",
  "Espera 30 segundos antes de solicitar otro código.":
    "Wait 30 seconds before requesting another code.",
  "Nuevo código de demostración generado.": "A new demo code has been generated.",
  "Verifica primero tu correo autorizado.": "Verify your authorized email first.",
  "La contraseña debe tener al menos 8 caracteres, una letra y un número.":
    "Your password must contain at least 8 characters, a letter and a number.",
  "Las contraseñas no coinciden.": "Passwords do not match.",
  "Introduce tu nombre completo.": "Enter your full name.",
  "No pudimos guardar la cuenta en este navegador. Inténtalo de nuevo.":
    "We could not save the account in this browser. Try again.",
  "No pudimos crear la cuenta. Inténtalo de nuevo.": "We could not create the account. Try again.",
  "Correo o contraseña incorrectos.": "Incorrect email or password.",
  "Selecciona el tipo de acceso de tu cuenta.": "Select the access type for your account.",
});
const translateBeforePolish = t;
t = function (value) {
  if (interfaceLanguage === "en") {
    if (/^© \d{4} MOVE · Demostración del producto$/.test(value))
      return value.replace("Demostración del producto", "Product demonstration");
    if (value === "UNIDAD 12 · ZONA 04") return "VEHICLE 12 · ZONE 04";
    if (value === "Ruta 04 · 22:30 · Asiento confirmado")
      return "Route 04 · 22:30 · Seat confirmed";
  }
  return translateBeforePolish(value);
};
let lastNavIndex = 0,
  lastNavCount = 0,
  revealObserver = null;
function decorateNavigation() {
  const bar = document.querySelector(".bottom-nav");
  if (bar.hidden) return;
  const links = [...bar.querySelectorAll(".nav-item")];
  if (!links.length) return;
  const index = Math.max(
    0,
    links.findIndex((link) => link.classList.contains("active")),
  );
  bar.style.setProperty("--nav-count", links.length);
  bar.style.setProperty("--nav-index", index);
  bar.style.setProperty("--nav-from", lastNavCount === links.length ? lastNavIndex : index);
  const track = document.createElement("span");
  track.className = "nav-indicator";
  track.setAttribute("aria-hidden", "true");
  bar.querySelector(".nav-indicator")?.remove();
  bar.append(track);
  lastNavIndex = index;
  lastNavCount = links.length;
  bar.classList.add("move-nav");
}
function decorateLanding() {
  if (page !== "landing") return;
  const nav = document.getElementById("landingMenu");
  const picker = document.createElement("select");
  picker.className = "landing-language";
  picker.setAttribute("aria-label", t("Idioma"));
  picker.innerHTML = htmlTemplate("components/shared/decorate-landing.html");
  picker.onchange = () => setInterfaceLanguage(picker.value);
  nav?.append(picker);
  const footer = document.querySelector(".landing-footer");
  const footerPicker = picker.cloneNode(true);
  footerPicker.onchange = () => setInterfaceLanguage(footerPicker.value);
  footer?.append(footerPicker);
  revealObserver?.disconnect();
  const reduced = window.matchMedia?.("(prefers-reduced-motion: reduce)").matches;
  if (!reduced && typeof IntersectionObserver !== "undefined") {
    revealObserver = new IntersectionObserver(
      (entries) => {
        entries.forEach((e) => {
          if (e.isIntersecting) {
            e.target.classList.add("is-revealed");
            revealObserver.unobserve(e.target);
          }
        });
      },
      { threshold: 0.08 },
    );
    document
      .querySelectorAll(
        ".marketing .section-intro,.marketing .benefit-grid article,.marketing .flow-grid article,.marketing .data-bottom,.marketing .calculator-section,.marketing .capability-grid article,.marketing .faq-section",
      )
      .forEach((node, i) => {
        node.classList.add("soft-reveal");
        node.style.setProperty("--reveal-delay", (i % 3) * 65 + "ms");
        revealObserver.observe(node);
      });
  }
}
const languageBeforePolish = setInterfaceLanguage;
setInterfaceLanguage = function (lang) {
  languageBeforePolish(lang);
  document
    .querySelectorAll(".landing-language")
    .forEach((select) => (select.value = interfaceLanguage));
};
const renderBeforePolish = render;
render = function () {
  if (location.hash.slice(1) === "register") {
    page = "register";
    document.body.classList.remove("landing-screen");
    document.body.classList.add("registration-screen");
    document.getElementById("landingMenu")?.remove();
    drawWorkspace(registrationView(), []);
    updateAccountControls();
    bindRegistration();
    translateInterface();
  } else {
    renderBeforePolish();
    decorateNavigation();
    decorateLanding();
    translateInterface();
  }
};
render();
