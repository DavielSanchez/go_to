const paths = {
  home: "M3 10l9-7 9 7v10a1 1 0 0 1-1 1h-5v-7H9v7H4a1 1 0 0 1-1-1z",
  bus: "M5 16V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2v11M5 11h14M8 3v8m8-8v8M5 16h14v3H5zM7 19v3m10-3v3M8 14h.01M16 14h.01",
  ticket: "M3 7h18v4a2 2 0 0 0 0 4v4H3v-4a2 2 0 0 0 0-4zM15 7v2m0 3v2m0 3v2",
  clock: "M12 8v5l3 2M22 12a10 10 0 1 1-20 0 10 10 0 0 1 20 0",
  user: "M20 21v-2a6 6 0 0 0-6-6h-4a6 6 0 0 0-6 6v2M16 6a4 4 0 1 1-8 0 4 4 0 0 1 8 0",
  pin: "M20 10c0 6-8 12-8 12S4 16 4 10a8 8 0 1 1 16 0M15 10a3 3 0 1 1-6 0 3 3 0 0 1 6 0",
  check: "M5 12l4 4L19 6",
  chevron: "M9 5l7 7-7 7",
  back: "M15 5l-7 7 7 7",
  shield: "M12 3l8 3v6c0 5-8 9-8 9s-8-4-8-9V6zM8 12l3 3 5-6",
  info: "M12 11v6m0-10v.01M22 12a10 10 0 1 1-20 0 10 10 0 0 1 20 0",
  phone: "M5 3h4l2 5-3 2c2 3 3 4 6 6l2-3 5 2v4c-8 5-22-9-16-16",
  chat: "M21 11a9 9 0 0 1-9 9H4l-3 2 2-6a9 9 0 1 1 18-5M7 11h10",
  star: "M12 3l3 6 7 1-5 5 1 7-6-3-6 3 1-7-5-5 7-1z",
};
const icon = (n) => htmlTemplate("components/employee/fragment.html");
let state = {
  confirmed: false,
  declined: false,
  exception: false,
  completed: false,
  reviewed: false,
  rating: 0,
  tags: [],
  eligible: true,
  address: "Entrada de Pantoja · Los Alcarrizos",
  addressChanges: 0,
  pendingAddress: "",
};
try {
  state = { ...state, ...JSON.parse(sessionStorage.getItem("move-demo") || "{}") };
} catch {}
let page = "home";
const app = document.getElementById("app");
const navs = [
  ["home", "home", "Inicio"],
  ["trip", "bus", "Mi viaje"],
  ["exception", "ticket", "Excepciones"],
  ["history", "clock", "Historial"],
  ["profile", "user", "Perfil"],
];
function save() {
  try {
    sessionStorage.setItem("move-demo", JSON.stringify(state));
  } catch {}
}
function toast(s) {
  document.getElementById("toast").textContent = s;
  document.getElementById("toast").classList.add("visible");
  setTimeout(() => document.getElementById("toast").classList.remove("visible"), 3200);
}
function navigate(p) {
  location.hash = p;
}
function pageHeading(title, sub = "", extra = "") {
  return htmlTemplate("components/employee/page-heading.html");
}
function route() {
  return htmlTemplate("components/employee/route.html");
}
function demo() {
  return htmlTemplate("components/employee/demo.html");
}
function render() {
  page = location.hash.slice(1) || "home";
  if (
    !["home", "trip", "exception", "history", "profile", "review", "address", "ticket"].includes(
      page,
    )
  )
    page = "home";
  const nav = navs.map(([p, i, l]) => htmlTemplate("components/employee/render.html")).join("");
  document.querySelector(".bottom-nav").innerHTML = nav;
  document.querySelector(".side-nav").innerHTML = nav;
  app.innerHTML = views[page]();
  window.scrollTo(0, 0);
  bind();
}
const views = {
  home: () => htmlTemplate("screens/employee/home.html"),
  exception: () => htmlTemplate("components/employee/exception-original.html"),
  trip: () => htmlTemplate("screens/employee/trip.html"),
  review: () => htmlTemplate("screens/employee/review.html"),
  history: () => htmlTemplate("screens/employee/history.html"),
  profile: () => htmlTemplate("components/employee/profile-original.html"),
};
function historyRow(date, time, rating, link = false) {
  return htmlTemplate("components/employee/history-row.html");
}
function escapeHTML(s) {
  return String(s).replace(
    /[&<>"']/g,
    (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c],
  );
}
function confirmRide() {
  if (!state.eligible) {
    toast("Solicita una excepción para usar transporte hoy.");
    navigate("exception");
    return;
  }
  if (!state.addressPoint) {
    navigate("address");
    toast("Agrega tu dirección antes de confirmar.");
    return;
  }
  state.confirmed = true;
  state.declined = false;
  save();
  render();
  toast("Tu transporte para hoy está confirmado.");
}
function cancelRide() {
  state.confirmed = false;
  save();
  render();
  toast("Confirmación cancelada. Puedes volver a reservar.");
}
function declineRide() {
  state.declined = true;
  save();
  render();
  toast("Registramos que hoy no usarás transporte.");
}
function finishTrip() {
  state.completed = true;
  save();
  navigate("review");
}
function setRating(n) {
  state.comment = document.getElementById("comment")?.value || "";
  state.rating = n;
  save();
  render();
}
function toggleTag(t) {
  state.comment = document.getElementById("comment")?.value || "";
  state.tags = state.tags.includes(t) ? state.tags.filter((x) => x !== t) : [...state.tags, t];
  save();
  render();
}
function submitReview() {
  if (!state.rating) return;
  state.comment = document.getElementById("comment").value;
  state.reviewed = true;
  save();
  render();
}
function resetDemo() {
  sessionStorage.removeItem("move-demo");
  location.reload();
}
function bind() {
  document.getElementById("exceptionForm")?.addEventListener("submit", (e) => {
    e.preventDefault();
    const f = new FormData(e.target);
    state.exception = true;
    state.reason = f.get("reason");
    state.requestTime = f.get("time");
    save();
    render();
    toast("Solicitud enviada para revisión.");
  });
}
window.addEventListener("hashchange", () => render());
render();
if ("serviceWorker" in navigator) navigator.serviceWorker.register("./sw.js").catch(() => {});
if (document.modelContext?.registerTool) {
  Promise.resolve(
    document.modelContext.registerTool({
      name: "confirm_demo_transport",
      description: "Confirma el transporte diario en el prototipo MOVE con datos de demostración.",
      inputSchema: { type: "object", properties: {}, additionalProperties: false },
      annotations: { readOnlyHint: false },
      execute(input) {
        if (!input || typeof input !== "object" || Object.keys(input).length)
          throw new Error("Se espera un objeto vacío");
        confirmRide();
        return { confirmed: state.confirmed };
      },
    }),
  ).catch(() => {});
}

// Employee UI variations: session-only demonstration, no live approvals.
let theme = "light";
try {
  theme =
    localStorage.getItem("move-theme") ||
    (matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light");
} catch {}
function applyTheme() {
  document.documentElement.dataset.theme = theme;
  document.querySelector('meta[name="theme-color"]').content =
    theme === "dark" ? "#121216" : "#ff005c";
  const b = document.getElementById("themeToggle");
  if (b) {
    b.innerHTML = icon(theme === "dark" ? "sun" : "moon");
    b.setAttribute("aria-label", theme === "dark" ? "Activar modo claro" : "Activar modo oscuro");
    b.setAttribute("aria-pressed", String(theme === "dark"));
  }
}
function toggleTheme() {
  theme = theme === "dark" ? "light" : "dark";
  try {
    localStorage.setItem("move-theme", theme);
  } catch {}
  applyTheme();
}
const themeButton = document.createElement("button");
themeButton.id = "themeToggle";
themeButton.className = "theme-toggle";
themeButton.onclick = toggleTheme;
document.querySelector(".header-right").prepend(themeButton);
applyTheme();
function addressSummary() {
  return htmlTemplate("components/employee/address-summary.html");
}
const originalHome = views.home;
views.home = () => {
  if (state.eligible && state.address)
    return originalHome().replace(
      htmlTemplate("components/employee/home-address-match-start.html") +
        icon("pin") +
        htmlTemplate("components/employee/home-address-match-end.html"),
      addressSummary(),
    );
  return htmlTemplate("screens/employee/home-unavailable.html");
};
const originalTrip = views.trip;
views.trip = () => {
  if (!state.eligible || !state.address)
    return htmlTemplate("screens/employee/trip-unavailable.html");
  return originalTrip().replaceAll(
    "Entrada de Pantoja · Los Alcarrizos",
    escapeHTML(state.address),
  );
};
views.profile = () => htmlTemplate("screens/employee/profile.html");
views.address = () => htmlTemplate("components/employee/address-original.html");
function setScenario(value) {
  state.confirmed = false;
  state.declined = false;
  state.completed = false;
  state.exception = false;
  state.pendingAddress = "";
  state.eligible = value !== "ineligible";
  state.address = value === "missing" ? "" : "Entrada de Pantoja · Los Alcarrizos";
  state.addressChanges = value === "fourth" ? 3 : value === "third" ? 2 : 0;
  save();
  navigate("home");
  render();
}
function withdrawAddress() {
  state.pendingAddress = "";
  save();
  render();
  toast("Solicitud retirada. Conservamos tu dirección vigente.");
}
const originalBind = bind;
bind = function () {
  originalBind();
  document.getElementById("addressForm")?.addEventListener("submit", (e) => {
    e.preventDefault();
    const destination = new FormData(e.target).get("destination").trim();
    if (destination.length < 10) {
      toast("Incluye una dirección de al menos 10 caracteres.");
      return;
    }
    if (destination === state.address) {
      toast("La dirección coincide con la que tienes registrada.");
      return;
    }
    if (state.address && state.addressChanges >= 3) {
      state.pendingAddress = destination;
      save();
      render();
      toast("Cambio enviado para aprobación del equipo de transporte.");
      return;
    }
    if (state.address) state.addressChanges++;
    state.address = destination;
    save();
    navigate("home");
    render();
    toast("Dirección guardada. Tu destino está actualizado.");
  });
};
render();

paths.sun =
  "M12 2v2m0 16v2M2 12h2m16 0h2M5 5l1.4 1.4m11.2 11.2L19 19M5 19l1.4-1.4M17.6 6.4L19 5M16 12a4 4 0 1 1-8 0 4 4 0 0 1 8 0";
paths.moon = "M21 13A9 9 0 1 1 11 3a7 7 0 0 0 10 10";
function today() {
  return new Intl.DateTimeFormat("en-CA", {
    timeZone: "America/Santo_Domingo",
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
  }).format(new Date());
}
function dateLabel(d) {
  return new Intl.DateTimeFormat("es-DO", { dateStyle: "long" }).format(new Date(d + "T12:00:00"));
}
function pointLabel(p) {
  return p ? `${Number(p.lat).toFixed(5)}, ${Number(p.lng).toFixed(5)}` : "";
}
if (state.address && !state.addressPoint) state.addressPoint = { lat: 18.527, lng: -70.003 };
let pickedPoint = null,
  addressMap = null,
  addressMarker = null;
function addressSummary() {
  return htmlTemplate("components/employee/address-summary-part-03.html");
}
views.address = () => htmlTemplate("screens/employee/address.html");
function setPin(lat, lng) {
  pickedPoint = { lat, lng };
  if (addressMap) {
    if (!addressMarker) {
      addressMarker = L.marker([lat, lng], {
        draggable: true,
        icon: L.divIcon({
          className: "destination-pin",
          html: icon("pin"),
          iconSize: [36, 42],
          iconAnchor: [18, 40],
        }),
      }).addTo(addressMap);
      addressMarker.on("dragend", () => {
        const p = addressMarker.getLatLng();
        setPin(p.lat, p.lng);
      });
    } else addressMarker.setLatLng([lat, lng]);
  }
  document.getElementById("pinStatus").textContent =
    "Destino seleccionado: " + pointLabel(pickedPoint);
  document.getElementById("savePin").disabled = false;
}
function useGPS() {
  if (!navigator.geolocation) {
    toast("Este dispositivo no ofrece ubicación GPS. Coloca el pin en el mapa.");
    return;
  }
  const b = document.getElementById("gpsButton");
  b.disabled = true;
  b.textContent = "Buscando tu ubicación…";
  navigator.geolocation.getCurrentPosition(
    (pos) => {
      if (page !== "address") return;
      b.disabled = false;
      b.innerHTML = icon("pin") + "Usar mi ubicación actual";
      setPin(pos.coords.latitude, pos.coords.longitude);
      addressMap?.setView([pickedPoint.lat, pickedPoint.lng], 17);
      toast("Ubicación encontrada. Ajusta el pin si hace falta.");
    },
    (err) => {
      if (page !== "address") return;
      b.disabled = false;
      b.innerHTML = icon("pin") + "Usar mi ubicación actual";
      toast(
        err.code === 1
          ? "Permite el acceso a tu ubicación o selecciona el destino en el mapa."
          : "No pudimos obtener tu ubicación. Selecciona el destino en el mapa.",
      );
    },
    { enableHighAccuracy: true, timeout: 12000, maximumAge: 30000 },
  );
}
const bindBeforePin = bind;
bind = function () {
  bindBeforePin();
  const f = document.getElementById("pinAddressForm");
  if (!f) return;
  pickedPoint = null;
  addressMap = null;
  addressMarker = null;
  const center = state.addressPoint || { lat: 18.4861, lng: -69.9312 };
  if (typeof L !== "undefined") {
    addressMap = L.map("destinationMap").setView([center.lat, center.lng], 14);
    L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
      attribution: htmlTemplate("components/employee/fragment-part-02.html"),
      maxZoom: 19,
    }).addTo(addressMap);
    addressMap.on("click", (e) => setPin(e.latlng.lat, e.latlng.lng));
    document.getElementById("destinationMap").addEventListener("keydown", (e) => {
      if (e.key === "Enter") {
        e.preventDefault();
        const c = addressMap.getCenter();
        setPin(c.lat, c.lng);
      }
    });
    if (state.addressPoint) setPin(center.lat, center.lng);
  } else
    document.getElementById("pinStatus").textContent =
      "No se pudo cargar el mapa. Recarga para volver a intentarlo.";
  f.addEventListener("submit", (e) => {
    e.preventDefault();
    if (!pickedPoint) {
      toast("Selecciona tu destino en el mapa.");
      return;
    }
    const text = new FormData(f).get("destination").trim();
    const samePoint =
      state.addressPoint &&
      Math.abs(pickedPoint.lat - state.addressPoint.lat) < 0.000001 &&
      Math.abs(pickedPoint.lng - state.addressPoint.lng) < 0.000001;
    if (samePoint && text === state.address) {
      toast("Tu destino no ha cambiado.");
      return;
    }
    const label = text || "Destino marcado en el mapa";
    if (state.addressPoint && state.addressChanges >= 3) {
      state.pendingAddress = label;
      state.pendingAddressPoint = { ...pickedPoint };
      save();
      render();
      toast("Cambio enviado para aprobación.");
      return;
    }
    if (state.addressPoint) state.addressChanges++;
    state.address = label;
    state.addressPoint = { ...pickedPoint };
    save();
    navigate("home");
    render();
    toast("Destino guardado.");
  });
};
const oldScenario = setScenario;
setScenario = function (v) {
  oldScenario(v);
  state.addressPoint = v === "missing" ? null : { lat: 18.527, lng: -70.003 };
  state.pendingAddressPoint = null;
  state.ticket = null;
  state.exceptionStatus = null;
  save();
  render();
};
function issueTicket(date, time, source) {
  state.ticket = {
    id: crypto.randomUUID(),
    date,
    time,
    source,
    vehicle: "12",
    employee: "104582",
    status: "valid",
  };
  save();
}
const beforeTicketConfirm = confirmRide;
confirmRide = function () {
  beforeTicketConfirm();
  if (state.confirmed) {
    issueTicket(today(), "22:30", "daily");
    navigate("ticket");
    render();
  }
};
const beforeTicketCancel = cancelRide;
cancelRide = function () {
  beforeTicketCancel();
  state.ticket = null;
  save();
  render();
};
function ticketValid() {
  return (
    state.ticket &&
    state.ticket.status === "valid" &&
    (state.ticket.source === "exception"
      ? state.exceptionStatus === "approved"
      : state.confirmed) &&
    !!state.addressPoint
  );
}
function qrMarkup() {
  if (typeof qrcode === "undefined") return htmlTemplate("components/employee/qr-markup.html");
  const qr = qrcode(0, "M");
  qr.addData(JSON.stringify({ type: "MOVE-DEMO", ticket: state.ticket.id }));
  qr.make();
  return qr.createSvgTag({ cellSize: 6, margin: 4, scalable: true });
}
function ticketCard() {
  return htmlTemplate("components/employee/ticket-card.html");
}
const homeBeforeQR = views.home;
views.home = () => {
  let html = homeBeforeQR();
  html = html.replace("VIERNES, 2 DE OCTUBRE", dateLabel(today()).toUpperCase());
  if (ticketValid()) html = ticketCard() + html;
  return html;
};
const tripBeforeQR = views.trip;
views.trip = () => (ticketValid() ? ticketCard() : "") + tripBeforeQR();
views.ticket = () => htmlTemplate("screens/employee/ticket.html");
function validateTicket(t, scan) {
  if (!ticketValid() || scan.revoked)
    return {
      kind: "error",
      title: "Ticket sin autorización",
      text: "No se puede abordar. Verifica la confirmación o aprobación con transporte.",
    };
  if (scan.date !== t.date)
    return {
      kind: "error",
      title: "Fecha incorrecta",
      text: "Tu ticket corresponde al " + dateLabel(t.date) + ".",
    };
  if (scan.vehicle !== t.vehicle)
    return {
      kind: "error",
      title: "Vehículo incorrecto",
      text: "Tu ticket corresponde a la Unidad " + t.vehicle + ". Dirígete al vehículo asignado.",
    };
  if (scan.time !== t.time)
    return {
      kind: "warning",
      title: "Horario incorrecto",
      text: "Tu salida asignada es a las " + t.time + ". Consulta con transporte antes de abordar.",
    };
  return {
    kind: "success",
    title: "Abordaje autorizado",
    text: "Ticket válido. Fecha, vehículo y horario coinciden.",
  };
}
function simulateScan(mode) {
  const t = state.ticket;
  const result = validateTicket(t, {
    date: mode === "date" ? "2020-01-01" : t.date,
    vehicle: mode === "vehicle" ? "08" : t.vehicle,
    time: mode === "time" ? "21:15" : t.time,
    revoked: mode === "revoked",
  });
  document.getElementById("scanResult").innerHTML = htmlTemplate(
    "components/employee/simulate-scan.html",
  );
}
views.exception = () => htmlTemplate("screens/employee/exception.html");
const bindWithMap = bind;
bind = function () {
  bindWithMap();
  document.getElementById("datedExceptionForm")?.addEventListener("submit", (e) => {
    e.preventDefault();
    const f = new FormData(e.target);
    if (f.get("date") < today()) {
      toast("Selecciona hoy o una fecha futura.");
      return;
    }
    state.exception = true;
    state.exceptionStatus = "pending";
    state.reason = f.get("reason");
    state.requestTime = f.get("time");
    state.requestDate = f.get("date");
    save();
    render();
    toast("Solicitud enviada para revisión.");
  });
};
function approveExceptionDemo() {
  state.exceptionStatus = "approved";
  if (state.addressPoint)
    issueTicket(state.requestDate || today(), state.requestTime || "22:30", "exception");
  save();
  render();
  toast("Demo: excepción aprobada y salida asignada.");
}
function newException() {
  state.exception = false;
  save();
  render();
}
const bindBeforeApprovedAddress = bind;
bind = function () {
  bindBeforeApprovedAddress();
  document.getElementById("pinAddressForm")?.addEventListener("submit", () => {
    if (state.exceptionStatus === "approved" && state.addressPoint && !state.ticket) {
      issueTicket(state.requestDate || today(), state.requestTime || "22:30", "exception");
      save();
      navigate("ticket");
      render();
    }
  });
};
if (state.confirmed && !state.ticket && state.addressPoint) issueTicket(today(), "22:30", "daily");
applyTheme();
save();
render();

const homeWithTicket = views.home;
views.home = () => {
  if (
    ticketValid() &&
    state.ticket.source === "exception" &&
    state.ticket.date === today() &&
    !state.eligible
  )
    return htmlTemplate("screens/employee/home-approved-exception.html");
  return homeWithTicket();
};
const tripWithTicket = views.trip;
views.trip = () => {
  if (ticketValid() && state.ticket.source === "exception") {
    if (state.ticket.date !== today()) return htmlTemplate("screens/employee/trip-scheduled.html");
    return ticketCard() + originalTrip();
  }
  return tripWithTicket();
};
render();
