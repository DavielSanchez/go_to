// Driver and shared-access UI. All operational records are demonstration data.
let access = { logged: false, role: "corporate" },
  driver = {
    onboarded: false,
    profile: {},
    photos: {},
    stage: "arrival",
    boarded: [],
    incidents: [],
    history: [],
    stop: 0,
  };
try {
  access = { ...access, ...JSON.parse(sessionStorage.getItem("move-access") || "{}") };
  driver = { ...driver, ...JSON.parse(sessionStorage.getItem("move-driver") || "{}") };
} catch {}
let uploadPreviews = {},
  onboardStep = 1,
  onboardDraft = { ...driver.profile },
  scanStream = null,
  scanFrame = null,
  scannerKind = "",
  scanMessage = null,
  routeAbort = null,
  driverMap = null;
const driverNav = [
  ["driver-home", "home", "Inicio"],
  ["driver-route", "pin", "Ruta"],
  ["driver-board", "ticket", "Abordaje"],
  ["driver-incident", "info", "Incidencias"],
  ["driver-history", "clock", "Historial"],
  ["driver-profile", "user", "Perfil"],
];
const basePassengers = [
  { id: "104582", name: "Daviel Sánchez", stop: 2 },
  { id: "104601", name: "Ana Pérez", stop: 0 },
  { id: "104612", name: "Carlos Mejía", stop: 0 },
  { id: "104630", name: "Laura Díaz", stop: 1 },
  { id: "104644", name: "Miguel Santos", stop: 1 },
  { id: "104657", name: "Sofía Rodríguez", stop: 2 },
];
const zonePool = [
  ...Array.from({ length: 12 }, (_, i) => ({
    id: String(105000 + i),
    name:
      [
        "Pedro",
        "María",
        "Luis",
        "Elena",
        "Juan",
        "Diana",
        "Raúl",
        "Rosa",
        "Daniel",
        "Patricia",
        "Andrés",
        "Carmen",
      ][i] + " · Demo",
    stop: i % 3,
  })),
  ...basePassengers,
];
const zoneVehicles = [
  { unit: "10", order: 1, capacity: 6 },
  { unit: "11", order: 2, capacity: 6 },
  { unit: "12", order: 3, capacity: 6 },
];
function distributePassengers(pool, vehicles) {
  let offset = 0;
  return [...vehicles]
    .sort((a, b) => a.order - b.order)
    .map((v) => {
      const assigned = pool.slice(offset, offset + v.capacity);
      offset += assigned.length;
      return { ...v, passengers: assigned };
    });
}
const zoneAssignments = distributePassengers(zonePool, zoneVehicles);
const passengers = zoneAssignments.find((v) => v.unit === "12").passengers;
let otherBoarded = {};
try {
  otherBoarded = JSON.parse(sessionStorage.getItem("move-zone-boarding") || "{}");
} catch {}
if (driver.stage === "waiting") {
  driver.stage = "assigned";
  driver.tripDate = driver.tripDate || today();
  saveDriver();
}

const stops = [
  { name: "Los Girasoles", point: [18.517, -69.968] },
  { name: "Ciudad Real", point: [18.522, -69.984] },
  { name: "Entrada de Pantoja", point: [18.527, -70.003] },
];
function saveDriver() {
  try {
    sessionStorage.setItem("move-access", JSON.stringify(access));
    sessionStorage.setItem("move-driver", JSON.stringify(driver));
  } catch {}
}
function switchRole(role) {
  if (page !== "login" || !["corporate", "driver"].includes(role)) return;
  stopScanner();
  access.logged = false;
  access.role = role;
  saveDriver();
  navigate("login");
  render();
}
function logoutMove() {
  access.logged = false;
  saveDriver();
  navigate("login");
  render();
}
const employeeRender = render;
function setNavigation(links) {
  const bottom = document.querySelector(".bottom-nav");
  bottom.innerHTML = links;
  bottom.hidden = !links;
  bottom.style.removeProperty("display");
  document.body.classList.toggle("login-screen", !access.logged);
  document.querySelector(".side-nav").innerHTML =
    links + (access.logged ? htmlTemplate("components/driver/set-navigation.html") : "");
}
function syncHeader() {
  document.getElementById("topRole")?.remove();
  document.getElementById("roleSelectorCorporate")?.remove();
  const avatar = document.querySelector("header .avatar");
  avatar.textContent = access.role === "driver" ? "JR" : "DS";
  avatar.onclick = () => {
    if (access.logged) navigate(access.role === "driver" ? "driver-profile" : "profile");
  };
  document.querySelector(".side-bottom").innerHTML = htmlTemplate(
    "components/driver/sync-header.html",
  );
}
render = function () {
  stopScanner();
  routeAbort?.abort();
  const requested = location.hash.slice(1) || "home";
  const driverPage = requested.startsWith("driver-");
  syncHeader();
  if (!access.logged || requested === "login") {
    page = "login";
    drawWorkspace(loginView(), []);
    bindLogin();
    return;
  }
  if (access.role === "driver") {
    page = driver.onboarded
      ? driverPage && driverViews[requested]
        ? requested
        : "driver-home"
      : "driver-onboarding";
    drawWorkspace(page === "driver-onboarding" ? onboardingView() : driverViews[page](), driverNav);
    bindDriver();
    return;
  }
  employeeRender();
  const bottom = document.querySelector(".bottom-nav");
  document.body.classList.remove("login-screen");
  bottom.hidden = false;
  bottom.style.removeProperty("display");
  document
    .querySelector(".side-nav")
    .insertAdjacentHTML("beforeend", htmlTemplate("components/driver/fragment.html"));
  const profile = document.querySelector(".profile-wrap");
  if (profile)
    profile.insertAdjacentHTML(
      "beforeend",
      htmlTemplate("components/driver/fragment-part-02.html"),
    );
};
function drawWorkspace(html, nav) {
  app.innerHTML = html;
  const links = nav
    .map(([p, i, l]) => htmlTemplate("components/driver/draw-workspace.html"))
    .join("");
  setNavigation(links);
  window.scrollTo(0, 0);
}
function loginView() {
  return htmlTemplate("screens/auth/login.html");
}
function bindLogin() {
  document.getElementById("sharedLogin")?.addEventListener("submit", (e) => {
    e.preventDefault();
    access.logged = true;
    saveDriver();
    navigate(
      access.role === "driver" ? (driver.onboarded ? "driver-home" : "driver-onboarding") : "home",
    );
    render();
  });
}
function field(name, label, type = "text", extra = "") {
  return htmlTemplate("components/driver/field.html");
}
function photoField(key, label) {
  return htmlTemplate("components/driver/photo-field.html");
}
function onboardingView() {
  return htmlTemplate("screens/driver/onboarding.html");
}
function backOnboarding() {
  stashOnboarding();
  onboardStep--;
  render();
}
function stashOnboarding() {
  const f = document.getElementById("driverOnboarding");
  if (f) for (const [k, v] of new FormData(f)) onboardDraft[k] = v;
}
function setPhoto(input) {
  const file = input.files?.[0];
  if (!file) return;
  if (!file.type.startsWith("image/")) {
    toast("Selecciona una imagen.");
    return;
  }
  if (file.size > 12 * 1024 * 1024) {
    toast("La foto debe pesar menos de 12 MB.");
    return;
  }
  const k = input.dataset.photo;
  if (uploadPreviews[k]) URL.revokeObjectURL(uploadPreviews[k]);
  uploadPreviews[k] = URL.createObjectURL(file);
  driver.photos[k] = { name: file.name };
  const p = document.getElementById("preview-" + k);
  p.innerHTML = htmlTemplate("components/driver/set-photo.html");
  saveDriver();
}
function driverBanner() {
  return htmlTemplate("components/driver/driver-banner.html");
}
function demoRouteCatalog() {
  const tenant = access.tenant || "tp";
  return ["21:30", "22:30", "23:30", "00:30"].map((time) => {
    let date = today();
    if (time === "00:30") {
      const d = new Date(date + "T12:00:00Z");
      d.setUTCDate(d.getUTCDate() + 1);
      date = d.toISOString().slice(0, 10);
    }
    return {
      type: "MOVE-ROUTE-DEMO",
      routeId: `${tenant}-04-${date}-${time.replace(":", "")}`,
      tenant,
      zone: "04",
      route: "04",
      date,
      time,
    };
  });
}
function routeQR(route) {
  if (typeof qrcode === "undefined") return "";
  const qr = qrcode(0, "M");
  qr.addData(JSON.stringify(route));
  qr.make();
  return qr.createSvgTag({ cellSize: 5, margin: 4, scalable: true });
}
function resolveDemoRoute(data) {
  if (!data || data.type !== "MOVE-ROUTE-DEMO") return null;
  return (
    demoRouteCatalog().find((r) =>
      ["type", "routeId", "tenant", "zone", "route", "date", "time"].every((k) => r[k] === data[k]),
    ) || null
  );
}
function zoneCard() {
  return htmlTemplate("components/driver/zone-card.html");
}
function simulateRouteScan(id) {
  const route = demoRouteCatalog().find((r) => r.routeId === id);
  if (!route) return;
  scannerKind = "zone";
  handleQRCode(JSON.stringify(route));
}
function routeStops() {
  return htmlTemplate("components/driver/route-stops.html");
}
function assignmentCard() {
  return htmlTemplate("components/driver/assignment-card.html");
}
const driverViews = {
  "driver-home": () => htmlTemplate("screens/driver/home.html"),
  "driver-board": () =>
    `${pageHeading("Abordaje", "Valida el ticket de cada empleado antes de darle entrada.")}${!["assigned", "boarding"].includes(driver.stage) ? emptyDriver("El abordaje aún no está abierto", "Escanea el QR de tu ruta para recibir los pasajeros de esa salida.") : htmlTemplate("screens/driver/board.html")}${demo()}`,
  "driver-route": () =>
    `${pageHeading(driver.stage === "active" || driver.stage === "paused" ? "En ruta" : "Mi ruta", "Zona 04 · Los Alcarrizos")}${driver.stage === "arrival" ? emptyDriver("Aún no tienes una ruta asignada", "Escanea el QR de la zona para recibir tus pasajeros.") : htmlTemplate("screens/driver/route.html")}${demo()}`,
  "driver-incident": () => htmlTemplate("screens/driver/incident.html"),
  "driver-history": () => htmlTemplate("screens/driver/history.html"),
  "driver-profile": () => htmlTemplate("screens/driver/profile.html"),
};
function emptyDriver(title, sub) {
  return htmlTemplate("components/driver/empty-driver.html");
}
function joinZone(routeId) {
  const route = demoRouteCatalog().find((r) => r.routeId === routeId);
  if (!route) {
    toast(t("QR de ruta no válido. Revisa la fecha y la salida con tu proveedor."));
    return false;
  }
  if (driver.stage !== "arrival") {
    toast(t("Ya tienes una ruta asignada. Su hora no se puede cambiar."));
    return false;
  }
  driver.stage = "assigned";
  driver.arrivedAt = new Date().toISOString();
  driver.routeId = route.routeId;
  driver.departureTime = route.time;
  driver.tripDate = route.date;
  driver.boarded = [];
  driver.stop = 0;
  scanMessage = null;
  otherBoarded = {};
  try {
    sessionStorage.setItem("move-zone-boarding", "{}");
  } catch {}
  saveDriver();
  navigate("driver-home");
  render();
  toast(t("Ruta asignada. La hora de salida queda fijada por su QR."));
  return true;
}
function zoneDistributionCard() {
  return htmlTemplate("components/driver/zone-distribution-card.html");
}
function scanOtherVehicle(unit) {
  const assigned = zoneAssignments.find((v) => v.unit === unit);
  if (!assigned || unit === "12") return;
  const ids = otherBoarded[unit] || [];
  const next = assigned.passengers.find((p) => !ids.includes(p.id));
  if (!next) {
    toast("Todos los pasajeros de esta unidad abordaron.");
    return;
  }
  otherBoarded[unit] = [...ids, next.id];
  try {
    sessionStorage.setItem("move-zone-boarding", JSON.stringify(otherBoarded));
  } catch {}
  render();
  toast("Unidad " + unit + ": pasajero registrado. Tu abordaje sigue disponible.");
}
function checkBoarding(t) {
  if (!["assigned", "boarding"].includes(driver.stage))
    return {
      kind: "error",
      title: "Abordaje cerrado",
      text: "Recibe una ruta y abre el abordaje antes de escanear.",
    };
  if (!t || !t.authorized)
    return {
      kind: "error",
      title: "Ticket sin autorización",
      text: "El empleado debe confirmar el transporte o recibir aprobación.",
    };
  if (t.date !== driver.tripDate)
    return {
      kind: "error",
      title: "Fecha incorrecta",
      text: "Este vehículo opera el " + dateLabel(driver.tripDate) + ".",
    };
  if (t.vehicle !== "12")
    return {
      kind: "error",
      title: "Vehículo incorrecto",
      text: "El ticket corresponde a otra unidad. No se registra el abordaje.",
    };
  if (t.time !== (driver.departureTime || "22:30"))
    return {
      kind: "warning",
      title: "Horario incorrecto",
      text:
        "Esta salida es a las " +
        (driver.departureTime || "22:30") +
        ". Transporte debe resolver la diferencia antes de abordar.",
    };
  if (!passengers.some((p) => p.id === t.employee))
    return {
      kind: "error",
      title: "Empleado no asignado",
      text: "El empleado no está en el listado de esta ruta.",
    };
  if (driver.boarded.includes(t.employee))
    return {
      kind: "warning",
      title: "Ticket ya utilizado",
      text: "Este empleado ya está registrado a bordo.",
    };
  return {
    kind: "success",
    title: "Abordaje autorizado",
    text: passengers.find((p) => p.id === t.employee).name + " puede abordar la Unidad 12.",
  };
}
function boardTicket(t) {
  const result = checkBoarding(t);
  if (result.kind === "success") {
    driver.boarded.push(t.employee);
    driver.stage = "boarding";
    saveDriver();
  }
  scanMessage = result;
  return result;
}
function demoBoard(mode) {
  const employee = passengers.find((p) => !driver.boarded.includes(p.id))?.id || passengers[0].id;
  boardTicket({
    employee,
    authorized: mode !== "revoked",
    date: mode === "date" ? "2020-01-01" : driver.tripDate,
    vehicle: mode === "vehicle" ? "08" : "12",
    time: mode === "time" ? "21:15" : driver.departureTime || "22:30",
  });
  render();
}
function scanResultHTML(r) {
  return htmlTemplate("components/driver/scan-result-html.html");
}
function startDriverTrip() {
  if (!["assigned", "boarding"].includes(driver.stage) || !driver.boarded.length) return;
  driver.stage = "active";
  driver.startedAt = Date.now();
  driver.tripIncidents = driver.incidents.length;
  driver.stop = 0;
  saveDriver();
  navigate("driver-route");
  render();
}
function toggleDriverPause() {
  if (driver.stage === "active") driver.stage = "paused";
  else if (driver.stage === "paused") driver.stage = "active";
  else return;
  saveDriver();
  render();
}
function nextDriverStop() {
  if (driver.stage !== "active") return;
  if (driver.stop < 2) driver.stop++;
  else {
    driver.history.push({
      date: driver.tripDate,
      passengers: driver.boarded.length,
      minutes: Math.max(1, Math.round((Date.now() - driver.startedAt) / 60000)),
      incidents: driver.incidents.length - (driver.tripIncidents || 0),
    });
    driver.stage = "arrival";
    driver.routeId = null;
    driver.departureTime = null;
    driver.boarded = [];
    driver.stop = 0;
    saveDriver();
    navigate("driver-history");
    render();
    return;
  }
  saveDriver();
  render();
}
function resetDriver() {
  driver.onboarded = false;
  driver.profile = {};
  driver.photos = {};
  onboardDraft = {};
  onboardStep = 1;
  uploadPreviews = {};
  saveDriver();
  render();
}
function googleDirections() {
  return (
    "https://www.google.com/maps/dir/?api=1&origin=18.4738,-69.9400&destination=18.527,-70.003&waypoints=" +
    encodeURIComponent("18.517,-69.968|18.522,-69.984") +
    "&travelmode=driving"
  );
}
function maneuverText(step) {
  const m = step.maneuver;
  const directions = {
    right: "a la derecha",
    left: "a la izquierda",
    "slight right": "ligeramente a la derecha",
    "slight left": "ligeramente a la izquierda",
    straight: "recto",
    "sharp right": "cerrado a la derecha",
    "sharp left": "cerrado a la izquierda",
    uturn: "en U",
  };
  let text =
    m.type === "depart"
      ? "Inicia el recorrido"
      : m.type === "arrive"
        ? "Llegas a la parada"
        : m.type === "roundabout"
          ? `Toma la salida ${m.exit || ""} de la rotonda`
          : m.type === "turn"
            ? "Gira " + (directions[m.modifier] || "")
            : m.type === "merge"
              ? "Incorpórate " + (directions[m.modifier] || "")
              : "Continúa " + (directions[m.modifier] || "");
  return text + (step.name ? " por " + step.name : "");
}
async function loadDriverMap() {
  const node = document.getElementById("driverMap");
  if (!node || typeof L === "undefined") return;
  driverMap = L.map(node).setView([18.5, -69.965], 13);
  L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
    maxZoom: 19,
    attribution: "© OpenStreetMap",
  }).addTo(driverMap);
  const points = [[18.4738, -69.94], ...stops.map((s) => s.point)];
  points.forEach((p, i) =>
    L.marker(p, {
      icon: L.divIcon({
        className: "route-marker",
        html: htmlTemplate("components/driver/load-driver-map.html"),
        iconSize: [32, 32],
      }),
    })
      .addTo(driverMap)
      .bindPopup(i === 0 ? "Salida · TP Churchill" : stops[i - 1].name),
  );
  driverMap.fitBounds(points);
  routeAbort = new AbortController();
  try {
    const res = await fetch(
      "https://router.project-osrm.org/route/v1/driving/" +
        points.map((p) => p[1] + "," + p[0]).join(";") +
        "?overview=full&geometries=geojson&steps=true",
      { signal: routeAbort.signal },
    );
    const data = await res.json();
    if (data.code !== "Ok" || !data.routes?.length) throw Error("route");
    if (page !== "driver-route") return;
    const route = data.routes[0];
    L.geoJSON(route.geometry, { style: { color: "#ef0054", weight: 6 } }).addTo(driverMap);
    const instructions = route.legs.flatMap((l, i) => l.steps.map((s) => ({ s, i })));
    document.getElementById("routeInstructions").innerHTML = htmlTemplate(
      "components/driver/load-driver-map-part-02.html",
    );
  } catch (e) {
    if (e.name === "AbortError") return;
    const target = document.getElementById("routeInstructions");
    if (target) target.innerHTML = htmlTemplate("components/driver/load-driver-map-part-04.html");
  }
}
function bindDriver() {
  document
    .querySelectorAll("[data-photo]")
    .forEach((i) => i.addEventListener("change", () => setPhoto(i)));
  document.getElementById("driverOnboarding")?.addEventListener("submit", (e) => {
    e.preventDefault();
    stashOnboarding();
    if (onboardStep === 1 && (!driver.photos.id || !driver.photos.license)) {
      document.getElementById("onboardError").textContent =
        "Agrega las fotos de tu cédula y licencia para continuar.";
      return;
    }
    if (onboardStep === 1 && !/^\d{11}$/.test(onboardDraft.cedula.replace(/\D/g, ""))) {
      document.getElementById("onboardError").textContent = "La cédula debe tener 11 dígitos.";
      return;
    }
    if (onboardStep === 2 && !driver.photos.plate) {
      document.getElementById("onboardError").textContent =
        "Agrega una foto de la placa para continuar.";
      return;
    }
    if (onboardStep < 3) {
      onboardStep++;
      render();
    } else {
      driver.profile = { ...onboardDraft };
      driver.onboarded = true;
      saveDriver();
      navigate("driver-home");
      render();
    }
  });
  document.getElementById("incidentForm")?.addEventListener("submit", (e) => {
    e.preventDefault();
    const f = new FormData(e.target);
    driver.incidents.push({
      type: f.get("type"),
      detail: f.get("detail"),
      date: today(),
      photo: !!driver.photos.incident,
    });
    delete driver.photos.incident;
    delete uploadPreviews.incident;
    saveDriver();
    render();
    toast("Incidencia registrada en la demostración.");
  });
  if (page === "driver-route" && !["arrival", "waiting"].includes(driver.stage)) loadDriverMap();
}
function stopScanner() {
  if (scanFrame) cancelAnimationFrame(scanFrame);
  scanFrame = null;
  scanStream?.getTracks().forEach((t) => t.stop());
  scanStream = null;
  document.getElementById("scannerModal")?.remove();
}
function openScanner(kind) {
  scannerKind = kind;
  stopScanner();
  const modal = document.createElement("div");
  modal.id = "scannerModal";
  modal.className = "scanner-overlay";
  modal.innerHTML = htmlTemplate("components/driver/open-scanner.html");
  document.body.append(modal);
  modal.querySelector("button").focus();
  modal.addEventListener("keydown", (e) => {
    if (e.key === "Escape") stopScanner();
    if (e.key === "Tab") {
      const items = [...modal.querySelectorAll("button,input,label.btn")].filter((x) => !x.hidden);
      const first = items[0],
        last = items.at(-1);
      if (e.shiftKey && document.activeElement === first) {
        e.preventDefault();
        last.focus();
      } else if (!e.shiftKey && document.activeElement === last) {
        e.preventDefault();
        first.focus();
      }
    }
  });
  document.getElementById("scanImage").addEventListener("change", async (e) => {
    const f = e.target.files?.[0];
    if (!f) return;
    try {
      const bitmap = await createImageBitmap(f);
      const canvas = document.createElement("canvas");
      canvas.width = bitmap.width;
      canvas.height = bitmap.height;
      const ctx = canvas.getContext("2d");
      ctx.drawImage(bitmap, 0, 0);
      const pixels = ctx.getImageData(0, 0, canvas.width, canvas.height);
      const qr = jsQR(pixels.data, pixels.width, pixels.height);
      bitmap.close();
      if (qr) handleQRCode(qr.data);
      else
        document.getElementById("cameraStatus").textContent =
          "No encontramos un QR en esta imagen.";
    } catch {
      document.getElementById("cameraStatus").textContent =
        "No pudimos leer la imagen. Prueba otra foto.";
    }
  });
}
async function startScannerCamera() {
  if (scanStream) return;
  try {
    if (!navigator.mediaDevices?.getUserMedia) throw Error("camera");
    const stream = await navigator.mediaDevices.getUserMedia({
      video: { facingMode: { ideal: "environment" } },
      audio: false,
    });
    if (!document.getElementById("scanVideo")) {
      stream.getTracks().forEach((t) => t.stop());
      return;
    }
    scanStream = stream;
    const video = document.getElementById("scanVideo");
    video.srcObject = stream;
    await video.play();
    const canvas = document.createElement("canvas");
    const ctx = canvas.getContext("2d", { willReadFrequently: true });
    function frame() {
      if (!scanStream || !document.getElementById("scanVideo")) return;
      if (video.readyState >= 2) {
        canvas.width = video.videoWidth;
        canvas.height = video.videoHeight;
        ctx.drawImage(video, 0, 0);
        const image = ctx.getImageData(0, 0, canvas.width, canvas.height);
        const qr = typeof jsQR === "function" ? jsQR(image.data, image.width, image.height) : null;
        if (qr) {
          scanStream.getTracks().forEach((t) => t.stop());
          scanStream = null;
          handleQRCode(qr.data);
          return;
        }
      }
      scanFrame = requestAnimationFrame(frame);
    }
    frame();
  } catch {
    const status = document.getElementById("cameraStatus");
    if (status)
      status.textContent =
        "No pudimos abrir la cámara. Permite su acceso o selecciona una imagen de QR.";
  }
}
function handleQRCode(raw) {
  let data;
  try {
    data = JSON.parse(raw);
  } catch {
    data = null;
  }
  if (scannerKind === "zone") {
    const route = resolveDemoRoute(data);
    if (route) {
      stopScanner();
      joinZone(route.routeId);
      return;
    }
    const target = document.getElementById("cameraResult");
    if (target)
      target.innerHTML = scanResultHTML({
        kind: "error",
        title: "QR de ruta no válido",
        text: "Escanea el QR de la ruta, fecha y salida indicada por tu proveedor.",
      });
    return;
  }
  let t = null;
  if (data?.type === "MOVE-DEMO" && state.ticket?.id === data.ticket) {
    t = { ...state.ticket, authorized: !!ticketValid() };
  }
  const result = boardTicket(t);
  document.getElementById("cameraResult").innerHTML = scanResultHTML(result);
  if (result.kind === "success") {
    stopScanner();
    render();
  }
}
window.addEventListener("pagehide", stopScanner);
document.addEventListener("visibilitychange", () => {
  if (document.hidden) stopScanner();
});
render();

function loginDemo() {
  if (access.role === "driver" && !driver.onboarded) {
    driver.onboarded = true;
    driver.profile = {
      name: "José Ramírez",
      cedula: "00000000000",
      brand: "Hyundai",
      model: "County",
      year: "2023",
      plate: "I078542",
    };
    driver.photos = { id: { name: "Demo" }, license: { name: "Demo" }, plate: { name: "Demo" } };
    onboardDraft = { ...driver.profile };
  }
  access.logged = true;
  saveDriver();
  navigate(access.role === "driver" ? "driver-home" : "home");
  render();
}

let vehiclePhotoDraft = null,
  vehiclePhotoPreview = "";
function vehicleInput(key, label, type = "text", extra = "") {
  return htmlTemplate("components/driver/vehicle-input.html");
}
driverViews["driver-vehicle"] = () => htmlTemplate("screens/driver/vehicle.html");
function cancelVehicleEdit() {
  vehiclePhotoDraft = null;
  if (vehiclePhotoPreview) URL.revokeObjectURL(vehiclePhotoPreview);
  vehiclePhotoPreview = "";
  navigate("driver-profile");
  render();
}
function saveVehicleProfile(data, photo) {
  const updated = {};
  for (const key of ["brand", "model", "year", "plate"]) {
    updated[key] = String(data[key] || "").trim();
    if (!updated[key]) throw Error("Completa todos los campos del vehículo.");
  }
  const year = Number(updated.year);
  if (!Number.isInteger(year) || year < 1980 || year > new Date().getFullYear() + 1)
    throw Error("Introduce un año de vehículo válido.");
  if (updated.plate.length > 12) throw Error("La placa debe tener como máximo 12 caracteres.");
  updated.plate = updated.plate.toUpperCase();
  driver.profile = { ...driver.profile, ...updated };
  if (photo) driver.photos.plate = photo;
  onboardDraft = { ...driver.profile };
  saveDriver();
}
const bindBeforeVehicle = bindDriver;
bindDriver = function () {
  bindBeforeVehicle();
  document.querySelectorAll("[data-vehicle-photo]").forEach((input) =>
    input.addEventListener("change", () => {
      const file = input.files?.[0];
      if (!file) return;
      if (!file.type.startsWith("image/") || file.size > 12 * 1024 * 1024) {
        toast("Selecciona una imagen de menos de 12 MB.");
        return;
      }
      if (vehiclePhotoPreview) URL.revokeObjectURL(vehiclePhotoPreview);
      vehiclePhotoPreview = URL.createObjectURL(file);
      vehiclePhotoDraft = { name: file.name };
      document.getElementById("vehiclePhotoPreview").innerHTML = htmlTemplate(
        "components/driver/fragment-part-03.html",
      );
    }),
  );
  document.getElementById("vehicleEditForm")?.addEventListener("submit", (e) => {
    e.preventDefault();
    try {
      saveVehicleProfile(Object.fromEntries(new FormData(e.target)), vehiclePhotoDraft);
      cancelVehicleEdit();
      toast("Datos del vehículo actualizados.");
    } catch (error) {
      document.getElementById("vehicleEditError").textContent = error.message;
    }
  });
};
render();
