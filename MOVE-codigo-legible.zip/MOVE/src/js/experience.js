// Session-aware account controls and the corporate supervisor workspace.
access.corporateRole = access.corporateRole === "supervisor" ? "supervisor" : "agent";
let interfaceLanguage = "es";
try {
  interfaceLanguage = localStorage.getItem("move-language") === "en" ? "en" : "es";
} catch {}
let accountOpen = false,
  approvalFilter = "pending";
const supervisedEmployees = ["104601", "104612", "104630"];
let supervisorRequests = [
  {
    id: "EX-001",
    employee: "104601",
    name: "Ana Pérez",
    reason: "Horas extra",
    date: today(),
    time: "23:00",
    detail: "Mi jornada se extendió por cierre de operación.",
    status: "pending",
  },
  {
    id: "EX-002",
    employee: "104612",
    name: "Carlos Mejía",
    reason: "Capacitación",
    date: today(),
    time: "22:30",
    detail: "Capacitación del equipo después del turno.",
    status: "pending",
  },
  {
    id: "EX-003",
    employee: "104630",
    name: "Laura Díaz",
    reason: "Cambio de turno",
    date: today(),
    time: "22:30",
    detail: "Cambio de horario solicitado por la operación.",
    status: "approved",
  },
];
try {
  const saved = JSON.parse(sessionStorage.getItem("move-supervisor-requests") || "null");
  if (Array.isArray(saved)) supervisorRequests = saved;
} catch {}
const isSupervisor = () =>
  access.logged && access.role === "corporate" && access.corporateRole === "supervisor";
function selectCorporateRole(role) {
  if (page !== "login" || !["agent", "supervisor"].includes(role)) return;
  access.corporateRole = role;
  saveDriver();
  render();
}
const originalLoginView = loginView;
loginView = function () {
  let html = originalLoginView();
  if (access.role === "corporate") {
    html = html.replace(
      '<label class="label" for="loginId">',
      htmlTemplate("components/supervisor/fragment.html"),
    );
    if (access.corporateRole === "supervisor")
      html = html.replace("Entrar como corporativo demo", "Entrar como supervisor demo");
  }
  return html;
};
function approvalView() {
  const scoped = supervisorRequests.filter((r) => supervisedEmployees.includes(r.employee));
  const visible = scoped.filter((r) => approvalFilter === "all" || r.status === approvalFilter);
  return htmlTemplate("screens/supervisor/team.html");
}
function setApprovalFilter(filter) {
  if (!["pending", "approved", "rejected", "all"].includes(filter)) return;
  approvalFilter = filter;
  render();
}
function decideException(id, status) {
  if (!isSupervisor() || !["approved", "rejected"].includes(status)) return false;
  const r = supervisorRequests.find((r) => r.id === id && supervisedEmployees.includes(r.employee));
  if (!r || r.status !== "pending") return false;
  const comment = (document.getElementById("decision-" + id)?.value || "").trim();
  if (status === "rejected" && !comment) {
    const err = document.getElementById("decision-error-" + id);
    if (err) err.textContent = t("Escribe el motivo del rechazo.");
    return false;
  }
  r.status = status;
  r.comment = comment;
  r.decidedAt = new Date().toISOString();
  try {
    sessionStorage.setItem("move-supervisor-requests", JSON.stringify(supervisorRequests));
  } catch {}
  render();
  toast(t(status === "approved" ? "Excepción aprobada." : "Excepción rechazada."));
  return true;
}
function accountMenuHTML() {
  return htmlTemplate("screens/shared/account-menu.html");
}
function setAccountTheme(value) {
  if (!["light", "dark"].includes(value)) return;
  if (theme !== value) toggleTheme();
  render();
}
function toggleAccountMenu() {
  accountOpen = !accountOpen;
  updateAccountControls();
  translateInterface();
  if (accountOpen) document.querySelector("#accountMenu button")?.focus();
}
function updateAccountControls() {
  document.getElementById("accountMenu")?.remove();
  document.getElementById("guestPreferences")?.remove();
  const avatar = document.querySelector("header .avatar");
  const guest =
    page === "login" || page === "register" || page === "driver-onboarding" || !access.logged;
  avatar.hidden = guest || page === "landing";
  avatar.style.display = guest ? "none" : "";
  avatar.onclick = toggleAccountMenu;
  avatar.setAttribute("aria-label", t("Opciones de cuenta"));
  avatar.setAttribute("aria-expanded", String(accountOpen && !guest));
  avatar.setAttribute("aria-haspopup", "dialog");
  document.getElementById("themeToggle")?.remove();
  document.body.classList.toggle(
    "registration-screen",
    page === "driver-onboarding" || page === "register",
  );
  document.querySelector(".side-bottom").hidden = guest;
  if (page === "login" || page === "register" || page === "driver-onboarding") {
    accountOpen = false;
    const guestMenu = document.createElement("div");
    guestMenu.id = "guestPreferences";
    guestMenu.className = "guest-preferences";
    guestMenu.innerHTML = htmlTemplate("components/supervisor/update-account-controls.html");
    document.querySelector(".header-right").append(guestMenu);
  } else if (accountOpen && access.logged && page !== "landing") {
    document.querySelector(".header-right").insertAdjacentHTML("beforeend", accountMenuHTML());
  }
}
const renderBeforeExperience = render;
render = function () {
  const requested = location.hash.slice(1);
  if (requested === "approvals" && isSupervisor()) {
    page = "approvals";
    document.body.classList.remove("landing-screen", "login-screen");
    document.getElementById("landingMenu")?.remove();
    syncHeader();
    drawWorkspace(approvalView(), [
      ...navs.slice(0, 3),
      ["approvals", "shield", "Mi equipo"],
      ...navs.slice(3),
    ]);
    document
      .querySelector(".side-nav")
      .insertAdjacentHTML("beforeend", htmlTemplate("components/supervisor/fragment-part-02.html"));
  } else {
    renderBeforeExperience();
    if (isSupervisor() && page !== "login" && page !== "landing") {
      const links = [...navs.slice(0, 3), ["approvals", "shield", "Mi equipo"], ...navs.slice(3)]
        .map(([p, i, l]) => htmlTemplate("components/supervisor/fragment-part-03.html"))
        .join("");
      document.querySelector(".bottom-nav").innerHTML = links;
      document.querySelector(".side-nav").innerHTML =
        links + htmlTemplate("components/supervisor/fragment-part-04.html");
    }
  }
  updateAccountControls();
  translateInterface();
};
document.addEventListener("click", (e) => {
  if (accountOpen && !e.target.closest(".header-right")) {
    accountOpen = false;
    updateAccountControls();
    translateInterface();
  }
});
document.addEventListener("keydown", (e) => {
  if (e.key === "Escape" && accountOpen) {
    accountOpen = false;
    updateAccountControls();
    document.querySelector("header .avatar").focus();
  }
});
render();
