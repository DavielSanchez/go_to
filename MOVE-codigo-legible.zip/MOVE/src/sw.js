const CACHE = "move-ui-v14";
const ASSETS = [
  "./",
  "./index.html",
  "./style.css?v=14",
  "./app.js?v=14",
  "./tp-logo.svg",
  "./vendor/leaflet.js",
  "./vendor/leaflet.css",
  "./vendor/qrcode.js",
  "./vendor/jsqr.js",
  "./driver.js?v=14",
  "./landing.js?v=14",
  "./landing.css?v=14",
  "./transport.webp",
  "./i18n.js?v=14",
  "./experience.js?v=14",
  "./experience.css?v=14",
  "./registration.js?v=14",
  "./polish.js?v=14",
  "./polish.css?v=14",
  "./personalization.js?v=14",
  "./personalization.css?v=14",
  "./alorica-logo.png",
  "./trueshore-logo.svg",
  "./concentrix-logo.webp",
  "./icon.svg",
  "./manifest.webmanifest",
];
self.addEventListener("install", (e) => {
  e.waitUntil(caches.open(CACHE).then((c) => c.addAll(ASSETS)));
  self.skipWaiting();
});
self.addEventListener("activate", (e) => {
  e.waitUntil(
    caches
      .keys()
      .then((keys) => Promise.all(keys.filter((k) => k !== CACHE).map((k) => caches.delete(k)))),
  );
  self.clients.claim();
});
self.addEventListener("fetch", (e) => {
  if (e.request.method !== "GET" || new URL(e.request.url).origin !== self.location.origin) return;
  e.respondWith(
    fetch(e.request)
      .then((r) => {
        if (r.ok) {
          const copy = r.clone();
          caches.open(CACHE).then((c) => c.put(e.request, copy));
        }
        return r;
      })
      .catch(() => caches.match(e.request)),
  );
});
